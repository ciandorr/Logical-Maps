# Classicism [Draft] — complete map

Topic `classicism`. Generated 2026-09-18T18:05:39+00:00.

68 principles, 125 proved results, 2 recorded conjectures, 19 models.

This file is self-contained. Every principle statement, every proof, every model construction and every derived verdict in the database is reproduced below. `README.md` gives the semantics and the rules for adding to it; `OPEN-QUESTIONS.md` lists what is not settled.


Principles and connections over Bacon and Dorr’s Classicism.

## 1. Framework


The fixed base is Bacon and Dorr’s Classicism (C) in their relational type system. Types are generated from e and t by forming sigma→tau when tau is not e; every non-base type therefore ends in t. C is the smallest H-theory containing Logical Equivalence (Classicism, §1.3): lambda abstractions of H-equivalent formulas are identical. Preserve the theoremhood side condition; equivalence under optional assumptions does not satisfy it.

**Notation.** All type schemata use the fixed relational type system. Types and application associate to the right; curried application is parenthesized. Box applies after closing object variables. See Background for definitions and schema side conditions.

**Fixed background assumptions.** None. Every principle below is optional and must be assumed explicitly.

**Named package `c5` (C5).** □ND (`necessary-distinctness-necessary-r`).

**Named package `c5-atomic` (C5 + Atomicity).** □ND (`necessary-distinctness-necessary-r`), Atomicity (`atomicity-r`).

**Named package `extensional` (Extensionalism).** Extensionality (`extensionality-r`).

**Named package `pure-maximalist` (Pure Maximalist Classicism).** Distinctness (pure) (`distinctness-schema-r`).

## 2. Background and standing conventions

*Reproduced from `topics/classicism/background.md`.*

The fixed background is **Classicism (C)** of Andrew Bacon and Cian Dorr,
using the paper's **relational type system**. Its base types are $e$ and $t$.
Form $\sigma\tau$ from admitted types only when $\tau\ne e$: every
function type ends in $t$. Thus $et$, $tt$ and $(et)t$ are admitted,
while $ee$ and $(ee)t$ are not. Individuals of type $e$ remain available
as arguments and quantified objects.

Use the definition in *Classicism*, §1.3: C is the smallest H-theory containing
Logical Equivalence. This schema identifies $\lambda$-abstractions of formulas
equivalent in H. Its theoremhood side condition must be preserved when
reasoning from additional assumptions.

This is the type system called R in *Classicism*, §1.1. It is fixed
throughout the map, so principle names omit a type-system suffix.

### Notation

Types associate to the right: $\sigma\tau\rho$ means
$\sigma\to(\tau\to\rho)$. Application also associates to the right:
$fgx=f(gx)$. Write $(fx)y$ for curried application. A dot separates a
binder from its scope. The abbreviation $X[\bar x]$ means explicitly
left-nested application to the displayed tuple; it is $X$ for an empty tuple.

Put $\Box p:=(p=\top)$ and $\Diamond p:=(p\ne\bot)$.
At a relational type $\tau$, Boolean operations are defined pointwise.
The order is algebraic entailment,
$X\le_\tau Y$ iff $Y=X\lor_\tau Y$, rather than material implication.
At $t$ this is equivalent to $\Box(X\to Y)$; at a relation type it is
equivalent to the necessary universal closure of the pointwise implication.

The lattice predicates used in the principles are:

$$
\begin{aligned}
\operatorname{LB}_\tau(y,X)&:=\forall z^\tau\, .\,Xz\to y\le_\tau z,\\
\operatorname{GLB}_\tau(y,X)&:=\forall z^\tau\, .\,
  \operatorname{LB}_\tau(z,X)\leftrightarrow z\le_\tau y,\\
\operatorname{Atom}_\tau(y)&:=\forall z^\tau\, .\,
  (z\le_\tau y\land z\ne y)\leftrightarrow z\le_\tau\neg_\tau z.
\end{aligned}
$$

Thus an atom is non-bottom and has no non-bottom strict lower bound.
These are the definitions of *Classicism*, §2.2, pp. 23–24.

For a relation $Y$ with a finite argument tuple, including the empty tuple,
the comprehension predicates are:

$$
\begin{aligned}
\operatorname{Persistent}(Y)&:=Y\le\lambda\bar x\, .\,\Box Y[\bar x],\\
\operatorname{Inextensible}(Y)&:=\Box\forall X\, .\,
  (\forall\bar x\, .\,Y[\bar x]\to\Box X[\bar x])\to Y\le X,\\
\operatorname{Rigid}(Y)&:=\operatorname{Persistent}(Y)\land
  \operatorname{Inextensible}(Y).
\end{aligned}
$$

This is the rigidity convention of §2.3, p. 28. Gallin's alternative
convention has its own principle. For $U^{\sigma\tau t}$, set

$$
\begin{aligned}
\operatorname{Serial}(U)&:=\forall x^\sigma\, .\,\exists y^\tau\, .\,(Ux)y,\\
\operatorname{Functional}(U)&:=\forall x^\sigma\, .\,\exists y^\tau\, .\,
  (Ux)y\land\forall z^\tau\, .\,(Ux)z\to y=z.
\end{aligned}
$$

Functional includes totality. Relational Choice selects a functional
subrelation; Functional Choice selects an operation. An operation's output
type must differ from $e$. Relational Choice also covers relations with
individual outputs, since such a relation still ends in $t$.

Strong Possibility uses the distinctness-preserving modality of §2.6, p. 42:

$$
\Box_{\ne}p:=\exists q\, .\,q\land\Box(\Diamond q\to p),
\qquad \Diamond_{\ne}p:=\neg\Box_{\ne}\neg p.
$$

### Conventions

**Type scope.** Type parameters range over the fixed type system above.
A relational type is any admitted type other than $e$, including $t$.
Display restrictions such as $\tau\ne e$ when the schema needs them;
the overall type range is implicit.

**Schema scope.** $\forall^{\mathrm{Ty}}$ is metalinguistic. It ranges over
simple types, outside the object-language sentence, and does not add a
quantifier to C. A principle may have one outer universal or existential
block of type parameters; quantifier alternation requires a separate
extension of the convention. The present import has positive schemata and
selected individual instances. Finite tuples and formula schemata retain
their stated metalinguistic side conditions.

**Modal scope.** A boxed schema means that each admitted, fully closed
object-language instance is necessary. Close its object variables before
boxing it. Type ranges and formula side conditions remain outside the box.
C5 abbreviates C plus boxed ND at all types. It is an optional preset,
not part of the fixed background. A proof under an optional premise cannot
be necessitated unless that premise is discharged or supplied necessarily.

**Negation.** Failure of a type schema means failure of at least one of
its admitted instances, not failure at every type. For example,
$\neg\forall^{\mathrm{Ty}}\sigma\, .\,A_\sigma$ means
$\exists^{\mathrm{Ty}}\sigma\, .\,\neg A_\sigma$.
A necessarily false instance,
$\exists^{\mathrm{Ty}}\sigma\, .\,\Box\neg A_\sigma$, is stronger and
different from failure of the boxed schema. Negated principle nodes are
not added by this positive import. Incompatibilities conclude False;
model `violates` entries record schema failure.

**Pure and signature schemata.** In Distinctness and Possibility,
$C$ denotes the fixed background logic. Its theoremhood and consistency
side conditions are retained literally.
Fix a signature $\Sigma$ containing the displayed nonlogical constants and
fundamentality predicates $\operatorname{Fun}_\sigma$, all of admitted types,
with arbitrarily many distinct constants of each type. No nonlogical
axioms about them are standing assumptions. “Pure” excludes these symbols.
For Fundamental Possibility, $\operatorname{Fun}(\bar x)$ conjoins each
$\operatorname{Fun}_{\sigma_i}(x_i)$ and the distinctness of each pair of
same-typed entries. “Distinct constants” means distinct symbols, not an
assumed inequality between their denotations.

**Evidence.** References use the 87-page draft of *Classicism* dated
16 May 2023. Models cite the construction and evaluation point directly.
The source models now use exactly the map's type system. Their listed
properties provide countermodel evidence at the stated evaluation point.
The singleton-root coalesced model still awaits an expansion to the fixed
nonlogical signature; its record explains this separate obligation.
Two results reported without proofs in the draft retain pending verification status.
No record claims an independent human check or Lean verification.

## 3. Principles

### Extensionality

#### Extensionality — `extensionality-r`


At each relational type, coextensive relations are identical; include the nullary propositional case.

Formal: `$\forall^{\mathrm{Ty}}\bar\sigma\, .\,\forall X Y\, .\,(\forall\bar z\, .\,X[\bar z]\leftrightarrow Y[\bar z])\to X=Y$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.4, pp. 15–16.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.4, pp. 15–16

#### Fregean Axiom — `fregean-axiom`


Materially equivalent propositions are identical.

Formal: `$\forall p q\, .\,(p\leftrightarrow q)\to p=q$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.4, pp. 15–16.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.4, pp. 15–16

#### Functionality — `functionality-r`


Operations with the same value on every argument are identical. The output type is relational.

Formal: `$\forall^{\mathrm{Ty}}\sigma,\tau,\ \tau\ne e\, .\,\forall X Y^{\sigma\tau}\, .\,(\forall z^\sigma\, .\,Xz=Yz)\to X=Y$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.4, pp. 15–16, especially n. 18.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.4, pp. 15–16, especially n. 18

#### □Extensionality — `necessary-extensionality-r`


Every closed instance of Extensionality is necessary. Box the entire object-variable closure; retain the same type range and other schema side conditions.

Formal: `$\Box\phi\quad\text{for each closed instance }\phi\text{ of Extensionality}$`

Notes. Box each fully closed instance of Extensionality. Type quantifiers and formula side conditions remain outside the box.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34

#### □Fregean Axiom — `necessary-fregean-axiom`


Every closed instance of Fregean Axiom is necessary. Box the entire object-variable closure; retain the same type range and other schema side conditions.

Formal: `$\Box\phi\quad\text{for each closed instance }\phi\text{ of Fregean Axiom}$`

Notes. Box each fully closed instance of Fregean Axiom. Type quantifiers and formula side conditions remain outside the box.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34

#### □Functionality — `necessary-functionality-r`


Every closed instance of Functionality is necessary. Box the entire object-variable closure; retain the same type range and other schema side conditions.

Formal: `$\Box\phi\quad\text{for each closed instance }\phi\text{ of Functionality}$`

Notes. Box each fully closed instance of Functionality. Type quantifiers and formula side conditions remain outside the box.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34

### Modal principles

#### BF — `barcan-r`


The Barcan Formula at every type. The predicate formulation closes the formula schema using lambda abstraction.

Formal: `$\forall^{\mathrm{Ty}}\sigma\, .\,\forall X^{\sigma t}\, .\,(\forall x^\sigma\, .\,\Box Xx)\to\Box(\forall x^\sigma\, .\,Xx)$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.1, pp. 20–21.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.1, pp. 20–21
- **Origin: A Functional Calculus of First Order Based on Strict Implication.** Barcan, Ruth C. (1946). A Functional Calculus of First Order Based on Strict Implication. Journal of Symbolic Logic 11, 1–16. Bibliography and attribution as given in Classicism. — pp. 1–16; attribution in Classicism p. 21

#### ND — `distinctness-necessary-r`


Distinct things of any type are necessarily distinct.

Formal: `$\forall^{\mathrm{Ty}}\sigma\, .\,\forall x y^\sigma\, .\,x\ne y\to\Box(x\ne y)$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, pp. 21–22.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, pp. 21–22

#### B — `modal-b`


Every true proposition is necessarily possible.

Formal: `$\forall p\, .\,p\to\Box\Diamond p$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.2, p. 22.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.2, p. 22

#### 5 — `modal-five`


Every possible proposition is necessarily possible.

Formal: `$\forall p\, .\,\Diamond p\to\Box\Diamond p$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.2, p. 22.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.2, p. 22

#### □BF — `necessary-barcan-r`


Every closed instance of BF is necessary. Box the entire object-variable closure; retain the same type range and other schema side conditions.

Formal: `$\Box\phi\quad\text{for each closed instance }\phi\text{ of BF}$`

Notes. Box each fully closed instance of BF. Type quantifiers and formula side conditions remain outside the box.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34

#### □ND — `necessary-distinctness-necessary-r`


Every closed instance of ND is necessary. Box the entire object-variable closure; retain the same type range and other schema side conditions.

Formal: `$\Box\phi\quad\text{for each closed instance }\phi\text{ of ND}$`

Notes. Box each fully closed instance of ND. Type quantifiers and formula side conditions remain outside the box.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34

#### □B — `necessary-modal-b`


Every closed instance of B is necessary. Box the entire object-variable closure; retain the same type range and other schema side conditions.

Formal: `$\Box\phi\quad\text{for each closed instance }\phi\text{ of B}$`

Notes. Box each fully closed instance of B. Type quantifiers and formula side conditions remain outside the box.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34

#### □5 — `necessary-modal-five`


Every closed instance of 5 is necessary. Box the entire object-variable closure; retain the same type range and other schema side conditions.

Formal: `$\Box\phi\quad\text{for each closed instance }\phi\text{ of 5}$`

Notes. Box each fully closed instance of 5. Type quantifiers and formula side conditions remain outside the box.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34

#### □Tractarianism — `necessary-tractarianism-r`


Every closed instance of Tractarianism is necessary. Box the entire object-variable closure; retain the same type range and other schema side conditions.

Formal: `$\Box\phi\quad\text{for each closed instance }\phi\text{ of Tractarianism}$`

Notes. Box each fully closed instance of Tractarianism. Type quantifiers and formula side conditions remain outside the box.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34

#### Tractarianism — `tractarianism-r`


A proposition entailing every instance of a property entails its universal generalization.

Formal: `$\forall^{\mathrm{Ty}}\sigma\, .\,\forall p^t X^{\sigma t}\, .\,(\forall x^\sigma\, .\,p\le Xx)\to p\le(\forall x^\sigma\, .\,Xx)$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.1 and n. 27, pp. 20–21.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.1 and n. 27, pp. 20–21

### Boolean structure

#### Actual Profile — `actual-profile-r`


Every finite tuple has a true relational profile entailing every relation it instantiates; the tuple may be empty.

Formal: `$\forall^{\mathrm{Ty}}\bar\sigma\, .\,\forall\bar x\, .\,\exists Y\, .\,Y[\bar x]\land\forall Z\, .\,Z[\bar x]\to Y\le Z$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, n. 31, p. 25.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.2, n. 31, p. 25

#### Actuality — `actuality`


There is a true proposition that entails every true proposition.

Formal: `$\exists p\, .\,p\land\forall q\, .\,q\to p\le q$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, p. 25.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.2, p. 25

#### Atomicity — `atomicity-r`


Every non-bottom entity of each relational type has an atom below it.

Formal: `$\forall^{\mathrm{Ty}}\tau\ne e\, .\,\forall x^\tau\, .\,x\le_\tau\neg_\tau x\lor\exists y^\tau\, .\,\operatorname{Atom}_\tau(y)\land y\le_\tau x$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, p. 24.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.2, p. 24

#### Boolean Completeness — `boolean-completeness-r`


Every property of entities of a relational type has a greatest lower bound in that type.

Formal: `$\forall^{\mathrm{Ty}}\tau\ne e\, .\,\forall X^{\tau t}\, .\,\exists y^\tau\, .\,\operatorname{GLB}_\tau(y,X)$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, pp. 23–24.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.2, pp. 23–24

#### □Actuality — `necessary-actuality`


Every closed instance of Actuality is necessary. Box the entire object-variable closure; retain the same type range and other schema side conditions.

Formal: `$\Box\phi\quad\text{for each closed instance }\phi\text{ of Actuality}$`

Notes. Box each fully closed instance of Actuality. Type quantifiers and formula side conditions remain outside the box.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34

#### □Atomicity — `necessary-atomicity-r`


Every closed instance of Atomicity is necessary. Box the entire object-variable closure; retain the same type range and other schema side conditions.

Formal: `$\Box\phi\quad\text{for each closed instance }\phi\text{ of Atomicity}$`

Notes. Box each fully closed instance of Atomicity. Type quantifiers and formula side conditions remain outside the box.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34

#### □Boolean Completeness — `necessary-boolean-completeness-r`


Every closed instance of Boolean Completeness is necessary. Box the entire object-variable closure; retain the same type range and other schema side conditions.

Formal: `$\Box\phi\quad\text{for each closed instance }\phi\text{ of Boolean Completeness}$`

Notes. Box each fully closed instance of Boolean Completeness. Type quantifiers and formula side conditions remain outside the box.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34

### Comprehension

#### Gallin Extensional Comprehension — `gallin-extensional-comprehension-r`


Every relation is coextensive with one that is persistent and has a persistent pointwise negation. This is the source’s comparison with Gallin’s different rigidity convention.

Formal: `$\forall^{\mathrm{Ty}}\bar\sigma\, .\,\forall X\, .\,\exists Y\, .\,\operatorname{Persistent}(Y)\land\operatorname{Persistent}(\neg Y)\land(\forall\bar z\, .\,X[\bar z]\leftrightarrow Y[\bar z])$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, n. 37, p. 28.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, n. 37, p. 28
- **Origin: Intensional and Higher-Order Modal Logic.** Gallin, Daniel (1975). Intensional and Higher-Order Modal Logic: With Applications to Montague Semantics. North-Holland. Page 77, as cited in Classicism, n. 37. — p. 77, as described in Classicism n. 37

#### Inextensible Comprehension — `inextensible-comprehension-r`


Every relation, including a proposition, is coextensive with a inextensible one.

Formal: `$\forall^{\mathrm{Ty}}\bar\sigma\, .\,\forall X\, .\,\exists Y\, .\,\operatorname{Inextensible}(Y)\land(\forall\bar z\, .\,X[\bar z]\leftrightarrow Y[\bar z])$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, n. 38, p. 29.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, n. 38, p. 29

#### □Rigid Comprehension — `necessary-rigid-comprehension-r`


Every closed instance of Rigid Comprehension is necessary. Box the entire object-variable closure; retain the same type range and other schema side conditions.

Formal: `$\Box\phi\quad\text{for each closed instance }\phi\text{ of Rigid Comprehension}$`

Notes. Box each fully closed instance of Rigid Comprehension. Type quantifiers and formula side conditions remain outside the box.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34

#### Persistent Comprehension — `persistent-comprehension-r`


Every relation, including a proposition, is coextensive with a persistent one.

Formal: `$\forall^{\mathrm{Ty}}\bar\sigma\, .\,\forall X\, .\,\exists Y\, .\,\operatorname{Persistent}(Y)\land(\forall\bar z\, .\,X[\bar z]\leftrightarrow Y[\bar z])$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, n. 38, p. 29.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, n. 38, p. 29

#### Rigid Comprehension — `rigid-comprehension-r`


Every relation, including a proposition, is coextensive with a rigid one.

Formal: `$\forall^{\mathrm{Ty}}\bar\sigma\, .\,\forall X\, .\,\exists Y\, .\,\operatorname{Rigid}(Y)\land(\forall\bar z\, .\,X[\bar z]\leftrightarrow Y[\bar z])$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, pp. 28–30.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, pp. 28–30

### Choice and Plenitude

#### Functional Choice — `functional-choice-r`


Every serial binary relation admits a selecting operation. Its output type is relational, as required by the type system.

Formal: `$\forall^{\mathrm{Ty}}\sigma,\tau,\ \tau\ne e\, .\,\forall U^{\sigma\tau t}\, .\,\operatorname{Serial}(U)\to\exists X^{\sigma\tau}\, .\,\forall y\, .\,(Uy)(Xy)$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, pp. 31–33.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, pp. 31–33

#### □Plenitude — `necessary-plenitude-r`


Every closed instance of Plenitude is necessary. Box the entire object-variable closure; retain the same type range and other schema side conditions.

Formal: `$\Box\phi\quad\text{for each closed instance }\phi\text{ of Plenitude}$`

Notes. Box each fully closed instance of Plenitude. Type quantifiers and formula side conditions remain outside the box.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34

#### Plenitude — `plenitude-r`


Every total single-valued binary relation is represented by an operation. Its output type is relational, as required by the type system.

Formal: `$\forall^{\mathrm{Ty}}\sigma,\tau,\ \tau\ne e\, .\,\forall U^{\sigma\tau t}\, .\,\operatorname{Functional}(U)\to\exists X^{\sigma\tau}\, .\,\forall y\, .\,(Uy)(Xy)$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, pp. 31–33.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, pp. 31–33

#### Relational Choice — `relational-choice-r`


Every serial binary relation has a functional subrelation.

Formal: `$\forall^{\mathrm{Ty}}\sigma,\tau\, .\,\forall U^{\sigma\tau t}\, .\,\operatorname{Serial}(U)\to\exists S^{\sigma\tau t}\, .\,\operatorname{Functional}(S)\land(\forall x y\, .\,(Sx)y\to(Ux)y)$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, pp. 31–33.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, pp. 31–33

### Distinguished instances

#### Atomicity (type t) — `atomicity-t`


Atomicity (type t) in the displayed closed propositional formulation.

Formal: `$\forall p\, .\,p\le\neg p\lor\exists q\, .\,\operatorname{Atom}_t(q)\land q\le p$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, p. 24.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.2, p. 24

#### Atomlessness — `atomlessness`


Atomlessness in the displayed closed propositional formulation.

Formal: `$\forall p\, .\,\Diamond p\to\exists q\, .\,\Diamond q\land q\le p\land q\ne p$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 76.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Appendix D, p. 76

#### BF (type t) — `barcan-t`


BF (type t) in the displayed closed propositional formulation.

Formal: `$\forall X^{tt}\, .\,(\forall p\, .\,\Box Xp)\to\Box(\forall p\, .\,Xp)$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §3.5, p. 59

#### Boolean Completeness (type t) — `boolean-completeness-t`


Boolean Completeness (type t) in the displayed closed propositional formulation.

Formal: `$\forall X^{tt}\, .\,\exists p\, .\,\operatorname{GLB}_t(p,X)$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, pp. 23–26; Appendix D, n. 92, p. 74.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.2, pp. 23–26; Appendix D, n. 92, p. 74

#### ND (type t) — `distinctness-necessary-t`


ND (type t) in the displayed closed propositional formulation.

Formal: `$\forall p q\, .\,p\ne q\to\Box(p\ne q)$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.2, p. 22.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.2, p. 22

#### Infinity (type e) — `infinity-e`


There are arbitrarily many pairwise distinct entities of this fixed type; one sentence for each positive integer n.

Formal: `$\exists x_1^e\cdots x_n^e\, .\,\bigwedge_{i<j}x_i\ne x_j\quad(n\ge1)$`

Notes. Schema-level reading of the source’s informal infinity claim; no choice-dependent equivalence with Dedekind infinity is assumed.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, n. 47, p. 32.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, n. 47, p. 32

#### Infinity (type t) — `infinity-t`


There are arbitrarily many pairwise distinct entities of this fixed type; one sentence for each positive integer n.

Formal: `$\exists x_1^t\cdots x_n^t\, .\,\bigwedge_{i<j}x_i\ne x_j\quad(n\ge1)$`

Notes. Schema-level reading of the source’s informal infinity claim; no choice-dependent equivalence with Dedekind infinity is assumed.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, n. 47, p. 32.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, n. 47, p. 32

#### □BF (type t) — `necessary-barcan-t`


Every closed instance of BF (type t) is necessary. Box the entire object-variable closure; retain the same type range and other schema side conditions.

Formal: `$\Box\phi\quad\text{for each closed instance }\phi\text{ of BF (type t)}$`

Notes. Box each fully closed instance of BF (type t). Type quantifiers and formula side conditions remain outside the box.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34

#### □ND (type t) — `necessary-distinctness-necessary-t`


Every closed instance of ND (type t) is necessary. Box the entire object-variable closure; retain the same type range and other schema side conditions.

Formal: `$\Box\phi\quad\text{for each closed instance }\phi\text{ of ND (type t)}$`

Notes. Box each fully closed instance of ND (type t). Type quantifiers and formula side conditions remain outside the box.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, pp. 21–23; §§2.2–2.3, pp. 25–34

### Possibility and pure schemata

#### All individuals fundamental — `all-individuals-fundamental`


Every individual is fundamental.

Formal: `$\forall x^e\, .\,\operatorname{Fun}_e(x)$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, n. 60, p. 41.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.6, n. 60, p. 41

#### Converse Witnessed Possibility — `converse-witnessed-possibility-r`


The converse of Witnessed Possibility, with precisely the same formula, type and constant side conditions.

Formal: `$\Diamond P[\bar c/\bar x]\to(\exists\bar x\, .\,P)$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, n. 57, p. 38.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, n. 57, p. 38

#### Distinctness-preserving collapse — `distinctness-preserving-collapse`


Every truth is necessary under the distinctness-preserving modality.

Formal: `$\forall p\, .\,p\to\Box_{\ne}p$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix E, p. 83.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Appendix E, p. 83

#### Distinctness (pure) — `distinctness-schema-r`


Every closed pure identity not provable in C is false. The non-theorem condition is metalinguistic.

Formal: `$A\ne B\quad(A=B\text{ closed and pure; }C\nvdash A=B)$`

Notes. The reference theory in the side condition is the fixed background C.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.4, pp. 35–36.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.4, pp. 35–36

#### Distinctness (signature Σ) — `distinctness-signature-r`


The Distinctness schema for the fixed nonlogical signature Sigma.

Formal: `$A\ne B\quad(A=B\text{ closed in }\mathcal L(\Sigma);\ C(\Sigma)\nvdash A=B)$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, pp. 37–39.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, pp. 37–39

#### Fundamental Possibility — `fundamental-possibility-r`


For a pure-formula P consistent with C with free variables among x, every tuple of fundamental entities, pairwise distinct within each type, possibly satisfies P. Include the empty tuple.

Formal: `$\forall\bar x\, .\,\operatorname{Fun}(\bar x)\to\Diamond P$`

Notes. The predicates Fun_sigma are nonlogical and receive no standing axioms.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, pp. 39–40.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, pp. 39–40

#### Logical Necessity — `logical-necessity-r`


The Logical Necessity schema: necessity at distinct matching constants is equivalent to universal truth of the pure-formula. Preserve the side conditions of Witnessed Possibility.

Formal: `$\Box P[\bar c/\bar x]\leftrightarrow(\forall\bar x\, .\,P)$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, n. 57, p. 38.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, n. 57, p. 38
- **Origin: Logical Combinatorialism.** Bacon, Andrew (2020). Logical Combinatorialism. Philosophical Review 129(4), 537–589. As cited in Classicism, §§2.5 and 3.5. — Logical Necessity, cited in Classicism n. 57

#### No Pure Contingency — `no-pure-contingency-r`


Each closed sentence of the pure language, if true, is necessary. This is a sentence schema, not a quantifier over propositions.

Formal: `$P\to\Box P\quad(P\text{ a closed pure }\text{sentence})$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, p. 27.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.2, p. 27
- **Origin: Logical Foundations of Philosophy.** Goodsell, Zachary, and Juhani Yli-Vakkuri. Logical Foundations of Philosophy. Unpublished work cited in Classicism, p. 27; no proof from that work is imported here. — Logical Foundations of Philosophy; cited in Classicism p. 27

#### Possibility+ — `possibility-plus-r`


The strengthened Possibility schema for pure C-consistent formulas whose only free variables are the displayed individual variables; include the empty tuple.

Formal: `$\forall x_1^e\cdots x_n^e\, .\,(\bigwedge_{i<j}x_i\ne x_j)\to\Diamond P$`

Notes. The consistency and purity restrictions are inherited from Possibility, which the surrounding text says this strengthens; the shortened display on p. 41 must not be read as admitting contradictory P.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 41 and n. 60; Appendix E, p. 83.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.6, p. 41 and n. 60; Appendix E, p. 83

#### Possibility (pure) — `possibility-schema-r`


Every closed pure sentence consistent with C is possible.

Formal: `$\Diamond P\quad(P\text{ closed and pure; }C+P\text{ consistent})$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.4, pp. 35–36.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.4, pp. 35–36

#### Possibility (signature Σ) — `possibility-signature-r`


The Possibility schema for the fixed nonlogical signature Sigma.

Formal: `$\Diamond P\quad(P\text{ closed in }\mathcal L(\Sigma);\ C(\Sigma)+P\text{ consistent})$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, pp. 37–39.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, pp. 37–39

#### B for pure sentences — `pure-b-r`


The B instance for every closed sentence in the pure language.

Formal: `$P\to\Box\Diamond P\quad(P\text{ a closed pure }\text{sentence})$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, n. 81, p. 59.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §3.5, n. 81, p. 59

#### Separated Structure — `separated-structure-r`


For each typed nonlogical constant c and closed same-typed terms F,G not containing c, equality after application to c implies equality of F and G.

Formal: `$Fc=Gc\to F=G$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, pp. 38–39.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, pp. 38–39
- **Origin: Logical Combinatorialism.** Bacon, Andrew (2020). Logical Combinatorialism. Philosophical Review 129(4), 537–589. As cited in Classicism, §§2.5 and 3.5. — §4, cited in Classicism p. 38

#### Strong Possibility (pure) — `strong-possibility-r`


Each closed pure sentence consistent with Maximalist Classicism is possible under the distinctness-preserving modality.

Formal: `$\Diamond_{\ne}P\quad(P\text{ closed and pure; }\operatorname{Max}(C)+P\text{ consistent})$`

Notes. The paper leaves consistency open. The definition of Box_ne and its dual is given in Background.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 42.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.6, p. 42

#### Strong Possibility (signature Σ) — `strong-possibility-signature-r`


Every closed sentence of the fixed signature consistent with its Maximalist Classicism is possible under the distinctness-preserving modality.

Formal: `$\Diamond_{\ne}P\quad(P\in\mathcal L(\Sigma)\text{ closed; }\operatorname{Max}(C(\Sigma))+P\text{ consistent})$`

Notes. This keeps the signature-expanded reference theory throughout the consistency side condition. The separate pure-language variant uses Max(C). No conservativity between these two maximalizations is assumed. Consistency of Strong Possibility is left open in the source.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, pp. 37–39; §2.6, p. 42.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, pp. 37–39; §2.6, p. 42

#### Witnessed Possibility — `witnessed-possibility-r`


For pure-formulas P with free variables among a finite tuple x, and distinct matching nonlogical constants c, a witness to P entails that P at those constants is possible.

Formal: `$(\exists\bar x\, .\,P)\to\Diamond P[\bar c/\bar x]$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, n. 57, p. 38.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, n. 57, p. 38
- **Origin: Logical Combinatorialism.** Bacon, Andrew (2020). Logical Combinatorialism. Philosophical Review 129(4), 537–589. As cited in Classicism, §§2.5 and 3.5. — Logical Necessity discussion, as cited in Classicism n. 57

### Background consequences

#### Broad Necessitism — `broad-necessitism-r`


Every entity of an type is necessarily identical to something.

Formal: `$\forall^{\mathrm{Ty}}\sigma\, .\,\forall x^\sigma\, .\,\Box(\exists y^\sigma\, .\,y=x)$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, p. 19.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, p. 19

#### CBF — `converse-barcan-r`


The Converse Barcan Formula at every type.

Formal: `$\forall^{\mathrm{Ty}}\sigma\, .\,\forall X^{\sigma t}\, .\,\Box(\forall x^\sigma\, .\,Xx)\to(\forall x^\sigma\, .\,\Box Xx)$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, p. 19.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, p. 19

#### Existence — `existence-r`


Every type is inhabited.

Formal: `$\forall^{\mathrm{Ty}}\sigma\, .\,\exists x^\sigma\, .\,x=x$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.1, p. 7.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.1, p. 7

#### NI — `identity-necessary-r`


Identity is necessary at every type.

Formal: `$\forall^{\mathrm{Ty}}\sigma\, .\,\forall x y^\sigma\, .\,x=y\to\Box(x=y)$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, p. 22.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, p. 22

#### Intensionality — `intensionality-r`


Necessarily coextensive relations are identical.

Formal: `$\forall^{\mathrm{Ty}}\bar\sigma\, .\,\forall X Y\, .\,\Box(\forall\bar z\, .\,X[\bar z]\leftrightarrow Y[\bar z])\to X=Y$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, pp. 17–18.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, pp. 17–18

#### 4 — `modal-four`


Necessary propositions are necessarily necessary.

Formal: `$\forall p\, .\,\Box p\to\Box\Box p$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, p. 17.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, p. 17

#### K — `modal-k`


Necessity distributes over implication.

Formal: `$\forall p q\, .\,\Box(p\to q)\to(\Box p\to\Box q)$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, p. 16.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, p. 16

#### T — `modal-t`


Necessary propositions are true.

Formal: `$\forall p\, .\,\Box p\to p$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, p. 16.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, p. 16

#### Modalized Fregean Axiom — `modalized-fregean`


Necessarily equivalent propositions are identical.

Formal: `$\forall p q\, .\,\Box(p\leftrightarrow q)\to p=q$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, p. 18.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, p. 18

#### Modalized Functionality — `modalized-functionality-r`


Necessarily co-functional operations of function types are identical.

Formal: `$\forall^{\mathrm{Ty}}\sigma,\tau,\ \tau\ne e\, .\,\forall X Y^{\sigma\tau}\, .\,\Box(\forall z^\sigma\, .\,Xz=Yz)\to X=Y$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, p. 18 and n. 22.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, p. 18 and n. 22

#### Ordinary Comprehension — `ordinary-comprehension-r`


Every well-typed formula P with distinguished variables y defines a coextensive relation; X is fresh, and any other free object variables are universally closed.

Formal: `$\exists X\, .\,\forall\bar y\, .\,X[\bar y]\leftrightarrow P$`

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, p. 27.

- **Formulation: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, p. 27

## 4. Results

Each result is a Horn clause: the conjunction of its premises entails its conclusion, relative to the framework above. Premises are sufficient; minimality is not claimed.

### 4.1 Proved

#### Actual Profile ⇒ Actuality — `actual-profile-r-implies-actuality`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Actual Profile (`actual-profile-r`)

Conclusion: Actuality (`actuality`)

Proof.

Specialize Actual Profile to the empty tuple, so its relation variables have type t.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, n. 31, p. 25.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.2, n. 31, p. 25

Record: `topics/classicism/results/actual-profile-r-implies-actuality.yaml`.

#### Actuality ⇒ Actual Profile — `actuality-implies-actual-profile-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Actuality (`actuality`)

Conclusion: Actual Profile (`actual-profile-r`)

Proof.

Let w witness Actuality. At a tuple $\bar x$, use the relation $\lambda\bar y\, .\,w\land\bigwedge_i x_i=y_i$. It holds at $\bar x$. If $Z[\bar x]$ is true, w entails that truth; NI preserves the tuple identities, so the proposed relation entails Z. This gives the required profile for every type tuple.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, n. 31, p. 25.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.2, n. 31, p. 25

Record: `topics/classicism/results/actuality-implies-actual-profile-r.yaml`.

#### Actuality ⇒ Inextensible Comprehension — `actuality-implies-inextensible-comprehension-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Actuality (`actuality`)

Conclusion: Inextensible Comprehension (`inextensible-comprehension-r`)

Proof.

If w is the actual atom, the source takes $\lambda\bar y\, .\,w\land X[\bar y]$. Since w is true, this is coextensive with X. Its restriction to the actual complete profile makes the universal necessary consequences of its instances entailed by it, giving the source’s inextensibility condition.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, n. 38, p. 29.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, n. 38, p. 29

Record: `topics/classicism/results/actuality-implies-inextensible-comprehension-r.yaml`.

#### Actuality ⇒ Persistent Comprehension — `actuality-implies-persistent-comprehension-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Actuality (`actuality`)

Conclusion: Persistent Comprehension (`persistent-comprehension-r`)

Proof.

If w witnesses Actuality, then $\lambda\bar y\, .\,w\le X[\bar y]$ is coextensive with X. Entailments are necessary when true, so this relation is persistent.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, n. 38, p. 29.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, n. 38, p. 29

Record: `topics/classicism/results/actuality-implies-persistent-comprehension-r.yaml`.

#### Atomicity ∧ BF ⇒ □Actuality — `atomicity-and-bf-imply-necessary-actuality`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Atomicity (`atomicity-r`)
- BF (`barcan-r`)

Conclusion: □Actuality (`necessary-actuality`)

Proof.

If w is a propositional atom, it entails every conditional $q\to(w\le q)$: either it entails q, in which case the entailment is necessary, or it entails its negation. Tractarianism, equivalent to BF, combines these into the universal claim that w entails every truth. Hence w entails Actuality. Atomicity says every possible proposition has an atom below it, so no possible proposition can entail the negation of Actuality. Thus that negation is $\bot$ and Actuality is necessary.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.7, p. 26.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.7, p. 26

Record: `topics/classicism/results/atomicity-and-bf-imply-necessary-actuality.yaml`.

#### Atomicity ⇒ Atomicity (type t) — `atomicity-r-implies-atomicity-t`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Atomicity (`atomicity-r`)

Conclusion: Atomicity (type t) (`atomicity-t`)

Proof.

Specialize the source’s universal type block to type t.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, p. 24.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.2, p. 24

Record: `topics/classicism/results/atomicity-r-implies-atomicity-t.yaml`.

#### Atomicity (type t) ∧ BF ⇒ □Actuality — `atomicity-t-and-bf-imply-necessary-actuality`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Atomicity (type t) (`atomicity-t`)
- BF (`barcan-r`)

Conclusion: □Actuality (`necessary-actuality`)

Proof.

If w is a propositional atom, it entails every conditional $q\to(w\le q)$: either it entails q, in which case the entailment is necessary, or it entails its negation. Tractarianism, equivalent to BF, combines these into the universal claim that w entails every truth. Hence w entails Actuality. Atomicity says every possible proposition has an atom below it, so no possible proposition can entail the negation of Actuality. Thus that negation is $\bot$ and Actuality is necessary.

Notes. The displayed proof uses only the type-t Atomicity instance. BF retains its stated type-schematic scope; no weakening of its range is inferred.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.7 and proof, p. 26.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.7 and proof, p. 26

Record: `topics/classicism/results/atomicity-t-and-bf-imply-necessary-actuality.yaml`.

#### Atomicity (type t) ∧ Atomlessness ⇒ False (⊥) — `atomicity-t-incompatible-with-atomlessness`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Atomicity (type t) (`atomicity-t`)
- Atomlessness (`atomlessness`)

Conclusion: False (⊥) (`false`)

Proof.

Atomicity applied to $\top$ supplies a non-bottom atom. Atomlessness supplies a strictly smaller non-bottom proposition below that atom, contradicting its defining minimality.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, p. 24; Appendix D, p. 76.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.2, p. 24; Appendix D, p. 76

Record: `topics/classicism/results/atomicity-t-incompatible-with-atomlessness.yaml`.

#### BF ⇒ BF (type t) — `barcan-r-implies-barcan-t`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- BF (`barcan-r`)

Conclusion: BF (type t) (`barcan-t`)

Proof.

Specialize the source’s universal type block to type t.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.1, pp. 20–21.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.1, pp. 20–21

Record: `topics/classicism/results/barcan-r-implies-barcan-t.yaml`.

#### BF ⇒ Functionality — `barcan-r-implies-functionality-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- BF (`barcan-r`)

Conclusion: Functionality (`functionality-r`)

Proof.

Pointwise identity gives necessary pointwise agreement under all remaining applications, by Leibniz’s Law and NI. Apply the required BF instances to move the object quantifiers under the box. Intensionality then identifies X and Y. All function types here are admitted by the fixed type system.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.1, n. 27, pp. 20–21.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.1, n. 27, pp. 20–21

Record: `topics/classicism/results/barcan-r-implies-functionality-r.yaml`.

#### Boolean Completeness ⇒ Boolean Completeness (type t) — `boolean-completeness-r-implies-boolean-completeness-t`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Boolean Completeness (`boolean-completeness-r`)

Conclusion: Boolean Completeness (type t) (`boolean-completeness-t`)

Proof.

Specialize the source’s universal type block to type t.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, pp. 23–24.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.2, pp. 23–24

Record: `topics/classicism/results/boolean-completeness-r-implies-boolean-completeness-t.yaml`.

#### □ND ∧ Actuality ⇒ Boolean Completeness — `c5-and-actuality-imply-completeness`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □ND (`necessary-distinctness-necessary-r`)
- Actuality (`actuality`)

Conclusion: Boolean Completeness (`boolean-completeness-r`)

Proof.

Proposition 2.10 gives Rigid Comprehension from C5 and Actuality. Proposition 2.8 then gives Boolean Completeness. Both proofs are separately transcribed in this map.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.5, pp. 25, 29–30.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.5, pp. 25, 29–30

Record: `topics/classicism/results/c5-and-actuality-imply-completeness.yaml`.

#### □ND ∧ Actuality ⇒ Rigid Comprehension — `c5-and-actuality-imply-rigid-comprehension`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □ND (`necessary-distinctness-necessary-r`)
- Actuality (`actuality`)

Conclusion: Rigid Comprehension (`rigid-comprehension-r`)

Proof.

Actuality supplies persistent coextensions as in note 38. In C5, persistence implies inextensibility. To see this, suppose Y is persistent and each Y-instance necessarily satisfies X. B makes a failure of Y necessarily incompatible with necessary Y; by persistence this gives necessary non-Y. Therefore each argument necessarily satisfies the conditional from Y to X, and BF combines these into entailment. Boxed ND makes the reasoning available throughout the modal range, as required by Inextensible. The persistent coextension is consequently rigid.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.10, pp. 29–30 and n. 41.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.10, pp. 29–30 and n. 41

Record: `topics/classicism/results/c5-and-actuality-imply-rigid-comprehension.yaml`.

#### □ND ∧ Atomicity ⇒ □Atomicity — `c5-and-atomicity-imply-necessary-atomicity`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □ND (`necessary-distinctness-necessary-r`)
- Atomicity (`atomicity-r`)

Conclusion: □Atomicity (`necessary-atomicity-r`)

Proof.

The premises give boxed Actuality by Proposition 2.7. Axiom 4 supplies boxed C5 instances and doubly boxed Actuality. Necessitate the closed, finite-premise implication used for each target instance in Proposition 2.6 and apply K. This gives each boxed Atomicity instance.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.6, pp. 25–26; concluding equivalences, p. 33.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.6, pp. 25–26; concluding equivalences, p. 33

Record: `topics/classicism/results/c5-and-atomicity-imply-necessary-atomicity.yaml`.

#### □ND ∧ Atomicity ⇒ □Boolean Completeness — `c5-and-atomicity-imply-necessary-completeness`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □ND (`necessary-distinctness-necessary-r`)
- Atomicity (`atomicity-r`)

Conclusion: □Boolean Completeness (`necessary-boolean-completeness-r`)

Proof.

C5 gives BF, so Proposition 2.7 gives boxed Actuality. C5 is itself necessary by 4. Apply the necessitated, closed instance proofs of Proposition 2.5 inside this box to obtain every boxed instance of Boolean Completeness.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.6, pp. 25–26; Proposition 2.5.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.6, pp. 25–26; Proposition 2.5

Record: `topics/classicism/results/c5-and-atomicity-imply-necessary-completeness.yaml`.

#### □ND ∧ Atomicity ⇒ □Plenitude — `c5-and-atomicity-imply-necessary-plenitude`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □ND (`necessary-distinctness-necessary-r`)
- Atomicity (`atomicity-r`)

Conclusion: □Plenitude (`necessary-plenitude-r`)

Proof.

Proposition 2.6 gives boxed Boolean Completeness. C5 is itself necessary by 4, so the necessitated instance proofs of Proposition 2.14 yield boxed Plenitude.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, concluding equivalences, p. 33.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, concluding equivalences, p. 33

Record: `topics/classicism/results/c5-and-atomicity-imply-necessary-plenitude.yaml`.

#### □ND ∧ Atomicity ⇒ □Rigid Comprehension — `c5-and-atomicity-imply-necessary-rigid-comprehension`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □ND (`necessary-distinctness-necessary-r`)
- Atomicity (`atomicity-r`)

Conclusion: □Rigid Comprehension (`necessary-rigid-comprehension-r`)

Proof.

C5 and Atomicity give boxed Actuality by Proposition 2.7. C5 is necessary by 4. Use the necessitated instance proofs of Proposition 2.10 to get boxed Rigid Comprehension.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, concluding equivalences, p. 33.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, concluding equivalences, p. 33

Record: `topics/classicism/results/c5-and-atomicity-imply-necessary-rigid-comprehension.yaml`.

#### □ND ∧ Boolean Completeness ⇒ Actuality — `c5-and-completeness-imply-actuality`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □ND (`necessary-distinctness-necessary-r`)
- Boolean Completeness (`boolean-completeness-r`)

Conclusion: Actuality (`actuality`)

Proof.

Under C5, Proposition 2.14 obtains Plenitude from Boolean Completeness. Proposition 2.15 then supplies a true atom. The underlying proofs are recorded separately.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.5, pp. 25, 32–33.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.5, pp. 25, 32–33

Record: `topics/classicism/results/c5-and-completeness-imply-actuality.yaml`.

#### □ND ∧ Boolean Completeness ⇒ Plenitude — `c5-and-completeness-imply-plenitude`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □ND (`necessary-distinctness-necessary-r`)
- Boolean Completeness (`boolean-completeness-r`)

Conclusion: Plenitude (`plenitude-r`)

Proof.

For functional U with propositional output, take the least upper bound G of all operations X such that Xy entails the unique U-output at y. Fix a and its output p. The operation $\lambda x\, .\,x=a\land p$ lies below G, by ND, so p entails Ga. The operation $\lambda x\, .\,x\ne a\lor p$ is an upper bound of the same family: ND gives the pointwise comparison and BF promotes it to entailment. Therefore Ga entails p. Antisymmetry gives Ga=p. For relational outputs the argument is applied to their finite argument tuples as in the source; all output types are relational.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.14, pp. 32–33 and n. 48.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.14, pp. 32–33 and n. 48

Record: `topics/classicism/results/c5-and-completeness-imply-plenitude.yaml`.

#### □ND ∧ □Actuality ⇒ Atomicity — `c5-and-necessary-actuality-imply-atomicity`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □ND (`necessary-distinctness-necessary-r`)
- □Actuality (`necessary-actuality`)

Conclusion: Atomicity (`atomicity-r`)

Proof.

C5 supplies BF and ND throughout the relevant modal range. BF and ND imply that a possibly atomic entity is already atomic: move the tests of entailment or incompatibility outward with BF, then use ND to turn possible identities into identities. Given a non-bottom proposition, boxed Actuality supplies a possible actual atom compatible with it; BF brings that atom into the current domain, and its compatibility makes it lie below the proposition. At a relation type the same argument uses the possible true profile of an instance, pairing the actual atom with the tuple’s haecceity. BF imports its tuple and ND preserves its identities. This is the type-uniform direction of the proposition stated by the source.

Notes. The source sketches the propositional case; the relation-type clause explains the stated schema reading. No assertion is made about types ending in e.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.6, pp. 25–26.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.6, pp. 25–26

Record: `topics/classicism/results/c5-and-necessary-actuality-imply-atomicity.yaml`.

#### □ND ∧ □Boolean Completeness ⇒ Atomicity — `c5-and-necessary-completeness-imply-atomicity`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □ND (`necessary-distinctness-necessary-r`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)

Conclusion: Atomicity (`atomicity-r`)

Proof.

C5 remains available necessarily by 4. Necessitated instance proofs of Proposition 2.5 turn boxed Boolean Completeness into boxed Actuality. The other direction of Proposition 2.6 then gives Atomicity.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.6, pp. 25–26; Proposition 2.5.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.6, pp. 25–26; Proposition 2.5

Record: `topics/classicism/results/c5-and-necessary-completeness-imply-atomicity.yaml`.

#### ⊤ ⇒ Broad Necessitism — `classicism-implies-broad-necessitism-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- ⊤ (no premises)

Conclusion: Broad Necessitism (`broad-necessitism-r`)

Proof.

The theorem $\forall x\, .\,\exists y\, .\,y=x$ can be necessitated. Applying CBF yields $\forall x\, .\,\Box\exists y\, .\,y=x$.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, p. 19.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, p. 19

Record: `topics/classicism/results/classicism-implies-broad-necessitism-r.yaml`.

#### ⊤ ⇒ CBF — `classicism-implies-converse-barcan-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- ⊤ (no premises)

Conclusion: CBF (`converse-barcan-r`)

Proof.

Necessitate universal instantiation and use K to obtain $\Box\forall x\, .\,P\to\Box P$. Generalize x, preserving the side condition, to obtain CBF. The predicate version is supplied by lambda abstraction.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, p. 19.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, p. 19

Record: `topics/classicism/results/classicism-implies-converse-barcan-r.yaml`.

#### ⊤ ⇒ Existence — `classicism-implies-existence-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- ⊤ (no premises)

Conclusion: Existence (`existence-r`)

Proof.

Reflexivity gives y=y. Existential introduction yields exists x (x=x) at each admitted type; equivalently use the source’s beta and EG derivation on p. 7.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.1, p. 7.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.1, p. 7

Record: `topics/classicism/results/classicism-implies-existence-r.yaml`.

#### ⊤ ⇒ NI — `classicism-implies-identity-necessary-r`

Proved result; source **Necessity of identity (historical)**; produced by W. V. Quine (historical attribution in Classicism p. 22); recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- ⊤ (no premises)

Conclusion: NI (`identity-necessary-r`)

Proof.

Reflexivity is a theorem, so its necessitation gives $\Box(x=x)$. Leibniz’s Law substitutes y for the second x under the premise x=y, giving $\Box(x=y)$. Universally close the variables at each type.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, p. 22.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, p. 22

Record: `topics/classicism/results/classicism-implies-identity-necessary-r.yaml`.

#### ⊤ ⇒ Intensionality — `classicism-implies-intensionality-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- ⊤ (no premises)

Conclusion: Intensionality (`intensionality-r`)

Proof.

Logical Equivalence identifies the lambda abstractions of $X[\bar z]\land\forall\bar u\, .\,X[\bar u]\leftrightarrow Y[\bar u]$ and the analogous expression with Y in the first conjunct, with the quantified biconditional parenthesized as the second conjunct. If that biconditional is necessary, substitute its identity with $\top$ into the abstraction identity. Boolean identities and beta-eta conversion leave X=Y, exactly as on p. 17.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, pp. 17–18.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, pp. 17–18

Record: `topics/classicism/results/classicism-implies-intensionality-r.yaml`.

#### ⊤ ⇒ 4 — `classicism-implies-modal-four`

Proved result; source **The Broadest Necessity**; produced by Andrew Bacon (source credits the S4 result to Bacon 2018); recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- ⊤ (no premises)

Conclusion: 4 (`modal-four`)

Proof.

Apply NI to the identity $p=\top$. Its conclusion is $\Box(p=\top)$, which is $\Box\Box p$.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, p. 17.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, p. 17

Record: `topics/classicism/results/classicism-implies-modal-four.yaml`.

#### ⊤ ⇒ K — `classicism-implies-modal-k`

Proved result; source **The Broadest Necessity**; produced by Andrew Bacon (source credits the S4 result to Bacon 2018); recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- ⊤ (no premises)

Conclusion: K (`modal-k`)

Proof.

In the Boolean algebra of propositions, $\Box(p\to q)$ says that the implication is $\top$. Together with $p=\top$, substitution and the Boolean identities identify q with $\top$. This is K.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, p. 16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, p. 16

Record: `topics/classicism/results/classicism-implies-modal-k.yaml`.

#### ⊤ ⇒ T — `classicism-implies-modal-t`

Proved result; source **The Broadest Necessity**; produced by Andrew Bacon (source credits the S4 result to Bacon 2018); recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- ⊤ (no premises)

Conclusion: T (`modal-t`)

Proof.

If $p=\top$, identity elimination and truth of $\top$ give p.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, p. 16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, p. 16

Record: `topics/classicism/results/classicism-implies-modal-t.yaml`.

#### ⊤ ⇒ Modalized Fregean Axiom — `classicism-implies-modalized-fregean`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- ⊤ (no premises)

Conclusion: Modalized Fregean Axiom (`modalized-fregean`)

Proof.

Necessary equivalence identifies $(p\leftrightarrow q)$ with $\top$. The Boolean identities then identify p and q; this is the nullary Intensionality instance.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, p. 18.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, p. 18

Record: `topics/classicism/results/classicism-implies-modalized-fregean.yaml`.

#### ⊤ ⇒ Modalized Functionality — `classicism-implies-modalized-functionality-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- ⊤ (no premises)

Conclusion: Modalized Functionality (`modalized-functionality-r`)

Proof.

From boxed pointwise identity, identity elimination gives boxed agreement after applying every remaining argument of the relational output type. Quantification over those remaining arguments is inside the necessary logical implication. Intensionality and eta conversion identify the original operations; this is note 22, which relies on the output type ending in t.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, p. 18 and n. 22.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, p. 18 and n. 22

Record: `topics/classicism/results/classicism-implies-modalized-functionality-r.yaml`.

#### ⊤ ⇒ Ordinary Comprehension — `classicism-implies-ordinary-comprehension-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- ⊤ (no premises)

Conclusion: Ordinary Comprehension (`ordinary-comprehension-r`)

Proof.

The lambda term $\lambda\bar y\, .\,P$ is a witness; beta conversion makes its application equivalent to P at each tuple. Existential introduction supplies the comprehension instance.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, p. 27.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, p. 27

Record: `topics/classicism/results/classicism-implies-ordinary-comprehension-r.yaml`.

#### Converse Witnessed Possibility ⇒ No Pure Contingency — `converse-witnessed-possibility-r-implies-no-pure-contingency-r`

Proved result; source **Logical Combinatorialism**; produced by Andrew Bacon; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)

Conclusion: No Pure Contingency (`no-pure-contingency-r`)

Proof.

Take the empty variable tuple and use the schema on $\neg P$. Its instance $\Diamond\neg P\to\neg P$ contraposes to $P\to\Box P$.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, n. 57, p. 38.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, n. 57, p. 38
- **Origin: Logical Combinatorialism.** Bacon, Andrew (2020). Logical Combinatorialism. Philosophical Review 129(4), 537–589. As cited in Classicism, §§2.5 and 3.5. — Logical Necessity, as discussed in Classicism n. 57

Record: `topics/classicism/results/converse-witnessed-possibility-r-implies-no-pure-contingency-r.yaml`.

#### ND ⇒ ND (type t) — `distinctness-necessary-r-implies-distinctness-necessary-t`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- ND (`distinctness-necessary-r`)

Conclusion: ND (type t) (`distinctness-necessary-t`)

Proof.

Specialize the universal type schema ND to type t.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.2, p. 22.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.2, p. 22

Record: `topics/classicism/results/distinctness-necessary-r-implies-distinctness-necessary-t.yaml`.

#### ND (type t) ⇒ 5 — `distinctness-necessary-t-implies-modal-five`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- ND (type t) (`distinctness-necessary-t`)

Conclusion: 5 (`modal-five`)

Proof.

Apply propositional ND to the distinctness of $\neg p$ and $\top$. Using $\Diamond p\leftrightarrow\neg\Box\neg p$, its conclusion is $\Box\Diamond p$. Universally close p.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.2, p. 22.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.2, p. 22

Record: `topics/classicism/results/distinctness-necessary-t-implies-modal-five.yaml`.

#### Distinctness (pure) ⇒ Possibility (pure) — `distinctness-schema-r-implies-possibility-schema-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Distinctness (pure) (`distinctness-schema-r`)

Conclusion: Possibility (pure) (`possibility-schema-r`)

Proof.

If P is consistent with the reference C theory, the closed identity $\neg P=\top$ is not one of its theorems. Distinctness therefore gives $\neg P\ne\top$, equivalently $\Diamond P$. Preserve the chosen pure or Sigma-expanded signature.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.4, pp. 35–36; §2.5, p. 37.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.4, pp. 35–36; §2.5, p. 37

Record: `topics/classicism/results/distinctness-schema-r-implies-possibility-schema-r.yaml`.

#### Distinctness (signature Σ) ⇒ Distinctness (pure) — `distinctness-signature-r-implies-distinctness-schema-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Distinctness (signature Σ) (`distinctness-signature-r`)

Conclusion: Distinctness (pure) (`distinctness-schema-r`)

Proof.

The pure closed identities are among the Sigma-language identities. Restrict the signature schema to these instances; adjoining uninterpreted constants does not change pure theoremhood in the reference source theory.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, pp. 38–39.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, pp. 38–39

Record: `topics/classicism/results/distinctness-signature-r-implies-distinctness-schema-r.yaml`.

#### Distinctness (signature Σ) ⇒ Possibility (signature Σ) — `distinctness-signature-r-implies-possibility-signature-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Distinctness (signature Σ) (`distinctness-signature-r`)

Conclusion: Possibility (signature Σ) (`possibility-signature-r`)

Proof.

If P is consistent with the reference C theory, the closed identity $\neg P=\top$ is not one of its theorems. Distinctness therefore gives $\neg P\ne\top$, equivalently $\Diamond P$. Preserve the chosen pure or Sigma-expanded signature.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.4, pp. 35–36; §2.5, p. 37.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.4, pp. 35–36; §2.5, p. 37

Record: `topics/classicism/results/distinctness-signature-r-implies-possibility-signature-r.yaml`.

#### Distinctness (signature Σ) ⇒ Separated Structure — `distinctness-signature-r-implies-separated-structure-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Distinctness (signature Σ) (`distinctness-signature-r`)

Conclusion: Separated Structure (`separated-structure-r`)

Proof.

Fix the allowed c,F,G. If Fc=Gc is a theorem of the reference C theory, uniform substitution for the fresh c followed by its zeta rule yields F=G. Otherwise the signature Distinctness schema makes Fc=Gc false, so the conditional holds. The freshness condition on c is essential.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, p. 39.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, p. 39

Record: `topics/classicism/results/distinctness-signature-r-implies-separated-structure-r.yaml`.

#### Extensionality ⇒ Actuality — `extensionality-r-implies-actuality`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Extensionality (`extensionality-r`)

Conclusion: Actuality (`actuality`)

Proof.

Use $\top$ as the witness. Every true proposition is identical to $\top$ by the Fregean Axiom, so $\top$ entails every truth.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, p. 25.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.2, p. 25

Record: `topics/classicism/results/extensionality-r-implies-actuality.yaml`.

#### Extensionality ⇒ Atomicity — `extensionality-r-implies-atomicity-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Extensionality (`extensionality-r`)

Conclusion: Atomicity (`atomicity-r`)

Proof.

At type t, the Fregean Axiom leaves just $\bot,\top$ and $\top$ is an atom. At a relation type, each tuple’s haecceity $\lambda\bar z\, .\,\bigwedge_i z_i=y_i$ is an atom by Extensionality. A non-bottom relation has an instance, whose tuple-haecceity is below that relation.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, p. 24 and n. 30.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.2, p. 24 and n. 30

Record: `topics/classicism/results/extensionality-r-implies-atomicity-r.yaml`.

#### Extensionality ⇒ Boolean Completeness — `extensionality-r-implies-boolean-completeness-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Extensionality (`extensionality-r`)

Conclusion: Boolean Completeness (`boolean-completeness-r`)

Proof.

For a property X of relations, put $U=\lambda\bar z\, .\,\forall Z\, .\,XZ\to Z[\bar z]$. When XV holds, the Fregean Axiom makes XV necessary and the displayed universal sentence entails $V[\bar z]$; Extensionality gives $U\le V$. Conversely, any lower bound Y pointwise entails the displayed defining condition for U, so Extensionality gives $Y\le U$. Thus U is a GLB.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, p. 24 and n. 29.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.2, p. 24 and n. 29

Record: `topics/classicism/results/extensionality-r-implies-boolean-completeness-r.yaml`.

#### Extensionality ⇒ Fregean Axiom — `extensionality-r-implies-fregean-axiom`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Extensionality (`extensionality-r`)

Conclusion: Fregean Axiom (`fregean-axiom`)

Proof.

Take the nullary instance of Extensionality: the pointwise biconditional is simply p iff q.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.4, pp. 15–16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.4, pp. 15–16

Record: `topics/classicism/results/extensionality-r-implies-fregean-axiom.yaml`.

#### Extensionality ⇒ Functionality — `extensionality-r-implies-functionality-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Extensionality (`extensionality-r`)

Conclusion: Functionality (`functionality-r`)

Proof.

If $Xz=Yz$ for every z, application and identity elimination give agreement of $X[\bar z]$ and $Y[\bar z]$ on all remaining arguments. The output type ends in t, so Extensionality identifies X and Y.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.4, pp. 15–16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.4, pp. 15–16

Record: `topics/classicism/results/extensionality-r-implies-functionality-r.yaml`.

#### Extensionality ⇒ Plenitude — `extensionality-r-implies-plenitude-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Extensionality (`extensionality-r`)

Conclusion: Plenitude (`plenitude-r`)

Proof.

For a functional relation U with output type $\tau=\bar\sigma t$, take $X=\lambda x\bar y\, .\,\exists Z^\tau\, .\,(Ux)Z\land Z[\bar y]$. At each x, uniqueness of the U-output makes Xx coextensive with that output, and Extensionality identifies them. The formula therefore represents U.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, p. 31 and n. 45.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, p. 31 and n. 45

Record: `topics/classicism/results/extensionality-r-implies-plenitude-r.yaml`.

#### Extensionality ⇒ Rigid Comprehension — `extensionality-r-implies-rigid-comprehension-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Extensionality (`extensionality-r`)

Conclusion: Rigid Comprehension (`rigid-comprehension-r`)

Proof.

Under Extensionality and the Fregean Axiom, every truth is necessary and every relation is persistent and inextensible. The relation itself therefore witnesses its rigid coextension.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, p. 29.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, p. 29

Record: `topics/classicism/results/extensionality-r-implies-rigid-comprehension-r.yaml`.

#### Fregean Axiom ⇒ Extensionality — `fregean-axiom-implies-extensionality-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Fregean Axiom (`fregean-axiom`)

Conclusion: Extensionality (`extensionality-r`)

Proof.

The Fregean Axiom makes every true proposition identical to $\top$, hence necessary. Apply this to the sentence $\forall\bar z\, .\,X[\bar z]\leftrightarrow Y[\bar z]$ and then use the background Intensionality theorem at that relational type. Note 18 explicitly excludes the inference to Functionality at types ending in e.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.4, p. 16 and n. 18.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.4, p. 16 and n. 18

Record: `topics/classicism/results/fregean-axiom-implies-extensionality-r.yaml`.

#### Fregean Axiom ⇒ □ND — `fregean-axiom-implies-necessary-distinctness-necessary-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Fregean Axiom (`fregean-axiom`)

Conclusion: □ND (`necessary-distinctness-necessary-r`)

Proof.

The Fregean Axiom gives $p\to\Box p$ for every proposition p, by comparison with $\top$. Apply it to each distinctness claim, then universally close x,y to obtain ND at a chosen type. Apply the same Fregean Axiom to that whole true closed ND sentence. This yields boxed ND at each type.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.4, pp. 15–16; Figure 5, p. 23.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.4, pp. 15–16; Figure 5, p. 23

Record: `topics/classicism/results/fregean-axiom-implies-necessary-distinctness-necessary-r.yaml`.

#### Fregean Axiom ⇒ □Fregean Axiom — `fregean-axiom-implies-necessary-fregean-axiom`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Fregean Axiom (`fregean-axiom`)

Conclusion: □Fregean Axiom (`necessary-fregean-axiom`)

Proof.

Use the Fregean Axiom’s consequence $p\to\Box p$ on the proposition expressed by its own universal closure.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.4, pp. 15–16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.4, pp. 15–16

Record: `topics/classicism/results/fregean-axiom-implies-necessary-fregean-axiom.yaml`.

#### Fregean Axiom ⇒ No Pure Contingency — `fregean-axiom-implies-no-pure-contingency-r`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Fregean Axiom (`fregean-axiom`)

Conclusion: No Pure Contingency (`no-pure-contingency-r`)

Proof.

For each closed pure sentence P, if P is true it is materially equivalent to $\top$, hence identical to $\top$ by the Fregean Axiom. Thus $P\to\Box P$.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.4, pp. 15–16; §2.2, p. 27.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.4, pp. 15–16; §2.2, p. 27

Record: `topics/classicism/results/fregean-axiom-implies-no-pure-contingency-r.yaml`.

#### Fregean Axiom ∧ Infinity (type t) ⇒ False (⊥) — `fregean-incompatible-with-infinity-t`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Fregean Axiom (`fregean-axiom`)
- Infinity (type t) (`infinity-t`)

Conclusion: False (⊥) (`false`)

Proof.

The Fregean Axiom identifies every true proposition with $\top$ and every false one with $\bot$. Its propositional domain therefore has exactly two elements, contradicting the three-distinct-propositions instance of Infinity.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, n. 47, p. 32.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, n. 47, p. 32

Record: `topics/classicism/results/fregean-incompatible-with-infinity-t.yaml`.

#### Functional Choice ⇒ Plenitude — `functional-choice-r-implies-plenitude-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Functional Choice (`functional-choice-r`)

Conclusion: Plenitude (`plenitude-r`)

Proof.

A total single-valued relation is serial. Apply Functional Choice to obtain its representing operation.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, pp. 31–32.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, pp. 31–32

Record: `topics/classicism/results/functional-choice-r-implies-plenitude-r.yaml`.

#### Functional Choice ⇒ Relational Choice — `functional-choice-r-implies-relational-choice-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Functional Choice (`functional-choice-r`)

Conclusion: Relational Choice (`relational-choice-r`)

Proof.

Choose an operation X selecting from the serial relation U. Its graph, $\lambda x y\, .\,Xx=y$, is a functional subrelation of U. If the output type is e, first replace each output individual by its haecceity of type et. Functional Choice selects such a haecceity; equality with that selected haecceity defines a functional subrelation of the original relation. Haecceities are injective by identity elimination, so this covers the individual-output case without assuming a selecting operation into e.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, pp. 31–32.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, pp. 31–32

Record: `topics/classicism/results/functional-choice-r-implies-relational-choice-r.yaml`.

#### Functionality ⇒ Tractarianism — `functionality-r-implies-tractarianism-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Functionality (`functionality-r`)

Conclusion: Tractarianism (`tractarianism-r`)

Proof.

Assume $p\le Fx$ for every x. Functionality identifies $F$ with $\lambda x\, .\,Fx\lor p$. Distribution of the constant disjunct through the universal quantifier identifies $\forall x\, .\,Fx$ with $(\forall x\, .\,Fx)\lor p$, which is the required entailment.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.1, n. 27, pp. 20–21.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.1, n. 27, pp. 20–21

Record: `topics/classicism/results/functionality-r-implies-tractarianism-r.yaml`.

#### Fundamental Possibility ∧ All individuals fundamental ⇒ Possibility+ — `fundamental-possibility-and-fundamental-individuals-imply-possibility-plus`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Fundamental Possibility (`fundamental-possibility-r`)
- All individuals fundamental (`all-individuals-fundamental`)

Conclusion: Possibility+ (`possibility-plus-r`)

Proof.

Given a pairwise distinct tuple of individuals, the second premise makes every member fundamental. This supplies the full antecedent of the corresponding Fundamental Possibility instance, whose consequent is the required possibility.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, n. 60, p. 41.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.6, n. 60, p. 41

Record: `topics/classicism/results/fundamental-possibility-and-fundamental-individuals-imply-possibility-plus.yaml`.

#### Fundamental Possibility ⇒ Possibility (pure) — `fundamental-possibility-r-implies-possibility-schema-r`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Fundamental Possibility (`fundamental-possibility-r`)

Conclusion: Possibility (pure) (`possibility-schema-r`)

Proof.

Use the empty tuple of fundamental entities. Its empty conjunction of fundamentality and pairwise-distinctness conditions is true, and the remaining instances are exactly pure Possibility.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, pp. 39–40.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, pp. 39–40

Record: `topics/classicism/results/fundamental-possibility-r-implies-possibility-schema-r.yaml`.

#### Gallin Extensional Comprehension ∧ BF ⇒ Rigid Comprehension — `gallin-comprehension-and-bf-imply-rigid-comprehension`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- BF (`barcan-r`)

Conclusion: Rigid Comprehension (`rigid-comprehension-r`)

Proof.

The source states that, under BF, persistence of a relation and of its negation implies its inextensibility. Given pointwise necessary consequences on its instances, the persistent complement makes all non-instance cases necessary too; BF assembles the resulting pointwise necessary conditional into entailment. Use the Gallin-rigid coextension, which is then rigid in the source’s sense.

Notes. The source’s note states the predicate implication. This record applies it to the same comprehension witness; no converse is inferred.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, n. 37, p. 28.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, n. 37, p. 28

Record: `topics/classicism/results/gallin-comprehension-and-bf-imply-rigid-comprehension.yaml`.

#### Logical Necessity ⇒ No Pure Contingency — `logical-necessity-r-implies-no-pure-contingency-r`

Proved result; source **Logical Combinatorialism**; produced by Andrew Bacon; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Logical Necessity (`logical-necessity-r`)

Conclusion: No Pure Contingency (`no-pure-contingency-r`)

Proof.

Take the empty tuple in Logical Necessity; it states that a closed pure P is necessary iff true. Its right-to-left direction is No Pure Contingency.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, n. 57, p. 38.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, n. 57, p. 38
- **Origin: Logical Combinatorialism.** Bacon, Andrew (2020). Logical Combinatorialism. Philosophical Review 129(4), 537–589. As cited in Classicism, §§2.5 and 3.5. — Logical Necessity, as discussed in Classicism n. 57

Record: `topics/classicism/results/logical-necessity-r-implies-no-pure-contingency-r.yaml`.

#### Logical Necessity ⇒ Witnessed Possibility — `logical-necessity-r-implies-witnessed-possibility-r`

Proved result; source **Logical Combinatorialism**; produced by Andrew Bacon; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Logical Necessity (`logical-necessity-r`)

Conclusion: Witnessed Possibility (`witnessed-possibility-r`)

Proof.

Apply the biconditional to the negation of the pure formula. Contraposition and modal and quantifier duality yield Witnessed Possibility.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, n. 57, p. 38.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, n. 57, p. 38
- **Origin: Logical Combinatorialism.** Bacon, Andrew (2020). Logical Combinatorialism. Philosophical Review 129(4), 537–589. As cited in Classicism, §§2.5 and 3.5. — Logical Necessity, as discussed in Classicism n. 57

Record: `topics/classicism/results/logical-necessity-r-implies-witnessed-possibility-r.yaml`.

#### Distinctness (pure) ∧ ND ⇒ False (⊥) — `maximalist-distinctness-incompatible-with-nd`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Distinctness (pure) (`distinctness-schema-r`)
- ND (`distinctness-necessary-r`)

Conclusion: False (⊥) (`false`)

Proof.

Choose a closed pure identity A=B such that both it and its negation are C-consistent, as the paper explains. Distinctness gives $A\ne B$ while its equivalent Possibility schema gives $\Diamond(A=B)$. ND applied at the common type gives $\Box(A\ne B)$, a contradiction.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 41.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.6, p. 41

Record: `topics/classicism/results/maximalist-distinctness-incompatible-with-nd.yaml`.

#### Distinctness (pure) ∧ □Actuality ⇒ False (⊥) — `maximalist-distinctness-incompatible-with-necessary-actuality`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Distinctness (pure) (`distinctness-schema-r`)
- □Actuality (`necessary-actuality`)

Conclusion: False (⊥) (`false`)

Proof.

The cited source construction makes a closed instance of Actuality false, so its negation is C-consistent. Pure Possibility, equivalent to pure Distinctness, says that negation is possible. The corresponding boxed instance of the second premise says it is impossible.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 41; Appendix D, Proposition D.5(1), pp. 74–76.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.6, p. 41; Appendix D, Proposition D.5(1), pp. 74–76

Record: `topics/classicism/results/maximalist-distinctness-incompatible-with-necessary-actuality.yaml`.

#### Distinctness (pure) ∧ □Atomicity ⇒ False (⊥) — `maximalist-distinctness-incompatible-with-necessary-atomicity-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Distinctness (pure) (`distinctness-schema-r`)
- □Atomicity (`necessary-atomicity-r`)

Conclusion: False (⊥) (`false`)

Proof.

The cited source construction makes a closed instance of Atomicity false, so its negation is C-consistent. Pure Possibility, equivalent to pure Distinctness, says that negation is possible. The corresponding boxed instance of the second premise says it is impossible.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 41; Appendix D, Proposition D.5(1), pp. 74–76.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.6, p. 41; Appendix D, Proposition D.5(1), pp. 74–76

Record: `topics/classicism/results/maximalist-distinctness-incompatible-with-necessary-atomicity-r.yaml`.

#### Distinctness (pure) ∧ □BF ⇒ False (⊥) — `maximalist-distinctness-incompatible-with-necessary-barcan-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Distinctness (pure) (`distinctness-schema-r`)
- □BF (`necessary-barcan-r`)

Conclusion: False (⊥) (`false`)

Proof.

The cited source construction makes a closed instance of BF false, so its negation is C-consistent. Pure Possibility, equivalent to pure Distinctness, says that negation is possible. The corresponding boxed instance of the second premise says it is impossible.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 41; Appendix D, Proposition D.5(3), pp. 75, 77.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.6, p. 41; Appendix D, Proposition D.5(3), pp. 75, 77

Record: `topics/classicism/results/maximalist-distinctness-incompatible-with-necessary-barcan-r.yaml`.

#### Distinctness (pure) ∧ □Boolean Completeness ⇒ False (⊥) — `maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Distinctness (pure) (`distinctness-schema-r`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)

Conclusion: False (⊥) (`false`)

Proof.

The cited source construction makes a closed instance of Boolean Completeness false, so its negation is C-consistent. Pure Possibility, equivalent to pure Distinctness, says that negation is possible. The corresponding boxed instance of the second premise says it is impossible.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 41; Appendix D, Proposition D.5(1), pp. 74–76.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.6, p. 41; Appendix D, Proposition D.5(1), pp. 74–76

Record: `topics/classicism/results/maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r.yaml`.

#### Distinctness (pure) ∧ □Functionality ⇒ False (⊥) — `maximalist-distinctness-incompatible-with-necessary-functionality-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Distinctness (pure) (`distinctness-schema-r`)
- □Functionality (`necessary-functionality-r`)

Conclusion: False (⊥) (`false`)

Proof.

The cited source construction makes a closed instance of Functionality false, so its negation is C-consistent. Pure Possibility, equivalent to pure Distinctness, says that negation is possible. The corresponding boxed instance of the second premise says it is impossible.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 41; Proposition 2.1, pp. 20–21, and Appendix D, Proposition D.5(3).

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.6, p. 41; Proposition 2.1, pp. 20–21, and Appendix D, Proposition D.5(3)

Record: `topics/classicism/results/maximalist-distinctness-incompatible-with-necessary-functionality-r.yaml`.

#### Distinctness (pure) ∧ □Rigid Comprehension ⇒ False (⊥) — `maximalist-distinctness-incompatible-with-necessary-rigid-comprehension-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Distinctness (pure) (`distinctness-schema-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)

Conclusion: False (⊥) (`false`)

Proof.

The cited source construction makes a closed instance of Rigid Comprehension false, so its negation is C-consistent. Pure Possibility, equivalent to pure Distinctness, says that negation is possible. The corresponding boxed instance of the second premise says it is impossible.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 41; Appendix D, Proposition D.5(1), pp. 74–76.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.6, p. 41; Appendix D, Proposition D.5(1), pp. 74–76

Record: `topics/classicism/results/maximalist-distinctness-incompatible-with-necessary-rigid-comprehension-r.yaml`.

#### Distinctness (pure) ∧ □Tractarianism ⇒ False (⊥) — `maximalist-distinctness-incompatible-with-necessary-tractarianism-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Distinctness (pure) (`distinctness-schema-r`)
- □Tractarianism (`necessary-tractarianism-r`)

Conclusion: False (⊥) (`false`)

Proof.

The cited source construction makes a closed instance of Tractarianism false, so its negation is C-consistent. Pure Possibility, equivalent to pure Distinctness, says that negation is possible. The corresponding boxed instance of the second premise says it is impossible.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 41; Proposition 2.1, pp. 20–21, and Appendix D, Proposition D.5(3).

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.6, p. 41; Proposition 2.1, pp. 20–21, and Appendix D, Proposition D.5(3)

Record: `topics/classicism/results/maximalist-distinctness-incompatible-with-necessary-tractarianism-r.yaml`.

#### B ⇒ ND — `modal-b-implies-distinctness-necessary-r`

Proved result; source **Prior, Formal Logic**; produced by A. N. Prior; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- B (`modal-b`)

Conclusion: ND (`distinctness-necessary-r`)

Proof.

Assume $x\ne y$. B gives $\Box\neg\Box(x=y)$. The necessitation of NI gives $\Box(x=y\to\Box(x=y))$. Within the box, contraposition yields $\neg(x=y)$, and K therefore yields $\Box(x\ne y)$. The argument is uniform at each type.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.2, p. 22 (Prior argument).

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.2, p. 22 (Prior argument)
- **Origin: Formal Logic.** Prior, A. N. (1963). Formal Logic. Oxford University Press. Pages 206–207, as credited in Classicism, Proposition 2.2. — pp. 206–207, as credited in Classicism Proposition 2.2

Record: `topics/classicism/results/modal-b-implies-distinctness-necessary-r.yaml`.

#### B ⇒ B for pure sentences — `modal-b-implies-pure-b-r`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- B (`modal-b`)

Conclusion: B for pure sentences (`pure-b-r`)

Proof.

Specialize the quantified propositional B principle to the proposition expressed by each closed pure sentence.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, n. 81, p. 59.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §3.5, n. 81, p. 59

Record: `topics/classicism/results/modal-b-implies-pure-b-r.yaml`.

#### 5 ⇒ B — `modal-five-implies-modal-b`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- 5 (`modal-five`)

Conclusion: B (`modal-b`)

Proof.

T gives $p\to\Diamond p$. Compose this with $\Diamond p\to\Box\Diamond p$.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.2, p. 22.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.2, p. 22

Record: `topics/classicism/results/modal-five-implies-modal-b.yaml`.

#### ND ∧ BF ⇒ □ND — `nd-and-bf-imply-necessary-nd`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- ND (`distinctness-necessary-r`)
- BF (`barcan-r`)

Conclusion: □ND (`necessary-distinctness-necessary-r`)

Proof.

For arbitrary x,y, classical identity cases, NI and ND give $\Box(x=y)\lor\Box(x\ne y)$. Using 4, strengthen the second disjunct to $\Box\Box(x\ne y)$. Normal modal reasoning yields $\Box(x=y\lor\Box(x\ne y))$, equivalently $\Box(x\ne y\to\Box(x\ne y))$. Generalize over x,y and apply BF twice to box the entire universal closure. Repeat at each type.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.4, p. 23.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.4, p. 23

Record: `topics/classicism/results/nd-and-bf-imply-necessary-nd.yaml`.

#### □Actuality ⇒ Actuality — `necessary-actuality-implies-actuality`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □Actuality (`necessary-actuality`)

Conclusion: Actuality (`actuality`)

Proof.

At each admitted closed instance phi, T gives Box phi → phi. Apply this to every instance in the boxed premise, preserving its type and formula side conditions.

Notes. Routine instancewise use of source axiom T; recorded as a connecting derivation, not an additional Bacon–Dorr theorem.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, T, p. 16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, T, p. 16

Record: `topics/classicism/results/necessary-actuality-implies-actuality.yaml`.

#### □Atomicity ∧ Boolean Completeness ∧ BF ⇒ Rigid Comprehension — `necessary-atomicity-completeness-bf-imply-rigid-comprehension`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □Atomicity (`necessary-atomicity-r`)
- Boolean Completeness (`boolean-completeness-r`)
- BF (`barcan-r`)

Conclusion: Rigid Comprehension (`rigid-comprehension-r`)

Proof.

For a relation X, form the property F of haecceities of its instances and take their least upper bound $X^*$. It contains each X-instance. Actuality follows from Atomicity and BF by Proposition 2.7; let w be the actual atom. The relation $w\to X$ is an upper bound of F, so $X^*$ is also contained in X. Each haecceity entails its own necessitation by NI, so $\Box X^*$ is another upper bound; hence $X^*$ is persistent. For inextensibility, note 42 assumes a possible failure, uses boxed Atomicity and BF to obtain atoms w and w′ witnessing the two stages, and replaces w′ by the GLB of its w-possible aliases. Then $w^{\prime}\to Y$ is an upper bound of F but is contradicted by the proposed failure of inextensibility. This contradiction establishes rigidity.

Notes. This is a summary of note 42; see the accompanying write-up for the alias-GLB step. The source’s first cross-reference to Proposition 2.6 is replaced in this transcription by the sufficient Proposition 2.7; the statement and premises are unchanged.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.11, p. 30 and n. 42.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.11, p. 30 and n. 42

Record: `topics/classicism/results/necessary-atomicity-completeness-bf-imply-rigid-comprehension.yaml`.

<details><summary>Hand-written write-up</summary>

#### Boxed Atomicity, Boolean Completeness and BF imply Rigid Comprehension

Assume boxed Atomicity, Boolean Completeness
and BF, with the map's fixed type range. The conclusion is Rigid Comprehension. This is
Proposition 2.11 of Bacon and Dorr, *Classicism* (16 May 2023 draft), p. 30,
with the proof in note 42.

Here is the unary case from that proof. Let $X$ be a property. Let $F$
be the property of being the haecceity of an $X$-instance, and let $X^*$
be the least upper bound of $F$. Boolean Completeness supplies this
upper bound by Boolean duality. We verify that $X^*$ is a rigid
coextension of $X$.

If $Xz$, the haecceity of $z$ belongs to $F$ and entails $X^*$, so $X^*z$.
For the converse, boxed Atomicity gives Atomicity by T; together with BF,
Proposition 2.7 gives Actuality. Let $w$ witness Actuality. The property
$\lambda y\, .\,w\to Xy$ is an upper bound of $F$: for an $X$-instance
$z$, $w$ entails $Xz$, and identity elimination gives the required
necessary conditional for its haecceity. Minimality of $X^*$ now gives
$X^*\le\lambda y\, .\,w\to Xy$. Since $w$ is true, $X^*z$ entails $Xz$
materially. This proves coextension.

For persistence, every haecceity in $F$ entails $X^*$. NI therefore makes
it entail $\lambda y\, .\,\Box X^*y$ as well. This last property is
another upper bound of $F$. Minimality gives
$X^*\le\lambda y\, .\,\Box X^*y$.

For inextensibility, fix $Y,z$. Suppose, towards contradiction,

$$
\Diamond\bigl((\forall x\, .\,X^*x\to\Box Yx)
  \land\Diamond(X^*z\land\neg Yz)\bigr).
$$

Use Atomicity to choose an atom $w$ below the displayed possible
proposition. Boxed Atomicity supplies an atom beneath the further
possible $X^*z\land\neg Yz$. BF brings a witness $w'$ into the present
domain so that $w$ entails

$$
(\forall x\, .\,X^*x\to\Box Yx)\land
\operatorname{Atom}_t(w')\land w'\le(X^*z\land\neg Yz).
$$

Use Boolean Completeness to normalize this witness as in note 42:
replace it by the greatest lower bound of the propositions $p$ such that
$w\le(p=w')$. The replacement remains identified with the old witness
under $w$ and is itself the greatest lower bound of its corresponding
identity class. Denote this normalized witness again by $w'$.

Set $H=\lambda x\, .\,w'\to Yx$. For any $u$ satisfying $Xu$,
coextension and persistence give $\Box X^*u$. Thus $w$ entails $X^*u$,
then $\Box Yu$, and hence $w'\le Yu$. The normalization makes the last
entailment hold outright: $w$ identifies $w'$ with $w'\land Yu$, so
$w'\land Yu$ lies in the class whose greatest lower bound is $w'$.
It follows that $w'\le w'\land Yu$, and consequently $w'\le Yu$.
Thus $\Box Hu$.

NI now shows that every haecceity in $F$ entails $H$. Hence $H$ is an
upper bound of $F$ and $X^*\le H$. But $w'$ is possible (it is possibly
an atom) and entails $X^*z\land\neg Yz$. Together with $X^*\le H$,
this would make it entail $Yz$ as well, a contradiction.

We have proved the necessary conditional for arbitrary $Y,z$. BF closes
these object variables under the box to give the Inextensible condition.
Together with persistence this makes $X^*$ rigid. For a relation with
several arguments, use tuple-haecceities, replace the displayed variable
by that finite tuple, and apply the corresponding BF instances; the
same upper-bound argument applies. Empty tuples give the propositional
case.

The source's note 42 cites Proposition 2.6 when obtaining Actuality.
The derivation above uses Proposition 2.7, which has the required
assumptions without adding C5. The normalization step is the one supplied
in note 42, not an assumption of choice or of necessary completeness.

Mathematical source: Andrew Bacon and Cian Dorr. Recorded by OpenAI Codex
(GPT-6), 17 September 2026. No independent checker or Lean verification
is claimed.

</details>

#### □Atomicity ⇒ Atomicity — `necessary-atomicity-r-implies-atomicity-r`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □Atomicity (`necessary-atomicity-r`)

Conclusion: Atomicity (`atomicity-r`)

Proof.

At each admitted closed instance phi, T gives Box phi → phi. Apply this to every instance in the boxed premise, preserving its type and formula side conditions.

Notes. Routine instancewise use of source axiom T; recorded as a connecting derivation, not an additional Bacon–Dorr theorem.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, T, p. 16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, T, p. 16

Record: `topics/classicism/results/necessary-atomicity-r-implies-atomicity-r.yaml`.

#### □BF ⇒ BF — `necessary-barcan-r-implies-barcan-r`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □BF (`necessary-barcan-r`)

Conclusion: BF (`barcan-r`)

Proof.

At each admitted closed instance phi, T gives Box phi → phi. Apply this to every instance in the boxed premise, preserving its type and formula side conditions.

Notes. Routine instancewise use of source axiom T; recorded as a connecting derivation, not an additional Bacon–Dorr theorem.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, T, p. 16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, T, p. 16

Record: `topics/classicism/results/necessary-barcan-r-implies-barcan-r.yaml`.

#### □BF ⇒ □BF (type t) — `necessary-barcan-r-implies-necessary-barcan-t`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □BF (`necessary-barcan-r`)

Conclusion: □BF (type t) (`necessary-barcan-t`)

Proof.

Take the type-t instance of the boxed source schema, retaining the whole object-variable closure inside the box.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.1, pp. 20–21.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.1, pp. 20–21

Record: `topics/classicism/results/necessary-barcan-r-implies-necessary-barcan-t.yaml`.

#### □BF ⇒ □Functionality — `necessary-barcan-r-implies-necessary-functionality-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □BF (`necessary-barcan-r`)

Conclusion: □Functionality (`necessary-functionality-r`)

Proof.

Use the source’s uniform proof of the unboxed connection at an arbitrary target type. Discharge its finitely many closed premise instances to obtain a theorem of C, necessitate that theorem, then apply K with the corresponding boxed premise instances. This proves the boxed target instance. Generalization over the admitted target types is metalinguistic; no type quantifier is placed inside Box.

Notes. Instancewise boxed connection stated or used in the cited discussion. The premise is the boxed schema, not an unboxed optional assumption.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, p. 21.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, p. 21

Record: `topics/classicism/results/necessary-barcan-r-implies-necessary-functionality-r.yaml`.

#### □BF (type t) ⇒ BF (type t) — `necessary-barcan-t-implies-barcan-t`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □BF (type t) (`necessary-barcan-t`)

Conclusion: BF (type t) (`barcan-t`)

Proof.

At each admitted closed instance phi, T gives Box phi → phi. Apply this to every instance in the boxed premise, preserving its type and formula side conditions.

Notes. Routine instancewise use of source axiom T; recorded as a connecting derivation, not an additional Bacon–Dorr theorem.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, T, p. 16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, T, p. 16

Record: `topics/classicism/results/necessary-barcan-t-implies-barcan-t.yaml`.

#### □Boolean Completeness ⇒ Boolean Completeness — `necessary-boolean-completeness-r-implies-boolean-completeness-r`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □Boolean Completeness (`necessary-boolean-completeness-r`)

Conclusion: Boolean Completeness (`boolean-completeness-r`)

Proof.

At each admitted closed instance phi, T gives Box phi → phi. Apply this to every instance in the boxed premise, preserving its type and formula side conditions.

Notes. Routine instancewise use of source axiom T; recorded as a connecting derivation, not an additional Bacon–Dorr theorem.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, T, p. 16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, T, p. 16

Record: `topics/classicism/results/necessary-boolean-completeness-r-implies-boolean-completeness-r.yaml`.

#### □ND ⇒ ND — `necessary-distinctness-necessary-r-implies-distinctness-necessary-r`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □ND (`necessary-distinctness-necessary-r`)

Conclusion: ND (`distinctness-necessary-r`)

Proof.

At each admitted closed instance phi, T gives Box phi → phi. Apply this to every instance in the boxed premise, preserving its type and formula side conditions.

Notes. Routine instancewise use of source axiom T; recorded as a connecting derivation, not an additional Bacon–Dorr theorem.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, T, p. 16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, T, p. 16

Record: `topics/classicism/results/necessary-distinctness-necessary-r-implies-distinctness-necessary-r.yaml`.

#### □ND ⇒ □BF — `necessary-distinctness-necessary-r-implies-necessary-barcan-r`

Proved result; source **Prior / Lemmon on BF**; produced by A. N. Prior; E. J. Lemmon (simplified proof); recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □ND (`necessary-distinctness-necessary-r`)

Conclusion: □BF (`necessary-barcan-r`)

Proof.

For any target BF instance, the proof of Proposition 2.3 uses finitely many boxed ND instances. By 4 the premise supplies the boxes of those boxed instances. Necessitate the closed conditional proved in Proposition 2.3 and apply K to obtain the boxed target BF instance.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.3, p. 22; Figure 5, p. 23.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.3, p. 22; Figure 5, p. 23
- **Origin: Modality and Quantification in S5; Past, Present, and Future.** Prior, A. N. (1956). Modality and Quantification in S5. Journal of Symbolic Logic 21(1), 60–62. See also Prior (1967), Past, Present, and Future, p. 146, crediting E. J. Lemmon’s simplified proof. Attribution as given in Classicism, Proposition 2.3. — Prior 1956; Prior 1967, p. 146; attribution in Classicism Proposition 2.3

Record: `topics/classicism/results/necessary-distinctness-necessary-r-implies-necessary-barcan-r.yaml`.

#### □ND ⇒ □ND (type t) — `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □ND (`necessary-distinctness-necessary-r`)

Conclusion: □ND (type t) (`necessary-distinctness-necessary-t`)

Proof.

Take the type-t instance of the boxed source schema, retaining the whole object-variable closure inside the box.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, pp. 21–22.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, pp. 21–22

Record: `topics/classicism/results/necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t.yaml`.

#### □ND ⇒ □5 — `necessary-distinctness-necessary-r-implies-necessary-modal-five`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □ND (`necessary-distinctness-necessary-r`)

Conclusion: □5 (`necessary-modal-five`)

Proof.

Use the source’s uniform proof of the unboxed connection at an arbitrary target type. Discharge its finitely many closed premise instances to obtain a theorem of C, necessitate that theorem, then apply K with the corresponding boxed premise instances. This proves the boxed target instance. Generalization over the admitted target types is metalinguistic; no type quantifier is placed inside Box.

Notes. Instancewise boxed connection stated or used in the cited discussion. The premise is the boxed schema, not an unboxed optional assumption.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, p. 22.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, p. 22

Record: `topics/classicism/results/necessary-distinctness-necessary-r-implies-necessary-modal-five.yaml`.

#### □ND (type t) ⇒ ND (type t) — `necessary-distinctness-necessary-t-implies-distinctness-necessary-t`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □ND (type t) (`necessary-distinctness-necessary-t`)

Conclusion: ND (type t) (`distinctness-necessary-t`)

Proof.

At each admitted closed instance phi, T gives Box phi → phi. Apply this to every instance in the boxed premise, preserving its type and formula side conditions.

Notes. Routine instancewise use of source axiom T; recorded as a connecting derivation, not an additional Bacon–Dorr theorem.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, T, p. 16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, T, p. 16

Record: `topics/classicism/results/necessary-distinctness-necessary-t-implies-distinctness-necessary-t.yaml`.

#### □ND (type t) ⇒ □ND — `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □ND (type t) (`necessary-distinctness-necessary-t`)

Conclusion: □ND (`necessary-distinctness-necessary-r`)

Proof.

The closed proof from ND at t to 5 to B to ND at any chosen type uses no other ND instance. Necessitate this implication and apply K to boxed ND at t. Repeat for every type.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.2, p. 22.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.2, p. 22

Record: `topics/classicism/results/necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r.yaml`.

#### □Extensionality ⇒ Extensionality — `necessary-extensionality-r-implies-extensionality-r`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □Extensionality (`necessary-extensionality-r`)

Conclusion: Extensionality (`extensionality-r`)

Proof.

At each admitted closed instance phi, T gives Box phi → phi. Apply this to every instance in the boxed premise, preserving its type and formula side conditions.

Notes. Routine instancewise use of source axiom T; recorded as a connecting derivation, not an additional Bacon–Dorr theorem.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, T, p. 16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, T, p. 16

Record: `topics/classicism/results/necessary-extensionality-r-implies-extensionality-r.yaml`.

#### □Fregean Axiom ⇒ Fregean Axiom — `necessary-fregean-axiom-implies-fregean-axiom`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □Fregean Axiom (`necessary-fregean-axiom`)

Conclusion: Fregean Axiom (`fregean-axiom`)

Proof.

At each admitted closed instance phi, T gives Box phi → phi. Apply this to every instance in the boxed premise, preserving its type and formula side conditions.

Notes. Routine instancewise use of source axiom T; recorded as a connecting derivation, not an additional Bacon–Dorr theorem.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, T, p. 16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, T, p. 16

Record: `topics/classicism/results/necessary-fregean-axiom-implies-fregean-axiom.yaml`.

#### □Functionality ⇒ Functionality — `necessary-functionality-r-implies-functionality-r`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □Functionality (`necessary-functionality-r`)

Conclusion: Functionality (`functionality-r`)

Proof.

At each admitted closed instance phi, T gives Box phi → phi. Apply this to every instance in the boxed premise, preserving its type and formula side conditions.

Notes. Routine instancewise use of source axiom T; recorded as a connecting derivation, not an additional Bacon–Dorr theorem.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, T, p. 16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, T, p. 16

Record: `topics/classicism/results/necessary-functionality-r-implies-functionality-r.yaml`.

#### □Functionality ⇒ □Tractarianism — `necessary-functionality-r-implies-necessary-tractarianism-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □Functionality (`necessary-functionality-r`)

Conclusion: □Tractarianism (`necessary-tractarianism-r`)

Proof.

Use the source’s uniform proof of the unboxed connection at an arbitrary target type. Discharge its finitely many closed premise instances to obtain a theorem of C, necessitate that theorem, then apply K with the corresponding boxed premise instances. This proves the boxed target instance. Generalization over the admitted target types is metalinguistic; no type quantifier is placed inside Box.

Notes. Instancewise boxed connection stated or used in the cited discussion. The premise is the boxed schema, not an unboxed optional assumption.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, p. 21.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, p. 21

Record: `topics/classicism/results/necessary-functionality-r-implies-necessary-tractarianism-r.yaml`.

#### □B ⇒ B — `necessary-modal-b-implies-modal-b`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □B (`necessary-modal-b`)

Conclusion: B (`modal-b`)

Proof.

At each admitted closed instance phi, T gives Box phi → phi. Apply this to every instance in the boxed premise, preserving its type and formula side conditions.

Notes. Routine instancewise use of source axiom T; recorded as a connecting derivation, not an additional Bacon–Dorr theorem.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, T, p. 16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, T, p. 16

Record: `topics/classicism/results/necessary-modal-b-implies-modal-b.yaml`.

#### □B ⇒ □ND — `necessary-modal-b-implies-necessary-distinctness-necessary-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □B (`necessary-modal-b`)

Conclusion: □ND (`necessary-distinctness-necessary-r`)

Proof.

Use the source’s uniform proof of the unboxed connection at an arbitrary target type. Discharge its finitely many closed premise instances to obtain a theorem of C, necessitate that theorem, then apply K with the corresponding boxed premise instances. This proves the boxed target instance. Generalization over the admitted target types is metalinguistic; no type quantifier is placed inside Box.

Notes. Instancewise boxed connection stated or used in the cited discussion. The premise is the boxed schema, not an unboxed optional assumption.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, p. 22.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, p. 22

Record: `topics/classicism/results/necessary-modal-b-implies-necessary-distinctness-necessary-r.yaml`.

#### □5 ⇒ 5 — `necessary-modal-five-implies-modal-five`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □5 (`necessary-modal-five`)

Conclusion: 5 (`modal-five`)

Proof.

At each admitted closed instance phi, T gives Box phi → phi. Apply this to every instance in the boxed premise, preserving its type and formula side conditions.

Notes. Routine instancewise use of source axiom T; recorded as a connecting derivation, not an additional Bacon–Dorr theorem.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, T, p. 16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, T, p. 16

Record: `topics/classicism/results/necessary-modal-five-implies-modal-five.yaml`.

#### □5 ⇒ □B — `necessary-modal-five-implies-necessary-modal-b`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □5 (`necessary-modal-five`)

Conclusion: □B (`necessary-modal-b`)

Proof.

Use the source’s uniform proof of the unboxed connection at an arbitrary target type. Discharge its finitely many closed premise instances to obtain a theorem of C, necessitate that theorem, then apply K with the corresponding boxed premise instances. This proves the boxed target instance. Generalization over the admitted target types is metalinguistic; no type quantifier is placed inside Box.

Notes. Instancewise boxed connection stated or used in the cited discussion. The premise is the boxed schema, not an unboxed optional assumption.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, p. 22.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, p. 22

Record: `topics/classicism/results/necessary-modal-five-implies-necessary-modal-b.yaml`.

#### □ND ⇒ BF — `necessary-nd-implies-bf`

Proved result; source **Prior / Lemmon on BF**; produced by A. N. Prior; E. J. Lemmon (simplified proof); recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □ND (`necessary-distinctness-necessary-r`)

Conclusion: BF (`barcan-r`)

Proof.

From $\forall x\, .\,\Box Fx$, B gives $\Box\Diamond(\forall x\, .\,\Box Fx)$. CBF gives the implication from the possible universal statement to $\forall x\, .\,\Diamond\Box Fx$; necessitate that logical implication to use it inside the leading box. The necessitated B dual gives $\Diamond\Box Fx\to Fx$ there. The result is $\Box(\forall x\, .\,Fx)$. The required B and boxed-B instances follow from boxed ND as explained with Proposition 2.2.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.3, p. 22.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.3, p. 22
- **Origin: Modality and Quantification in S5; Past, Present, and Future.** Prior, A. N. (1956). Modality and Quantification in S5. Journal of Symbolic Logic 21(1), 60–62. See also Prior (1967), Past, Present, and Future, p. 146, crediting E. J. Lemmon’s simplified proof. Attribution as given in Classicism, Proposition 2.3. — Prior 1956; Prior 1967, p. 146; attribution in Classicism Proposition 2.3

Record: `topics/classicism/results/necessary-nd-implies-bf.yaml`.

#### □Plenitude ⇒ Atomicity — `necessary-plenitude-r-implies-atomicity-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □Plenitude (`necessary-plenitude-r`)

Conclusion: Atomicity (`atomicity-r`)

Proof.

Boxed versions of Propositions 2.13 and 2.15 yield C5 and boxed Actuality. Proposition 2.6 then yields Atomicity.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, concluding equivalences, p. 33.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, concluding equivalences, p. 33

Record: `topics/classicism/results/necessary-plenitude-r-implies-atomicity-r.yaml`.

#### □Plenitude ⇒ □Actuality — `necessary-plenitude-r-implies-necessary-actuality`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □Plenitude (`necessary-plenitude-r`)

Conclusion: □Actuality (`necessary-actuality`)

Proof.

Use the source’s uniform proof of the unboxed connection at an arbitrary target type. Discharge its finitely many closed premise instances to obtain a theorem of C, necessitate that theorem, then apply K with the corresponding boxed premise instances. This proves the boxed target instance. Generalization over the admitted target types is metalinguistic; no type quantifier is placed inside Box.

Notes. Instancewise boxed connection stated or used in the cited discussion. The premise is the boxed schema, not an unboxed optional assumption.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.15; §2.3, p. 33.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.15; §2.3, p. 33

Record: `topics/classicism/results/necessary-plenitude-r-implies-necessary-actuality.yaml`.

#### □Plenitude ⇒ □ND — `necessary-plenitude-r-implies-necessary-distinctness-necessary-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □Plenitude (`necessary-plenitude-r`)

Conclusion: □ND (`necessary-distinctness-necessary-r`)

Proof.

Use the source’s uniform proof of the unboxed connection at an arbitrary target type. Discharge its finitely many closed premise instances to obtain a theorem of C, necessitate that theorem, then apply K with the corresponding boxed premise instances. This proves the boxed target instance. Generalization over the admitted target types is metalinguistic; no type quantifier is placed inside Box.

Notes. Instancewise boxed connection stated or used in the cited discussion. The premise is the boxed schema, not an unboxed optional assumption.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.13; §2.3, p. 33.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.13; §2.3, p. 33

Record: `topics/classicism/results/necessary-plenitude-r-implies-necessary-distinctness-necessary-r.yaml`.

#### □Plenitude ⇒ Plenitude — `necessary-plenitude-r-implies-plenitude-r`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □Plenitude (`necessary-plenitude-r`)

Conclusion: Plenitude (`plenitude-r`)

Proof.

At each admitted closed instance phi, T gives Box phi → phi. Apply this to every instance in the boxed premise, preserving its type and formula side conditions.

Notes. Routine instancewise use of source axiom T; recorded as a connecting derivation, not an additional Bacon–Dorr theorem.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, T, p. 16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, T, p. 16

Record: `topics/classicism/results/necessary-plenitude-r-implies-plenitude-r.yaml`.

#### □Rigid Comprehension ⇒ □Actuality — `necessary-rigid-comprehension-r-implies-necessary-actuality`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □Rigid Comprehension (`necessary-rigid-comprehension-r`)

Conclusion: □Actuality (`necessary-actuality`)

Proof.

Use the source’s uniform proof of the unboxed connection at an arbitrary target type. Discharge its finitely many closed premise instances to obtain a theorem of C, necessitate that theorem, then apply K with the corresponding boxed premise instances. This proves the boxed target instance. Generalization over the admitted target types is metalinguistic; no type quantifier is placed inside Box.

Notes. Instancewise boxed connection stated or used in the cited discussion. The premise is the boxed schema, not an unboxed optional assumption.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.9; §2.3, p. 33.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.9; §2.3, p. 33

Record: `topics/classicism/results/necessary-rigid-comprehension-r-implies-necessary-actuality.yaml`.

#### □Rigid Comprehension ⇒ □Boolean Completeness — `necessary-rigid-comprehension-r-implies-necessary-boolean-completeness-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □Rigid Comprehension (`necessary-rigid-comprehension-r`)

Conclusion: □Boolean Completeness (`necessary-boolean-completeness-r`)

Proof.

Use the source’s uniform proof of the unboxed connection at an arbitrary target type. Discharge its finitely many closed premise instances to obtain a theorem of C, necessitate that theorem, then apply K with the corresponding boxed premise instances. This proves the boxed target instance. Generalization over the admitted target types is metalinguistic; no type quantifier is placed inside Box.

Notes. Instancewise boxed connection stated or used in the cited discussion. The premise is the boxed schema, not an unboxed optional assumption.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.8; §2.3, p. 33.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.8; §2.3, p. 33

Record: `topics/classicism/results/necessary-rigid-comprehension-r-implies-necessary-boolean-completeness-r.yaml`.

#### □Rigid Comprehension ⇒ Rigid Comprehension — `necessary-rigid-comprehension-r-implies-rigid-comprehension-r`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □Rigid Comprehension (`necessary-rigid-comprehension-r`)

Conclusion: Rigid Comprehension (`rigid-comprehension-r`)

Proof.

At each admitted closed instance phi, T gives Box phi → phi. Apply this to every instance in the boxed premise, preserving its type and formula side conditions.

Notes. Routine instancewise use of source axiom T; recorded as a connecting derivation, not an additional Bacon–Dorr theorem.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, T, p. 16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, T, p. 16

Record: `topics/classicism/results/necessary-rigid-comprehension-r-implies-rigid-comprehension-r.yaml`.

#### □Tractarianism ⇒ □BF — `necessary-tractarianism-r-implies-necessary-barcan-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □Tractarianism (`necessary-tractarianism-r`)

Conclusion: □BF (`necessary-barcan-r`)

Proof.

Use the source’s uniform proof of the unboxed connection at an arbitrary target type. Discharge its finitely many closed premise instances to obtain a theorem of C, necessitate that theorem, then apply K with the corresponding boxed premise instances. This proves the boxed target instance. Generalization over the admitted target types is metalinguistic; no type quantifier is placed inside Box.

Notes. Instancewise boxed connection stated or used in the cited discussion. The premise is the boxed schema, not an unboxed optional assumption.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.1, p. 21.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.1, p. 21

Record: `topics/classicism/results/necessary-tractarianism-r-implies-necessary-barcan-r.yaml`.

#### □Tractarianism ⇒ Tractarianism — `necessary-tractarianism-r-implies-tractarianism-r`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □Tractarianism (`necessary-tractarianism-r`)

Conclusion: Tractarianism (`tractarianism-r`)

Proof.

At each admitted closed instance phi, T gives Box phi → phi. Apply this to every instance in the boxed premise, preserving its type and formula side conditions.

Notes. Routine instancewise use of source axiom T; recorded as a connecting derivation, not an additional Bacon–Dorr theorem.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §1.5, T, p. 16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §1.5, T, p. 16

Record: `topics/classicism/results/necessary-tractarianism-r-implies-tractarianism-r.yaml`.

#### No Pure Contingency ⇒ Converse Witnessed Possibility — `no-pure-contingency-r-implies-converse-witnessed-possibility-r`

Proved result; source **Logical Combinatorialism**; produced by Andrew Bacon; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- No Pure Contingency (`no-pure-contingency-r`)

Conclusion: Converse Witnessed Possibility (`converse-witnessed-possibility-r`)

Proof.

Apply No Pure Contingency to the closed pure sentence $\neg\exists\bar x\, .\,P$. If it is true it is necessary, which rules out $\Diamond P[\bar c/\bar x]$. Contraposition proves the required converse.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, n. 57, p. 38.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, n. 57, p. 38
- **Origin: Logical Combinatorialism.** Bacon, Andrew (2020). Logical Combinatorialism. Philosophical Review 129(4), 537–589. As cited in Classicism, §§2.5 and 3.5. — Logical Necessity, as discussed in Classicism n. 57

Record: `topics/classicism/results/no-pure-contingency-r-implies-converse-witnessed-possibility-r.yaml`.

#### No Pure Contingency ⇒ B for pure sentences — `no-pure-contingency-r-implies-pure-b-r`

Proved result; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- No Pure Contingency (`no-pure-contingency-r`)

Conclusion: B for pure sentences (`pure-b-r`)

Proof.

No Pure Contingency yields $P\to\Box P$. Necessitating the T-dual theorem $P\to\Diamond P$ and applying K gives $\Box P\to\Box\Diamond P$.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, n. 81, p. 59.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §3.5, n. 81, p. 59

Record: `topics/classicism/results/no-pure-contingency-r-implies-pure-b-r.yaml`.

#### Persistent Comprehension ⇒ Actuality — `persistent-comprehension-r-implies-actuality`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Persistent Comprehension (`persistent-comprehension-r`)

Conclusion: Actuality (`actuality`)

Proof.

Choose a persistent predicate T coextensive with truth and use $\forall p\, .\,Tp\to p$. The proof of Proposition 2.9 uses persistence, not inextensibility, to show that this true proposition entails every truth.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, n. 38 and n. 40, p. 29.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, n. 38 and n. 40, p. 29

Record: `topics/classicism/results/persistent-comprehension-r-implies-actuality.yaml`.

#### Plenitude ⇒ Actuality — `plenitude-r-implies-actuality`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Plenitude (`plenitude-r`)

Conclusion: Actuality (`actuality`)

Proof.

Use the functional relation taking each true proposition to itself and each false proposition to $\top$: $(p\land p=q)\lor(\neg p\land q=\top)$. Plenitude supplies Z with those values. The proposition $\forall p\, .\,Zp$ is true and entails Zp for every p, hence entails every true p. It witnesses Actuality.

Notes. The displayed relation in the PDF’s prose on p. 33 has p=top in its second disjunct. The surrounding definition and subsequent proof require q=top. This transcription explicitly follows that intended truth-to-itself/falsehood-to-top construction.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.15, pp. 32–33.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.15, pp. 32–33

Record: `topics/classicism/results/plenitude-r-implies-actuality.yaml`.

#### Plenitude ⇒ ND — `plenitude-r-implies-distinctness-necessary-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Plenitude (`plenitude-r`)

Conclusion: ND (`distinctness-necessary-r`)

Proof.

Given distinct x,y of any type, use the functional relation taking x to $\top$ and every other argument to $\bot$. Plenitude gives an operation Z with $Zx=\top$ and $Zy=\bot$. Since those values are necessarily distinct, Leibniz’s Law yields the necessary distinctness of x and y.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.13, p. 32.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.13, p. 32

Record: `topics/classicism/results/plenitude-r-implies-distinctness-necessary-r.yaml`.

#### Possibility (pure) ∧ No Pure Contingency ⇒ False (⊥) — `possibility-and-no-pure-contingency-incompatible`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Possibility (pure) (`possibility-schema-r`)
- No Pure Contingency (`no-pure-contingency-r`)

Conclusion: False (⊥) (`false`)

Proof.

The Fregean Axiom A is a closed pure sentence. Both A and its negation are C-consistent: an ordinary two-valued Henkin model satisfies A, whereas the source’s full two-element-group model has four propositions and falsifies A. Possibility gives $\Diamond A$ and $\Diamond\neg A$. By excluded middle either A or its negation is true. No Pure Contingency applied to the true one makes it necessary, contradicting the possibility of the other.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, n. 57, p. 38; §3.5, p. 59.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, n. 57, p. 38; §3.5, p. 59

Record: `topics/classicism/results/possibility-and-no-pure-contingency-incompatible.yaml`.

#### Possibility+ ⇒ Possibility (pure) — `possibility-plus-r-implies-possibility-schema-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Possibility+ (`possibility-plus-r`)

Conclusion: Possibility (pure) (`possibility-schema-r`)

Proof.

Take the empty tuple of individual variables. Its distinctness condition is vacuous; the instances are pure Possibility.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 41.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.6, p. 41

Record: `topics/classicism/results/possibility-plus-r-implies-possibility-schema-r.yaml`.

#### Possibility (pure) ⇒ Distinctness (pure) — `possibility-schema-r-implies-distinctness-schema-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Possibility (pure) (`possibility-schema-r`)

Conclusion: Distinctness (pure) (`distinctness-schema-r`)

Proof.

If a closed identity A=B is not a theorem of the reference theory, its negation is consistent. Possibility gives $\Diamond(A\ne B)$. NI implies that A=B would make this impossible, so A and B are distinct.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.4, pp. 35–36; §2.5, p. 37.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.4, pp. 35–36; §2.5, p. 37

Record: `topics/classicism/results/possibility-schema-r-implies-distinctness-schema-r.yaml`.

#### Possibility (signature Σ) ⇒ Distinctness (signature Σ) — `possibility-signature-r-implies-distinctness-signature-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Possibility (signature Σ) (`possibility-signature-r`)

Conclusion: Distinctness (signature Σ) (`distinctness-signature-r`)

Proof.

If a closed identity A=B is not a theorem of the reference theory, its negation is consistent. Possibility gives $\Diamond(A\ne B)$. NI implies that A=B would make this impossible, so A and B are distinct.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.4, pp. 35–36; §2.5, p. 37.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.4, pp. 35–36; §2.5, p. 37

Record: `topics/classicism/results/possibility-signature-r-implies-distinctness-signature-r.yaml`.

#### Possibility (signature Σ) ⇒ Witnessed Possibility — `possibility-signature-r-implies-witnessed-possibility-r`

Proved result; source **Logical Combinatorialism**; produced by Andrew Bacon; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Possibility (signature Σ) (`possibility-signature-r`)

Conclusion: Witnessed Possibility (`witnessed-possibility-r`)

Proof.

For a fixed pure formula P, either P has a witness consistently with the reference C theory or it does not. In the first case interpreting the fresh constants as witnesses makes P[c/x] consistent, and signature Possibility supplies its possibility. In the second case the reference theory proves there is no witness, so the required conditional has a false antecedent.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, n. 57, p. 38.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, n. 57, p. 38
- **Origin: Logical Combinatorialism.** Bacon, Andrew (2020). Logical Combinatorialism. Philosophical Review 129(4), 537–589. As cited in Classicism, §§2.5 and 3.5. — Logical Necessity and Witnessed Possibility, as discussed in Classicism n. 57

Record: `topics/classicism/results/possibility-signature-r-implies-witnessed-possibility-r.yaml`.

#### Distinctness (pure) ∧ Separated Structure ⇒ Distinctness (signature Σ) — `pure-distinctness-and-separated-structure-imply-signature-distinctness`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Distinctness (pure) (`distinctness-schema-r`)
- Separated Structure (`separated-structure-r`)

Conclusion: Distinctness (signature Σ) (`distinctness-signature-r`)

Proof.

Iterating Separated Structure gives the corresponding conditional for a finite tuple of distinct constants. Abstract the constants occurring in a closed A,B to write them as iterated applications of pure closed F,G. If A=B is not a theorem, F=G cannot be a theorem either. Pure Distinctness gives F≠G; contraposition of the iterated Separated Structure conditional gives A≠B.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, p. 39.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, p. 39

Record: `topics/classicism/results/pure-distinctness-and-separated-structure-imply-signature-distinctness.yaml`.

#### Relational Choice ∧ Plenitude ⇒ Functional Choice — `relational-choice-and-plenitude-imply-functional-choice-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Relational Choice (`relational-choice-r`)
- Plenitude (`plenitude-r`)

Conclusion: Functional Choice (`functional-choice-r`)

Proof.

For a serial relation U, Relational Choice yields a functional subrelation S. Plenitude represents S by an operation; because S is a subrelation of U, that operation selects from U.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, pp. 31–32.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, pp. 31–32

Record: `topics/classicism/results/relational-choice-and-plenitude-imply-functional-choice-r.yaml`.

#### Rigid Comprehension ∧ BF ⇒ □BF — `rigid-comprehension-and-bf-imply-necessary-bf`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Rigid Comprehension (`rigid-comprehension-r`)
- BF (`barcan-r`)

Conclusion: □BF (`necessary-barcan-r`)

Proof.

Choose a rigid property F coextensive with self-identity. Persistence gives $\forall x\, .\,\Box Fx$ and BF gives $\Box\forall x\, .\,Fx$. The inextensibility of F supplies boxed BF with its quantifiers restricted to F. Inside the box everything is F, so the restrictions can be removed. This is the boxed, universally closed BF instance at the chosen type.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.12, p. 30 and n. 43.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.12, p. 30 and n. 43

Record: `topics/classicism/results/rigid-comprehension-and-bf-imply-necessary-bf.yaml`.

#### Rigid Comprehension ∧ ND ⇒ Plenitude — `rigid-comprehension-and-nd-imply-plenitude`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Rigid Comprehension (`rigid-comprehension-r`)
- ND (`distinctness-necessary-r`)

Conclusion: Plenitude (`plenitude-r`)

Proof.

For functional U with propositional output, choose a rigid coextension $U^*$ and put $Zy=\forall p\, .\,(U^*y)p\to p$. If Uxq, persistence makes $(U^*x)q$ necessary, so Zx entails q. Functionality, NI and ND make every $U^*$-pair necessarily either have a different first coordinate or have second coordinate q. Inextensibility combines this into necessary uniqueness at x, which gives q entails Zx. Thus Zx=q and Z represents U. The source extends this construction pointwise to every relational relational output type.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.16, p. 33 and n. 49.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.16, p. 33 and n. 49

Record: `topics/classicism/results/rigid-comprehension-and-nd-imply-plenitude.yaml`.

#### Rigid Comprehension ⇒ Actuality — `rigid-comprehension-r-implies-actuality`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Rigid Comprehension (`rigid-comprehension-r`)

Conclusion: Actuality (`actuality`)

Proof.

Choose a rigid predicate T coextensive with truth and let $w=\forall p\, .\,Tp\to p$. This is true. If p is true, then Tp is true and, by persistence, necessary. Consequently w entails p. Thus w is a true lower bound of all truths.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.9, p. 29 and n. 40.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.9, p. 29 and n. 40

Record: `topics/classicism/results/rigid-comprehension-r-implies-actuality.yaml`.

#### Rigid Comprehension ⇒ Boolean Completeness — `rigid-comprehension-r-implies-boolean-completeness-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Rigid Comprehension (`rigid-comprehension-r`)

Conclusion: Boolean Completeness (`boolean-completeness-r`)

Proof.

For a property X of relations, choose a rigid coextension $X^*$. Define $U=\lambda\bar z\, .\,\forall Y\, .\,X^*Y\to Y[\bar z]$. For any V, being a lower bound of X is equivalent to being one of $X^*$; rigidity turns the pointwise necessary consequences for members of $X^*$ into their necessary universal generalization. This says exactly $V\le U$. Thus the lower bounds of X are precisely the entities below U, which is the GLB condition. This works at each relational type.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.8, p. 29 and n. 39.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.8, p. 29 and n. 39

Record: `topics/classicism/results/rigid-comprehension-r-implies-boolean-completeness-r.yaml`.

#### Rigid Comprehension ⇒ Inextensible Comprehension — `rigid-comprehension-r-implies-inextensible-comprehension-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Rigid Comprehension (`rigid-comprehension-r`)

Conclusion: Inextensible Comprehension (`inextensible-comprehension-r`)

Proof.

Every rigid coextension is inextensible by the definition of Rigid. Use the same witness.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, definition of rigidity, p. 28; n. 38, p. 29.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, definition of rigidity, p. 28; n. 38, p. 29

Record: `topics/classicism/results/rigid-comprehension-r-implies-inextensible-comprehension-r.yaml`.

#### Rigid Comprehension ⇒ Persistent Comprehension — `rigid-comprehension-r-implies-persistent-comprehension-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Rigid Comprehension (`rigid-comprehension-r`)

Conclusion: Persistent Comprehension (`persistent-comprehension-r`)

Proof.

Every rigid coextension is persistent by the definition of Rigid. Use the same witness.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, definition of rigidity, p. 28; n. 38, p. 29.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, definition of rigidity, p. 28; n. 38, p. 29

Record: `topics/classicism/results/rigid-comprehension-r-implies-persistent-comprehension-r.yaml`.

#### Strong Possibility (pure) ⇒ Possibility (pure) — `strong-possibility-r-implies-possibility-schema-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Strong Possibility (pure) (`strong-possibility-r`)

Conclusion: Possibility (pure) (`possibility-schema-r`)

Proof.

If P is C-consistent, then $\Diamond P$ is a theorem of Max(C). The source’s consistency theorem for Max(C) therefore makes $\Diamond P$ consistent with that theory. Strong Possibility gives $\Diamond_{\ne}\Diamond P$, which implies $\Diamond\Diamond P$ and hence $\Diamond P$ by 4.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 42.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.6, p. 42

Record: `topics/classicism/results/strong-possibility-r-implies-possibility-schema-r.yaml`.

#### Strong Possibility (signature Σ) ⇒ Possibility (signature Σ) — `strong-possibility-signature-r-implies-possibility-signature-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Strong Possibility (signature Σ) (`strong-possibility-signature-r`)

Conclusion: Possibility (signature Σ) (`possibility-signature-r`)

Proof.

If the closed Sigma-sentence P is consistent with C(Sigma), Max(C(Sigma)) proves $\Diamond P$. The source consistency theorem for that maximalization therefore makes $\Diamond P$ consistent with it. Strong Possibility yields $\Diamond_{\ne}\Diamond P$, hence $\Diamond\Diamond P$ and $\Diamond P$ by 4. The signature and reference theory remain fixed throughout.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 42, following the signature convention of §2.5.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.6, p. 42, following the signature convention of §2.5

Record: `topics/classicism/results/strong-possibility-signature-r-implies-possibility-signature-r.yaml`.

#### Tractarianism ⇒ BF — `tractarianism-r-implies-barcan-r`

Proved result; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Tractarianism (`tractarianism-r`)

Conclusion: BF (`barcan-r`)

Proof.

Use $p=\top$ in Tractarianism. Entailment by $\top$ is necessity, so pointwise necessity entails necessity of the universal generalization.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.1, n. 27, pp. 20–21.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Proposition 2.1, n. 27, pp. 20–21

Record: `topics/classicism/results/tractarianism-r-implies-barcan-r.yaml`.

#### Witnessed Possibility ∧ No Pure Contingency ⇒ Logical Necessity — `witnessed-possibility-and-no-pure-contingency-imply-logical-necessity`

Proved result; source **Logical Combinatorialism**; produced by Andrew Bacon; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Witnessed Possibility (`witnessed-possibility-r`)
- No Pure Contingency (`no-pure-contingency-r`)

Conclusion: Logical Necessity (`logical-necessity-r`)

Proof.

No Pure Contingency gives Converse Witnessed Possibility. Apply both directions of the resulting equivalence to the negation of a pure formula and contrapose; modal duality and quantifier duality yield necessity at the constants iff universal truth.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, n. 57, p. 38.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.5, n. 57, p. 38
- **Origin: Logical Combinatorialism.** Bacon, Andrew (2020). Logical Combinatorialism. Philosophical Review 129(4), 537–589. As cited in Classicism, §§2.5 and 3.5. — Logical Necessity, as discussed in Classicism n. 57

Record: `topics/classicism/results/witnessed-possibility-and-no-pure-contingency-imply-logical-necessity.yaml`.

### 4.2 Recorded conjectures

These are displayed but never used as evidence in any derivation below.

#### □ND ∧ Atomicity ⇒ No Pure Contingency — `c5-and-atomicity-imply-no-pure-contingency`

Conjecture; source **Goodsell / Yli-Vakkuri (unpublished)**; produced by Zachary Goodsell and Juhani Yli-Vakkuri; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- □ND (`necessary-distinctness-necessary-r`)
- Atomicity (`atomicity-r`)

Conclusion: No Pure Contingency (`no-pure-contingency-r`)

No proof is recorded. This is a conjecture only.

Notes. Reported by the source as a theorem; conjectured is the map’s pending-verification status, not the source authors’ classification.

Source report / verification needed: The source attributes this theorem to Goodsell and Yli-Vakkuri (unpublished) but does not reproduce a proof. Obtain and check that proof for the source schema before promoting this record.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, p. 27.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.2, p. 27
- **Origin: Logical Foundations of Philosophy.** Goodsell, Zachary, and Juhani Yli-Vakkuri. Logical Foundations of Philosophy. Unpublished work cited in Classicism, p. 27; no proof from that work is imported here. — Logical Foundations of Philosophy, as cited in Classicism p. 27

Record: `topics/classicism/results/c5-and-atomicity-imply-no-pure-contingency.yaml`.

#### Distinctness (pure) ∧ Rigid Comprehension ⇒ False (⊥) — `maximalist-distinctness-incompatible-with-rigid-comprehension`

Conjecture; source **Goodsell (personal communication)**; produced by Zachary Goodsell; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Premises:

- Distinctness (pure) (`distinctness-schema-r`)
- Rigid Comprehension (`rigid-comprehension-r`)

Conclusion: False (⊥) (`false`)

No proof is recorded. This is a conjecture only.

Notes. A reported theorem awaiting a supplied proof in this map; not presented as a conjecture by the source.

Source report / verification needed: The paper credits Zach Goodsell (personal communication) with this incompatibility, but supplies no proof. A checked proof of the stated source-scope incompatibility is still needed.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 41.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.6, p. 41

Record: `topics/classicism/results/maximalist-distinctness-incompatible-with-rigid-comprehension.yaml`.

## 5. Models

A model witnesses consistency, and so refutes every implication from what it satisfies to what it violates. Independence is never recorded directly; the model is the record.

### Coalesced sum: maximalist root — `coalesced-maximalist-root`

Model; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- Distinctness (signature Σ) (`distinctness-signature-r`)
- Actuality (`actuality`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)

Violates:

- Strong Possibility (pure) (`strong-possibility-r`)
- ND (`distinctness-necessary-r`)

Unknown in this model: All individuals fundamental (`all-individuals-fundamental`), Atomicity (`atomicity-r`), Atomicity (type t) (`atomicity-t`), Atomlessness (`atomlessness`), BF (`barcan-r`), BF (type t) (`barcan-t`), Boolean Completeness (`boolean-completeness-r`), Boolean Completeness (type t) (`boolean-completeness-t`), Functionality (`functionality-r`), Fundamental Possibility (`fundamental-possibility-r`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), □BF (type t) (`necessary-barcan-t`), Possibility+ (`possibility-plus-r`), B for pure sentences (`pure-b-r`), Relational Choice (`relational-choice-r`), Rigid Comprehension (`rigid-comprehension-r`), Strong Possibility (signature Σ) (`strong-possibility-signature-r`), Tractarianism (`tractarianism-r`)

Construction.

Take a coalesced sum of a set of source action models complete for C in the fixed signature, evaluated at the new root. See Definition E.2 for the construction; the singleton root proposition witnesses Actuality. The p. 83 discussion supplies the distinctness-preserving collapse and the obstruction to Strong Possibility.

Notes. The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

Revisions:

- **2026-09-17** (OpenAI Codex (GPT-6)) — Adopted the source’s relational type system at the user’s request. The cited construction now directly supplies the recorded model; the former type-extension obligation is removed. Now satisfies: Distinctness (signature Σ), Actuality, Distinctness-preserving collapse. Now violates: Strong Possibility (pure), ND.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Theorem 3.26, §§3.6, pp. 62–64; Appendix E, pp. 80–83; §2.6, p. 41.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Theorem 3.26, §§3.6, pp. 62–64; Appendix E, pp. 80–83; §2.6, p. 41

Record: `topics/classicism/models/coalesced-maximalist-root.yaml`.

### Coalesced sum: singleton individual root — `coalesced-single-individual-root`

Conjectured model; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- Possibility+ (`possibility-plus-r`)
- Actuality (`actuality`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)

Violates:

- Infinity (type e) (`infinity-e`)
- Strong Possibility (pure) (`strong-possibility-r`)

Unknown in this model: nothing; every principle is settled.

Construction.

Use the alternative coalesced-sum root with a singleton e-domain and no type-e constants; the source also describes the analogous chosen-constant root. The displayed package concerns the pure schemata.

Notes. The source establishes the displayed package in the pure language. The topic also fixes nonlogical constants, including individual constants. An expansion of this particular singleton-root construction to that signature preserving the listed assertions still needs to be supplied; its conjectured status concerns only that expansion. See Appendix E, p. 83 for the distinction between a singleton root without individual constants and the alternative root indexed by individual constants.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, pp. 41–42 and n. 61; Appendix E, p. 83.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.6, pp. 41–42 and n. 61; Appendix E, p. 83

Record: `topics/classicism/models/coalesced-single-individual-root.yaml`.

### Finite-support action model: dyadic roundings of N — `finite-support-dyadic-roundings`

Model; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- Atomicity (`atomicity-r`)
- Actuality (`actuality`)
- No Pure Contingency (`no-pure-contingency-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Actuality (`necessary-actuality`)

Violates:

- ND (`distinctness-necessary-r`)
- BF (`barcan-r`)
- Boolean Completeness (`boolean-completeness-r`)
- Rigid Comprehension (`rigid-comprehension-r`)

Unknown in this model: All individuals fundamental (`all-individuals-fundamental`), BF (type t) (`barcan-t`), Boolean Completeness (type t) (`boolean-completeness-t`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), Logical Necessity (`logical-necessity-r`), □BF (type t) (`necessary-barcan-t`), Relational Choice (`relational-choice-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

Construction.

The finite-support model in Part 7, evaluated at its sole object N. See the indicated construction. Negations in the source mean failure at some type: note 92 locates atomicity failures at t, ND/BF failures at e, and the displayed completeness failures at et.

Notes. The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

Revisions:

- **2026-09-17** (OpenAI Codex (GPT-6)) — Adopted the source’s relational type system at the user’s request. The cited construction now directly supplies the recorded model; the former type-extension obligation is removed. Now satisfies: Atomicity, Actuality, No Pure Contingency, □Atomicity, □Actuality. Now violates: ND, BF, Boolean Completeness, Rigid Comprehension.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(7), pp. 74–75; construction p. 78, Part 7; p. 79 (No Pure Contingency).

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Appendix D, Proposition D.5(7), pp. 74–75; construction p. 78, Part 7; p. 79 (No Pure Contingency)

Record: `topics/classicism/models/finite-support-dyadic-roundings.yaml`.

### Finite-support action model: identity-or-collapse monotone surjections — `finite-support-identity-or-collapse-surjections`

Model; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- Actuality (`actuality`)
- BF (`barcan-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- □Actuality (`necessary-actuality`)
- □BF (`necessary-barcan-r`)

Violates:

- ND (`distinctness-necessary-r`)
- Atomicity (`atomicity-r`)
- Boolean Completeness (`boolean-completeness-r`)
- Rigid Comprehension (`rigid-comprehension-r`)

Unknown in this model: All individuals fundamental (`all-individuals-fundamental`), Atomicity (type t) (`atomicity-t`), Atomlessness (`atomlessness`), Boolean Completeness (type t) (`boolean-completeness-t`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), Logical Necessity (`logical-necessity-r`), Relational Choice (`relational-choice-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

Construction.

The finite-support model in Part 5, evaluated at its sole object N. See the indicated construction. Negations in the source mean failure at some type: note 92 locates atomicity failures at t, ND/BF failures at e, and the displayed completeness failures at et.

Notes. The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

Revisions:

- **2026-09-17** (OpenAI Codex (GPT-6)) — Adopted the source’s relational type system at the user’s request. The cited construction now directly supplies the recorded model; the former type-extension obligation is removed. Now satisfies: Actuality, BF, No Pure Contingency, □Actuality, □BF. Now violates: ND, Atomicity, Boolean Completeness, Rigid Comprehension.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(5), pp. 74–75; construction p. 78, Part 5; p. 79 (No Pure Contingency).

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Appendix D, Proposition D.5(5), pp. 74–75; construction p. 78, Part 5; p. 79 (No Pure Contingency)

Record: `topics/classicism/models/finite-support-identity-or-collapse-surjections.yaml`.

### Finite-support action model: identity-or-collapse monotone maps — `finite-support-identity-or-collapse`

Model; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- Actuality (`actuality`)
- No Pure Contingency (`no-pure-contingency-r`)
- □Actuality (`necessary-actuality`)

Violates:

- ND (`distinctness-necessary-r`)
- Atomicity (`atomicity-r`)
- BF (`barcan-r`)
- Boolean Completeness (`boolean-completeness-r`)
- Rigid Comprehension (`rigid-comprehension-r`)

Unknown in this model: All individuals fundamental (`all-individuals-fundamental`), Atomicity (type t) (`atomicity-t`), Atomlessness (`atomlessness`), BF (type t) (`barcan-t`), Boolean Completeness (type t) (`boolean-completeness-t`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), Logical Necessity (`logical-necessity-r`), □BF (type t) (`necessary-barcan-t`), Relational Choice (`relational-choice-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

Construction.

The finite-support model in Part 4, evaluated at its sole object N. See the indicated construction. Negations in the source mean failure at some type: note 92 locates atomicity failures at t, ND/BF failures at e, and the displayed completeness failures at et.

Notes. The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

Revisions:

- **2026-09-17** (OpenAI Codex (GPT-6)) — Adopted the source’s relational type system at the user’s request. The cited construction now directly supplies the recorded model; the former type-extension obligation is removed. Now satisfies: Actuality, No Pure Contingency, □Actuality. Now violates: ND, Atomicity, BF, Boolean Completeness, Rigid Comprehension.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(4), pp. 74–75; construction p. 78, Part 4; p. 79 (No Pure Contingency).

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Appendix D, Proposition D.5(4), pp. 74–75; construction p. 78, Part 4; p. 79 (No Pure Contingency)

Record: `topics/classicism/models/finite-support-identity-or-collapse.yaml`.

### Finite-support action model: monotone maps of N — `finite-support-monotone-maps`

Model; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- No Pure Contingency (`no-pure-contingency-r`)
- Atomlessness (`atomlessness`)

Violates:

- ND (`distinctness-necessary-r`)
- Atomicity (`atomicity-r`)
- Actuality (`actuality`)
- BF (`barcan-r`)
- Boolean Completeness (`boolean-completeness-r`)
- Rigid Comprehension (`rigid-comprehension-r`)

Unknown in this model: All individuals fundamental (`all-individuals-fundamental`), BF (type t) (`barcan-t`), Boolean Completeness (type t) (`boolean-completeness-t`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Inextensible Comprehension (`inextensible-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), Logical Necessity (`logical-necessity-r`), □BF (type t) (`necessary-barcan-t`), Relational Choice (`relational-choice-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

Construction.

The finite-support model in Part 3, evaluated at its sole object N. See the indicated construction. Negations in the source mean failure at some type: note 92 locates atomicity failures at t, ND/BF failures at e, and the displayed completeness failures at et.

Notes. The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

Revisions:

- **2026-09-17** (OpenAI Codex (GPT-6)) — Adopted the source’s relational type system at the user’s request. The cited construction now directly supplies the recorded model; the former type-extension obligation is removed. Now satisfies: No Pure Contingency, Atomlessness. Now violates: ND, Atomicity, Actuality, BF, Boolean Completeness, Rigid Comprehension.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(3), pp. 74–75; construction p. 77; p. 79 (No Pure Contingency).

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Appendix D, Proposition D.5(3), pp. 74–75; construction p. 77; p. 79 (No Pure Contingency)

Record: `topics/classicism/models/finite-support-monotone-maps.yaml`.

### Finite-support action model: monotone surjections of N — `finite-support-monotone-surjections`

Model; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- BF (`barcan-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- □BF (`necessary-barcan-r`)
- Atomlessness (`atomlessness`)

Violates:

- ND (`distinctness-necessary-r`)
- Atomicity (`atomicity-r`)
- Actuality (`actuality`)
- Boolean Completeness (`boolean-completeness-r`)
- Rigid Comprehension (`rigid-comprehension-r`)

Unknown in this model: All individuals fundamental (`all-individuals-fundamental`), Boolean Completeness (type t) (`boolean-completeness-t`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Inextensible Comprehension (`inextensible-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), Logical Necessity (`logical-necessity-r`), Relational Choice (`relational-choice-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

Construction.

The finite-support model in Part 2, evaluated at its sole object N. See the indicated construction. Negations in the source mean failure at some type: note 92 locates atomicity failures at t, ND/BF failures at e, and the displayed completeness failures at et.

Notes. The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

Revisions:

- **2026-09-17** (OpenAI Codex (GPT-6)) — Adopted the source’s relational type system at the user’s request. The cited construction now directly supplies the recorded model; the former type-extension obligation is removed. Now satisfies: BF, No Pure Contingency, □BF, Atomlessness. Now violates: ND, Atomicity, Actuality, Boolean Completeness, Rigid Comprehension.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(2), pp. 74–75; construction pp. 76–77; p. 79 (No Pure Contingency).

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Appendix D, Proposition D.5(2), pp. 74–75; construction pp. 76–77; p. 79 (No Pure Contingency)

Record: `topics/classicism/models/finite-support-monotone-surjections.yaml`.

### Finite-support action model: permutations of N — `finite-support-permutations`

Model; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- ND (`distinctness-necessary-r`)
- BF (`barcan-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- □ND (`necessary-distinctness-necessary-r`)
- □BF (`necessary-barcan-r`)
- Atomlessness (`atomlessness`)

Violates:

- Atomicity (`atomicity-r`)
- Actuality (`actuality`)
- Boolean Completeness (`boolean-completeness-r`)
- Rigid Comprehension (`rigid-comprehension-r`)

Unknown in this model: All individuals fundamental (`all-individuals-fundamental`), Boolean Completeness (type t) (`boolean-completeness-t`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Inextensible Comprehension (`inextensible-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), Logical Necessity (`logical-necessity-r`), Relational Choice (`relational-choice-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

Construction.

The finite-support model in Part 1, evaluated at its sole object N. See the indicated construction. Negations in the source mean failure at some type: note 92 locates atomicity failures at t, ND/BF failures at e, and the displayed completeness failures at et.

Notes. The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

Revisions:

- **2026-09-17** (OpenAI Codex (GPT-6)) — Adopted the source’s relational type system at the user’s request. The cited construction now directly supplies the recorded model; the former type-extension obligation is removed. Now satisfies: ND, BF, No Pure Contingency, □ND, □BF, Atomlessness. Now violates: Atomicity, Actuality, Boolean Completeness, Rigid Comprehension.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(1), pp. 74–75; construction pp. 75–76; p. 79 (No Pure Contingency).

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Appendix D, Proposition D.5(1), pp. 74–75; construction pp. 75–76; p. 79 (No Pure Contingency)

Record: `topics/classicism/models/finite-support-permutations.yaml`.

### Finite-support action model: qualitative contrast — `finite-support-qualitative-contrast`

Model; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- □ND (`necessary-distinctness-necessary-r`)
- Actuality (`actuality`)

Violates:

- □Actuality (`necessary-actuality`)
- Atomicity (`atomicity-r`)

Unknown in this model: All individuals fundamental (`all-individuals-fundamental`), Atomlessness (`atomlessness`), Converse Witnessed Possibility (`converse-witnessed-possibility-r`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Functional Choice (`functional-choice-r`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), Logical Necessity (`logical-necessity-r`), No Pure Contingency (`no-pure-contingency-r`), Relational Choice (`relational-choice-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

Construction.

Evaluate at W0 in the two-copy permutation category with the extra condition on propositional intensions. The source gives C5 and Actuality at W0, with Actuality failing at W1.

Notes. The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

Revisions:

- **2026-09-17** (OpenAI Codex (GPT-6)) — Adopted the source’s relational type system at the user’s request. The cited construction now directly supplies the recorded model; the former type-extension obligation is removed. Now satisfies: □ND, Actuality. Now violates: □Actuality, Atomicity.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, final construction (two copies of N).

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Appendix D, p. 79, final construction (two copies of N)

Record: `topics/classicism/models/finite-support-qualitative-contrast.yaml`.

### Finite-support action model: truncated shifts of N — `finite-support-truncated-shifts`

Model; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- Atomicity (`atomicity-r`)
- Actuality (`actuality`)
- BF (`barcan-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Actuality (`necessary-actuality`)
- □BF (`necessary-barcan-r`)

Violates:

- ND (`distinctness-necessary-r`)
- Boolean Completeness (`boolean-completeness-r`)
- Rigid Comprehension (`rigid-comprehension-r`)

Unknown in this model: All individuals fundamental (`all-individuals-fundamental`), Boolean Completeness (type t) (`boolean-completeness-t`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), Logical Necessity (`logical-necessity-r`), Relational Choice (`relational-choice-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

Construction.

The finite-support model in Part 8, evaluated at its sole object N. See the indicated construction. Negations in the source mean failure at some type: note 92 locates atomicity failures at t, ND/BF failures at e, and the displayed completeness failures at et.

Notes. The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

Revisions:

- **2026-09-17** (OpenAI Codex (GPT-6)) — Adopted the source’s relational type system at the user’s request. The cited construction now directly supplies the recorded model; the former type-extension obligation is removed. Now satisfies: Atomicity, Actuality, BF, No Pure Contingency, □Atomicity, □Actuality, □BF. Now violates: ND, Boolean Completeness, Rigid Comprehension.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(8), pp. 74–75; construction pp. 78–79, Part 8; p. 79 (No Pure Contingency).

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Appendix D, Proposition D.5(8), pp. 74–75; construction pp. 78–79, Part 8; p. 79 (No Pure Contingency)

Record: `topics/classicism/models/finite-support-truncated-shifts.yaml`.

### Finite-support action model: truncations of N — `finite-support-truncations`

Model; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- Atomicity (`atomicity-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- □Atomicity (`necessary-atomicity-r`)

Violates:

- ND (`distinctness-necessary-r`)
- Actuality (`actuality`)
- BF (`barcan-r`)
- Boolean Completeness (`boolean-completeness-r`)
- Rigid Comprehension (`rigid-comprehension-r`)

Unknown in this model: All individuals fundamental (`all-individuals-fundamental`), BF (type t) (`barcan-t`), Boolean Completeness (type t) (`boolean-completeness-t`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Inextensible Comprehension (`inextensible-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), Logical Necessity (`logical-necessity-r`), □BF (type t) (`necessary-barcan-t`), Relational Choice (`relational-choice-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

Construction.

The finite-support model in Part 6, evaluated at its sole object N. See the indicated construction. Negations in the source mean failure at some type: note 92 locates atomicity failures at t, ND/BF failures at e, and the displayed completeness failures at et.

Notes. The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

Revisions:

- **2026-09-17** (OpenAI Codex (GPT-6)) — Adopted the source’s relational type system at the user’s request. The cited construction now directly supplies the recorded model; the former type-extension obligation is removed. Now satisfies: Atomicity, No Pure Contingency, □Atomicity. Now violates: ND, Actuality, BF, Boolean Completeness, Rigid Comprehension.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(6), pp. 74–75; construction p. 78, Part 6; p. 79 (No Pure Contingency).

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Appendix D, Proposition D.5(6), pp. 74–75; construction p. 78, Part 6; p. 79 (No Pure Contingency)

Record: `topics/classicism/models/finite-support-truncations.yaml`.

### Finite-support action model: N and singleton, all maps — `finite-support-two-object-all-maps`

Model; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- BF (`barcan-r`)

Violates:

- □BF (`necessary-barcan-r`)

Unknown in this model: Actual Profile (`actual-profile-r`), Actuality (`actuality`), All individuals fundamental (`all-individuals-fundamental`), Atomicity (`atomicity-r`), Atomicity (type t) (`atomicity-t`), Atomlessness (`atomlessness`), Boolean Completeness (`boolean-completeness-r`), Boolean Completeness (type t) (`boolean-completeness-t`), Converse Witnessed Possibility (`converse-witnessed-possibility-r`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Distinctness (pure) (`distinctness-schema-r`), Distinctness (signature Σ) (`distinctness-signature-r`), Fundamental Possibility (`fundamental-possibility-r`), Inextensible Comprehension (`inextensible-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), Logical Necessity (`logical-necessity-r`), □Actuality (`necessary-actuality`), □Atomicity (`necessary-atomicity-r`), □BF (type t) (`necessary-barcan-t`), □Boolean Completeness (`necessary-boolean-completeness-r`), No Pure Contingency (`no-pure-contingency-r`), Persistent Comprehension (`persistent-comprehension-r`), Possibility+ (`possibility-plus-r`), Possibility (pure) (`possibility-schema-r`), Possibility (signature Σ) (`possibility-signature-r`), B for pure sentences (`pure-b-r`), Relational Choice (`relational-choice-r`), Separated Structure (`separated-structure-r`), Strong Possibility (pure) (`strong-possibility-r`), Strong Possibility (signature Σ) (`strong-possibility-signature-r`), Witnessed Possibility (`witnessed-possibility-r`)

Construction.

Use N and {0} with all maps between them, evaluated at N. BF holds there and fails at the accessible singleton; the paragraph gives the type-e failure.

Notes. The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

Revisions:

- **2026-09-17** (OpenAI Codex (GPT-6)) — Adopted the source’s relational type system at the user’s request. The cited construction now directly supplies the recorded model; the former type-extension obligation is removed. Now satisfies: BF. Now violates: □BF.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, paragraph beginning “One particularly interesting result”.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — Appendix D, p. 79, paragraph beginning “One particularly interesting result”

Record: `topics/classicism/models/finite-support-two-object-all-maps.yaml`.

### Full Henkin model: singleton individual domain — `full-henkin-singleton-base`

Model; source **Misc.**; produced by OpenAI Codex (GPT-6), 17 September 2026; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- Fregean Axiom (`fregean-axiom`)
- Functionality (`functionality-r`)
- Modalized Functionality (`modalized-functionality-r`)
- Plenitude (`plenitude-r`)
- Functional Choice (`functional-choice-r`)
- Relational Choice (`relational-choice-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)

Violates:

- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- Atomlessness (`atomlessness`)
- Possibility (pure) (`possibility-schema-r`)

Unknown in this model: All individuals fundamental (`all-individuals-fundamental`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Logical Necessity (`logical-necessity-r`), □Extensionality (`necessary-extensionality-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

Construction.

Use the ordinary full Henkin interpretation: D_e is a singleton, D_t={0,1}, and every admitted function type contains all functions between its domains. Domains are finite by induction on types, so every serial relation has a functional subrelation and, when the output type is relational, a selecting operation. Equality is genuine equality and Box is the identity on truth values. These facts verify the listed positive assertions. The two finite base domains refute the infinity assertions, top is an atom, and the possible existence of two individuals is false although its pure sentence is C-consistent.

Notes. Explicit specialization of the source’s standard Henkin construction to a singleton individual domain. No independent checking or formal verification is claimed.

Revisions:

- **2026-09-17** (OpenAI Codex (GPT-6)) — Restricted the example and its recorded choice properties to the map’s relational type system at the user’s request. Now satisfies: Fregean Axiom, Functionality, Modalized Functionality, Plenitude, Functional Choice, Relational Choice, No Pure Contingency, Distinctness-preserving collapse.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.2, Definition 3.6 and Proposition 3.7, pp. 47–48; §1.4, n. 18, p. 16.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §3.2, Definition 3.6 and Proposition 3.7, pp. 47–48; §1.4, n. 18, p. 16

Record: `topics/classicism/models/full-henkin-singleton-base.yaml`.

### Full action model: idempotent two-arrow monoid — `full-idempotent-monoid`

Model; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Actuality (`necessary-actuality`)
- No Pure Contingency (`no-pure-contingency-r`)

Violates:

- ND (type t) (`distinctness-necessary-t`)
- BF (type t) (`barcan-t`)
- Fregean Axiom (`fregean-axiom`)

Unknown in this model: All individuals fundamental (`all-individuals-fundamental`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), Logical Necessity (`logical-necessity-r`), Relational Choice (`relational-choice-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

Construction.

The full model on {1,k} with k²=k, evaluated at its sole object. Refer to the cited paragraph for the four propositions and the failure witnesses.

Notes. The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

Revisions:

- **2026-09-17** (OpenAI Codex (GPT-6)) — Adopted the source’s relational type system at the user’s request. The cited construction now directly supplies the recorded model; the former type-extension obligation is removed. Now satisfies: □Rigid Comprehension, □Atomicity, □Actuality, No Pure Contingency. Now violates: ND (type t), BF (type t), Fregean Axiom.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, first paragraph; p. 61 (full-model principles).

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §3.5, p. 59, first paragraph; p. 61 (full-model principles)

Record: `topics/classicism/models/full-idempotent-monoid.yaml`.

### Full action model: two-element group — `full-involution-group`

Model; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Actuality (`necessary-actuality`)
- □ND (`necessary-distinctness-necessary-r`)
- No Pure Contingency (`no-pure-contingency-r`)

Violates:

- Fregean Axiom (`fregean-axiom`)

Unknown in this model: All individuals fundamental (`all-individuals-fundamental`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Functional Choice (`functional-choice-r`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), Logical Necessity (`logical-necessity-r`), Relational Choice (`relational-choice-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

Construction.

Change the two-arrow multiplication to k²=1; evaluate at the sole object. The source establishes boxed ND and exhibits four propositions.

Notes. The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

Revisions:

- **2026-09-17** (OpenAI Codex (GPT-6)) — Adopted the source’s relational type system at the user’s request. The cited construction now directly supplies the recorded model; the former type-extension obligation is removed. Now satisfies: □Rigid Comprehension, □Atomicity, □Actuality, □ND, No Pure Contingency. Now violates: Fregean Axiom.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, second paragraph; p. 61.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §3.5, p. 59, second paragraph; p. 61

Record: `topics/classicism/models/full-involution-group.yaml`.

### Full action model: surjections of an infinite set — `full-surjection-monoid`

Model; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Actuality (`necessary-actuality`)
- □BF (`necessary-barcan-r`)
- No Pure Contingency (`no-pure-contingency-r`)

Violates:

- ND (type t) (`distinctness-necessary-t`)

Unknown in this model: All individuals fundamental (`all-individuals-fundamental`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), Logical Necessity (`logical-necessity-r`), Relational Choice (`relational-choice-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

Construction.

Use the monoid of surjections of an infinite set and a surjective individual action, at its sole object. The source cites Bacon 2020, Proposition A.3 for the higher-type surjectivity argument.

Notes. The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

Revisions:

- **2026-09-17** (OpenAI Codex (GPT-6)) — Adopted the source’s relational type system at the user’s request. The cited construction now directly supplies the recorded model; the former type-extension obligation is removed. Now satisfies: □Rigid Comprehension, □Atomicity, □Actuality, □BF, No Pure Contingency. Now violates: ND (type t).

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §3.5, p. 59, third paragraph; p. 61 and n. 84
- **Proof: Logical Combinatorialism.** Bacon, Andrew (2020). Logical Combinatorialism. Philosophical Review 129(4), 537–589. As cited in Classicism, §§2.5 and 3.5. — Proposition A.3, as cited in Classicism p. 59

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

### Full action model: two-object chain — `full-two-object-chain`

Model; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Actuality (`necessary-actuality`)

Violates:

- Fregean Axiom (`fregean-axiom`)
- No Pure Contingency (`no-pure-contingency-r`)

Unknown in this model: All individuals fundamental (`all-individuals-fundamental`), BF (`barcan-r`), BF (type t) (`barcan-t`), ND (`distinctness-necessary-r`), ND (type t) (`distinctness-necessary-t`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Functional Choice (`functional-choice-r`), Functionality (`functionality-r`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), B (`modal-b`), 5 (`modal-five`), □BF (`necessary-barcan-r`), □BF (type t) (`necessary-barcan-t`), □ND (`necessary-distinctness-necessary-r`), □ND (type t) (`necessary-distinctness-necessary-t`), □Functionality (`necessary-functionality-r`), □B (`necessary-modal-b`), □5 (`necessary-modal-five`), □Plenitude (`necessary-plenitude-r`), □Tractarianism (`necessary-tractarianism-r`), Plenitude (`plenitude-r`), B for pure sentences (`pure-b-r`), Relational Choice (`relational-choice-r`), Separated Structure (`separated-structure-r`), Tractarianism (`tractarianism-r`), Witnessed Possibility (`witnessed-possibility-r`)

Construction.

Use two objects with one nonidentity arrow from W0 to W1, evaluated at W0. The source makes the Fregean Axiom false at W0 and true at W1.

Notes. The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

Revisions:

- **2026-09-17** (OpenAI Codex (GPT-6)) — Adopted the source’s relational type system at the user’s request. The cited construction now directly supplies the recorded model; the former type-extension obligation is removed. Now satisfies: □Rigid Comprehension, □Atomicity, □Actuality. Now violates: Fregean Axiom, No Pure Contingency.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fourth paragraph; p. 61.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §3.5, p. 59, fourth paragraph; p. 61

Record: `topics/classicism/models/full-two-object-chain.yaml`.

### Full action model: two-object retract — `full-two-object-retract`

Model; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Actuality (`necessary-actuality`)
- ND (type t) (`distinctness-necessary-t`)
- B for pure sentences (`pure-b-r`)

Violates:

- □ND (type t) (`necessary-distinctness-necessary-t`)
- No Pure Contingency (`no-pure-contingency-r`)

Unknown in this model: All individuals fundamental (`all-individuals-fundamental`), BF (type t) (`barcan-t`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Functional Choice (`functional-choice-r`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), □BF (type t) (`necessary-barcan-t`), Relational Choice (`relational-choice-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

Construction.

Use the source’s category with h:W0→W1, j:W1→W0 and k:W1→W1, evaluated at W0. ND at t holds there and fails at W1. Only the type-t ND assertion is recorded.

Notes. The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

Revisions:

- **2026-09-17** (OpenAI Codex (GPT-6)) — Adopted the source’s relational type system at the user’s request. The cited construction now directly supplies the recorded model; the former type-extension obligation is removed. Now satisfies: □Rigid Comprehension, □Atomicity, □Actuality, ND (type t), B for pure sentences. Now violates: □ND (type t), No Pure Contingency.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fifth paragraph and n. 81; p. 61.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §3.5, p. 59, fifth paragraph and n. 81; p. 61

Record: `topics/classicism/models/full-two-object-retract.yaml`.

### Henkin model: base without a choice function — `henkin-without-relational-choice`

Model; source **Classicism (2023 draft)**; produced by Andrew Bacon and Cian Dorr; recorded by OpenAI Codex (GPT-6), 17 September 2026; checked by nobody; 2026-09-17.

Satisfies:

- Extensionality (`extensionality-r`)

Violates:

- Relational Choice (`relational-choice-r`)

Unknown in this model: All individuals fundamental (`all-individuals-fundamental`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Infinity (type e) (`infinity-e`), Logical Necessity (`logical-necessity-r`), □Extensionality (`necessary-extensionality-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

Construction.

The source’s relative-consistency construction starts in a model of ZF without choice and uses the domain of a serial relation with no functional subrelation as its individual domain. Refer to note 46; its set-theoretic hypothesis is part of the construction.

Notes. The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

Revisions:

- **2026-09-17** (OpenAI Codex (GPT-6)) — Adopted the source’s relational type system at the user’s request. The cited construction now directly supplies the recorded model; the former type-extension obligation is removed. Now satisfies: Extensionality. Now violates: Relational Choice.

Sources:

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, n. 46, p. 32.

- **Proof: Classicism.** Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft. — §2.3, n. 46, p. 32

Record: `topics/classicism/models/henkin-without-relational-choice.yaml`.

## 6. Derived state

Computed from the proved records only, by the closure rules in `README.md`. Conjectures take no part. A missing entry means *not recorded*, not *false*.

### 6.1 Interderivable principles

- Actual Profile (`actual-profile-r`) ⇔ Actuality (`actuality`) ⇔ Persistent Comprehension (`persistent-comprehension-r`)
- BF (`barcan-r`) ⇔ Functionality (`functionality-r`) ⇔ Tractarianism (`tractarianism-r`)
- Broad Necessitism (`broad-necessitism-r`) ⇔ CBF (`converse-barcan-r`) ⇔ Existence (`existence-r`) ⇔ NI (`identity-necessary-r`) ⇔ Intensionality (`intensionality-r`) ⇔ 4 (`modal-four`) ⇔ K (`modal-k`) ⇔ T (`modal-t`) ⇔ Modalized Fregean Axiom (`modalized-fregean`) ⇔ Modalized Functionality (`modalized-functionality-r`) ⇔ Ordinary Comprehension (`ordinary-comprehension-r`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`) ⇔ No Pure Contingency (`no-pure-contingency-r`)
- ND (`distinctness-necessary-r`) ⇔ ND (type t) (`distinctness-necessary-t`) ⇔ B (`modal-b`) ⇔ 5 (`modal-five`)
- Distinctness (pure) (`distinctness-schema-r`) ⇔ Possibility (pure) (`possibility-schema-r`)
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇔ Possibility (signature Σ) (`possibility-signature-r`)
- Extensionality (`extensionality-r`) ⇔ Fregean Axiom (`fregean-axiom`) ⇔ □Fregean Axiom (`necessary-fregean-axiom`)
- □BF (`necessary-barcan-r`) ⇔ □Functionality (`necessary-functionality-r`) ⇔ □Tractarianism (`necessary-tractarianism-r`)
- □ND (`necessary-distinctness-necessary-r`) ⇔ □ND (type t) (`necessary-distinctness-necessary-t`) ⇔ □B (`necessary-modal-b`) ⇔ □5 (`necessary-modal-five`)

### 6.2 Settled single-premise implications (1110)

| From | To | Via |
| --- | --- | --- |
| Actual Profile | Actuality | `actual-profile-r-implies-actuality` |
| Actual Profile | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Actual Profile | CBF | `classicism-implies-converse-barcan-r` |
| Actual Profile | Existence | `classicism-implies-existence-r` |
| Actual Profile | NI | `classicism-implies-identity-necessary-r` |
| Actual Profile | Inextensible Comprehension | `actual-profile-r-implies-actuality`, `actuality-implies-inextensible-comprehension-r` |
| Actual Profile | Intensionality | `classicism-implies-intensionality-r` |
| Actual Profile | 4 | `classicism-implies-modal-four` |
| Actual Profile | K | `classicism-implies-modal-k` |
| Actual Profile | T | `classicism-implies-modal-t` |
| Actual Profile | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Actual Profile | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Actual Profile | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Actual Profile | Persistent Comprehension | `actual-profile-r-implies-actuality`, `actuality-implies-persistent-comprehension-r` |
| Actuality | Actual Profile | `actuality-implies-actual-profile-r` |
| Actuality | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Actuality | CBF | `classicism-implies-converse-barcan-r` |
| Actuality | Existence | `classicism-implies-existence-r` |
| Actuality | NI | `classicism-implies-identity-necessary-r` |
| Actuality | Inextensible Comprehension | `actuality-implies-inextensible-comprehension-r` |
| Actuality | Intensionality | `classicism-implies-intensionality-r` |
| Actuality | 4 | `classicism-implies-modal-four` |
| Actuality | K | `classicism-implies-modal-k` |
| Actuality | T | `classicism-implies-modal-t` |
| Actuality | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Actuality | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Actuality | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Actuality | Persistent Comprehension | `actuality-implies-persistent-comprehension-r` |
| All individuals fundamental | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| All individuals fundamental | CBF | `classicism-implies-converse-barcan-r` |
| All individuals fundamental | Existence | `classicism-implies-existence-r` |
| All individuals fundamental | NI | `classicism-implies-identity-necessary-r` |
| All individuals fundamental | Intensionality | `classicism-implies-intensionality-r` |
| All individuals fundamental | 4 | `classicism-implies-modal-four` |
| All individuals fundamental | K | `classicism-implies-modal-k` |
| All individuals fundamental | T | `classicism-implies-modal-t` |
| All individuals fundamental | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| All individuals fundamental | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| All individuals fundamental | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Atomicity | Atomicity (type t) | `atomicity-r-implies-atomicity-t` |
| Atomicity | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Atomicity | CBF | `classicism-implies-converse-barcan-r` |
| Atomicity | Existence | `classicism-implies-existence-r` |
| Atomicity | NI | `classicism-implies-identity-necessary-r` |
| Atomicity | Intensionality | `classicism-implies-intensionality-r` |
| Atomicity | 4 | `classicism-implies-modal-four` |
| Atomicity | K | `classicism-implies-modal-k` |
| Atomicity | T | `classicism-implies-modal-t` |
| Atomicity | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Atomicity | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Atomicity | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Atomicity (type t) | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Atomicity (type t) | CBF | `classicism-implies-converse-barcan-r` |
| Atomicity (type t) | Existence | `classicism-implies-existence-r` |
| Atomicity (type t) | NI | `classicism-implies-identity-necessary-r` |
| Atomicity (type t) | Intensionality | `classicism-implies-intensionality-r` |
| Atomicity (type t) | 4 | `classicism-implies-modal-four` |
| Atomicity (type t) | K | `classicism-implies-modal-k` |
| Atomicity (type t) | T | `classicism-implies-modal-t` |
| Atomicity (type t) | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Atomicity (type t) | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Atomicity (type t) | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Atomlessness | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Atomlessness | CBF | `classicism-implies-converse-barcan-r` |
| Atomlessness | Existence | `classicism-implies-existence-r` |
| Atomlessness | NI | `classicism-implies-identity-necessary-r` |
| Atomlessness | Intensionality | `classicism-implies-intensionality-r` |
| Atomlessness | 4 | `classicism-implies-modal-four` |
| Atomlessness | K | `classicism-implies-modal-k` |
| Atomlessness | T | `classicism-implies-modal-t` |
| Atomlessness | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Atomlessness | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Atomlessness | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| BF | BF (type t) | `barcan-r-implies-barcan-t` |
| BF | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| BF | CBF | `classicism-implies-converse-barcan-r` |
| BF | Existence | `classicism-implies-existence-r` |
| BF | Functionality | `barcan-r-implies-functionality-r` |
| BF | NI | `classicism-implies-identity-necessary-r` |
| BF | Intensionality | `classicism-implies-intensionality-r` |
| BF | 4 | `classicism-implies-modal-four` |
| BF | K | `classicism-implies-modal-k` |
| BF | T | `classicism-implies-modal-t` |
| BF | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| BF | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| BF | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| BF | Tractarianism | `barcan-r-implies-functionality-r`, `functionality-r-implies-tractarianism-r` |
| BF (type t) | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| BF (type t) | CBF | `classicism-implies-converse-barcan-r` |
| BF (type t) | Existence | `classicism-implies-existence-r` |
| BF (type t) | NI | `classicism-implies-identity-necessary-r` |
| BF (type t) | Intensionality | `classicism-implies-intensionality-r` |
| BF (type t) | 4 | `classicism-implies-modal-four` |
| BF (type t) | K | `classicism-implies-modal-k` |
| BF (type t) | T | `classicism-implies-modal-t` |
| BF (type t) | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| BF (type t) | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| BF (type t) | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Boolean Completeness | Boolean Completeness (type t) | `boolean-completeness-r-implies-boolean-completeness-t` |
| Boolean Completeness | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Boolean Completeness | CBF | `classicism-implies-converse-barcan-r` |
| Boolean Completeness | Existence | `classicism-implies-existence-r` |
| Boolean Completeness | NI | `classicism-implies-identity-necessary-r` |
| Boolean Completeness | Intensionality | `classicism-implies-intensionality-r` |
| Boolean Completeness | 4 | `classicism-implies-modal-four` |
| Boolean Completeness | K | `classicism-implies-modal-k` |
| Boolean Completeness | T | `classicism-implies-modal-t` |
| Boolean Completeness | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Boolean Completeness | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Boolean Completeness | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Boolean Completeness (type t) | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Boolean Completeness (type t) | CBF | `classicism-implies-converse-barcan-r` |
| Boolean Completeness (type t) | Existence | `classicism-implies-existence-r` |
| Boolean Completeness (type t) | NI | `classicism-implies-identity-necessary-r` |
| Boolean Completeness (type t) | Intensionality | `classicism-implies-intensionality-r` |
| Boolean Completeness (type t) | 4 | `classicism-implies-modal-four` |
| Boolean Completeness (type t) | K | `classicism-implies-modal-k` |
| Boolean Completeness (type t) | T | `classicism-implies-modal-t` |
| Boolean Completeness (type t) | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Boolean Completeness (type t) | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Boolean Completeness (type t) | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Broad Necessitism | CBF | `classicism-implies-converse-barcan-r` |
| Broad Necessitism | Existence | `classicism-implies-existence-r` |
| Broad Necessitism | NI | `classicism-implies-identity-necessary-r` |
| Broad Necessitism | Intensionality | `classicism-implies-intensionality-r` |
| Broad Necessitism | 4 | `classicism-implies-modal-four` |
| Broad Necessitism | K | `classicism-implies-modal-k` |
| Broad Necessitism | T | `classicism-implies-modal-t` |
| Broad Necessitism | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Broad Necessitism | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Broad Necessitism | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| CBF | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| CBF | Existence | `classicism-implies-existence-r` |
| CBF | NI | `classicism-implies-identity-necessary-r` |
| CBF | Intensionality | `classicism-implies-intensionality-r` |
| CBF | 4 | `classicism-implies-modal-four` |
| CBF | K | `classicism-implies-modal-k` |
| CBF | T | `classicism-implies-modal-t` |
| CBF | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| CBF | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| CBF | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Converse Witnessed Possibility | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Converse Witnessed Possibility | CBF | `classicism-implies-converse-barcan-r` |
| Converse Witnessed Possibility | Existence | `classicism-implies-existence-r` |
| Converse Witnessed Possibility | NI | `classicism-implies-identity-necessary-r` |
| Converse Witnessed Possibility | Intensionality | `classicism-implies-intensionality-r` |
| Converse Witnessed Possibility | 4 | `classicism-implies-modal-four` |
| Converse Witnessed Possibility | K | `classicism-implies-modal-k` |
| Converse Witnessed Possibility | T | `classicism-implies-modal-t` |
| Converse Witnessed Possibility | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Converse Witnessed Possibility | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Converse Witnessed Possibility | No Pure Contingency | `converse-witnessed-possibility-r-implies-no-pure-contingency-r` |
| Converse Witnessed Possibility | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Converse Witnessed Possibility | B for pure sentences | `converse-witnessed-possibility-r-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-pure-b-r` |
| ND | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| ND | CBF | `classicism-implies-converse-barcan-r` |
| ND | ND (type t) | `distinctness-necessary-r-implies-distinctness-necessary-t` |
| ND | Existence | `classicism-implies-existence-r` |
| ND | NI | `classicism-implies-identity-necessary-r` |
| ND | Intensionality | `classicism-implies-intensionality-r` |
| ND | B | `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b` |
| ND | 5 | `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-modal-five` |
| ND | 4 | `classicism-implies-modal-four` |
| ND | K | `classicism-implies-modal-k` |
| ND | T | `classicism-implies-modal-t` |
| ND | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| ND | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| ND | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| ND | B for pure sentences | `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r` |
| ND (type t) | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| ND (type t) | CBF | `classicism-implies-converse-barcan-r` |
| ND (type t) | ND | `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-distinctness-necessary-r` |
| ND (type t) | Existence | `classicism-implies-existence-r` |
| ND (type t) | NI | `classicism-implies-identity-necessary-r` |
| ND (type t) | Intensionality | `classicism-implies-intensionality-r` |
| ND (type t) | B | `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b` |
| ND (type t) | 5 | `distinctness-necessary-t-implies-modal-five` |
| ND (type t) | 4 | `classicism-implies-modal-four` |
| ND (type t) | K | `classicism-implies-modal-k` |
| ND (type t) | T | `classicism-implies-modal-t` |
| ND (type t) | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| ND (type t) | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| ND (type t) | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| ND (type t) | B for pure sentences | `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r` |
| Distinctness-preserving collapse | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Distinctness-preserving collapse | CBF | `classicism-implies-converse-barcan-r` |
| Distinctness-preserving collapse | Existence | `classicism-implies-existence-r` |
| Distinctness-preserving collapse | NI | `classicism-implies-identity-necessary-r` |
| Distinctness-preserving collapse | Intensionality | `classicism-implies-intensionality-r` |
| Distinctness-preserving collapse | 4 | `classicism-implies-modal-four` |
| Distinctness-preserving collapse | K | `classicism-implies-modal-k` |
| Distinctness-preserving collapse | T | `classicism-implies-modal-t` |
| Distinctness-preserving collapse | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Distinctness-preserving collapse | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Distinctness-preserving collapse | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Distinctness (pure) | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Distinctness (pure) | CBF | `classicism-implies-converse-barcan-r` |
| Distinctness (pure) | Existence | `classicism-implies-existence-r` |
| Distinctness (pure) | NI | `classicism-implies-identity-necessary-r` |
| Distinctness (pure) | Intensionality | `classicism-implies-intensionality-r` |
| Distinctness (pure) | 4 | `classicism-implies-modal-four` |
| Distinctness (pure) | K | `classicism-implies-modal-k` |
| Distinctness (pure) | T | `classicism-implies-modal-t` |
| Distinctness (pure) | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Distinctness (pure) | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Distinctness (pure) | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Distinctness (pure) | Possibility (pure) | `distinctness-schema-r-implies-possibility-schema-r` |
| Distinctness (signature Σ) | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Distinctness (signature Σ) | CBF | `classicism-implies-converse-barcan-r` |
| Distinctness (signature Σ) | Distinctness (pure) | `distinctness-signature-r-implies-distinctness-schema-r` |
| Distinctness (signature Σ) | Existence | `classicism-implies-existence-r` |
| Distinctness (signature Σ) | NI | `classicism-implies-identity-necessary-r` |
| Distinctness (signature Σ) | Intensionality | `classicism-implies-intensionality-r` |
| Distinctness (signature Σ) | 4 | `classicism-implies-modal-four` |
| Distinctness (signature Σ) | K | `classicism-implies-modal-k` |
| Distinctness (signature Σ) | T | `classicism-implies-modal-t` |
| Distinctness (signature Σ) | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Distinctness (signature Σ) | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Distinctness (signature Σ) | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Distinctness (signature Σ) | Possibility (pure) | `distinctness-signature-r-implies-distinctness-schema-r`, `distinctness-schema-r-implies-possibility-schema-r` |
| Distinctness (signature Σ) | Possibility (signature Σ) | `distinctness-signature-r-implies-possibility-signature-r` |
| Distinctness (signature Σ) | Separated Structure | `distinctness-signature-r-implies-separated-structure-r` |
| Distinctness (signature Σ) | Witnessed Possibility | `distinctness-signature-r-implies-possibility-signature-r`, `possibility-signature-r-implies-witnessed-possibility-r` |
| Existence | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Existence | CBF | `classicism-implies-converse-barcan-r` |
| Existence | NI | `classicism-implies-identity-necessary-r` |
| Existence | Intensionality | `classicism-implies-intensionality-r` |
| Existence | 4 | `classicism-implies-modal-four` |
| Existence | K | `classicism-implies-modal-k` |
| Existence | T | `classicism-implies-modal-t` |
| Existence | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Existence | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Existence | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Extensionality | Actual Profile | `extensionality-r-implies-actuality`, `actuality-implies-actual-profile-r` |
| Extensionality | Actuality | `extensionality-r-implies-actuality` |
| Extensionality | Atomicity | `extensionality-r-implies-atomicity-r` |
| Extensionality | Atomicity (type t) | `extensionality-r-implies-atomicity-r`, `atomicity-r-implies-atomicity-t` |
| Extensionality | BF | `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf` |
| Extensionality | BF (type t) | `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-barcan-t` |
| Extensionality | Boolean Completeness | `extensionality-r-implies-boolean-completeness-r` |
| Extensionality | Boolean Completeness (type t) | `extensionality-r-implies-boolean-completeness-r`, `boolean-completeness-r-implies-boolean-completeness-t` |
| Extensionality | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Extensionality | CBF | `classicism-implies-converse-barcan-r` |
| Extensionality | Converse Witnessed Possibility | `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-converse-witnessed-possibility-r` |
| Extensionality | ND | `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-distinctness-necessary-r` |
| Extensionality | ND (type t) | `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t`, `necessary-distinctness-necessary-t-implies-distinctness-necessary-t` |
| Extensionality | Existence | `classicism-implies-existence-r` |
| Extensionality | Fregean Axiom | `extensionality-r-implies-fregean-axiom` |
| Extensionality | Functionality | `extensionality-r-implies-functionality-r` |
| Extensionality | NI | `classicism-implies-identity-necessary-r` |
| Extensionality | Inextensible Comprehension | `extensionality-r-implies-rigid-comprehension-r`, `rigid-comprehension-r-implies-inextensible-comprehension-r` |
| Extensionality | Intensionality | `classicism-implies-intensionality-r` |
| Extensionality | B | `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-modal-five`, `modal-five-implies-modal-b` |
| Extensionality | 5 | `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-modal-five` |
| Extensionality | 4 | `classicism-implies-modal-four` |
| Extensionality | K | `classicism-implies-modal-k` |
| Extensionality | T | `classicism-implies-modal-t` |
| Extensionality | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Extensionality | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Extensionality | □Actuality | `extensionality-r-implies-atomicity-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `atomicity-and-bf-imply-necessary-actuality` |
| Extensionality | □Atomicity | `extensionality-r-implies-atomicity-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-atomicity` |
| Extensionality | □BF | `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r` |
| Extensionality | □BF (type t) | `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-barcan-t` |
| Extensionality | □Boolean Completeness | `extensionality-r-implies-atomicity-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-completeness` |
| Extensionality | □ND | `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r` |
| Extensionality | □ND (type t) | `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t` |
| Extensionality | □Fregean Axiom | `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-fregean-axiom` |
| Extensionality | □Functionality | `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r` |
| Extensionality | □B | `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-necessary-modal-b` |
| Extensionality | □5 | `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five` |
| Extensionality | □Plenitude | `extensionality-r-implies-atomicity-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-plenitude` |
| Extensionality | □Rigid Comprehension | `extensionality-r-implies-atomicity-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-rigid-comprehension` |
| Extensionality | □Tractarianism | `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r`, `necessary-functionality-r-implies-necessary-tractarianism-r` |
| Extensionality | No Pure Contingency | `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-no-pure-contingency-r` |
| Extensionality | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Extensionality | Persistent Comprehension | `extensionality-r-implies-rigid-comprehension-r`, `rigid-comprehension-r-implies-persistent-comprehension-r` |
| Extensionality | Plenitude | `extensionality-r-implies-plenitude-r` |
| Extensionality | B for pure sentences | `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-pure-b-r` |
| Extensionality | Rigid Comprehension | `extensionality-r-implies-rigid-comprehension-r` |
| Extensionality | Tractarianism | `extensionality-r-implies-functionality-r`, `functionality-r-implies-tractarianism-r` |
| Fregean Axiom | Actual Profile | `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-actuality`, `actuality-implies-actual-profile-r` |
| Fregean Axiom | Actuality | `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-actuality` |
| Fregean Axiom | Atomicity | `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-atomicity-r` |
| Fregean Axiom | Atomicity (type t) | `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-atomicity-r`, `atomicity-r-implies-atomicity-t` |
| Fregean Axiom | BF | `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf` |
| Fregean Axiom | BF (type t) | `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-barcan-t` |
| Fregean Axiom | Boolean Completeness | `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-boolean-completeness-r` |
| Fregean Axiom | Boolean Completeness (type t) | `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-boolean-completeness-r`, `boolean-completeness-r-implies-boolean-completeness-t` |
| Fregean Axiom | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Fregean Axiom | CBF | `classicism-implies-converse-barcan-r` |
| Fregean Axiom | Converse Witnessed Possibility | `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-converse-witnessed-possibility-r` |
| Fregean Axiom | ND | `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-distinctness-necessary-r` |
| Fregean Axiom | ND (type t) | `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t`, `necessary-distinctness-necessary-t-implies-distinctness-necessary-t` |
| Fregean Axiom | Existence | `classicism-implies-existence-r` |
| Fregean Axiom | Extensionality | `fregean-axiom-implies-extensionality-r` |
| Fregean Axiom | Functionality | `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-functionality-r` |
| Fregean Axiom | NI | `classicism-implies-identity-necessary-r` |
| Fregean Axiom | Inextensible Comprehension | `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-rigid-comprehension-r`, `rigid-comprehension-r-implies-inextensible-comprehension-r` |
| Fregean Axiom | Intensionality | `classicism-implies-intensionality-r` |
| Fregean Axiom | B | `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-modal-five`, `modal-five-implies-modal-b` |
| Fregean Axiom | 5 | `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-modal-five` |
| Fregean Axiom | 4 | `classicism-implies-modal-four` |
| Fregean Axiom | K | `classicism-implies-modal-k` |
| Fregean Axiom | T | `classicism-implies-modal-t` |
| Fregean Axiom | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Fregean Axiom | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Fregean Axiom | □Actuality | `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-atomicity-r`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `atomicity-and-bf-imply-necessary-actuality` |
| Fregean Axiom | □Atomicity | `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-atomicity-r`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-atomicity` |
| Fregean Axiom | □BF | `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r` |
| Fregean Axiom | □BF (type t) | `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-barcan-t` |
| Fregean Axiom | □Boolean Completeness | `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-atomicity-r`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-completeness` |
| Fregean Axiom | □ND | `fregean-axiom-implies-necessary-distinctness-necessary-r` |
| Fregean Axiom | □ND (type t) | `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t` |
| Fregean Axiom | □Fregean Axiom | `fregean-axiom-implies-necessary-fregean-axiom` |
| Fregean Axiom | □Functionality | `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r` |
| Fregean Axiom | □B | `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-necessary-modal-b` |
| Fregean Axiom | □5 | `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five` |
| Fregean Axiom | □Plenitude | `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-atomicity-r`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-plenitude` |
| Fregean Axiom | □Rigid Comprehension | `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-atomicity-r`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-rigid-comprehension` |
| Fregean Axiom | □Tractarianism | `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r`, `necessary-functionality-r-implies-necessary-tractarianism-r` |
| Fregean Axiom | No Pure Contingency | `fregean-axiom-implies-no-pure-contingency-r` |
| Fregean Axiom | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Fregean Axiom | Persistent Comprehension | `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-rigid-comprehension-r`, `rigid-comprehension-r-implies-persistent-comprehension-r` |
| Fregean Axiom | Plenitude | `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-plenitude-r` |
| Fregean Axiom | B for pure sentences | `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-pure-b-r` |
| Fregean Axiom | Rigid Comprehension | `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-rigid-comprehension-r` |
| Fregean Axiom | Tractarianism | `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-functionality-r`, `functionality-r-implies-tractarianism-r` |
| Functional Choice | Actual Profile | `functional-choice-r-implies-plenitude-r`, `plenitude-r-implies-actuality`, `actuality-implies-actual-profile-r` |
| Functional Choice | Actuality | `functional-choice-r-implies-plenitude-r`, `plenitude-r-implies-actuality` |
| Functional Choice | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Functional Choice | CBF | `classicism-implies-converse-barcan-r` |
| Functional Choice | ND | `functional-choice-r-implies-plenitude-r`, `plenitude-r-implies-distinctness-necessary-r` |
| Functional Choice | ND (type t) | `functional-choice-r-implies-plenitude-r`, `plenitude-r-implies-distinctness-necessary-r`, `distinctness-necessary-r-implies-distinctness-necessary-t` |
| Functional Choice | Existence | `classicism-implies-existence-r` |
| Functional Choice | NI | `classicism-implies-identity-necessary-r` |
| Functional Choice | Inextensible Comprehension | `functional-choice-r-implies-plenitude-r`, `plenitude-r-implies-actuality`, `actuality-implies-inextensible-comprehension-r` |
| Functional Choice | Intensionality | `classicism-implies-intensionality-r` |
| Functional Choice | B | `functional-choice-r-implies-plenitude-r`, `plenitude-r-implies-distinctness-necessary-r`, `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b` |
| Functional Choice | 5 | `functional-choice-r-implies-plenitude-r`, `plenitude-r-implies-distinctness-necessary-r`, `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-modal-five` |
| Functional Choice | 4 | `classicism-implies-modal-four` |
| Functional Choice | K | `classicism-implies-modal-k` |
| Functional Choice | T | `classicism-implies-modal-t` |
| Functional Choice | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Functional Choice | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Functional Choice | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Functional Choice | Persistent Comprehension | `functional-choice-r-implies-plenitude-r`, `plenitude-r-implies-actuality`, `actuality-implies-persistent-comprehension-r` |
| Functional Choice | Plenitude | `functional-choice-r-implies-plenitude-r` |
| Functional Choice | B for pure sentences | `functional-choice-r-implies-plenitude-r`, `plenitude-r-implies-distinctness-necessary-r`, `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r` |
| Functional Choice | Relational Choice | `functional-choice-r-implies-relational-choice-r` |
| Functionality | BF | `functionality-r-implies-tractarianism-r`, `tractarianism-r-implies-barcan-r` |
| Functionality | BF (type t) | `functionality-r-implies-tractarianism-r`, `tractarianism-r-implies-barcan-r`, `barcan-r-implies-barcan-t` |
| Functionality | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Functionality | CBF | `classicism-implies-converse-barcan-r` |
| Functionality | Existence | `classicism-implies-existence-r` |
| Functionality | NI | `classicism-implies-identity-necessary-r` |
| Functionality | Intensionality | `classicism-implies-intensionality-r` |
| Functionality | 4 | `classicism-implies-modal-four` |
| Functionality | K | `classicism-implies-modal-k` |
| Functionality | T | `classicism-implies-modal-t` |
| Functionality | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Functionality | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Functionality | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Functionality | Tractarianism | `functionality-r-implies-tractarianism-r` |
| Fundamental Possibility | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Fundamental Possibility | CBF | `classicism-implies-converse-barcan-r` |
| Fundamental Possibility | Distinctness (pure) | `fundamental-possibility-r-implies-possibility-schema-r`, `possibility-schema-r-implies-distinctness-schema-r` |
| Fundamental Possibility | Existence | `classicism-implies-existence-r` |
| Fundamental Possibility | NI | `classicism-implies-identity-necessary-r` |
| Fundamental Possibility | Intensionality | `classicism-implies-intensionality-r` |
| Fundamental Possibility | 4 | `classicism-implies-modal-four` |
| Fundamental Possibility | K | `classicism-implies-modal-k` |
| Fundamental Possibility | T | `classicism-implies-modal-t` |
| Fundamental Possibility | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Fundamental Possibility | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Fundamental Possibility | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Fundamental Possibility | Possibility (pure) | `fundamental-possibility-r-implies-possibility-schema-r` |
| Gallin Extensional Comprehension | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Gallin Extensional Comprehension | CBF | `classicism-implies-converse-barcan-r` |
| Gallin Extensional Comprehension | Existence | `classicism-implies-existence-r` |
| Gallin Extensional Comprehension | NI | `classicism-implies-identity-necessary-r` |
| Gallin Extensional Comprehension | Intensionality | `classicism-implies-intensionality-r` |
| Gallin Extensional Comprehension | 4 | `classicism-implies-modal-four` |
| Gallin Extensional Comprehension | K | `classicism-implies-modal-k` |
| Gallin Extensional Comprehension | T | `classicism-implies-modal-t` |
| Gallin Extensional Comprehension | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Gallin Extensional Comprehension | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Gallin Extensional Comprehension | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| NI | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| NI | CBF | `classicism-implies-converse-barcan-r` |
| NI | Existence | `classicism-implies-existence-r` |
| NI | Intensionality | `classicism-implies-intensionality-r` |
| NI | 4 | `classicism-implies-modal-four` |
| NI | K | `classicism-implies-modal-k` |
| NI | T | `classicism-implies-modal-t` |
| NI | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| NI | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| NI | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Inextensible Comprehension | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Inextensible Comprehension | CBF | `classicism-implies-converse-barcan-r` |
| Inextensible Comprehension | Existence | `classicism-implies-existence-r` |
| Inextensible Comprehension | NI | `classicism-implies-identity-necessary-r` |
| Inextensible Comprehension | Intensionality | `classicism-implies-intensionality-r` |
| Inextensible Comprehension | 4 | `classicism-implies-modal-four` |
| Inextensible Comprehension | K | `classicism-implies-modal-k` |
| Inextensible Comprehension | T | `classicism-implies-modal-t` |
| Inextensible Comprehension | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Inextensible Comprehension | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Inextensible Comprehension | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Infinity (type e) | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Infinity (type e) | CBF | `classicism-implies-converse-barcan-r` |
| Infinity (type e) | Existence | `classicism-implies-existence-r` |
| Infinity (type e) | NI | `classicism-implies-identity-necessary-r` |
| Infinity (type e) | Intensionality | `classicism-implies-intensionality-r` |
| Infinity (type e) | 4 | `classicism-implies-modal-four` |
| Infinity (type e) | K | `classicism-implies-modal-k` |
| Infinity (type e) | T | `classicism-implies-modal-t` |
| Infinity (type e) | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Infinity (type e) | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Infinity (type e) | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Infinity (type t) | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Infinity (type t) | CBF | `classicism-implies-converse-barcan-r` |
| Infinity (type t) | Existence | `classicism-implies-existence-r` |
| Infinity (type t) | NI | `classicism-implies-identity-necessary-r` |
| Infinity (type t) | Intensionality | `classicism-implies-intensionality-r` |
| Infinity (type t) | 4 | `classicism-implies-modal-four` |
| Infinity (type t) | K | `classicism-implies-modal-k` |
| Infinity (type t) | T | `classicism-implies-modal-t` |
| Infinity (type t) | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Infinity (type t) | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Infinity (type t) | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Intensionality | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Intensionality | CBF | `classicism-implies-converse-barcan-r` |
| Intensionality | Existence | `classicism-implies-existence-r` |
| Intensionality | NI | `classicism-implies-identity-necessary-r` |
| Intensionality | 4 | `classicism-implies-modal-four` |
| Intensionality | K | `classicism-implies-modal-k` |
| Intensionality | T | `classicism-implies-modal-t` |
| Intensionality | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Intensionality | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Intensionality | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Logical Necessity | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Logical Necessity | CBF | `classicism-implies-converse-barcan-r` |
| Logical Necessity | Converse Witnessed Possibility | `logical-necessity-r-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-converse-witnessed-possibility-r` |
| Logical Necessity | Existence | `classicism-implies-existence-r` |
| Logical Necessity | NI | `classicism-implies-identity-necessary-r` |
| Logical Necessity | Intensionality | `classicism-implies-intensionality-r` |
| Logical Necessity | 4 | `classicism-implies-modal-four` |
| Logical Necessity | K | `classicism-implies-modal-k` |
| Logical Necessity | T | `classicism-implies-modal-t` |
| Logical Necessity | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Logical Necessity | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Logical Necessity | No Pure Contingency | `logical-necessity-r-implies-no-pure-contingency-r` |
| Logical Necessity | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Logical Necessity | B for pure sentences | `logical-necessity-r-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-pure-b-r` |
| Logical Necessity | Witnessed Possibility | `logical-necessity-r-implies-witnessed-possibility-r` |
| B | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| B | CBF | `classicism-implies-converse-barcan-r` |
| B | ND | `modal-b-implies-distinctness-necessary-r` |
| B | ND (type t) | `modal-b-implies-distinctness-necessary-r`, `distinctness-necessary-r-implies-distinctness-necessary-t` |
| B | Existence | `classicism-implies-existence-r` |
| B | NI | `classicism-implies-identity-necessary-r` |
| B | Intensionality | `classicism-implies-intensionality-r` |
| B | 5 | `modal-b-implies-distinctness-necessary-r`, `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-modal-five` |
| B | 4 | `classicism-implies-modal-four` |
| B | K | `classicism-implies-modal-k` |
| B | T | `classicism-implies-modal-t` |
| B | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| B | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| B | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| B | B for pure sentences | `modal-b-implies-pure-b-r` |
| 5 | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| 5 | CBF | `classicism-implies-converse-barcan-r` |
| 5 | ND | `modal-five-implies-modal-b`, `modal-b-implies-distinctness-necessary-r` |
| 5 | ND (type t) | `modal-five-implies-modal-b`, `modal-b-implies-distinctness-necessary-r`, `distinctness-necessary-r-implies-distinctness-necessary-t` |
| 5 | Existence | `classicism-implies-existence-r` |
| 5 | NI | `classicism-implies-identity-necessary-r` |
| 5 | Intensionality | `classicism-implies-intensionality-r` |
| 5 | B | `modal-five-implies-modal-b` |
| 5 | 4 | `classicism-implies-modal-four` |
| 5 | K | `classicism-implies-modal-k` |
| 5 | T | `classicism-implies-modal-t` |
| 5 | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| 5 | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| 5 | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| 5 | B for pure sentences | `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r` |
| 4 | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| 4 | CBF | `classicism-implies-converse-barcan-r` |
| 4 | Existence | `classicism-implies-existence-r` |
| 4 | NI | `classicism-implies-identity-necessary-r` |
| 4 | Intensionality | `classicism-implies-intensionality-r` |
| 4 | K | `classicism-implies-modal-k` |
| 4 | T | `classicism-implies-modal-t` |
| 4 | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| 4 | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| 4 | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| K | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| K | CBF | `classicism-implies-converse-barcan-r` |
| K | Existence | `classicism-implies-existence-r` |
| K | NI | `classicism-implies-identity-necessary-r` |
| K | Intensionality | `classicism-implies-intensionality-r` |
| K | 4 | `classicism-implies-modal-four` |
| K | T | `classicism-implies-modal-t` |
| K | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| K | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| K | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| T | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| T | CBF | `classicism-implies-converse-barcan-r` |
| T | Existence | `classicism-implies-existence-r` |
| T | NI | `classicism-implies-identity-necessary-r` |
| T | Intensionality | `classicism-implies-intensionality-r` |
| T | 4 | `classicism-implies-modal-four` |
| T | K | `classicism-implies-modal-k` |
| T | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| T | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| T | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Modalized Fregean Axiom | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Modalized Fregean Axiom | CBF | `classicism-implies-converse-barcan-r` |
| Modalized Fregean Axiom | Existence | `classicism-implies-existence-r` |
| Modalized Fregean Axiom | NI | `classicism-implies-identity-necessary-r` |
| Modalized Fregean Axiom | Intensionality | `classicism-implies-intensionality-r` |
| Modalized Fregean Axiom | 4 | `classicism-implies-modal-four` |
| Modalized Fregean Axiom | K | `classicism-implies-modal-k` |
| Modalized Fregean Axiom | T | `classicism-implies-modal-t` |
| Modalized Fregean Axiom | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Modalized Fregean Axiom | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Modalized Functionality | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Modalized Functionality | CBF | `classicism-implies-converse-barcan-r` |
| Modalized Functionality | Existence | `classicism-implies-existence-r` |
| Modalized Functionality | NI | `classicism-implies-identity-necessary-r` |
| Modalized Functionality | Intensionality | `classicism-implies-intensionality-r` |
| Modalized Functionality | 4 | `classicism-implies-modal-four` |
| Modalized Functionality | K | `classicism-implies-modal-k` |
| Modalized Functionality | T | `classicism-implies-modal-t` |
| Modalized Functionality | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Modalized Functionality | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| □Actuality | Actual Profile | `necessary-actuality-implies-actuality`, `actuality-implies-actual-profile-r` |
| □Actuality | Actuality | `necessary-actuality-implies-actuality` |
| □Actuality | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| □Actuality | CBF | `classicism-implies-converse-barcan-r` |
| □Actuality | Existence | `classicism-implies-existence-r` |
| □Actuality | NI | `classicism-implies-identity-necessary-r` |
| □Actuality | Inextensible Comprehension | `necessary-actuality-implies-actuality`, `actuality-implies-inextensible-comprehension-r` |
| □Actuality | Intensionality | `classicism-implies-intensionality-r` |
| □Actuality | 4 | `classicism-implies-modal-four` |
| □Actuality | K | `classicism-implies-modal-k` |
| □Actuality | T | `classicism-implies-modal-t` |
| □Actuality | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| □Actuality | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| □Actuality | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| □Actuality | Persistent Comprehension | `necessary-actuality-implies-actuality`, `actuality-implies-persistent-comprehension-r` |
| □Atomicity | Atomicity | `necessary-atomicity-r-implies-atomicity-r` |
| □Atomicity | Atomicity (type t) | `necessary-atomicity-r-implies-atomicity-r`, `atomicity-r-implies-atomicity-t` |
| □Atomicity | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| □Atomicity | CBF | `classicism-implies-converse-barcan-r` |
| □Atomicity | Existence | `classicism-implies-existence-r` |
| □Atomicity | NI | `classicism-implies-identity-necessary-r` |
| □Atomicity | Intensionality | `classicism-implies-intensionality-r` |
| □Atomicity | 4 | `classicism-implies-modal-four` |
| □Atomicity | K | `classicism-implies-modal-k` |
| □Atomicity | T | `classicism-implies-modal-t` |
| □Atomicity | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| □Atomicity | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| □Atomicity | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| □BF | BF | `necessary-barcan-r-implies-barcan-r` |
| □BF | BF (type t) | `necessary-barcan-r-implies-necessary-barcan-t`, `necessary-barcan-t-implies-barcan-t` |
| □BF | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| □BF | CBF | `classicism-implies-converse-barcan-r` |
| □BF | Existence | `classicism-implies-existence-r` |
| □BF | Functionality | `necessary-barcan-r-implies-necessary-functionality-r`, `necessary-functionality-r-implies-functionality-r` |
| □BF | NI | `classicism-implies-identity-necessary-r` |
| □BF | Intensionality | `classicism-implies-intensionality-r` |
| □BF | 4 | `classicism-implies-modal-four` |
| □BF | K | `classicism-implies-modal-k` |
| □BF | T | `classicism-implies-modal-t` |
| □BF | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| □BF | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| □BF | □BF (type t) | `necessary-barcan-r-implies-necessary-barcan-t` |
| □BF | □Functionality | `necessary-barcan-r-implies-necessary-functionality-r` |
| □BF | □Tractarianism | `necessary-barcan-r-implies-necessary-functionality-r`, `necessary-functionality-r-implies-necessary-tractarianism-r` |
| □BF | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| □BF | Tractarianism | `necessary-barcan-r-implies-necessary-functionality-r`, `necessary-functionality-r-implies-necessary-tractarianism-r`, `necessary-tractarianism-r-implies-tractarianism-r` |
| □BF (type t) | BF (type t) | `necessary-barcan-t-implies-barcan-t` |
| □BF (type t) | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| □BF (type t) | CBF | `classicism-implies-converse-barcan-r` |
| □BF (type t) | Existence | `classicism-implies-existence-r` |
| □BF (type t) | NI | `classicism-implies-identity-necessary-r` |
| □BF (type t) | Intensionality | `classicism-implies-intensionality-r` |
| □BF (type t) | 4 | `classicism-implies-modal-four` |
| □BF (type t) | K | `classicism-implies-modal-k` |
| □BF (type t) | T | `classicism-implies-modal-t` |
| □BF (type t) | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| □BF (type t) | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| □BF (type t) | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| □Boolean Completeness | Boolean Completeness | `necessary-boolean-completeness-r-implies-boolean-completeness-r` |
| □Boolean Completeness | Boolean Completeness (type t) | `necessary-boolean-completeness-r-implies-boolean-completeness-r`, `boolean-completeness-r-implies-boolean-completeness-t` |
| □Boolean Completeness | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| □Boolean Completeness | CBF | `classicism-implies-converse-barcan-r` |
| □Boolean Completeness | Existence | `classicism-implies-existence-r` |
| □Boolean Completeness | NI | `classicism-implies-identity-necessary-r` |
| □Boolean Completeness | Intensionality | `classicism-implies-intensionality-r` |
| □Boolean Completeness | 4 | `classicism-implies-modal-four` |
| □Boolean Completeness | K | `classicism-implies-modal-k` |
| □Boolean Completeness | T | `classicism-implies-modal-t` |
| □Boolean Completeness | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| □Boolean Completeness | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| □Boolean Completeness | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| □ND | BF | `necessary-nd-implies-bf` |
| □ND | BF (type t) | `necessary-nd-implies-bf`, `barcan-r-implies-barcan-t` |
| □ND | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| □ND | CBF | `classicism-implies-converse-barcan-r` |
| □ND | ND | `necessary-distinctness-necessary-r-implies-distinctness-necessary-r` |
| □ND | ND (type t) | `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t`, `necessary-distinctness-necessary-t-implies-distinctness-necessary-t` |
| □ND | Existence | `classicism-implies-existence-r` |
| □ND | Functionality | `necessary-nd-implies-bf`, `barcan-r-implies-functionality-r` |
| □ND | NI | `classicism-implies-identity-necessary-r` |
| □ND | Intensionality | `classicism-implies-intensionality-r` |
| □ND | B | `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-modal-five`, `modal-five-implies-modal-b` |
| □ND | 5 | `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-modal-five` |
| □ND | 4 | `classicism-implies-modal-four` |
| □ND | K | `classicism-implies-modal-k` |
| □ND | T | `classicism-implies-modal-t` |
| □ND | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| □ND | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| □ND | □BF | `necessary-distinctness-necessary-r-implies-necessary-barcan-r` |
| □ND | □BF (type t) | `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-barcan-t` |
| □ND | □ND (type t) | `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t` |
| □ND | □Functionality | `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r` |
| □ND | □B | `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-necessary-modal-b` |
| □ND | □5 | `necessary-distinctness-necessary-r-implies-necessary-modal-five` |
| □ND | □Tractarianism | `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r`, `necessary-functionality-r-implies-necessary-tractarianism-r` |
| □ND | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| □ND | B for pure sentences | `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r` |
| □ND | Tractarianism | `necessary-nd-implies-bf`, `barcan-r-implies-functionality-r`, `functionality-r-implies-tractarianism-r` |
| □ND (type t) | BF | `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf` |
| □ND (type t) | BF (type t) | `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-barcan-t` |
| □ND (type t) | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| □ND (type t) | CBF | `classicism-implies-converse-barcan-r` |
| □ND (type t) | ND | `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-distinctness-necessary-r` |
| □ND (type t) | ND (type t) | `necessary-distinctness-necessary-t-implies-distinctness-necessary-t` |
| □ND (type t) | Existence | `classicism-implies-existence-r` |
| □ND (type t) | Functionality | `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-functionality-r` |
| □ND (type t) | NI | `classicism-implies-identity-necessary-r` |
| □ND (type t) | Intensionality | `classicism-implies-intensionality-r` |
| □ND (type t) | B | `necessary-distinctness-necessary-t-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b` |
| □ND (type t) | 5 | `necessary-distinctness-necessary-t-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-modal-five` |
| □ND (type t) | 4 | `classicism-implies-modal-four` |
| □ND (type t) | K | `classicism-implies-modal-k` |
| □ND (type t) | T | `classicism-implies-modal-t` |
| □ND (type t) | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| □ND (type t) | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| □ND (type t) | □BF | `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r` |
| □ND (type t) | □BF (type t) | `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-barcan-t` |
| □ND (type t) | □ND | `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r` |
| □ND (type t) | □Functionality | `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r` |
| □ND (type t) | □B | `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-necessary-modal-b` |
| □ND (type t) | □5 | `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five` |
| □ND (type t) | □Tractarianism | `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r`, `necessary-functionality-r-implies-necessary-tractarianism-r` |
| □ND (type t) | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| □ND (type t) | B for pure sentences | `necessary-distinctness-necessary-t-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r` |
| □ND (type t) | Tractarianism | `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-functionality-r`, `functionality-r-implies-tractarianism-r` |
| □Extensionality | Actual Profile | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-actuality`, `actuality-implies-actual-profile-r` |
| □Extensionality | Actuality | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-actuality` |
| □Extensionality | Atomicity | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-atomicity-r` |
| □Extensionality | Atomicity (type t) | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-atomicity-r`, `atomicity-r-implies-atomicity-t` |
| □Extensionality | BF | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf` |
| □Extensionality | BF (type t) | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-barcan-t` |
| □Extensionality | Boolean Completeness | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-boolean-completeness-r` |
| □Extensionality | Boolean Completeness (type t) | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-boolean-completeness-r`, `boolean-completeness-r-implies-boolean-completeness-t` |
| □Extensionality | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| □Extensionality | CBF | `classicism-implies-converse-barcan-r` |
| □Extensionality | Converse Witnessed Possibility | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-converse-witnessed-possibility-r` |
| □Extensionality | ND | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-distinctness-necessary-r` |
| □Extensionality | ND (type t) | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t`, `necessary-distinctness-necessary-t-implies-distinctness-necessary-t` |
| □Extensionality | Existence | `classicism-implies-existence-r` |
| □Extensionality | Extensionality | `necessary-extensionality-r-implies-extensionality-r` |
| □Extensionality | Fregean Axiom | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom` |
| □Extensionality | Functionality | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-functionality-r` |
| □Extensionality | NI | `classicism-implies-identity-necessary-r` |
| □Extensionality | Inextensible Comprehension | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-rigid-comprehension-r`, `rigid-comprehension-r-implies-inextensible-comprehension-r` |
| □Extensionality | Intensionality | `classicism-implies-intensionality-r` |
| □Extensionality | B | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-modal-five`, `modal-five-implies-modal-b` |
| □Extensionality | 5 | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-modal-five` |
| □Extensionality | 4 | `classicism-implies-modal-four` |
| □Extensionality | K | `classicism-implies-modal-k` |
| □Extensionality | T | `classicism-implies-modal-t` |
| □Extensionality | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| □Extensionality | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| □Extensionality | □Actuality | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-atomicity-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `atomicity-and-bf-imply-necessary-actuality` |
| □Extensionality | □Atomicity | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-atomicity-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-atomicity` |
| □Extensionality | □BF | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r` |
| □Extensionality | □BF (type t) | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-barcan-t` |
| □Extensionality | □Boolean Completeness | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-atomicity-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-completeness` |
| □Extensionality | □ND | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r` |
| □Extensionality | □ND (type t) | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t` |
| □Extensionality | □Fregean Axiom | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-fregean-axiom` |
| □Extensionality | □Functionality | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r` |
| □Extensionality | □B | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-necessary-modal-b` |
| □Extensionality | □5 | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five` |
| □Extensionality | □Plenitude | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-atomicity-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-plenitude` |
| □Extensionality | □Rigid Comprehension | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-atomicity-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-rigid-comprehension` |
| □Extensionality | □Tractarianism | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r`, `necessary-functionality-r-implies-necessary-tractarianism-r` |
| □Extensionality | No Pure Contingency | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-no-pure-contingency-r` |
| □Extensionality | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| □Extensionality | Persistent Comprehension | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-rigid-comprehension-r`, `rigid-comprehension-r-implies-persistent-comprehension-r` |
| □Extensionality | Plenitude | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-plenitude-r` |
| □Extensionality | B for pure sentences | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-pure-b-r` |
| □Extensionality | Rigid Comprehension | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-rigid-comprehension-r` |
| □Extensionality | Tractarianism | `necessary-extensionality-r-implies-extensionality-r`, `extensionality-r-implies-functionality-r`, `functionality-r-implies-tractarianism-r` |
| □Fregean Axiom | Actual Profile | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-actuality`, `actuality-implies-actual-profile-r` |
| □Fregean Axiom | Actuality | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-actuality` |
| □Fregean Axiom | Atomicity | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-atomicity-r` |
| □Fregean Axiom | Atomicity (type t) | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-atomicity-r`, `atomicity-r-implies-atomicity-t` |
| □Fregean Axiom | BF | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf` |
| □Fregean Axiom | BF (type t) | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-barcan-t` |
| □Fregean Axiom | Boolean Completeness | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-boolean-completeness-r` |
| □Fregean Axiom | Boolean Completeness (type t) | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-boolean-completeness-r`, `boolean-completeness-r-implies-boolean-completeness-t` |
| □Fregean Axiom | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| □Fregean Axiom | CBF | `classicism-implies-converse-barcan-r` |
| □Fregean Axiom | Converse Witnessed Possibility | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-converse-witnessed-possibility-r` |
| □Fregean Axiom | ND | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-distinctness-necessary-r` |
| □Fregean Axiom | ND (type t) | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t`, `necessary-distinctness-necessary-t-implies-distinctness-necessary-t` |
| □Fregean Axiom | Existence | `classicism-implies-existence-r` |
| □Fregean Axiom | Extensionality | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-extensionality-r` |
| □Fregean Axiom | Fregean Axiom | `necessary-fregean-axiom-implies-fregean-axiom` |
| □Fregean Axiom | Functionality | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-functionality-r` |
| □Fregean Axiom | NI | `classicism-implies-identity-necessary-r` |
| □Fregean Axiom | Inextensible Comprehension | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-rigid-comprehension-r`, `rigid-comprehension-r-implies-inextensible-comprehension-r` |
| □Fregean Axiom | Intensionality | `classicism-implies-intensionality-r` |
| □Fregean Axiom | B | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-modal-five`, `modal-five-implies-modal-b` |
| □Fregean Axiom | 5 | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-modal-five` |
| □Fregean Axiom | 4 | `classicism-implies-modal-four` |
| □Fregean Axiom | K | `classicism-implies-modal-k` |
| □Fregean Axiom | T | `classicism-implies-modal-t` |
| □Fregean Axiom | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| □Fregean Axiom | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| □Fregean Axiom | □Actuality | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-atomicity-r`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `atomicity-and-bf-imply-necessary-actuality` |
| □Fregean Axiom | □Atomicity | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-atomicity-r`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-atomicity` |
| □Fregean Axiom | □BF | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r` |
| □Fregean Axiom | □BF (type t) | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-barcan-t` |
| □Fregean Axiom | □Boolean Completeness | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-atomicity-r`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-completeness` |
| □Fregean Axiom | □ND | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r` |
| □Fregean Axiom | □ND (type t) | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t` |
| □Fregean Axiom | □Functionality | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r` |
| □Fregean Axiom | □B | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-necessary-modal-b` |
| □Fregean Axiom | □5 | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five` |
| □Fregean Axiom | □Plenitude | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-atomicity-r`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-plenitude` |
| □Fregean Axiom | □Rigid Comprehension | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-atomicity-r`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-rigid-comprehension` |
| □Fregean Axiom | □Tractarianism | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r`, `necessary-functionality-r-implies-necessary-tractarianism-r` |
| □Fregean Axiom | No Pure Contingency | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-no-pure-contingency-r` |
| □Fregean Axiom | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| □Fregean Axiom | Persistent Comprehension | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-rigid-comprehension-r`, `rigid-comprehension-r-implies-persistent-comprehension-r` |
| □Fregean Axiom | Plenitude | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-plenitude-r` |
| □Fregean Axiom | B for pure sentences | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-pure-b-r` |
| □Fregean Axiom | Rigid Comprehension | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-extensionality-r`, `extensionality-r-implies-rigid-comprehension-r` |
| □Fregean Axiom | Tractarianism | `necessary-fregean-axiom-implies-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-functionality-r`, `functionality-r-implies-tractarianism-r` |
| □Functionality | BF | `necessary-functionality-r-implies-necessary-tractarianism-r`, `necessary-tractarianism-r-implies-tractarianism-r`, `tractarianism-r-implies-barcan-r` |
| □Functionality | BF (type t) | `necessary-functionality-r-implies-necessary-tractarianism-r`, `necessary-tractarianism-r-implies-tractarianism-r`, `tractarianism-r-implies-barcan-r`, `barcan-r-implies-barcan-t` |
| □Functionality | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| □Functionality | CBF | `classicism-implies-converse-barcan-r` |
| □Functionality | Existence | `classicism-implies-existence-r` |
| □Functionality | Functionality | `necessary-functionality-r-implies-functionality-r` |
| □Functionality | NI | `classicism-implies-identity-necessary-r` |
| □Functionality | Intensionality | `classicism-implies-intensionality-r` |
| □Functionality | 4 | `classicism-implies-modal-four` |
| □Functionality | K | `classicism-implies-modal-k` |
| □Functionality | T | `classicism-implies-modal-t` |
| □Functionality | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| □Functionality | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| □Functionality | □BF | `necessary-functionality-r-implies-necessary-tractarianism-r`, `necessary-tractarianism-r-implies-necessary-barcan-r` |
| □Functionality | □BF (type t) | `necessary-functionality-r-implies-necessary-tractarianism-r`, `necessary-tractarianism-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-barcan-t` |
| □Functionality | □Tractarianism | `necessary-functionality-r-implies-necessary-tractarianism-r` |
| □Functionality | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| □Functionality | Tractarianism | `necessary-functionality-r-implies-necessary-tractarianism-r`, `necessary-tractarianism-r-implies-tractarianism-r` |
| □B | BF | `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf` |
| □B | BF (type t) | `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-barcan-t` |
| □B | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| □B | CBF | `classicism-implies-converse-barcan-r` |
| □B | ND | `necessary-modal-b-implies-modal-b`, `modal-b-implies-distinctness-necessary-r` |
| □B | ND (type t) | `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t`, `necessary-distinctness-necessary-t-implies-distinctness-necessary-t` |
| □B | Existence | `classicism-implies-existence-r` |
| □B | Functionality | `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-functionality-r` |
| □B | NI | `classicism-implies-identity-necessary-r` |
| □B | Intensionality | `classicism-implies-intensionality-r` |
| □B | B | `necessary-modal-b-implies-modal-b` |
| □B | 5 | `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-modal-five` |
| □B | 4 | `classicism-implies-modal-four` |
| □B | K | `classicism-implies-modal-k` |
| □B | T | `classicism-implies-modal-t` |
| □B | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| □B | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| □B | □BF | `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r` |
| □B | □BF (type t) | `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-barcan-t` |
| □B | □ND | `necessary-modal-b-implies-necessary-distinctness-necessary-r` |
| □B | □ND (type t) | `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t` |
| □B | □Functionality | `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r` |
| □B | □5 | `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five` |
| □B | □Tractarianism | `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r`, `necessary-functionality-r-implies-necessary-tractarianism-r` |
| □B | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| □B | B for pure sentences | `necessary-modal-b-implies-modal-b`, `modal-b-implies-pure-b-r` |
| □B | Tractarianism | `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-functionality-r`, `functionality-r-implies-tractarianism-r` |
| □5 | BF | `necessary-modal-five-implies-necessary-modal-b`, `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf` |
| □5 | BF (type t) | `necessary-modal-five-implies-necessary-modal-b`, `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-barcan-t` |
| □5 | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| □5 | CBF | `classicism-implies-converse-barcan-r` |
| □5 | ND | `necessary-modal-five-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-distinctness-necessary-r` |
| □5 | ND (type t) | `necessary-modal-five-implies-necessary-modal-b`, `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t`, `necessary-distinctness-necessary-t-implies-distinctness-necessary-t` |
| □5 | Existence | `classicism-implies-existence-r` |
| □5 | Functionality | `necessary-modal-five-implies-necessary-modal-b`, `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-functionality-r` |
| □5 | NI | `classicism-implies-identity-necessary-r` |
| □5 | Intensionality | `classicism-implies-intensionality-r` |
| □5 | B | `necessary-modal-five-implies-modal-five`, `modal-five-implies-modal-b` |
| □5 | 5 | `necessary-modal-five-implies-modal-five` |
| □5 | 4 | `classicism-implies-modal-four` |
| □5 | K | `classicism-implies-modal-k` |
| □5 | T | `classicism-implies-modal-t` |
| □5 | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| □5 | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| □5 | □BF | `necessary-modal-five-implies-necessary-modal-b`, `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r` |
| □5 | □BF (type t) | `necessary-modal-five-implies-necessary-modal-b`, `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-barcan-t` |
| □5 | □ND | `necessary-modal-five-implies-necessary-modal-b`, `necessary-modal-b-implies-necessary-distinctness-necessary-r` |
| □5 | □ND (type t) | `necessary-modal-five-implies-necessary-modal-b`, `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t` |
| □5 | □Functionality | `necessary-modal-five-implies-necessary-modal-b`, `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r` |
| □5 | □B | `necessary-modal-five-implies-necessary-modal-b` |
| □5 | □Tractarianism | `necessary-modal-five-implies-necessary-modal-b`, `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r`, `necessary-functionality-r-implies-necessary-tractarianism-r` |
| □5 | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| □5 | B for pure sentences | `necessary-modal-five-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r` |
| □5 | Tractarianism | `necessary-modal-five-implies-necessary-modal-b`, `necessary-modal-b-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-functionality-r`, `functionality-r-implies-tractarianism-r` |
| □Plenitude | Actual Profile | `necessary-plenitude-r-implies-plenitude-r`, `plenitude-r-implies-actuality`, `actuality-implies-actual-profile-r` |
| □Plenitude | Actuality | `necessary-plenitude-r-implies-plenitude-r`, `plenitude-r-implies-actuality` |
| □Plenitude | Atomicity | `necessary-plenitude-r-implies-atomicity-r` |
| □Plenitude | Atomicity (type t) | `necessary-plenitude-r-implies-atomicity-r`, `atomicity-r-implies-atomicity-t` |
| □Plenitude | BF | `necessary-plenitude-r-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf` |
| □Plenitude | BF (type t) | `necessary-plenitude-r-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-barcan-t` |
| □Plenitude | Boolean Completeness | `necessary-plenitude-r-implies-plenitude-r`, `plenitude-r-implies-actuality`, `necessary-plenitude-r-implies-necessary-distinctness-necessary-r`, `c5-and-actuality-imply-completeness` |
| □Plenitude | Boolean Completeness (type t) | `necessary-plenitude-r-implies-plenitude-r`, `plenitude-r-implies-actuality`, `necessary-plenitude-r-implies-necessary-distinctness-necessary-r`, `c5-and-actuality-imply-completeness`, `boolean-completeness-r-implies-boolean-completeness-t` |
| □Plenitude | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| □Plenitude | CBF | `classicism-implies-converse-barcan-r` |
| □Plenitude | ND | `necessary-plenitude-r-implies-plenitude-r`, `plenitude-r-implies-distinctness-necessary-r` |
| □Plenitude | ND (type t) | `necessary-plenitude-r-implies-plenitude-r`, `plenitude-r-implies-distinctness-necessary-r`, `distinctness-necessary-r-implies-distinctness-necessary-t` |
| □Plenitude | Existence | `classicism-implies-existence-r` |
| □Plenitude | Functionality | `necessary-plenitude-r-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-functionality-r` |
| □Plenitude | NI | `classicism-implies-identity-necessary-r` |
| □Plenitude | Inextensible Comprehension | `necessary-plenitude-r-implies-plenitude-r`, `plenitude-r-implies-actuality`, `actuality-implies-inextensible-comprehension-r` |
| □Plenitude | Intensionality | `classicism-implies-intensionality-r` |
| □Plenitude | B | `necessary-plenitude-r-implies-plenitude-r`, `plenitude-r-implies-distinctness-necessary-r`, `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b` |
| □Plenitude | 5 | `necessary-plenitude-r-implies-plenitude-r`, `plenitude-r-implies-distinctness-necessary-r`, `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-modal-five` |
| □Plenitude | 4 | `classicism-implies-modal-four` |
| □Plenitude | K | `classicism-implies-modal-k` |
| □Plenitude | T | `classicism-implies-modal-t` |
| □Plenitude | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| □Plenitude | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| □Plenitude | □Actuality | `necessary-plenitude-r-implies-necessary-actuality` |
| □Plenitude | □Atomicity | `necessary-plenitude-r-implies-atomicity-r`, `necessary-plenitude-r-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-atomicity` |
| □Plenitude | □BF | `necessary-plenitude-r-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r` |
| □Plenitude | □BF (type t) | `necessary-plenitude-r-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-barcan-t` |
| □Plenitude | □Boolean Completeness | `necessary-plenitude-r-implies-atomicity-r`, `necessary-plenitude-r-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-completeness` |
| □Plenitude | □ND | `necessary-plenitude-r-implies-necessary-distinctness-necessary-r` |
| □Plenitude | □ND (type t) | `necessary-plenitude-r-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t` |
| □Plenitude | □Functionality | `necessary-plenitude-r-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r` |
| □Plenitude | □B | `necessary-plenitude-r-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five`, `necessary-modal-five-implies-necessary-modal-b` |
| □Plenitude | □5 | `necessary-plenitude-r-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-modal-five` |
| □Plenitude | □Rigid Comprehension | `necessary-plenitude-r-implies-atomicity-r`, `necessary-plenitude-r-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-necessary-rigid-comprehension` |
| □Plenitude | □Tractarianism | `necessary-plenitude-r-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r`, `necessary-functionality-r-implies-necessary-tractarianism-r` |
| □Plenitude | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| □Plenitude | Persistent Comprehension | `necessary-plenitude-r-implies-plenitude-r`, `plenitude-r-implies-actuality`, `actuality-implies-persistent-comprehension-r` |
| □Plenitude | Plenitude | `necessary-plenitude-r-implies-plenitude-r` |
| □Plenitude | B for pure sentences | `necessary-plenitude-r-implies-plenitude-r`, `plenitude-r-implies-distinctness-necessary-r`, `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r` |
| □Plenitude | Rigid Comprehension | `necessary-plenitude-r-implies-plenitude-r`, `plenitude-r-implies-actuality`, `necessary-plenitude-r-implies-necessary-distinctness-necessary-r`, `c5-and-actuality-imply-rigid-comprehension` |
| □Plenitude | Tractarianism | `necessary-plenitude-r-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-functionality-r`, `functionality-r-implies-tractarianism-r` |
| □Rigid Comprehension | Actual Profile | `necessary-rigid-comprehension-r-implies-rigid-comprehension-r`, `rigid-comprehension-r-implies-actuality`, `actuality-implies-actual-profile-r` |
| □Rigid Comprehension | Actuality | `necessary-rigid-comprehension-r-implies-rigid-comprehension-r`, `rigid-comprehension-r-implies-actuality` |
| □Rigid Comprehension | Boolean Completeness | `necessary-rigid-comprehension-r-implies-rigid-comprehension-r`, `rigid-comprehension-r-implies-boolean-completeness-r` |
| □Rigid Comprehension | Boolean Completeness (type t) | `necessary-rigid-comprehension-r-implies-rigid-comprehension-r`, `rigid-comprehension-r-implies-boolean-completeness-r`, `boolean-completeness-r-implies-boolean-completeness-t` |
| □Rigid Comprehension | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| □Rigid Comprehension | CBF | `classicism-implies-converse-barcan-r` |
| □Rigid Comprehension | Existence | `classicism-implies-existence-r` |
| □Rigid Comprehension | NI | `classicism-implies-identity-necessary-r` |
| □Rigid Comprehension | Inextensible Comprehension | `necessary-rigid-comprehension-r-implies-rigid-comprehension-r`, `rigid-comprehension-r-implies-inextensible-comprehension-r` |
| □Rigid Comprehension | Intensionality | `classicism-implies-intensionality-r` |
| □Rigid Comprehension | 4 | `classicism-implies-modal-four` |
| □Rigid Comprehension | K | `classicism-implies-modal-k` |
| □Rigid Comprehension | T | `classicism-implies-modal-t` |
| □Rigid Comprehension | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| □Rigid Comprehension | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| □Rigid Comprehension | □Actuality | `necessary-rigid-comprehension-r-implies-necessary-actuality` |
| □Rigid Comprehension | □Boolean Completeness | `necessary-rigid-comprehension-r-implies-necessary-boolean-completeness-r` |
| □Rigid Comprehension | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| □Rigid Comprehension | Persistent Comprehension | `necessary-rigid-comprehension-r-implies-rigid-comprehension-r`, `rigid-comprehension-r-implies-persistent-comprehension-r` |
| □Rigid Comprehension | Rigid Comprehension | `necessary-rigid-comprehension-r-implies-rigid-comprehension-r` |
| □Tractarianism | BF | `necessary-tractarianism-r-implies-tractarianism-r`, `tractarianism-r-implies-barcan-r` |
| □Tractarianism | BF (type t) | `necessary-tractarianism-r-implies-tractarianism-r`, `tractarianism-r-implies-barcan-r`, `barcan-r-implies-barcan-t` |
| □Tractarianism | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| □Tractarianism | CBF | `classicism-implies-converse-barcan-r` |
| □Tractarianism | Existence | `classicism-implies-existence-r` |
| □Tractarianism | Functionality | `necessary-tractarianism-r-implies-tractarianism-r`, `tractarianism-r-implies-barcan-r`, `barcan-r-implies-functionality-r` |
| □Tractarianism | NI | `classicism-implies-identity-necessary-r` |
| □Tractarianism | Intensionality | `classicism-implies-intensionality-r` |
| □Tractarianism | 4 | `classicism-implies-modal-four` |
| □Tractarianism | K | `classicism-implies-modal-k` |
| □Tractarianism | T | `classicism-implies-modal-t` |
| □Tractarianism | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| □Tractarianism | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| □Tractarianism | □BF | `necessary-tractarianism-r-implies-necessary-barcan-r` |
| □Tractarianism | □BF (type t) | `necessary-tractarianism-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-barcan-t` |
| □Tractarianism | □Functionality | `necessary-tractarianism-r-implies-necessary-barcan-r`, `necessary-barcan-r-implies-necessary-functionality-r` |
| □Tractarianism | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| □Tractarianism | Tractarianism | `necessary-tractarianism-r-implies-tractarianism-r` |
| No Pure Contingency | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| No Pure Contingency | CBF | `classicism-implies-converse-barcan-r` |
| No Pure Contingency | Converse Witnessed Possibility | `no-pure-contingency-r-implies-converse-witnessed-possibility-r` |
| No Pure Contingency | Existence | `classicism-implies-existence-r` |
| No Pure Contingency | NI | `classicism-implies-identity-necessary-r` |
| No Pure Contingency | Intensionality | `classicism-implies-intensionality-r` |
| No Pure Contingency | 4 | `classicism-implies-modal-four` |
| No Pure Contingency | K | `classicism-implies-modal-k` |
| No Pure Contingency | T | `classicism-implies-modal-t` |
| No Pure Contingency | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| No Pure Contingency | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| No Pure Contingency | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| No Pure Contingency | B for pure sentences | `no-pure-contingency-r-implies-pure-b-r` |
| Ordinary Comprehension | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Ordinary Comprehension | CBF | `classicism-implies-converse-barcan-r` |
| Ordinary Comprehension | Existence | `classicism-implies-existence-r` |
| Ordinary Comprehension | NI | `classicism-implies-identity-necessary-r` |
| Ordinary Comprehension | Intensionality | `classicism-implies-intensionality-r` |
| Ordinary Comprehension | 4 | `classicism-implies-modal-four` |
| Ordinary Comprehension | K | `classicism-implies-modal-k` |
| Ordinary Comprehension | T | `classicism-implies-modal-t` |
| Ordinary Comprehension | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Ordinary Comprehension | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Persistent Comprehension | Actual Profile | `persistent-comprehension-r-implies-actuality`, `actuality-implies-actual-profile-r` |
| Persistent Comprehension | Actuality | `persistent-comprehension-r-implies-actuality` |
| Persistent Comprehension | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Persistent Comprehension | CBF | `classicism-implies-converse-barcan-r` |
| Persistent Comprehension | Existence | `classicism-implies-existence-r` |
| Persistent Comprehension | NI | `classicism-implies-identity-necessary-r` |
| Persistent Comprehension | Inextensible Comprehension | `persistent-comprehension-r-implies-actuality`, `actuality-implies-inextensible-comprehension-r` |
| Persistent Comprehension | Intensionality | `classicism-implies-intensionality-r` |
| Persistent Comprehension | 4 | `classicism-implies-modal-four` |
| Persistent Comprehension | K | `classicism-implies-modal-k` |
| Persistent Comprehension | T | `classicism-implies-modal-t` |
| Persistent Comprehension | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Persistent Comprehension | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Persistent Comprehension | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Plenitude | Actual Profile | `plenitude-r-implies-actuality`, `actuality-implies-actual-profile-r` |
| Plenitude | Actuality | `plenitude-r-implies-actuality` |
| Plenitude | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Plenitude | CBF | `classicism-implies-converse-barcan-r` |
| Plenitude | ND | `plenitude-r-implies-distinctness-necessary-r` |
| Plenitude | ND (type t) | `plenitude-r-implies-distinctness-necessary-r`, `distinctness-necessary-r-implies-distinctness-necessary-t` |
| Plenitude | Existence | `classicism-implies-existence-r` |
| Plenitude | NI | `classicism-implies-identity-necessary-r` |
| Plenitude | Inextensible Comprehension | `plenitude-r-implies-actuality`, `actuality-implies-inextensible-comprehension-r` |
| Plenitude | Intensionality | `classicism-implies-intensionality-r` |
| Plenitude | B | `plenitude-r-implies-distinctness-necessary-r`, `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b` |
| Plenitude | 5 | `plenitude-r-implies-distinctness-necessary-r`, `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-modal-five` |
| Plenitude | 4 | `classicism-implies-modal-four` |
| Plenitude | K | `classicism-implies-modal-k` |
| Plenitude | T | `classicism-implies-modal-t` |
| Plenitude | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Plenitude | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Plenitude | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Plenitude | Persistent Comprehension | `plenitude-r-implies-actuality`, `actuality-implies-persistent-comprehension-r` |
| Plenitude | B for pure sentences | `plenitude-r-implies-distinctness-necessary-r`, `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r` |
| Possibility+ | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Possibility+ | CBF | `classicism-implies-converse-barcan-r` |
| Possibility+ | Distinctness (pure) | `possibility-plus-r-implies-possibility-schema-r`, `possibility-schema-r-implies-distinctness-schema-r` |
| Possibility+ | Existence | `classicism-implies-existence-r` |
| Possibility+ | NI | `classicism-implies-identity-necessary-r` |
| Possibility+ | Intensionality | `classicism-implies-intensionality-r` |
| Possibility+ | 4 | `classicism-implies-modal-four` |
| Possibility+ | K | `classicism-implies-modal-k` |
| Possibility+ | T | `classicism-implies-modal-t` |
| Possibility+ | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Possibility+ | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Possibility+ | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Possibility+ | Possibility (pure) | `possibility-plus-r-implies-possibility-schema-r` |
| Possibility (pure) | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Possibility (pure) | CBF | `classicism-implies-converse-barcan-r` |
| Possibility (pure) | Distinctness (pure) | `possibility-schema-r-implies-distinctness-schema-r` |
| Possibility (pure) | Existence | `classicism-implies-existence-r` |
| Possibility (pure) | NI | `classicism-implies-identity-necessary-r` |
| Possibility (pure) | Intensionality | `classicism-implies-intensionality-r` |
| Possibility (pure) | 4 | `classicism-implies-modal-four` |
| Possibility (pure) | K | `classicism-implies-modal-k` |
| Possibility (pure) | T | `classicism-implies-modal-t` |
| Possibility (pure) | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Possibility (pure) | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Possibility (pure) | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Possibility (signature Σ) | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Possibility (signature Σ) | CBF | `classicism-implies-converse-barcan-r` |
| Possibility (signature Σ) | Distinctness (pure) | `possibility-signature-r-implies-distinctness-signature-r`, `distinctness-signature-r-implies-distinctness-schema-r` |
| Possibility (signature Σ) | Distinctness (signature Σ) | `possibility-signature-r-implies-distinctness-signature-r` |
| Possibility (signature Σ) | Existence | `classicism-implies-existence-r` |
| Possibility (signature Σ) | NI | `classicism-implies-identity-necessary-r` |
| Possibility (signature Σ) | Intensionality | `classicism-implies-intensionality-r` |
| Possibility (signature Σ) | 4 | `classicism-implies-modal-four` |
| Possibility (signature Σ) | K | `classicism-implies-modal-k` |
| Possibility (signature Σ) | T | `classicism-implies-modal-t` |
| Possibility (signature Σ) | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Possibility (signature Σ) | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Possibility (signature Σ) | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Possibility (signature Σ) | Possibility (pure) | `possibility-signature-r-implies-distinctness-signature-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `distinctness-schema-r-implies-possibility-schema-r` |
| Possibility (signature Σ) | Separated Structure | `possibility-signature-r-implies-distinctness-signature-r`, `distinctness-signature-r-implies-separated-structure-r` |
| Possibility (signature Σ) | Witnessed Possibility | `possibility-signature-r-implies-witnessed-possibility-r` |
| B for pure sentences | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| B for pure sentences | CBF | `classicism-implies-converse-barcan-r` |
| B for pure sentences | Existence | `classicism-implies-existence-r` |
| B for pure sentences | NI | `classicism-implies-identity-necessary-r` |
| B for pure sentences | Intensionality | `classicism-implies-intensionality-r` |
| B for pure sentences | 4 | `classicism-implies-modal-four` |
| B for pure sentences | K | `classicism-implies-modal-k` |
| B for pure sentences | T | `classicism-implies-modal-t` |
| B for pure sentences | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| B for pure sentences | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| B for pure sentences | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Relational Choice | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Relational Choice | CBF | `classicism-implies-converse-barcan-r` |
| Relational Choice | Existence | `classicism-implies-existence-r` |
| Relational Choice | NI | `classicism-implies-identity-necessary-r` |
| Relational Choice | Intensionality | `classicism-implies-intensionality-r` |
| Relational Choice | 4 | `classicism-implies-modal-four` |
| Relational Choice | K | `classicism-implies-modal-k` |
| Relational Choice | T | `classicism-implies-modal-t` |
| Relational Choice | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Relational Choice | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Relational Choice | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Rigid Comprehension | Actual Profile | `rigid-comprehension-r-implies-actuality`, `actuality-implies-actual-profile-r` |
| Rigid Comprehension | Actuality | `rigid-comprehension-r-implies-actuality` |
| Rigid Comprehension | Boolean Completeness | `rigid-comprehension-r-implies-boolean-completeness-r` |
| Rigid Comprehension | Boolean Completeness (type t) | `rigid-comprehension-r-implies-boolean-completeness-r`, `boolean-completeness-r-implies-boolean-completeness-t` |
| Rigid Comprehension | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Rigid Comprehension | CBF | `classicism-implies-converse-barcan-r` |
| Rigid Comprehension | Existence | `classicism-implies-existence-r` |
| Rigid Comprehension | NI | `classicism-implies-identity-necessary-r` |
| Rigid Comprehension | Inextensible Comprehension | `rigid-comprehension-r-implies-inextensible-comprehension-r` |
| Rigid Comprehension | Intensionality | `classicism-implies-intensionality-r` |
| Rigid Comprehension | 4 | `classicism-implies-modal-four` |
| Rigid Comprehension | K | `classicism-implies-modal-k` |
| Rigid Comprehension | T | `classicism-implies-modal-t` |
| Rigid Comprehension | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Rigid Comprehension | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Rigid Comprehension | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Rigid Comprehension | Persistent Comprehension | `rigid-comprehension-r-implies-persistent-comprehension-r` |
| Separated Structure | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Separated Structure | CBF | `classicism-implies-converse-barcan-r` |
| Separated Structure | Existence | `classicism-implies-existence-r` |
| Separated Structure | NI | `classicism-implies-identity-necessary-r` |
| Separated Structure | Intensionality | `classicism-implies-intensionality-r` |
| Separated Structure | 4 | `classicism-implies-modal-four` |
| Separated Structure | K | `classicism-implies-modal-k` |
| Separated Structure | T | `classicism-implies-modal-t` |
| Separated Structure | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Separated Structure | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Separated Structure | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Strong Possibility (pure) | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Strong Possibility (pure) | CBF | `classicism-implies-converse-barcan-r` |
| Strong Possibility (pure) | Distinctness (pure) | `strong-possibility-r-implies-possibility-schema-r`, `possibility-schema-r-implies-distinctness-schema-r` |
| Strong Possibility (pure) | Existence | `classicism-implies-existence-r` |
| Strong Possibility (pure) | NI | `classicism-implies-identity-necessary-r` |
| Strong Possibility (pure) | Intensionality | `classicism-implies-intensionality-r` |
| Strong Possibility (pure) | 4 | `classicism-implies-modal-four` |
| Strong Possibility (pure) | K | `classicism-implies-modal-k` |
| Strong Possibility (pure) | T | `classicism-implies-modal-t` |
| Strong Possibility (pure) | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Strong Possibility (pure) | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Strong Possibility (pure) | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Strong Possibility (pure) | Possibility (pure) | `strong-possibility-r-implies-possibility-schema-r` |
| Strong Possibility (signature Σ) | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Strong Possibility (signature Σ) | CBF | `classicism-implies-converse-barcan-r` |
| Strong Possibility (signature Σ) | Distinctness (pure) | `strong-possibility-signature-r-implies-possibility-signature-r`, `possibility-signature-r-implies-distinctness-signature-r`, `distinctness-signature-r-implies-distinctness-schema-r` |
| Strong Possibility (signature Σ) | Distinctness (signature Σ) | `strong-possibility-signature-r-implies-possibility-signature-r`, `possibility-signature-r-implies-distinctness-signature-r` |
| Strong Possibility (signature Σ) | Existence | `classicism-implies-existence-r` |
| Strong Possibility (signature Σ) | NI | `classicism-implies-identity-necessary-r` |
| Strong Possibility (signature Σ) | Intensionality | `classicism-implies-intensionality-r` |
| Strong Possibility (signature Σ) | 4 | `classicism-implies-modal-four` |
| Strong Possibility (signature Σ) | K | `classicism-implies-modal-k` |
| Strong Possibility (signature Σ) | T | `classicism-implies-modal-t` |
| Strong Possibility (signature Σ) | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Strong Possibility (signature Σ) | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Strong Possibility (signature Σ) | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Strong Possibility (signature Σ) | Possibility (pure) | `strong-possibility-signature-r-implies-possibility-signature-r`, `possibility-signature-r-implies-distinctness-signature-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `distinctness-schema-r-implies-possibility-schema-r` |
| Strong Possibility (signature Σ) | Possibility (signature Σ) | `strong-possibility-signature-r-implies-possibility-signature-r` |
| Strong Possibility (signature Σ) | Separated Structure | `strong-possibility-signature-r-implies-possibility-signature-r`, `possibility-signature-r-implies-distinctness-signature-r`, `distinctness-signature-r-implies-separated-structure-r` |
| Strong Possibility (signature Σ) | Witnessed Possibility | `strong-possibility-signature-r-implies-possibility-signature-r`, `possibility-signature-r-implies-witnessed-possibility-r` |
| Tractarianism | BF | `tractarianism-r-implies-barcan-r` |
| Tractarianism | BF (type t) | `tractarianism-r-implies-barcan-r`, `barcan-r-implies-barcan-t` |
| Tractarianism | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Tractarianism | CBF | `classicism-implies-converse-barcan-r` |
| Tractarianism | Existence | `classicism-implies-existence-r` |
| Tractarianism | Functionality | `tractarianism-r-implies-barcan-r`, `barcan-r-implies-functionality-r` |
| Tractarianism | NI | `classicism-implies-identity-necessary-r` |
| Tractarianism | Intensionality | `classicism-implies-intensionality-r` |
| Tractarianism | 4 | `classicism-implies-modal-four` |
| Tractarianism | K | `classicism-implies-modal-k` |
| Tractarianism | T | `classicism-implies-modal-t` |
| Tractarianism | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Tractarianism | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Tractarianism | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |
| Witnessed Possibility | Broad Necessitism | `classicism-implies-broad-necessitism-r` |
| Witnessed Possibility | CBF | `classicism-implies-converse-barcan-r` |
| Witnessed Possibility | Existence | `classicism-implies-existence-r` |
| Witnessed Possibility | NI | `classicism-implies-identity-necessary-r` |
| Witnessed Possibility | Intensionality | `classicism-implies-intensionality-r` |
| Witnessed Possibility | 4 | `classicism-implies-modal-four` |
| Witnessed Possibility | K | `classicism-implies-modal-k` |
| Witnessed Possibility | T | `classicism-implies-modal-t` |
| Witnessed Possibility | Modalized Fregean Axiom | `classicism-implies-modalized-fregean` |
| Witnessed Possibility | Modalized Functionality | `classicism-implies-modalized-functionality-r` |
| Witnessed Possibility | Ordinary Comprehension | `classicism-implies-ordinary-comprehension-r` |

### 6.3 Refuted single-premise implications (1946)

Read *A ⇏ B*: assuming A alone does not yield B, as the named model shows.

| From | To | Witness model |
| --- | --- | --- |
| Actual Profile | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast` |
| Actual Profile | Atomicity (type t) | `finite-support-qualitative-contrast` |
| Actual Profile | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Actual Profile | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Actual Profile | BF (type t) | `full-idempotent-monoid` |
| Actual Profile | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts` |
| Actual Profile | Converse Witnessed Possibility | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Actual Profile | ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Actual Profile | ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Actual Profile | Distinctness (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Actual Profile | Distinctness (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Actual Profile | Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Actual Profile | Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Actual Profile | Functional Choice | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Actual Profile | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Actual Profile | Fundamental Possibility | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Actual Profile | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-truncated-shifts` |
| Actual Profile | Infinity (type e) | `full-henkin-singleton-base` |
| Actual Profile | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Actual Profile | Logical Necessity | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Actual Profile | B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Actual Profile | 5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Actual Profile | □Actuality | `coalesced-maximalist-root`, `finite-support-qualitative-contrast` |
| Actual Profile | □Atomicity | `coalesced-maximalist-root`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast` |
| Actual Profile | □BF | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Actual Profile | □BF (type t) | `full-idempotent-monoid` |
| Actual Profile | □Boolean Completeness | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| Actual Profile | □ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Actual Profile | □ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Actual Profile | □Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Actual Profile | □Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Actual Profile | □Functionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Actual Profile | □B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Actual Profile | □5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Actual Profile | □Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Actual Profile | □Rigid Comprehension | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| Actual Profile | □Tractarianism | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Actual Profile | No Pure Contingency | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Actual Profile | Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Actual Profile | Possibility+ | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Actual Profile | Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Actual Profile | Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Actual Profile | Relational Choice | `henkin-without-relational-choice` |
| Actual Profile | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts` |
| Actual Profile | Strong Possibility (pure) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Actual Profile | Strong Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Actual Profile | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Actuality | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast` |
| Actuality | Atomicity (type t) | `finite-support-qualitative-contrast` |
| Actuality | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Actuality | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Actuality | BF (type t) | `full-idempotent-monoid` |
| Actuality | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts` |
| Actuality | Converse Witnessed Possibility | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Actuality | ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Actuality | ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Actuality | Distinctness (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Actuality | Distinctness (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Actuality | Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Actuality | Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Actuality | Functional Choice | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Actuality | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Actuality | Fundamental Possibility | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Actuality | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-truncated-shifts` |
| Actuality | Infinity (type e) | `full-henkin-singleton-base` |
| Actuality | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Actuality | Logical Necessity | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Actuality | B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Actuality | 5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Actuality | □Actuality | `coalesced-maximalist-root`, `finite-support-qualitative-contrast` |
| Actuality | □Atomicity | `coalesced-maximalist-root`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast` |
| Actuality | □BF | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Actuality | □BF (type t) | `full-idempotent-monoid` |
| Actuality | □Boolean Completeness | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| Actuality | □ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Actuality | □ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Actuality | □Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Actuality | □Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Actuality | □Functionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Actuality | □B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Actuality | □5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Actuality | □Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Actuality | □Rigid Comprehension | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| Actuality | □Tractarianism | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Actuality | No Pure Contingency | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Actuality | Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Actuality | Possibility+ | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Actuality | Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Actuality | Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Actuality | Relational Choice | `henkin-without-relational-choice` |
| Actuality | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts` |
| Actuality | Strong Possibility (pure) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Actuality | Strong Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Actuality | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Atomicity | Actual Profile | `finite-support-truncations` |
| Atomicity | Actuality | `finite-support-truncations` |
| Atomicity | BF | `finite-support-dyadic-roundings`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Atomicity | BF (type t) | `full-idempotent-monoid` |
| Atomicity | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Atomicity | Converse Witnessed Possibility | `full-two-object-chain`, `full-two-object-retract` |
| Atomicity | ND | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Atomicity | ND (type t) | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Atomicity | Distinctness (pure) | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Atomicity | Distinctness (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Atomicity | Extensionality | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Atomicity | Fregean Axiom | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Atomicity | Functional Choice | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Atomicity | Functionality | `finite-support-dyadic-roundings`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Atomicity | Fundamental Possibility | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Atomicity | Gallin Extensional Comprehension | `finite-support-truncated-shifts` |
| Atomicity | Infinity (type e) | `full-henkin-singleton-base` |
| Atomicity | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Atomicity | Logical Necessity | `full-two-object-chain`, `full-two-object-retract` |
| Atomicity | B | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Atomicity | 5 | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Atomicity | □Actuality | `finite-support-truncations` |
| Atomicity | □BF | `finite-support-dyadic-roundings`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Atomicity | □BF (type t) | `full-idempotent-monoid` |
| Atomicity | □Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Atomicity | □ND | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Atomicity | □ND (type t) | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Atomicity | □Extensionality | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Atomicity | □Fregean Axiom | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Atomicity | □Functionality | `finite-support-dyadic-roundings`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Atomicity | □B | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Atomicity | □5 | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Atomicity | □Plenitude | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Atomicity | □Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Atomicity | □Tractarianism | `finite-support-dyadic-roundings`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Atomicity | No Pure Contingency | `full-two-object-chain`, `full-two-object-retract` |
| Atomicity | Persistent Comprehension | `finite-support-truncations` |
| Atomicity | Plenitude | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Atomicity | Possibility+ | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Atomicity | Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Atomicity | Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Atomicity | Relational Choice | `henkin-without-relational-choice` |
| Atomicity | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Atomicity | Strong Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Atomicity | Strong Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Atomicity | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Atomicity (type t) | Actual Profile | `finite-support-truncations` |
| Atomicity (type t) | Actuality | `finite-support-truncations` |
| Atomicity (type t) | BF | `finite-support-dyadic-roundings`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Atomicity (type t) | BF (type t) | `full-idempotent-monoid` |
| Atomicity (type t) | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Atomicity (type t) | Converse Witnessed Possibility | `full-two-object-chain`, `full-two-object-retract` |
| Atomicity (type t) | ND | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Atomicity (type t) | ND (type t) | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Atomicity (type t) | Distinctness (pure) | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Atomicity (type t) | Distinctness (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Atomicity (type t) | Extensionality | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Atomicity (type t) | Fregean Axiom | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Atomicity (type t) | Functional Choice | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Atomicity (type t) | Functionality | `finite-support-dyadic-roundings`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Atomicity (type t) | Fundamental Possibility | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Atomicity (type t) | Gallin Extensional Comprehension | `finite-support-truncated-shifts` |
| Atomicity (type t) | Infinity (type e) | `full-henkin-singleton-base` |
| Atomicity (type t) | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Atomicity (type t) | Logical Necessity | `full-two-object-chain`, `full-two-object-retract` |
| Atomicity (type t) | B | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Atomicity (type t) | 5 | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Atomicity (type t) | □Actuality | `finite-support-truncations` |
| Atomicity (type t) | □BF | `finite-support-dyadic-roundings`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Atomicity (type t) | □BF (type t) | `full-idempotent-monoid` |
| Atomicity (type t) | □Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Atomicity (type t) | □ND | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Atomicity (type t) | □ND (type t) | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Atomicity (type t) | □Extensionality | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Atomicity (type t) | □Fregean Axiom | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Atomicity (type t) | □Functionality | `finite-support-dyadic-roundings`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Atomicity (type t) | □B | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Atomicity (type t) | □5 | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Atomicity (type t) | □Plenitude | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Atomicity (type t) | □Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Atomicity (type t) | □Tractarianism | `finite-support-dyadic-roundings`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Atomicity (type t) | No Pure Contingency | `full-two-object-chain`, `full-two-object-retract` |
| Atomicity (type t) | Persistent Comprehension | `finite-support-truncations` |
| Atomicity (type t) | Plenitude | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Atomicity (type t) | Possibility+ | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Atomicity (type t) | Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Atomicity (type t) | Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Atomicity (type t) | Relational Choice | `henkin-without-relational-choice` |
| Atomicity (type t) | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Atomicity (type t) | Strong Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Atomicity (type t) | Strong Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Atomicity (type t) | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Atomlessness | Actual Profile | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | BF | `finite-support-monotone-maps` |
| Atomlessness | Boolean Completeness | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | ND | `finite-support-monotone-maps`, `finite-support-monotone-surjections` |
| Atomlessness | ND (type t) | `finite-support-monotone-maps`, `finite-support-monotone-surjections` |
| Atomlessness | Distinctness (pure) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | Distinctness (signature Σ) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | Functional Choice | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | Functionality | `finite-support-monotone-maps` |
| Atomlessness | Fundamental Possibility | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | Gallin Extensional Comprehension | `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | B | `finite-support-monotone-maps`, `finite-support-monotone-surjections` |
| Atomlessness | 5 | `finite-support-monotone-maps`, `finite-support-monotone-surjections` |
| Atomlessness | □Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | □BF | `finite-support-monotone-maps` |
| Atomlessness | □Boolean Completeness | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | □ND | `finite-support-monotone-maps`, `finite-support-monotone-surjections` |
| Atomlessness | □ND (type t) | `finite-support-monotone-maps`, `finite-support-monotone-surjections` |
| Atomlessness | □Functionality | `finite-support-monotone-maps` |
| Atomlessness | □B | `finite-support-monotone-maps`, `finite-support-monotone-surjections` |
| Atomlessness | □5 | `finite-support-monotone-maps`, `finite-support-monotone-surjections` |
| Atomlessness | □Rigid Comprehension | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | □Tractarianism | `finite-support-monotone-maps` |
| Atomlessness | Persistent Comprehension | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | Plenitude | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | Possibility+ | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | Possibility (pure) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | Possibility (signature Σ) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | Rigid Comprehension | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | Strong Possibility (pure) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | Strong Possibility (signature Σ) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Atomlessness | Tractarianism | `finite-support-monotone-maps` |
| BF | Actual Profile | `finite-support-monotone-surjections`, `finite-support-permutations` |
| BF | Actuality | `finite-support-monotone-surjections`, `finite-support-permutations` |
| BF | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| BF | Atomicity (type t) | `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| BF | Atomlessness | `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF | Boolean Completeness | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| BF | ND | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF | ND (type t) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF | Distinctness (pure) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF | Distinctness (signature Σ) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF | Extensionality | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-involution-group`, `full-surjection-monoid` |
| BF | Fregean Axiom | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-involution-group`, `full-surjection-monoid` |
| BF | Functional Choice | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF | Fundamental Possibility | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| BF | Infinity (type e) | `full-henkin-singleton-base` |
| BF | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| BF | B | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF | 5 | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF | □Actuality | `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| BF | □Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| BF | □BF | `finite-support-two-object-all-maps` |
| BF | □Boolean Completeness | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| BF | □ND | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF | □ND (type t) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF | □Extensionality | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-involution-group`, `full-surjection-monoid` |
| BF | □Fregean Axiom | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-involution-group`, `full-surjection-monoid` |
| BF | □Functionality | `finite-support-two-object-all-maps` |
| BF | □B | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF | □5 | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF | □Plenitude | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF | □Rigid Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| BF | □Tractarianism | `finite-support-two-object-all-maps` |
| BF | Persistent Comprehension | `finite-support-monotone-surjections`, `finite-support-permutations` |
| BF | Plenitude | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF | Possibility+ | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF | Possibility (pure) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF | Possibility (signature Σ) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF | Relational Choice | `henkin-without-relational-choice` |
| BF | Rigid Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| BF | Strong Possibility (pure) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF | Strong Possibility (signature Σ) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF (type t) | Actual Profile | `finite-support-monotone-surjections`, `finite-support-permutations` |
| BF (type t) | Actuality | `finite-support-monotone-surjections`, `finite-support-permutations` |
| BF (type t) | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| BF (type t) | Atomicity (type t) | `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| BF (type t) | Atomlessness | `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF (type t) | Boolean Completeness | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| BF (type t) | ND | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF (type t) | ND (type t) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF (type t) | Distinctness (pure) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF (type t) | Distinctness (signature Σ) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF (type t) | Extensionality | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-involution-group`, `full-surjection-monoid` |
| BF (type t) | Fregean Axiom | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-involution-group`, `full-surjection-monoid` |
| BF (type t) | Functional Choice | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF (type t) | Fundamental Possibility | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF (type t) | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| BF (type t) | Infinity (type e) | `full-henkin-singleton-base` |
| BF (type t) | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| BF (type t) | B | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF (type t) | 5 | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF (type t) | □Actuality | `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| BF (type t) | □Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| BF (type t) | □BF | `finite-support-two-object-all-maps` |
| BF (type t) | □Boolean Completeness | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| BF (type t) | □ND | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF (type t) | □ND (type t) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF (type t) | □Extensionality | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-involution-group`, `full-surjection-monoid` |
| BF (type t) | □Fregean Axiom | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-involution-group`, `full-surjection-monoid` |
| BF (type t) | □Functionality | `finite-support-two-object-all-maps` |
| BF (type t) | □B | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF (type t) | □5 | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF (type t) | □Plenitude | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF (type t) | □Rigid Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| BF (type t) | □Tractarianism | `finite-support-two-object-all-maps` |
| BF (type t) | Persistent Comprehension | `finite-support-monotone-surjections`, `finite-support-permutations` |
| BF (type t) | Plenitude | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| BF (type t) | Possibility+ | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF (type t) | Possibility (pure) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF (type t) | Possibility (signature Σ) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF (type t) | Relational Choice | `henkin-without-relational-choice` |
| BF (type t) | Rigid Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| BF (type t) | Strong Possibility (pure) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| BF (type t) | Strong Possibility (signature Σ) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Boolean Completeness | Atomicity | `finite-support-qualitative-contrast` |
| Boolean Completeness | Atomicity (type t) | `finite-support-qualitative-contrast` |
| Boolean Completeness | Atomlessness | `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Boolean Completeness | BF | `full-idempotent-monoid`, `full-two-object-retract` |
| Boolean Completeness | BF (type t) | `full-idempotent-monoid` |
| Boolean Completeness | Converse Witnessed Possibility | `full-two-object-chain`, `full-two-object-retract` |
| Boolean Completeness | ND | `full-idempotent-monoid`, `full-surjection-monoid` |
| Boolean Completeness | ND (type t) | `full-idempotent-monoid`, `full-surjection-monoid` |
| Boolean Completeness | Distinctness (pure) | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Boolean Completeness | Distinctness (signature Σ) | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Boolean Completeness | Extensionality | `finite-support-qualitative-contrast`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Boolean Completeness | Fregean Axiom | `finite-support-qualitative-contrast`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Boolean Completeness | Functional Choice | `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Boolean Completeness | Functionality | `full-idempotent-monoid`, `full-two-object-retract` |
| Boolean Completeness | Fundamental Possibility | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Boolean Completeness | Infinity (type e) | `full-henkin-singleton-base` |
| Boolean Completeness | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Boolean Completeness | Logical Necessity | `full-two-object-chain`, `full-two-object-retract` |
| Boolean Completeness | B | `full-idempotent-monoid`, `full-surjection-monoid` |
| Boolean Completeness | 5 | `full-idempotent-monoid`, `full-surjection-monoid` |
| Boolean Completeness | □Actuality | `finite-support-qualitative-contrast` |
| Boolean Completeness | □Atomicity | `finite-support-qualitative-contrast` |
| Boolean Completeness | □BF | `full-idempotent-monoid`, `full-two-object-retract` |
| Boolean Completeness | □BF (type t) | `full-idempotent-monoid` |
| Boolean Completeness | □Boolean Completeness | `finite-support-qualitative-contrast` |
| Boolean Completeness | □ND | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Boolean Completeness | □ND (type t) | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Boolean Completeness | □Extensionality | `finite-support-qualitative-contrast`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Boolean Completeness | □Fregean Axiom | `finite-support-qualitative-contrast`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Boolean Completeness | □Functionality | `full-idempotent-monoid`, `full-two-object-retract` |
| Boolean Completeness | □B | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Boolean Completeness | □5 | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Boolean Completeness | □Plenitude | `finite-support-qualitative-contrast`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Boolean Completeness | □Rigid Comprehension | `finite-support-qualitative-contrast` |
| Boolean Completeness | □Tractarianism | `full-idempotent-monoid`, `full-two-object-retract` |
| Boolean Completeness | No Pure Contingency | `full-two-object-chain`, `full-two-object-retract` |
| Boolean Completeness | Plenitude | `full-idempotent-monoid`, `full-surjection-monoid` |
| Boolean Completeness | Possibility+ | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Boolean Completeness | Possibility (pure) | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Boolean Completeness | Possibility (signature Σ) | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Boolean Completeness | Relational Choice | `henkin-without-relational-choice` |
| Boolean Completeness | Strong Possibility (pure) | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Boolean Completeness | Strong Possibility (signature Σ) | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Boolean Completeness | Tractarianism | `full-idempotent-monoid`, `full-two-object-retract` |
| Boolean Completeness (type t) | Atomicity | `finite-support-qualitative-contrast` |
| Boolean Completeness (type t) | Atomicity (type t) | `finite-support-qualitative-contrast` |
| Boolean Completeness (type t) | Atomlessness | `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Boolean Completeness (type t) | BF | `full-idempotent-monoid`, `full-two-object-retract` |
| Boolean Completeness (type t) | BF (type t) | `full-idempotent-monoid` |
| Boolean Completeness (type t) | Converse Witnessed Possibility | `full-two-object-chain`, `full-two-object-retract` |
| Boolean Completeness (type t) | ND | `full-idempotent-monoid`, `full-surjection-monoid` |
| Boolean Completeness (type t) | ND (type t) | `full-idempotent-monoid`, `full-surjection-monoid` |
| Boolean Completeness (type t) | Distinctness (pure) | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Boolean Completeness (type t) | Distinctness (signature Σ) | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Boolean Completeness (type t) | Extensionality | `finite-support-qualitative-contrast`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Boolean Completeness (type t) | Fregean Axiom | `finite-support-qualitative-contrast`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Boolean Completeness (type t) | Functional Choice | `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Boolean Completeness (type t) | Functionality | `full-idempotent-monoid`, `full-two-object-retract` |
| Boolean Completeness (type t) | Fundamental Possibility | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Boolean Completeness (type t) | Infinity (type e) | `full-henkin-singleton-base` |
| Boolean Completeness (type t) | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Boolean Completeness (type t) | Logical Necessity | `full-two-object-chain`, `full-two-object-retract` |
| Boolean Completeness (type t) | B | `full-idempotent-monoid`, `full-surjection-monoid` |
| Boolean Completeness (type t) | 5 | `full-idempotent-monoid`, `full-surjection-monoid` |
| Boolean Completeness (type t) | □Actuality | `finite-support-qualitative-contrast` |
| Boolean Completeness (type t) | □Atomicity | `finite-support-qualitative-contrast` |
| Boolean Completeness (type t) | □BF | `full-idempotent-monoid`, `full-two-object-retract` |
| Boolean Completeness (type t) | □BF (type t) | `full-idempotent-monoid` |
| Boolean Completeness (type t) | □Boolean Completeness | `finite-support-qualitative-contrast` |
| Boolean Completeness (type t) | □ND | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Boolean Completeness (type t) | □ND (type t) | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Boolean Completeness (type t) | □Extensionality | `finite-support-qualitative-contrast`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Boolean Completeness (type t) | □Fregean Axiom | `finite-support-qualitative-contrast`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Boolean Completeness (type t) | □Functionality | `full-idempotent-monoid`, `full-two-object-retract` |
| Boolean Completeness (type t) | □B | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Boolean Completeness (type t) | □5 | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Boolean Completeness (type t) | □Plenitude | `finite-support-qualitative-contrast`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Boolean Completeness (type t) | □Rigid Comprehension | `finite-support-qualitative-contrast` |
| Boolean Completeness (type t) | □Tractarianism | `full-idempotent-monoid`, `full-two-object-retract` |
| Boolean Completeness (type t) | No Pure Contingency | `full-two-object-chain`, `full-two-object-retract` |
| Boolean Completeness (type t) | Plenitude | `full-idempotent-monoid`, `full-surjection-monoid` |
| Boolean Completeness (type t) | Possibility+ | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Boolean Completeness (type t) | Possibility (pure) | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Boolean Completeness (type t) | Possibility (signature Σ) | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Boolean Completeness (type t) | Relational Choice | `henkin-without-relational-choice` |
| Boolean Completeness (type t) | Strong Possibility (pure) | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Boolean Completeness (type t) | Strong Possibility (signature Σ) | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Boolean Completeness (type t) | Tractarianism | `full-idempotent-monoid`, `full-two-object-retract` |
| Broad Necessitism | Actual Profile | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Broad Necessitism | Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Broad Necessitism | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Broad Necessitism | Atomicity (type t) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Broad Necessitism | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Broad Necessitism | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Broad Necessitism | BF (type t) | `full-idempotent-monoid` |
| Broad Necessitism | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Broad Necessitism | Converse Witnessed Possibility | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Broad Necessitism | ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Broad Necessitism | ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Broad Necessitism | Distinctness (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Broad Necessitism | Distinctness (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Broad Necessitism | Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Broad Necessitism | Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Broad Necessitism | Functional Choice | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Broad Necessitism | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Broad Necessitism | Fundamental Possibility | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Broad Necessitism | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| Broad Necessitism | Infinity (type e) | `full-henkin-singleton-base` |
| Broad Necessitism | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Broad Necessitism | Logical Necessity | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Broad Necessitism | B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Broad Necessitism | 5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Broad Necessitism | □Actuality | `coalesced-maximalist-root`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncations` |
| Broad Necessitism | □Atomicity | `coalesced-maximalist-root`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Broad Necessitism | □BF | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| Broad Necessitism | □BF (type t) | `full-idempotent-monoid` |
| Broad Necessitism | □Boolean Completeness | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Broad Necessitism | □ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Broad Necessitism | □ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Broad Necessitism | □Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Broad Necessitism | □Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Broad Necessitism | □Functionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| Broad Necessitism | □B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Broad Necessitism | □5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Broad Necessitism | □Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Broad Necessitism | □Rigid Comprehension | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| Broad Necessitism | □Tractarianism | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| Broad Necessitism | No Pure Contingency | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Broad Necessitism | Persistent Comprehension | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Broad Necessitism | Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Broad Necessitism | Possibility+ | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Broad Necessitism | Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Broad Necessitism | Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Broad Necessitism | Relational Choice | `henkin-without-relational-choice` |
| Broad Necessitism | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| Broad Necessitism | Strong Possibility (pure) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Broad Necessitism | Strong Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Broad Necessitism | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| CBF | Actual Profile | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| CBF | Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| CBF | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| CBF | Atomicity (type t) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| CBF | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| CBF | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| CBF | BF (type t) | `full-idempotent-monoid` |
| CBF | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| CBF | Converse Witnessed Possibility | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| CBF | ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| CBF | ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| CBF | Distinctness (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| CBF | Distinctness (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| CBF | Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| CBF | Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| CBF | Functional Choice | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| CBF | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| CBF | Fundamental Possibility | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| CBF | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| CBF | Infinity (type e) | `full-henkin-singleton-base` |
| CBF | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| CBF | Logical Necessity | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| CBF | B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| CBF | 5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| CBF | □Actuality | `coalesced-maximalist-root`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncations` |
| CBF | □Atomicity | `coalesced-maximalist-root`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| CBF | □BF | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| CBF | □BF (type t) | `full-idempotent-monoid` |
| CBF | □Boolean Completeness | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| CBF | □ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| CBF | □ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| CBF | □Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| CBF | □Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| CBF | □Functionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| CBF | □B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| CBF | □5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| CBF | □Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| CBF | □Rigid Comprehension | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| CBF | □Tractarianism | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| CBF | No Pure Contingency | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| CBF | Persistent Comprehension | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| CBF | Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| CBF | Possibility+ | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| CBF | Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| CBF | Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| CBF | Relational Choice | `henkin-without-relational-choice` |
| CBF | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| CBF | Strong Possibility (pure) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| CBF | Strong Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| CBF | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Converse Witnessed Possibility | Actual Profile | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Converse Witnessed Possibility | Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Converse Witnessed Possibility | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Converse Witnessed Possibility | Atomicity (type t) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Converse Witnessed Possibility | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Converse Witnessed Possibility | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid` |
| Converse Witnessed Possibility | BF (type t) | `full-idempotent-monoid` |
| Converse Witnessed Possibility | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Converse Witnessed Possibility | ND | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Converse Witnessed Possibility | ND (type t) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Converse Witnessed Possibility | Extensionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid` |
| Converse Witnessed Possibility | Fregean Axiom | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid` |
| Converse Witnessed Possibility | Functional Choice | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Converse Witnessed Possibility | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid` |
| Converse Witnessed Possibility | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| Converse Witnessed Possibility | Infinity (type e) | `full-henkin-singleton-base` |
| Converse Witnessed Possibility | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Converse Witnessed Possibility | B | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Converse Witnessed Possibility | 5 | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Converse Witnessed Possibility | □Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Converse Witnessed Possibility | □Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| Converse Witnessed Possibility | □BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid` |
| Converse Witnessed Possibility | □BF (type t) | `full-idempotent-monoid` |
| Converse Witnessed Possibility | □Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Converse Witnessed Possibility | □ND | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Converse Witnessed Possibility | □ND (type t) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Converse Witnessed Possibility | □Extensionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid` |
| Converse Witnessed Possibility | □Fregean Axiom | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid` |
| Converse Witnessed Possibility | □Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid` |
| Converse Witnessed Possibility | □B | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Converse Witnessed Possibility | □5 | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Converse Witnessed Possibility | □Plenitude | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Converse Witnessed Possibility | □Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Converse Witnessed Possibility | □Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid` |
| Converse Witnessed Possibility | Persistent Comprehension | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Converse Witnessed Possibility | Plenitude | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Converse Witnessed Possibility | Relational Choice | `henkin-without-relational-choice` |
| Converse Witnessed Possibility | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Converse Witnessed Possibility | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid` |
| ND | Actual Profile | `finite-support-permutations` |
| ND | Actuality | `finite-support-permutations` |
| ND | Atomicity | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| ND | Atomicity (type t) | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| ND | Atomlessness | `full-henkin-singleton-base`, `full-involution-group`, `full-two-object-retract`, `henkin-without-relational-choice` |
| ND | BF | `full-two-object-retract` |
| ND | Boolean Completeness | `finite-support-permutations` |
| ND | Converse Witnessed Possibility | `full-two-object-retract` |
| ND | Extensionality | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| ND | Fregean Axiom | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| ND | Functional Choice | `finite-support-permutations`, `henkin-without-relational-choice` |
| ND | Functionality | `full-two-object-retract` |
| ND | Gallin Extensional Comprehension | `finite-support-permutations` |
| ND | Infinity (type e) | `full-henkin-singleton-base` |
| ND | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| ND | Logical Necessity | `full-two-object-retract` |
| ND | □Actuality | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| ND | □Atomicity | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| ND | □BF | `full-two-object-retract` |
| ND | □Boolean Completeness | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| ND | □ND | `full-two-object-retract` |
| ND | □ND (type t) | `full-two-object-retract` |
| ND | □Extensionality | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| ND | □Fregean Axiom | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| ND | □Functionality | `full-two-object-retract` |
| ND | □B | `full-two-object-retract` |
| ND | □5 | `full-two-object-retract` |
| ND | □Plenitude | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-two-object-retract` |
| ND | □Rigid Comprehension | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| ND | □Tractarianism | `full-two-object-retract` |
| ND | No Pure Contingency | `full-two-object-retract` |
| ND | Persistent Comprehension | `finite-support-permutations` |
| ND | Plenitude | `finite-support-permutations` |
| ND | Relational Choice | `henkin-without-relational-choice` |
| ND | Rigid Comprehension | `finite-support-permutations` |
| ND | Tractarianism | `full-two-object-retract` |
| ND (type t) | Actual Profile | `finite-support-permutations` |
| ND (type t) | Actuality | `finite-support-permutations` |
| ND (type t) | Atomicity | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| ND (type t) | Atomicity (type t) | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| ND (type t) | Atomlessness | `full-henkin-singleton-base`, `full-involution-group`, `full-two-object-retract`, `henkin-without-relational-choice` |
| ND (type t) | BF | `full-two-object-retract` |
| ND (type t) | Boolean Completeness | `finite-support-permutations` |
| ND (type t) | Converse Witnessed Possibility | `full-two-object-retract` |
| ND (type t) | Extensionality | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| ND (type t) | Fregean Axiom | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| ND (type t) | Functional Choice | `finite-support-permutations`, `henkin-without-relational-choice` |
| ND (type t) | Functionality | `full-two-object-retract` |
| ND (type t) | Gallin Extensional Comprehension | `finite-support-permutations` |
| ND (type t) | Infinity (type e) | `full-henkin-singleton-base` |
| ND (type t) | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| ND (type t) | Logical Necessity | `full-two-object-retract` |
| ND (type t) | □Actuality | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| ND (type t) | □Atomicity | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| ND (type t) | □BF | `full-two-object-retract` |
| ND (type t) | □Boolean Completeness | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| ND (type t) | □ND | `full-two-object-retract` |
| ND (type t) | □ND (type t) | `full-two-object-retract` |
| ND (type t) | □Extensionality | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| ND (type t) | □Fregean Axiom | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| ND (type t) | □Functionality | `full-two-object-retract` |
| ND (type t) | □B | `full-two-object-retract` |
| ND (type t) | □5 | `full-two-object-retract` |
| ND (type t) | □Plenitude | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-two-object-retract` |
| ND (type t) | □Rigid Comprehension | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| ND (type t) | □Tractarianism | `full-two-object-retract` |
| ND (type t) | No Pure Contingency | `full-two-object-retract` |
| ND (type t) | Persistent Comprehension | `finite-support-permutations` |
| ND (type t) | Plenitude | `finite-support-permutations` |
| ND (type t) | Relational Choice | `henkin-without-relational-choice` |
| ND (type t) | Rigid Comprehension | `finite-support-permutations` |
| ND (type t) | Tractarianism | `full-two-object-retract` |
| Distinctness-preserving collapse | Atomlessness | `full-henkin-singleton-base` |
| Distinctness-preserving collapse | Converse Witnessed Possibility | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | ND | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | ND (type t) | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | Distinctness (pure) | `full-henkin-singleton-base` |
| Distinctness-preserving collapse | Distinctness (signature Σ) | `full-henkin-singleton-base` |
| Distinctness-preserving collapse | Extensionality | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | Fregean Axiom | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | Functional Choice | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | Fundamental Possibility | `full-henkin-singleton-base` |
| Distinctness-preserving collapse | Infinity (type e) | `full-henkin-singleton-base` |
| Distinctness-preserving collapse | Infinity (type t) | `full-henkin-singleton-base` |
| Distinctness-preserving collapse | Logical Necessity | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | B | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | 5 | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | □Actuality | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | □Atomicity | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | □BF | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | □Boolean Completeness | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | □ND | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | □ND (type t) | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | □Extensionality | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | □Fregean Axiom | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | □Functionality | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | □B | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | □5 | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | □Plenitude | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | □Rigid Comprehension | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | □Tractarianism | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | No Pure Contingency | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | Plenitude | `coalesced-maximalist-root` |
| Distinctness-preserving collapse | Possibility+ | `full-henkin-singleton-base` |
| Distinctness-preserving collapse | Possibility (pure) | `full-henkin-singleton-base` |
| Distinctness-preserving collapse | Possibility (signature Σ) | `full-henkin-singleton-base` |
| Distinctness-preserving collapse | Strong Possibility (pure) | `coalesced-maximalist-root`, `full-henkin-singleton-base` |
| Distinctness-preserving collapse | Strong Possibility (signature Σ) | `full-henkin-singleton-base` |
| Distinctness (pure) | Strong Possibility (pure) | `coalesced-maximalist-root` |
| Distinctness (signature Σ) | Strong Possibility (pure) | `coalesced-maximalist-root` |
| Existence | Actual Profile | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Existence | Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Existence | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Existence | Atomicity (type t) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Existence | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Existence | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Existence | BF (type t) | `full-idempotent-monoid` |
| Existence | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Existence | Converse Witnessed Possibility | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Existence | ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Existence | ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Existence | Distinctness (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Existence | Distinctness (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Existence | Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Existence | Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Existence | Functional Choice | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Existence | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Existence | Fundamental Possibility | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Existence | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| Existence | Infinity (type e) | `full-henkin-singleton-base` |
| Existence | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Existence | Logical Necessity | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Existence | B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Existence | 5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Existence | □Actuality | `coalesced-maximalist-root`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncations` |
| Existence | □Atomicity | `coalesced-maximalist-root`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Existence | □BF | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| Existence | □BF (type t) | `full-idempotent-monoid` |
| Existence | □Boolean Completeness | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Existence | □ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Existence | □ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Existence | □Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Existence | □Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Existence | □Functionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| Existence | □B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Existence | □5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Existence | □Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Existence | □Rigid Comprehension | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| Existence | □Tractarianism | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| Existence | No Pure Contingency | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Existence | Persistent Comprehension | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Existence | Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Existence | Possibility+ | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Existence | Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Existence | Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Existence | Relational Choice | `henkin-without-relational-choice` |
| Existence | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| Existence | Strong Possibility (pure) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Existence | Strong Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Existence | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Extensionality | Functional Choice | `henkin-without-relational-choice` |
| Extensionality | Infinity (type e) | `full-henkin-singleton-base` |
| Extensionality | Relational Choice | `henkin-without-relational-choice` |
| Fregean Axiom | Functional Choice | `henkin-without-relational-choice` |
| Fregean Axiom | Infinity (type e) | `full-henkin-singleton-base` |
| Fregean Axiom | Relational Choice | `henkin-without-relational-choice` |
| Functional Choice | Atomlessness | `full-henkin-singleton-base` |
| Functional Choice | Infinity (type e) | `full-henkin-singleton-base` |
| Functional Choice | Infinity (type t) | `full-henkin-singleton-base` |
| Functionality | Actual Profile | `finite-support-monotone-surjections`, `finite-support-permutations` |
| Functionality | Actuality | `finite-support-monotone-surjections`, `finite-support-permutations` |
| Functionality | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Functionality | Atomicity (type t) | `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Functionality | Atomlessness | `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Functionality | Boolean Completeness | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| Functionality | ND | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Functionality | ND (type t) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Functionality | Distinctness (pure) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Functionality | Distinctness (signature Σ) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Functionality | Extensionality | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-involution-group`, `full-surjection-monoid` |
| Functionality | Fregean Axiom | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-involution-group`, `full-surjection-monoid` |
| Functionality | Functional Choice | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Functionality | Fundamental Possibility | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Functionality | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| Functionality | Infinity (type e) | `full-henkin-singleton-base` |
| Functionality | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Functionality | B | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Functionality | 5 | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Functionality | □Actuality | `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Functionality | □Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Functionality | □BF | `finite-support-two-object-all-maps` |
| Functionality | □Boolean Completeness | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| Functionality | □ND | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Functionality | □ND (type t) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Functionality | □Extensionality | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-involution-group`, `full-surjection-monoid` |
| Functionality | □Fregean Axiom | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-involution-group`, `full-surjection-monoid` |
| Functionality | □Functionality | `finite-support-two-object-all-maps` |
| Functionality | □B | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Functionality | □5 | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Functionality | □Plenitude | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Functionality | □Rigid Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| Functionality | □Tractarianism | `finite-support-two-object-all-maps` |
| Functionality | Persistent Comprehension | `finite-support-monotone-surjections`, `finite-support-permutations` |
| Functionality | Plenitude | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Functionality | Possibility+ | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Functionality | Possibility (pure) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Functionality | Possibility (signature Σ) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Functionality | Relational Choice | `henkin-without-relational-choice` |
| Functionality | Rigid Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| Functionality | Strong Possibility (pure) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Functionality | Strong Possibility (signature Σ) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| NI | Actual Profile | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| NI | Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| NI | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| NI | Atomicity (type t) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| NI | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| NI | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| NI | BF (type t) | `full-idempotent-monoid` |
| NI | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| NI | Converse Witnessed Possibility | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| NI | ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| NI | ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| NI | Distinctness (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| NI | Distinctness (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| NI | Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| NI | Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| NI | Functional Choice | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| NI | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| NI | Fundamental Possibility | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| NI | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| NI | Infinity (type e) | `full-henkin-singleton-base` |
| NI | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| NI | Logical Necessity | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| NI | B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| NI | 5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| NI | □Actuality | `coalesced-maximalist-root`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncations` |
| NI | □Atomicity | `coalesced-maximalist-root`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| NI | □BF | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| NI | □BF (type t) | `full-idempotent-monoid` |
| NI | □Boolean Completeness | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| NI | □ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| NI | □ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| NI | □Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| NI | □Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| NI | □Functionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| NI | □B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| NI | □5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| NI | □Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| NI | □Rigid Comprehension | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| NI | □Tractarianism | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| NI | No Pure Contingency | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| NI | Persistent Comprehension | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| NI | Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| NI | Possibility+ | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| NI | Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| NI | Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| NI | Relational Choice | `henkin-without-relational-choice` |
| NI | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| NI | Strong Possibility (pure) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| NI | Strong Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| NI | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Inextensible Comprehension | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast` |
| Inextensible Comprehension | Atomicity (type t) | `finite-support-qualitative-contrast` |
| Inextensible Comprehension | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Inextensible Comprehension | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Inextensible Comprehension | BF (type t) | `full-idempotent-monoid` |
| Inextensible Comprehension | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts` |
| Inextensible Comprehension | Converse Witnessed Possibility | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Inextensible Comprehension | ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Inextensible Comprehension | ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Inextensible Comprehension | Distinctness (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Inextensible Comprehension | Distinctness (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Inextensible Comprehension | Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Inextensible Comprehension | Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Inextensible Comprehension | Functional Choice | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Inextensible Comprehension | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Inextensible Comprehension | Fundamental Possibility | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Inextensible Comprehension | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-truncated-shifts` |
| Inextensible Comprehension | Infinity (type e) | `full-henkin-singleton-base` |
| Inextensible Comprehension | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Inextensible Comprehension | Logical Necessity | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Inextensible Comprehension | B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Inextensible Comprehension | 5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Inextensible Comprehension | □Actuality | `coalesced-maximalist-root`, `finite-support-qualitative-contrast` |
| Inextensible Comprehension | □Atomicity | `coalesced-maximalist-root`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast` |
| Inextensible Comprehension | □BF | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Inextensible Comprehension | □BF (type t) | `full-idempotent-monoid` |
| Inextensible Comprehension | □Boolean Completeness | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| Inextensible Comprehension | □ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Inextensible Comprehension | □ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Inextensible Comprehension | □Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Inextensible Comprehension | □Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Inextensible Comprehension | □Functionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Inextensible Comprehension | □B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Inextensible Comprehension | □5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Inextensible Comprehension | □Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Inextensible Comprehension | □Rigid Comprehension | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| Inextensible Comprehension | □Tractarianism | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Inextensible Comprehension | No Pure Contingency | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Inextensible Comprehension | Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Inextensible Comprehension | Possibility+ | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Inextensible Comprehension | Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Inextensible Comprehension | Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Inextensible Comprehension | Relational Choice | `henkin-without-relational-choice` |
| Inextensible Comprehension | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts` |
| Inextensible Comprehension | Strong Possibility (pure) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Inextensible Comprehension | Strong Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Inextensible Comprehension | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Intensionality | Actual Profile | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Intensionality | Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Intensionality | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Intensionality | Atomicity (type t) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Intensionality | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Intensionality | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Intensionality | BF (type t) | `full-idempotent-monoid` |
| Intensionality | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Intensionality | Converse Witnessed Possibility | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Intensionality | ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Intensionality | ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Intensionality | Distinctness (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Intensionality | Distinctness (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Intensionality | Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Intensionality | Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Intensionality | Functional Choice | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Intensionality | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Intensionality | Fundamental Possibility | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Intensionality | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| Intensionality | Infinity (type e) | `full-henkin-singleton-base` |
| Intensionality | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Intensionality | Logical Necessity | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Intensionality | B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Intensionality | 5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Intensionality | □Actuality | `coalesced-maximalist-root`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncations` |
| Intensionality | □Atomicity | `coalesced-maximalist-root`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Intensionality | □BF | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| Intensionality | □BF (type t) | `full-idempotent-monoid` |
| Intensionality | □Boolean Completeness | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Intensionality | □ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Intensionality | □ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Intensionality | □Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Intensionality | □Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Intensionality | □Functionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| Intensionality | □B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Intensionality | □5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Intensionality | □Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Intensionality | □Rigid Comprehension | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| Intensionality | □Tractarianism | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| Intensionality | No Pure Contingency | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Intensionality | Persistent Comprehension | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Intensionality | Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Intensionality | Possibility+ | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Intensionality | Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Intensionality | Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Intensionality | Relational Choice | `henkin-without-relational-choice` |
| Intensionality | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| Intensionality | Strong Possibility (pure) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Intensionality | Strong Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Intensionality | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| B | Actual Profile | `finite-support-permutations` |
| B | Actuality | `finite-support-permutations` |
| B | Atomicity | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| B | Atomicity (type t) | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| B | Atomlessness | `full-henkin-singleton-base`, `full-involution-group`, `full-two-object-retract`, `henkin-without-relational-choice` |
| B | BF | `full-two-object-retract` |
| B | Boolean Completeness | `finite-support-permutations` |
| B | Converse Witnessed Possibility | `full-two-object-retract` |
| B | Extensionality | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| B | Fregean Axiom | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| B | Functional Choice | `finite-support-permutations`, `henkin-without-relational-choice` |
| B | Functionality | `full-two-object-retract` |
| B | Gallin Extensional Comprehension | `finite-support-permutations` |
| B | Infinity (type e) | `full-henkin-singleton-base` |
| B | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| B | Logical Necessity | `full-two-object-retract` |
| B | □Actuality | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| B | □Atomicity | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| B | □BF | `full-two-object-retract` |
| B | □Boolean Completeness | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| B | □ND | `full-two-object-retract` |
| B | □ND (type t) | `full-two-object-retract` |
| B | □Extensionality | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| B | □Fregean Axiom | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| B | □Functionality | `full-two-object-retract` |
| B | □B | `full-two-object-retract` |
| B | □5 | `full-two-object-retract` |
| B | □Plenitude | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-two-object-retract` |
| B | □Rigid Comprehension | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| B | □Tractarianism | `full-two-object-retract` |
| B | No Pure Contingency | `full-two-object-retract` |
| B | Persistent Comprehension | `finite-support-permutations` |
| B | Plenitude | `finite-support-permutations` |
| B | Relational Choice | `henkin-without-relational-choice` |
| B | Rigid Comprehension | `finite-support-permutations` |
| B | Tractarianism | `full-two-object-retract` |
| 5 | Actual Profile | `finite-support-permutations` |
| 5 | Actuality | `finite-support-permutations` |
| 5 | Atomicity | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| 5 | Atomicity (type t) | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| 5 | Atomlessness | `full-henkin-singleton-base`, `full-involution-group`, `full-two-object-retract`, `henkin-without-relational-choice` |
| 5 | BF | `full-two-object-retract` |
| 5 | Boolean Completeness | `finite-support-permutations` |
| 5 | Converse Witnessed Possibility | `full-two-object-retract` |
| 5 | Extensionality | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| 5 | Fregean Axiom | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| 5 | Functional Choice | `finite-support-permutations`, `henkin-without-relational-choice` |
| 5 | Functionality | `full-two-object-retract` |
| 5 | Gallin Extensional Comprehension | `finite-support-permutations` |
| 5 | Infinity (type e) | `full-henkin-singleton-base` |
| 5 | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| 5 | Logical Necessity | `full-two-object-retract` |
| 5 | □Actuality | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| 5 | □Atomicity | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| 5 | □BF | `full-two-object-retract` |
| 5 | □Boolean Completeness | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| 5 | □ND | `full-two-object-retract` |
| 5 | □ND (type t) | `full-two-object-retract` |
| 5 | □Extensionality | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| 5 | □Fregean Axiom | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| 5 | □Functionality | `full-two-object-retract` |
| 5 | □B | `full-two-object-retract` |
| 5 | □5 | `full-two-object-retract` |
| 5 | □Plenitude | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-two-object-retract` |
| 5 | □Rigid Comprehension | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| 5 | □Tractarianism | `full-two-object-retract` |
| 5 | No Pure Contingency | `full-two-object-retract` |
| 5 | Persistent Comprehension | `finite-support-permutations` |
| 5 | Plenitude | `finite-support-permutations` |
| 5 | Relational Choice | `henkin-without-relational-choice` |
| 5 | Rigid Comprehension | `finite-support-permutations` |
| 5 | Tractarianism | `full-two-object-retract` |
| 4 | Actual Profile | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| 4 | Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| 4 | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| 4 | Atomicity (type t) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| 4 | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| 4 | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| 4 | BF (type t) | `full-idempotent-monoid` |
| 4 | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| 4 | Converse Witnessed Possibility | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| 4 | ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| 4 | ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| 4 | Distinctness (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| 4 | Distinctness (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| 4 | Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| 4 | Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| 4 | Functional Choice | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| 4 | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| 4 | Fundamental Possibility | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| 4 | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| 4 | Infinity (type e) | `full-henkin-singleton-base` |
| 4 | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| 4 | Logical Necessity | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| 4 | B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| 4 | 5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| 4 | □Actuality | `coalesced-maximalist-root`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncations` |
| 4 | □Atomicity | `coalesced-maximalist-root`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| 4 | □BF | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| 4 | □BF (type t) | `full-idempotent-monoid` |
| 4 | □Boolean Completeness | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| 4 | □ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| 4 | □ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| 4 | □Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| 4 | □Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| 4 | □Functionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| 4 | □B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| 4 | □5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| 4 | □Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| 4 | □Rigid Comprehension | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| 4 | □Tractarianism | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| 4 | No Pure Contingency | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| 4 | Persistent Comprehension | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| 4 | Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| 4 | Possibility+ | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| 4 | Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| 4 | Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| 4 | Relational Choice | `henkin-without-relational-choice` |
| 4 | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| 4 | Strong Possibility (pure) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| 4 | Strong Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| 4 | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| K | Actual Profile | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| K | Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| K | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| K | Atomicity (type t) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| K | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| K | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| K | BF (type t) | `full-idempotent-monoid` |
| K | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| K | Converse Witnessed Possibility | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| K | ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| K | ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| K | Distinctness (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| K | Distinctness (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| K | Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| K | Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| K | Functional Choice | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| K | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| K | Fundamental Possibility | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| K | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| K | Infinity (type e) | `full-henkin-singleton-base` |
| K | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| K | Logical Necessity | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| K | B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| K | 5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| K | □Actuality | `coalesced-maximalist-root`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncations` |
| K | □Atomicity | `coalesced-maximalist-root`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| K | □BF | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| K | □BF (type t) | `full-idempotent-monoid` |
| K | □Boolean Completeness | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| K | □ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| K | □ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| K | □Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| K | □Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| K | □Functionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| K | □B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| K | □5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| K | □Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| K | □Rigid Comprehension | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| K | □Tractarianism | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| K | No Pure Contingency | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| K | Persistent Comprehension | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| K | Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| K | Possibility+ | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| K | Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| K | Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| K | Relational Choice | `henkin-without-relational-choice` |
| K | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| K | Strong Possibility (pure) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| K | Strong Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| K | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| T | Actual Profile | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| T | Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| T | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| T | Atomicity (type t) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| T | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| T | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| T | BF (type t) | `full-idempotent-monoid` |
| T | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| T | Converse Witnessed Possibility | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| T | ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| T | ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| T | Distinctness (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| T | Distinctness (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| T | Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| T | Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| T | Functional Choice | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| T | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| T | Fundamental Possibility | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| T | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| T | Infinity (type e) | `full-henkin-singleton-base` |
| T | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| T | Logical Necessity | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| T | B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| T | 5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| T | □Actuality | `coalesced-maximalist-root`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncations` |
| T | □Atomicity | `coalesced-maximalist-root`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| T | □BF | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| T | □BF (type t) | `full-idempotent-monoid` |
| T | □Boolean Completeness | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| T | □ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| T | □ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| T | □Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| T | □Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| T | □Functionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| T | □B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| T | □5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| T | □Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| T | □Rigid Comprehension | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| T | □Tractarianism | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| T | No Pure Contingency | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| T | Persistent Comprehension | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| T | Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| T | Possibility+ | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| T | Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| T | Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| T | Relational Choice | `henkin-without-relational-choice` |
| T | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| T | Strong Possibility (pure) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| T | Strong Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| T | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Modalized Fregean Axiom | Actual Profile | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Modalized Fregean Axiom | Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Modalized Fregean Axiom | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Modalized Fregean Axiom | Atomicity (type t) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Modalized Fregean Axiom | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Modalized Fregean Axiom | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Modalized Fregean Axiom | BF (type t) | `full-idempotent-monoid` |
| Modalized Fregean Axiom | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Modalized Fregean Axiom | Converse Witnessed Possibility | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Modalized Fregean Axiom | ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Modalized Fregean Axiom | ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Modalized Fregean Axiom | Distinctness (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Modalized Fregean Axiom | Distinctness (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Modalized Fregean Axiom | Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Modalized Fregean Axiom | Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Modalized Fregean Axiom | Functional Choice | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Modalized Fregean Axiom | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Modalized Fregean Axiom | Fundamental Possibility | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Modalized Fregean Axiom | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| Modalized Fregean Axiom | Infinity (type e) | `full-henkin-singleton-base` |
| Modalized Fregean Axiom | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Modalized Fregean Axiom | Logical Necessity | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Modalized Fregean Axiom | B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Modalized Fregean Axiom | 5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Modalized Fregean Axiom | □Actuality | `coalesced-maximalist-root`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncations` |
| Modalized Fregean Axiom | □Atomicity | `coalesced-maximalist-root`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Modalized Fregean Axiom | □BF | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| Modalized Fregean Axiom | □BF (type t) | `full-idempotent-monoid` |
| Modalized Fregean Axiom | □Boolean Completeness | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Modalized Fregean Axiom | □ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Modalized Fregean Axiom | □ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Modalized Fregean Axiom | □Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Modalized Fregean Axiom | □Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Modalized Fregean Axiom | □Functionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| Modalized Fregean Axiom | □B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Modalized Fregean Axiom | □5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Modalized Fregean Axiom | □Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Modalized Fregean Axiom | □Rigid Comprehension | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| Modalized Fregean Axiom | □Tractarianism | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| Modalized Fregean Axiom | No Pure Contingency | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Modalized Fregean Axiom | Persistent Comprehension | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Modalized Fregean Axiom | Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Modalized Fregean Axiom | Possibility+ | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Modalized Fregean Axiom | Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Modalized Fregean Axiom | Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Modalized Fregean Axiom | Relational Choice | `henkin-without-relational-choice` |
| Modalized Fregean Axiom | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| Modalized Fregean Axiom | Strong Possibility (pure) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Modalized Fregean Axiom | Strong Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Modalized Fregean Axiom | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Modalized Functionality | Actual Profile | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Modalized Functionality | Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Modalized Functionality | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Modalized Functionality | Atomicity (type t) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Modalized Functionality | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Modalized Functionality | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Modalized Functionality | BF (type t) | `full-idempotent-monoid` |
| Modalized Functionality | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Modalized Functionality | Converse Witnessed Possibility | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Modalized Functionality | ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Modalized Functionality | ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Modalized Functionality | Distinctness (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Modalized Functionality | Distinctness (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Modalized Functionality | Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Modalized Functionality | Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Modalized Functionality | Functional Choice | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Modalized Functionality | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Modalized Functionality | Fundamental Possibility | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Modalized Functionality | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| Modalized Functionality | Infinity (type e) | `full-henkin-singleton-base` |
| Modalized Functionality | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Modalized Functionality | Logical Necessity | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Modalized Functionality | B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Modalized Functionality | 5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Modalized Functionality | □Actuality | `coalesced-maximalist-root`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncations` |
| Modalized Functionality | □Atomicity | `coalesced-maximalist-root`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Modalized Functionality | □BF | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| Modalized Functionality | □BF (type t) | `full-idempotent-monoid` |
| Modalized Functionality | □Boolean Completeness | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Modalized Functionality | □ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Modalized Functionality | □ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Modalized Functionality | □Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Modalized Functionality | □Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Modalized Functionality | □Functionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| Modalized Functionality | □B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Modalized Functionality | □5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Modalized Functionality | □Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Modalized Functionality | □Rigid Comprehension | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| Modalized Functionality | □Tractarianism | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| Modalized Functionality | No Pure Contingency | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Modalized Functionality | Persistent Comprehension | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Modalized Functionality | Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Modalized Functionality | Possibility+ | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Modalized Functionality | Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Modalized Functionality | Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Modalized Functionality | Relational Choice | `henkin-without-relational-choice` |
| Modalized Functionality | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| Modalized Functionality | Strong Possibility (pure) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Modalized Functionality | Strong Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Modalized Functionality | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| □Actuality | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse` |
| □Actuality | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| □Actuality | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| □Actuality | BF (type t) | `full-idempotent-monoid` |
| □Actuality | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts` |
| □Actuality | Converse Witnessed Possibility | `full-two-object-chain`, `full-two-object-retract` |
| □Actuality | ND | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| □Actuality | ND (type t) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| □Actuality | Extensionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| □Actuality | Fregean Axiom | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| □Actuality | Functional Choice | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □Actuality | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| □Actuality | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-truncated-shifts` |
| □Actuality | Infinity (type e) | `full-henkin-singleton-base` |
| □Actuality | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| □Actuality | Logical Necessity | `full-two-object-chain`, `full-two-object-retract` |
| □Actuality | B | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| □Actuality | 5 | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| □Actuality | □Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse` |
| □Actuality | □BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| □Actuality | □BF (type t) | `full-idempotent-monoid` |
| □Actuality | □Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts` |
| □Actuality | □ND | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Actuality | □ND (type t) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Actuality | □Extensionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| □Actuality | □Fregean Axiom | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| □Actuality | □Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| □Actuality | □B | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Actuality | □5 | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Actuality | □Plenitude | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Actuality | □Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts` |
| □Actuality | □Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| □Actuality | No Pure Contingency | `full-two-object-chain`, `full-two-object-retract` |
| □Actuality | Plenitude | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| □Actuality | Relational Choice | `henkin-without-relational-choice` |
| □Actuality | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts` |
| □Actuality | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| □Atomicity | Actual Profile | `finite-support-truncations` |
| □Atomicity | Actuality | `finite-support-truncations` |
| □Atomicity | BF | `finite-support-dyadic-roundings`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| □Atomicity | BF (type t) | `full-idempotent-monoid` |
| □Atomicity | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| □Atomicity | Converse Witnessed Possibility | `full-two-object-chain`, `full-two-object-retract` |
| □Atomicity | ND | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| □Atomicity | ND (type t) | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| □Atomicity | Extensionality | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| □Atomicity | Fregean Axiom | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| □Atomicity | Functional Choice | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □Atomicity | Functionality | `finite-support-dyadic-roundings`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| □Atomicity | Gallin Extensional Comprehension | `finite-support-truncated-shifts` |
| □Atomicity | Infinity (type e) | `full-henkin-singleton-base` |
| □Atomicity | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| □Atomicity | Logical Necessity | `full-two-object-chain`, `full-two-object-retract` |
| □Atomicity | B | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| □Atomicity | 5 | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| □Atomicity | □Actuality | `finite-support-truncations` |
| □Atomicity | □BF | `finite-support-dyadic-roundings`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| □Atomicity | □BF (type t) | `full-idempotent-monoid` |
| □Atomicity | □Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| □Atomicity | □ND | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Atomicity | □ND (type t) | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Atomicity | □Extensionality | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| □Atomicity | □Fregean Axiom | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| □Atomicity | □Functionality | `finite-support-dyadic-roundings`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| □Atomicity | □B | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Atomicity | □5 | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Atomicity | □Plenitude | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Atomicity | □Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| □Atomicity | □Tractarianism | `finite-support-dyadic-roundings`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| □Atomicity | No Pure Contingency | `full-two-object-chain`, `full-two-object-retract` |
| □Atomicity | Persistent Comprehension | `finite-support-truncations` |
| □Atomicity | Plenitude | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| □Atomicity | Relational Choice | `henkin-without-relational-choice` |
| □Atomicity | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| □Atomicity | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| □BF | Actual Profile | `finite-support-monotone-surjections`, `finite-support-permutations` |
| □BF | Actuality | `finite-support-monotone-surjections`, `finite-support-permutations` |
| □BF | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □BF | Atomicity (type t) | `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □BF | Atomlessness | `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □BF | Boolean Completeness | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| □BF | ND | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF | ND (type t) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF | Extensionality | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-involution-group`, `full-surjection-monoid` |
| □BF | Fregean Axiom | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-involution-group`, `full-surjection-monoid` |
| □BF | Functional Choice | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □BF | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| □BF | Infinity (type e) | `full-henkin-singleton-base` |
| □BF | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| □BF | B | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF | 5 | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF | □Actuality | `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □BF | □Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □BF | □Boolean Completeness | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| □BF | □ND | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF | □ND (type t) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF | □Extensionality | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-involution-group`, `full-surjection-monoid` |
| □BF | □Fregean Axiom | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-involution-group`, `full-surjection-monoid` |
| □BF | □B | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF | □5 | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF | □Plenitude | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF | □Rigid Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| □BF | Persistent Comprehension | `finite-support-monotone-surjections`, `finite-support-permutations` |
| □BF | Plenitude | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF | Relational Choice | `henkin-without-relational-choice` |
| □BF | Rigid Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| □BF (type t) | Actual Profile | `finite-support-monotone-surjections`, `finite-support-permutations` |
| □BF (type t) | Actuality | `finite-support-monotone-surjections`, `finite-support-permutations` |
| □BF (type t) | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □BF (type t) | Atomicity (type t) | `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □BF (type t) | Atomlessness | `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □BF (type t) | Boolean Completeness | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| □BF (type t) | ND | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF (type t) | ND (type t) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF (type t) | Distinctness (pure) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □BF (type t) | Distinctness (signature Σ) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □BF (type t) | Extensionality | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-involution-group`, `full-surjection-monoid` |
| □BF (type t) | Fregean Axiom | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-involution-group`, `full-surjection-monoid` |
| □BF (type t) | Functional Choice | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □BF (type t) | Fundamental Possibility | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □BF (type t) | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| □BF (type t) | Infinity (type e) | `full-henkin-singleton-base` |
| □BF (type t) | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| □BF (type t) | B | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF (type t) | 5 | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF (type t) | □Actuality | `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □BF (type t) | □Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □BF (type t) | □Boolean Completeness | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| □BF (type t) | □ND | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF (type t) | □ND (type t) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF (type t) | □Extensionality | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-involution-group`, `full-surjection-monoid` |
| □BF (type t) | □Fregean Axiom | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-involution-group`, `full-surjection-monoid` |
| □BF (type t) | □B | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF (type t) | □5 | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF (type t) | □Plenitude | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF (type t) | □Rigid Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| □BF (type t) | Persistent Comprehension | `finite-support-monotone-surjections`, `finite-support-permutations` |
| □BF (type t) | Plenitude | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □BF (type t) | Possibility+ | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □BF (type t) | Possibility (pure) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □BF (type t) | Possibility (signature Σ) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □BF (type t) | Relational Choice | `henkin-without-relational-choice` |
| □BF (type t) | Rigid Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| □BF (type t) | Strong Possibility (pure) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □BF (type t) | Strong Possibility (signature Σ) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □Boolean Completeness | Atomlessness | `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| □Boolean Completeness | BF | `full-idempotent-monoid`, `full-two-object-retract` |
| □Boolean Completeness | BF (type t) | `full-idempotent-monoid` |
| □Boolean Completeness | Converse Witnessed Possibility | `full-two-object-chain`, `full-two-object-retract` |
| □Boolean Completeness | ND | `full-idempotent-monoid`, `full-surjection-monoid` |
| □Boolean Completeness | ND (type t) | `full-idempotent-monoid`, `full-surjection-monoid` |
| □Boolean Completeness | Extensionality | `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| □Boolean Completeness | Fregean Axiom | `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| □Boolean Completeness | Functional Choice | `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □Boolean Completeness | Functionality | `full-idempotent-monoid`, `full-two-object-retract` |
| □Boolean Completeness | Infinity (type e) | `full-henkin-singleton-base` |
| □Boolean Completeness | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| □Boolean Completeness | Logical Necessity | `full-two-object-chain`, `full-two-object-retract` |
| □Boolean Completeness | B | `full-idempotent-monoid`, `full-surjection-monoid` |
| □Boolean Completeness | 5 | `full-idempotent-monoid`, `full-surjection-monoid` |
| □Boolean Completeness | □BF | `full-idempotent-monoid`, `full-two-object-retract` |
| □Boolean Completeness | □BF (type t) | `full-idempotent-monoid` |
| □Boolean Completeness | □ND | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Boolean Completeness | □ND (type t) | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Boolean Completeness | □Extensionality | `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| □Boolean Completeness | □Fregean Axiom | `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| □Boolean Completeness | □Functionality | `full-idempotent-monoid`, `full-two-object-retract` |
| □Boolean Completeness | □B | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Boolean Completeness | □5 | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Boolean Completeness | □Plenitude | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Boolean Completeness | □Tractarianism | `full-idempotent-monoid`, `full-two-object-retract` |
| □Boolean Completeness | No Pure Contingency | `full-two-object-chain`, `full-two-object-retract` |
| □Boolean Completeness | Plenitude | `full-idempotent-monoid`, `full-surjection-monoid` |
| □Boolean Completeness | Relational Choice | `henkin-without-relational-choice` |
| □Boolean Completeness | Tractarianism | `full-idempotent-monoid`, `full-two-object-retract` |
| □ND | Actual Profile | `finite-support-permutations` |
| □ND | Actuality | `finite-support-permutations` |
| □ND | Atomicity | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □ND | Atomicity (type t) | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □ND | Atomlessness | `full-henkin-singleton-base`, `full-involution-group`, `henkin-without-relational-choice` |
| □ND | Boolean Completeness | `finite-support-permutations` |
| □ND | Extensionality | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group` |
| □ND | Fregean Axiom | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group` |
| □ND | Functional Choice | `finite-support-permutations`, `henkin-without-relational-choice` |
| □ND | Gallin Extensional Comprehension | `finite-support-permutations` |
| □ND | Infinity (type e) | `full-henkin-singleton-base` |
| □ND | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| □ND | □Actuality | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □ND | □Atomicity | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □ND | □Boolean Completeness | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □ND | □Extensionality | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group` |
| □ND | □Fregean Axiom | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group` |
| □ND | □Plenitude | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □ND | □Rigid Comprehension | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □ND | Persistent Comprehension | `finite-support-permutations` |
| □ND | Plenitude | `finite-support-permutations` |
| □ND | Relational Choice | `henkin-without-relational-choice` |
| □ND | Rigid Comprehension | `finite-support-permutations` |
| □ND (type t) | Actual Profile | `finite-support-permutations` |
| □ND (type t) | Actuality | `finite-support-permutations` |
| □ND (type t) | Atomicity | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □ND (type t) | Atomicity (type t) | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □ND (type t) | Atomlessness | `full-henkin-singleton-base`, `full-involution-group`, `henkin-without-relational-choice` |
| □ND (type t) | Boolean Completeness | `finite-support-permutations` |
| □ND (type t) | Extensionality | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group` |
| □ND (type t) | Fregean Axiom | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group` |
| □ND (type t) | Functional Choice | `finite-support-permutations`, `henkin-without-relational-choice` |
| □ND (type t) | Gallin Extensional Comprehension | `finite-support-permutations` |
| □ND (type t) | Infinity (type e) | `full-henkin-singleton-base` |
| □ND (type t) | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| □ND (type t) | □Actuality | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □ND (type t) | □Atomicity | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □ND (type t) | □Boolean Completeness | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □ND (type t) | □Extensionality | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group` |
| □ND (type t) | □Fregean Axiom | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group` |
| □ND (type t) | □Plenitude | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □ND (type t) | □Rigid Comprehension | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □ND (type t) | Persistent Comprehension | `finite-support-permutations` |
| □ND (type t) | Plenitude | `finite-support-permutations` |
| □ND (type t) | Relational Choice | `henkin-without-relational-choice` |
| □ND (type t) | Rigid Comprehension | `finite-support-permutations` |
| □Fregean Axiom | Functional Choice | `henkin-without-relational-choice` |
| □Fregean Axiom | Infinity (type e) | `full-henkin-singleton-base` |
| □Fregean Axiom | Relational Choice | `henkin-without-relational-choice` |
| □Functionality | Actual Profile | `finite-support-monotone-surjections`, `finite-support-permutations` |
| □Functionality | Actuality | `finite-support-monotone-surjections`, `finite-support-permutations` |
| □Functionality | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □Functionality | Atomicity (type t) | `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □Functionality | Atomlessness | `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □Functionality | Boolean Completeness | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| □Functionality | ND | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Functionality | ND (type t) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Functionality | Extensionality | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-involution-group`, `full-surjection-monoid` |
| □Functionality | Fregean Axiom | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-involution-group`, `full-surjection-monoid` |
| □Functionality | Functional Choice | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □Functionality | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| □Functionality | Infinity (type e) | `full-henkin-singleton-base` |
| □Functionality | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| □Functionality | B | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Functionality | 5 | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Functionality | □Actuality | `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □Functionality | □Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □Functionality | □Boolean Completeness | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| □Functionality | □ND | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Functionality | □ND (type t) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Functionality | □Extensionality | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-involution-group`, `full-surjection-monoid` |
| □Functionality | □Fregean Axiom | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-involution-group`, `full-surjection-monoid` |
| □Functionality | □B | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Functionality | □5 | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Functionality | □Plenitude | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Functionality | □Rigid Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| □Functionality | Persistent Comprehension | `finite-support-monotone-surjections`, `finite-support-permutations` |
| □Functionality | Plenitude | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Functionality | Relational Choice | `henkin-without-relational-choice` |
| □Functionality | Rigid Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| □B | Actual Profile | `finite-support-permutations` |
| □B | Actuality | `finite-support-permutations` |
| □B | Atomicity | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □B | Atomicity (type t) | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □B | Atomlessness | `full-henkin-singleton-base`, `full-involution-group`, `henkin-without-relational-choice` |
| □B | Boolean Completeness | `finite-support-permutations` |
| □B | Extensionality | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group` |
| □B | Fregean Axiom | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group` |
| □B | Functional Choice | `finite-support-permutations`, `henkin-without-relational-choice` |
| □B | Gallin Extensional Comprehension | `finite-support-permutations` |
| □B | Infinity (type e) | `full-henkin-singleton-base` |
| □B | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| □B | □Actuality | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □B | □Atomicity | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □B | □Boolean Completeness | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □B | □Extensionality | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group` |
| □B | □Fregean Axiom | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group` |
| □B | □Plenitude | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □B | □Rigid Comprehension | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □B | Persistent Comprehension | `finite-support-permutations` |
| □B | Plenitude | `finite-support-permutations` |
| □B | Relational Choice | `henkin-without-relational-choice` |
| □B | Rigid Comprehension | `finite-support-permutations` |
| □5 | Actual Profile | `finite-support-permutations` |
| □5 | Actuality | `finite-support-permutations` |
| □5 | Atomicity | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □5 | Atomicity (type t) | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □5 | Atomlessness | `full-henkin-singleton-base`, `full-involution-group`, `henkin-without-relational-choice` |
| □5 | Boolean Completeness | `finite-support-permutations` |
| □5 | Extensionality | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group` |
| □5 | Fregean Axiom | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group` |
| □5 | Functional Choice | `finite-support-permutations`, `henkin-without-relational-choice` |
| □5 | Gallin Extensional Comprehension | `finite-support-permutations` |
| □5 | Infinity (type e) | `full-henkin-singleton-base` |
| □5 | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| □5 | □Actuality | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □5 | □Atomicity | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □5 | □Boolean Completeness | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □5 | □Extensionality | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group` |
| □5 | □Fregean Axiom | `finite-support-permutations`, `finite-support-qualitative-contrast`, `full-involution-group` |
| □5 | □Plenitude | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □5 | □Rigid Comprehension | `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □5 | Persistent Comprehension | `finite-support-permutations` |
| □5 | Plenitude | `finite-support-permutations` |
| □5 | Relational Choice | `henkin-without-relational-choice` |
| □5 | Rigid Comprehension | `finite-support-permutations` |
| □Plenitude | Extensionality | `full-involution-group` |
| □Plenitude | Fregean Axiom | `full-involution-group` |
| □Plenitude | Functional Choice | `henkin-without-relational-choice` |
| □Plenitude | Infinity (type e) | `full-henkin-singleton-base` |
| □Plenitude | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| □Plenitude | □Extensionality | `full-involution-group` |
| □Plenitude | □Fregean Axiom | `full-involution-group` |
| □Plenitude | Relational Choice | `henkin-without-relational-choice` |
| □Rigid Comprehension | Atomlessness | `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| □Rigid Comprehension | BF | `full-idempotent-monoid`, `full-two-object-retract` |
| □Rigid Comprehension | BF (type t) | `full-idempotent-monoid` |
| □Rigid Comprehension | Converse Witnessed Possibility | `full-two-object-chain`, `full-two-object-retract` |
| □Rigid Comprehension | ND | `full-idempotent-monoid`, `full-surjection-monoid` |
| □Rigid Comprehension | ND (type t) | `full-idempotent-monoid`, `full-surjection-monoid` |
| □Rigid Comprehension | Extensionality | `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| □Rigid Comprehension | Fregean Axiom | `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| □Rigid Comprehension | Functional Choice | `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □Rigid Comprehension | Functionality | `full-idempotent-monoid`, `full-two-object-retract` |
| □Rigid Comprehension | Infinity (type e) | `full-henkin-singleton-base` |
| □Rigid Comprehension | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| □Rigid Comprehension | Logical Necessity | `full-two-object-chain`, `full-two-object-retract` |
| □Rigid Comprehension | B | `full-idempotent-monoid`, `full-surjection-monoid` |
| □Rigid Comprehension | 5 | `full-idempotent-monoid`, `full-surjection-monoid` |
| □Rigid Comprehension | □BF | `full-idempotent-monoid`, `full-two-object-retract` |
| □Rigid Comprehension | □BF (type t) | `full-idempotent-monoid` |
| □Rigid Comprehension | □ND | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Rigid Comprehension | □ND (type t) | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Rigid Comprehension | □Extensionality | `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| □Rigid Comprehension | □Fregean Axiom | `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| □Rigid Comprehension | □Functionality | `full-idempotent-monoid`, `full-two-object-retract` |
| □Rigid Comprehension | □B | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Rigid Comprehension | □5 | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Rigid Comprehension | □Plenitude | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| □Rigid Comprehension | □Tractarianism | `full-idempotent-monoid`, `full-two-object-retract` |
| □Rigid Comprehension | No Pure Contingency | `full-two-object-chain`, `full-two-object-retract` |
| □Rigid Comprehension | Plenitude | `full-idempotent-monoid`, `full-surjection-monoid` |
| □Rigid Comprehension | Relational Choice | `henkin-without-relational-choice` |
| □Rigid Comprehension | Tractarianism | `full-idempotent-monoid`, `full-two-object-retract` |
| □Tractarianism | Actual Profile | `finite-support-monotone-surjections`, `finite-support-permutations` |
| □Tractarianism | Actuality | `finite-support-monotone-surjections`, `finite-support-permutations` |
| □Tractarianism | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □Tractarianism | Atomicity (type t) | `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □Tractarianism | Atomlessness | `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □Tractarianism | Boolean Completeness | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| □Tractarianism | ND | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Tractarianism | ND (type t) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Tractarianism | Extensionality | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-involution-group`, `full-surjection-monoid` |
| □Tractarianism | Fregean Axiom | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-involution-group`, `full-surjection-monoid` |
| □Tractarianism | Functional Choice | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| □Tractarianism | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| □Tractarianism | Infinity (type e) | `full-henkin-singleton-base` |
| □Tractarianism | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| □Tractarianism | B | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Tractarianism | 5 | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Tractarianism | □Actuality | `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □Tractarianism | □Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| □Tractarianism | □Boolean Completeness | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| □Tractarianism | □ND | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Tractarianism | □ND (type t) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Tractarianism | □Extensionality | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-involution-group`, `full-surjection-monoid` |
| □Tractarianism | □Fregean Axiom | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-involution-group`, `full-surjection-monoid` |
| □Tractarianism | □B | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Tractarianism | □5 | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Tractarianism | □Plenitude | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Tractarianism | □Rigid Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| □Tractarianism | Persistent Comprehension | `finite-support-monotone-surjections`, `finite-support-permutations` |
| □Tractarianism | Plenitude | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `full-surjection-monoid` |
| □Tractarianism | Relational Choice | `henkin-without-relational-choice` |
| □Tractarianism | Rigid Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| No Pure Contingency | Actual Profile | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| No Pure Contingency | Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| No Pure Contingency | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| No Pure Contingency | Atomicity (type t) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| No Pure Contingency | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| No Pure Contingency | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid` |
| No Pure Contingency | BF (type t) | `full-idempotent-monoid` |
| No Pure Contingency | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| No Pure Contingency | ND | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| No Pure Contingency | ND (type t) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| No Pure Contingency | Extensionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid` |
| No Pure Contingency | Fregean Axiom | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid` |
| No Pure Contingency | Functional Choice | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| No Pure Contingency | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid` |
| No Pure Contingency | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| No Pure Contingency | Infinity (type e) | `full-henkin-singleton-base` |
| No Pure Contingency | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| No Pure Contingency | B | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| No Pure Contingency | 5 | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| No Pure Contingency | □Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| No Pure Contingency | □Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations` |
| No Pure Contingency | □BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid` |
| No Pure Contingency | □BF (type t) | `full-idempotent-monoid` |
| No Pure Contingency | □Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| No Pure Contingency | □ND | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| No Pure Contingency | □ND (type t) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| No Pure Contingency | □Extensionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid` |
| No Pure Contingency | □Fregean Axiom | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid` |
| No Pure Contingency | □Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid` |
| No Pure Contingency | □B | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| No Pure Contingency | □5 | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| No Pure Contingency | □Plenitude | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| No Pure Contingency | □Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| No Pure Contingency | □Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid` |
| No Pure Contingency | Persistent Comprehension | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| No Pure Contingency | Plenitude | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| No Pure Contingency | Relational Choice | `henkin-without-relational-choice` |
| No Pure Contingency | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| No Pure Contingency | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid` |
| Ordinary Comprehension | Actual Profile | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Ordinary Comprehension | Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Ordinary Comprehension | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Ordinary Comprehension | Atomicity (type t) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Ordinary Comprehension | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Ordinary Comprehension | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Ordinary Comprehension | BF (type t) | `full-idempotent-monoid` |
| Ordinary Comprehension | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Ordinary Comprehension | Converse Witnessed Possibility | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Ordinary Comprehension | ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Ordinary Comprehension | ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Ordinary Comprehension | Distinctness (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Ordinary Comprehension | Distinctness (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Ordinary Comprehension | Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Ordinary Comprehension | Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Ordinary Comprehension | Functional Choice | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Ordinary Comprehension | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Ordinary Comprehension | Fundamental Possibility | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Ordinary Comprehension | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| Ordinary Comprehension | Infinity (type e) | `full-henkin-singleton-base` |
| Ordinary Comprehension | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Ordinary Comprehension | Logical Necessity | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Ordinary Comprehension | B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Ordinary Comprehension | 5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Ordinary Comprehension | □Actuality | `coalesced-maximalist-root`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncations` |
| Ordinary Comprehension | □Atomicity | `coalesced-maximalist-root`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Ordinary Comprehension | □BF | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| Ordinary Comprehension | □BF (type t) | `full-idempotent-monoid` |
| Ordinary Comprehension | □Boolean Completeness | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| Ordinary Comprehension | □ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Ordinary Comprehension | □ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Ordinary Comprehension | □Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Ordinary Comprehension | □Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Ordinary Comprehension | □Functionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| Ordinary Comprehension | □B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Ordinary Comprehension | □5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Ordinary Comprehension | □Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Ordinary Comprehension | □Rigid Comprehension | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| Ordinary Comprehension | □Tractarianism | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-two-object-retract` |
| Ordinary Comprehension | No Pure Contingency | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Ordinary Comprehension | Persistent Comprehension | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| Ordinary Comprehension | Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Ordinary Comprehension | Possibility+ | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Ordinary Comprehension | Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Ordinary Comprehension | Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Ordinary Comprehension | Relational Choice | `henkin-without-relational-choice` |
| Ordinary Comprehension | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `finite-support-two-object-all-maps` |
| Ordinary Comprehension | Strong Possibility (pure) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Ordinary Comprehension | Strong Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Ordinary Comprehension | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Persistent Comprehension | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast` |
| Persistent Comprehension | Atomicity (type t) | `finite-support-qualitative-contrast` |
| Persistent Comprehension | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Persistent Comprehension | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Persistent Comprehension | BF (type t) | `full-idempotent-monoid` |
| Persistent Comprehension | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts` |
| Persistent Comprehension | Converse Witnessed Possibility | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Persistent Comprehension | ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Persistent Comprehension | ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Persistent Comprehension | Distinctness (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Persistent Comprehension | Distinctness (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Persistent Comprehension | Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Persistent Comprehension | Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Persistent Comprehension | Functional Choice | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Persistent Comprehension | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Persistent Comprehension | Fundamental Possibility | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Persistent Comprehension | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-truncated-shifts` |
| Persistent Comprehension | Infinity (type e) | `full-henkin-singleton-base` |
| Persistent Comprehension | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Persistent Comprehension | Logical Necessity | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Persistent Comprehension | B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Persistent Comprehension | 5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Persistent Comprehension | □Actuality | `coalesced-maximalist-root`, `finite-support-qualitative-contrast` |
| Persistent Comprehension | □Atomicity | `coalesced-maximalist-root`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast` |
| Persistent Comprehension | □BF | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Persistent Comprehension | □BF (type t) | `full-idempotent-monoid` |
| Persistent Comprehension | □Boolean Completeness | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| Persistent Comprehension | □ND | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Persistent Comprehension | □ND (type t) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Persistent Comprehension | □Extensionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Persistent Comprehension | □Fregean Axiom | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Persistent Comprehension | □Functionality | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Persistent Comprehension | □B | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Persistent Comprehension | □5 | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Persistent Comprehension | □Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Persistent Comprehension | □Rigid Comprehension | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| Persistent Comprehension | □Tractarianism | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Persistent Comprehension | No Pure Contingency | `coalesced-maximalist-root`, `full-two-object-chain`, `full-two-object-retract` |
| Persistent Comprehension | Plenitude | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts`, `full-idempotent-monoid`, `full-surjection-monoid` |
| Persistent Comprehension | Possibility+ | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Persistent Comprehension | Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Persistent Comprehension | Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Persistent Comprehension | Relational Choice | `henkin-without-relational-choice` |
| Persistent Comprehension | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-truncated-shifts` |
| Persistent Comprehension | Strong Possibility (pure) | `coalesced-maximalist-root`, `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Persistent Comprehension | Strong Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Persistent Comprehension | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `full-idempotent-monoid`, `full-two-object-retract` |
| Plenitude | Atomicity | `finite-support-qualitative-contrast` |
| Plenitude | Atomicity (type t) | `finite-support-qualitative-contrast` |
| Plenitude | Atomlessness | `full-henkin-singleton-base`, `full-involution-group`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Plenitude | BF | `full-two-object-retract` |
| Plenitude | Converse Witnessed Possibility | `full-two-object-retract` |
| Plenitude | Extensionality | `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| Plenitude | Fregean Axiom | `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| Plenitude | Functional Choice | `henkin-without-relational-choice` |
| Plenitude | Functionality | `full-two-object-retract` |
| Plenitude | Infinity (type e) | `full-henkin-singleton-base` |
| Plenitude | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Plenitude | Logical Necessity | `full-two-object-retract` |
| Plenitude | □Actuality | `finite-support-qualitative-contrast` |
| Plenitude | □Atomicity | `finite-support-qualitative-contrast` |
| Plenitude | □BF | `full-two-object-retract` |
| Plenitude | □Boolean Completeness | `finite-support-qualitative-contrast` |
| Plenitude | □ND | `full-two-object-retract` |
| Plenitude | □ND (type t) | `full-two-object-retract` |
| Plenitude | □Extensionality | `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| Plenitude | □Fregean Axiom | `finite-support-qualitative-contrast`, `full-involution-group`, `full-two-object-retract` |
| Plenitude | □Functionality | `full-two-object-retract` |
| Plenitude | □B | `full-two-object-retract` |
| Plenitude | □5 | `full-two-object-retract` |
| Plenitude | □Plenitude | `finite-support-qualitative-contrast`, `full-two-object-retract` |
| Plenitude | □Rigid Comprehension | `finite-support-qualitative-contrast` |
| Plenitude | □Tractarianism | `full-two-object-retract` |
| Plenitude | No Pure Contingency | `full-two-object-retract` |
| Plenitude | Relational Choice | `henkin-without-relational-choice` |
| Plenitude | Tractarianism | `full-two-object-retract` |
| Possibility (pure) | Strong Possibility (pure) | `coalesced-maximalist-root` |
| Possibility (signature Σ) | Strong Possibility (pure) | `coalesced-maximalist-root` |
| B for pure sentences | Actual Profile | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| B for pure sentences | Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| B for pure sentences | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| B for pure sentences | Atomicity (type t) | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| B for pure sentences | Atomlessness | `finite-support-dyadic-roundings`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-retract`, `henkin-without-relational-choice` |
| B for pure sentences | BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| B for pure sentences | BF (type t) | `full-idempotent-monoid` |
| B for pure sentences | Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| B for pure sentences | Converse Witnessed Possibility | `full-two-object-retract` |
| B for pure sentences | ND | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| B for pure sentences | ND (type t) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| B for pure sentences | Distinctness (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-retract`, `henkin-without-relational-choice` |
| B for pure sentences | Distinctness (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-retract`, `henkin-without-relational-choice` |
| B for pure sentences | Extensionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-retract` |
| B for pure sentences | Fregean Axiom | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-retract` |
| B for pure sentences | Functional Choice | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| B for pure sentences | Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| B for pure sentences | Fundamental Possibility | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-retract`, `henkin-without-relational-choice` |
| B for pure sentences | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| B for pure sentences | Infinity (type e) | `full-henkin-singleton-base` |
| B for pure sentences | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| B for pure sentences | Logical Necessity | `full-two-object-retract` |
| B for pure sentences | B | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| B for pure sentences | 5 | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| B for pure sentences | □Actuality | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncations` |
| B for pure sentences | □Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| B for pure sentences | □BF | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| B for pure sentences | □BF (type t) | `full-idempotent-monoid` |
| B for pure sentences | □Boolean Completeness | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| B for pure sentences | □ND | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| B for pure sentences | □ND (type t) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| B for pure sentences | □Extensionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-retract` |
| B for pure sentences | □Fregean Axiom | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-retract` |
| B for pure sentences | □Functionality | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| B for pure sentences | □B | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| B for pure sentences | □5 | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| B for pure sentences | □Plenitude | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| B for pure sentences | □Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| B for pure sentences | □Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| B for pure sentences | No Pure Contingency | `full-two-object-retract` |
| B for pure sentences | Persistent Comprehension | `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncations` |
| B for pure sentences | Plenitude | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-idempotent-monoid`, `full-surjection-monoid` |
| B for pure sentences | Possibility+ | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-retract`, `henkin-without-relational-choice` |
| B for pure sentences | Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-retract`, `henkin-without-relational-choice` |
| B for pure sentences | Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-retract`, `henkin-without-relational-choice` |
| B for pure sentences | Relational Choice | `henkin-without-relational-choice` |
| B for pure sentences | Rigid Comprehension | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-truncations` |
| B for pure sentences | Strong Possibility (pure) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-retract`, `henkin-without-relational-choice` |
| B for pure sentences | Strong Possibility (signature Σ) | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse-surjections`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-truncations`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-retract`, `henkin-without-relational-choice` |
| B for pure sentences | Tractarianism | `finite-support-dyadic-roundings`, `finite-support-identity-or-collapse`, `finite-support-monotone-maps`, `finite-support-truncations`, `full-idempotent-monoid`, `full-two-object-retract` |
| Relational Choice | Atomlessness | `full-henkin-singleton-base` |
| Relational Choice | Distinctness (pure) | `full-henkin-singleton-base` |
| Relational Choice | Distinctness (signature Σ) | `full-henkin-singleton-base` |
| Relational Choice | Fundamental Possibility | `full-henkin-singleton-base` |
| Relational Choice | Infinity (type e) | `full-henkin-singleton-base` |
| Relational Choice | Infinity (type t) | `full-henkin-singleton-base` |
| Relational Choice | Possibility+ | `full-henkin-singleton-base` |
| Relational Choice | Possibility (pure) | `full-henkin-singleton-base` |
| Relational Choice | Possibility (signature Σ) | `full-henkin-singleton-base` |
| Relational Choice | Strong Possibility (pure) | `full-henkin-singleton-base` |
| Relational Choice | Strong Possibility (signature Σ) | `full-henkin-singleton-base` |
| Rigid Comprehension | Atomicity | `finite-support-qualitative-contrast` |
| Rigid Comprehension | Atomicity (type t) | `finite-support-qualitative-contrast` |
| Rigid Comprehension | Atomlessness | `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Rigid Comprehension | BF | `full-idempotent-monoid`, `full-two-object-retract` |
| Rigid Comprehension | BF (type t) | `full-idempotent-monoid` |
| Rigid Comprehension | Converse Witnessed Possibility | `full-two-object-chain`, `full-two-object-retract` |
| Rigid Comprehension | ND | `full-idempotent-monoid`, `full-surjection-monoid` |
| Rigid Comprehension | ND (type t) | `full-idempotent-monoid`, `full-surjection-monoid` |
| Rigid Comprehension | Distinctness (pure) | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Rigid Comprehension | Distinctness (signature Σ) | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Rigid Comprehension | Extensionality | `finite-support-qualitative-contrast`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Rigid Comprehension | Fregean Axiom | `finite-support-qualitative-contrast`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Rigid Comprehension | Functional Choice | `full-idempotent-monoid`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Rigid Comprehension | Functionality | `full-idempotent-monoid`, `full-two-object-retract` |
| Rigid Comprehension | Fundamental Possibility | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Rigid Comprehension | Infinity (type e) | `full-henkin-singleton-base` |
| Rigid Comprehension | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Rigid Comprehension | Logical Necessity | `full-two-object-chain`, `full-two-object-retract` |
| Rigid Comprehension | B | `full-idempotent-monoid`, `full-surjection-monoid` |
| Rigid Comprehension | 5 | `full-idempotent-monoid`, `full-surjection-monoid` |
| Rigid Comprehension | □Actuality | `finite-support-qualitative-contrast` |
| Rigid Comprehension | □Atomicity | `finite-support-qualitative-contrast` |
| Rigid Comprehension | □BF | `full-idempotent-monoid`, `full-two-object-retract` |
| Rigid Comprehension | □BF (type t) | `full-idempotent-monoid` |
| Rigid Comprehension | □Boolean Completeness | `finite-support-qualitative-contrast` |
| Rigid Comprehension | □ND | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Rigid Comprehension | □ND (type t) | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Rigid Comprehension | □Extensionality | `finite-support-qualitative-contrast`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Rigid Comprehension | □Fregean Axiom | `finite-support-qualitative-contrast`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract` |
| Rigid Comprehension | □Functionality | `full-idempotent-monoid`, `full-two-object-retract` |
| Rigid Comprehension | □B | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Rigid Comprehension | □5 | `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Rigid Comprehension | □Plenitude | `finite-support-qualitative-contrast`, `full-idempotent-monoid`, `full-surjection-monoid`, `full-two-object-retract` |
| Rigid Comprehension | □Rigid Comprehension | `finite-support-qualitative-contrast` |
| Rigid Comprehension | □Tractarianism | `full-idempotent-monoid`, `full-two-object-retract` |
| Rigid Comprehension | No Pure Contingency | `full-two-object-chain`, `full-two-object-retract` |
| Rigid Comprehension | Plenitude | `full-idempotent-monoid`, `full-surjection-monoid` |
| Rigid Comprehension | Possibility+ | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Rigid Comprehension | Possibility (pure) | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Rigid Comprehension | Possibility (signature Σ) | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Rigid Comprehension | Relational Choice | `henkin-without-relational-choice` |
| Rigid Comprehension | Strong Possibility (pure) | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Rigid Comprehension | Strong Possibility (signature Σ) | `finite-support-qualitative-contrast`, `full-henkin-singleton-base`, `full-idempotent-monoid`, `full-involution-group`, `full-surjection-monoid`, `full-two-object-chain`, `full-two-object-retract`, `henkin-without-relational-choice` |
| Rigid Comprehension | Tractarianism | `full-idempotent-monoid`, `full-two-object-retract` |
| Separated Structure | Converse Witnessed Possibility | `coalesced-maximalist-root` |
| Separated Structure | ND | `coalesced-maximalist-root` |
| Separated Structure | ND (type t) | `coalesced-maximalist-root` |
| Separated Structure | Extensionality | `coalesced-maximalist-root` |
| Separated Structure | Fregean Axiom | `coalesced-maximalist-root` |
| Separated Structure | Functional Choice | `coalesced-maximalist-root` |
| Separated Structure | Logical Necessity | `coalesced-maximalist-root` |
| Separated Structure | B | `coalesced-maximalist-root` |
| Separated Structure | 5 | `coalesced-maximalist-root` |
| Separated Structure | □Actuality | `coalesced-maximalist-root` |
| Separated Structure | □Atomicity | `coalesced-maximalist-root` |
| Separated Structure | □BF | `coalesced-maximalist-root` |
| Separated Structure | □Boolean Completeness | `coalesced-maximalist-root` |
| Separated Structure | □ND | `coalesced-maximalist-root` |
| Separated Structure | □ND (type t) | `coalesced-maximalist-root` |
| Separated Structure | □Extensionality | `coalesced-maximalist-root` |
| Separated Structure | □Fregean Axiom | `coalesced-maximalist-root` |
| Separated Structure | □Functionality | `coalesced-maximalist-root` |
| Separated Structure | □B | `coalesced-maximalist-root` |
| Separated Structure | □5 | `coalesced-maximalist-root` |
| Separated Structure | □Plenitude | `coalesced-maximalist-root` |
| Separated Structure | □Rigid Comprehension | `coalesced-maximalist-root` |
| Separated Structure | □Tractarianism | `coalesced-maximalist-root` |
| Separated Structure | No Pure Contingency | `coalesced-maximalist-root` |
| Separated Structure | Plenitude | `coalesced-maximalist-root` |
| Separated Structure | Strong Possibility (pure) | `coalesced-maximalist-root` |
| Tractarianism | Actual Profile | `finite-support-monotone-surjections`, `finite-support-permutations` |
| Tractarianism | Actuality | `finite-support-monotone-surjections`, `finite-support-permutations` |
| Tractarianism | Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Tractarianism | Atomicity (type t) | `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Tractarianism | Atomlessness | `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Tractarianism | Boolean Completeness | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts` |
| Tractarianism | ND | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Tractarianism | ND (type t) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Tractarianism | Distinctness (pure) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Tractarianism | Distinctness (signature Σ) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Tractarianism | Extensionality | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-involution-group`, `full-surjection-monoid` |
| Tractarianism | Fregean Axiom | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-involution-group`, `full-surjection-monoid` |
| Tractarianism | Functional Choice | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Tractarianism | Fundamental Possibility | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Tractarianism | Gallin Extensional Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| Tractarianism | Infinity (type e) | `full-henkin-singleton-base` |
| Tractarianism | Infinity (type t) | `full-henkin-singleton-base`, `henkin-without-relational-choice` |
| Tractarianism | B | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Tractarianism | 5 | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Tractarianism | □Actuality | `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Tractarianism | □Atomicity | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast` |
| Tractarianism | □BF | `finite-support-two-object-all-maps` |
| Tractarianism | □Boolean Completeness | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts` |
| Tractarianism | □ND | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Tractarianism | □ND (type t) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Tractarianism | □Extensionality | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-involution-group`, `full-surjection-monoid` |
| Tractarianism | □Fregean Axiom | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-involution-group`, `full-surjection-monoid` |
| Tractarianism | □Functionality | `finite-support-two-object-all-maps` |
| Tractarianism | □B | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Tractarianism | □5 | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Tractarianism | □Plenitude | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Tractarianism | □Rigid Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| Tractarianism | □Tractarianism | `finite-support-two-object-all-maps` |
| Tractarianism | Persistent Comprehension | `finite-support-monotone-surjections`, `finite-support-permutations` |
| Tractarianism | Plenitude | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps`, `full-surjection-monoid` |
| Tractarianism | Possibility+ | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Tractarianism | Possibility (pure) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Tractarianism | Possibility (signature Σ) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Tractarianism | Relational Choice | `henkin-without-relational-choice` |
| Tractarianism | Rigid Comprehension | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-truncated-shifts`, `finite-support-two-object-all-maps` |
| Tractarianism | Strong Possibility (pure) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Tractarianism | Strong Possibility (signature Σ) | `finite-support-identity-or-collapse-surjections`, `finite-support-monotone-surjections`, `finite-support-permutations`, `finite-support-qualitative-contrast`, `finite-support-truncated-shifts`, `full-henkin-singleton-base`, `full-involution-group`, `full-surjection-monoid`, `henkin-without-relational-choice` |
| Witnessed Possibility | Converse Witnessed Possibility | `coalesced-maximalist-root` |
| Witnessed Possibility | ND | `coalesced-maximalist-root` |
| Witnessed Possibility | ND (type t) | `coalesced-maximalist-root` |
| Witnessed Possibility | Extensionality | `coalesced-maximalist-root` |
| Witnessed Possibility | Fregean Axiom | `coalesced-maximalist-root` |
| Witnessed Possibility | Functional Choice | `coalesced-maximalist-root` |
| Witnessed Possibility | Logical Necessity | `coalesced-maximalist-root` |
| Witnessed Possibility | B | `coalesced-maximalist-root` |
| Witnessed Possibility | 5 | `coalesced-maximalist-root` |
| Witnessed Possibility | □Actuality | `coalesced-maximalist-root` |
| Witnessed Possibility | □Atomicity | `coalesced-maximalist-root` |
| Witnessed Possibility | □BF | `coalesced-maximalist-root` |
| Witnessed Possibility | □Boolean Completeness | `coalesced-maximalist-root` |
| Witnessed Possibility | □ND | `coalesced-maximalist-root` |
| Witnessed Possibility | □ND (type t) | `coalesced-maximalist-root` |
| Witnessed Possibility | □Extensionality | `coalesced-maximalist-root` |
| Witnessed Possibility | □Fregean Axiom | `coalesced-maximalist-root` |
| Witnessed Possibility | □Functionality | `coalesced-maximalist-root` |
| Witnessed Possibility | □B | `coalesced-maximalist-root` |
| Witnessed Possibility | □5 | `coalesced-maximalist-root` |
| Witnessed Possibility | □Plenitude | `coalesced-maximalist-root` |
| Witnessed Possibility | □Rigid Comprehension | `coalesced-maximalist-root` |
| Witnessed Possibility | □Tractarianism | `coalesced-maximalist-root` |
| Witnessed Possibility | No Pure Contingency | `coalesced-maximalist-root` |
| Witnessed Possibility | Plenitude | `coalesced-maximalist-root` |
| Witnessed Possibility | Strong Possibility (pure) | `coalesced-maximalist-root` |

### 6.4 Open single-premise pairs (1076)

Listed in `OPEN-QUESTIONS.md`.

### Negative implications (424)

Read A ⇒ ¬B: A and B cannot hold together. This does not by itself witness a model of A.

- Atomicity (`atomicity-r`) ⇒ ¬ Atomlessness (`atomlessness`); via atomicity-r-implies-atomicity-t, atomicity-t-incompatible-with-atomlessness.
- Atomicity (type t) (`atomicity-t`) ⇒ ¬ Atomlessness (`atomlessness`); via atomicity-t-incompatible-with-atomlessness.
- Atomlessness (`atomlessness`) ⇒ ¬ Atomicity (`atomicity-r`); via atomicity-r-implies-atomicity-t, atomicity-t-incompatible-with-atomlessness.
- Atomlessness (`atomlessness`) ⇒ ¬ Atomicity (type t) (`atomicity-t`); via atomicity-t-incompatible-with-atomlessness.
- Atomlessness (`atomlessness`) ⇒ ¬ Extensionality (`extensionality-r`); via extensionality-r-implies-atomicity-r, atomicity-r-implies-atomicity-t, atomicity-t-incompatible-with-atomlessness.
- Atomlessness (`atomlessness`) ⇒ ¬ Fregean Axiom (`fregean-axiom`); via fregean-axiom-implies-extensionality-r, extensionality-r-implies-atomicity-r, atomicity-r-implies-atomicity-t, atomicity-t-incompatible-with-atomlessness.
- Atomlessness (`atomlessness`) ⇒ ¬ □Atomicity (`necessary-atomicity-r`); via necessary-atomicity-r-implies-atomicity-r, atomicity-r-implies-atomicity-t, atomicity-t-incompatible-with-atomlessness.
- Atomlessness (`atomlessness`) ⇒ ¬ □Extensionality (`necessary-extensionality-r`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-atomicity-r, atomicity-r-implies-atomicity-t, atomicity-t-incompatible-with-atomlessness.
- Atomlessness (`atomlessness`) ⇒ ¬ □Fregean Axiom (`necessary-fregean-axiom`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-axiom-implies-extensionality-r, extensionality-r-implies-atomicity-r, atomicity-r-implies-atomicity-t, atomicity-t-incompatible-with-atomlessness.
- Atomlessness (`atomlessness`) ⇒ ¬ □Plenitude (`necessary-plenitude-r`); via necessary-plenitude-r-implies-atomicity-r, atomicity-r-implies-atomicity-t, atomicity-t-incompatible-with-atomlessness.
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via converse-witnessed-possibility-r-implies-no-pure-contingency-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via converse-witnessed-possibility-r-implies-no-pure-contingency-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via converse-witnessed-possibility-r-implies-no-pure-contingency-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via converse-witnessed-possibility-r-implies-no-pure-contingency-r, possibility-plus-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via converse-witnessed-possibility-r-implies-no-pure-contingency-r, possibility-and-no-pure-contingency-incompatible.
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via converse-witnessed-possibility-r-implies-no-pure-contingency-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via converse-witnessed-possibility-r-implies-no-pure-contingency-r, strong-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via converse-witnessed-possibility-r-implies-no-pure-contingency-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- ND (`distinctness-necessary-r`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via maximalist-distinctness-incompatible-with-nd.
- ND (`distinctness-necessary-r`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- ND (`distinctness-necessary-r`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- ND (`distinctness-necessary-r`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- ND (`distinctness-necessary-r`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- ND (`distinctness-necessary-r`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- ND (`distinctness-necessary-r`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- ND (`distinctness-necessary-r`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- ND (type t) (`distinctness-necessary-t`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via distinctness-necessary-t-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- ND (type t) (`distinctness-necessary-t`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via distinctness-necessary-t-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- ND (type t) (`distinctness-necessary-t`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via distinctness-necessary-t-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- ND (type t) (`distinctness-necessary-t`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via distinctness-necessary-t-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- ND (type t) (`distinctness-necessary-t`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via distinctness-necessary-t-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- ND (type t) (`distinctness-necessary-t`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via distinctness-necessary-t-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- ND (type t) (`distinctness-necessary-t`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via distinctness-necessary-t-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- ND (type t) (`distinctness-necessary-t`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via distinctness-necessary-t-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ Converse Witnessed Possibility (`converse-witnessed-possibility-r`); via converse-witnessed-possibility-r-implies-no-pure-contingency-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ ND (`distinctness-necessary-r`); via maximalist-distinctness-incompatible-with-nd.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ ND (type t) (`distinctness-necessary-t`); via distinctness-necessary-t-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ Extensionality (`extensionality-r`); via extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ Fregean Axiom (`fregean-axiom`); via fregean-axiom-implies-no-pure-contingency-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ Functional Choice (`functional-choice-r`); via functional-choice-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ Logical Necessity (`logical-necessity-r`); via logical-necessity-r-implies-no-pure-contingency-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ B (`modal-b`); via modal-b-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ 5 (`modal-five`); via modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ □Actuality (`necessary-actuality`); via maximalist-distinctness-incompatible-with-necessary-actuality.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ □Atomicity (`necessary-atomicity-r`); via maximalist-distinctness-incompatible-with-necessary-atomicity-r.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ □BF (`necessary-barcan-r`); via maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ □Boolean Completeness (`necessary-boolean-completeness-r`); via maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ □ND (`necessary-distinctness-necessary-r`); via necessary-distinctness-necessary-r-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ □ND (type t) (`necessary-distinctness-necessary-t`); via necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ □Extensionality (`necessary-extensionality-r`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ □Fregean Axiom (`necessary-fregean-axiom`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ □Functionality (`necessary-functionality-r`); via maximalist-distinctness-incompatible-with-necessary-functionality-r.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ □B (`necessary-modal-b`); via necessary-modal-b-implies-modal-b, modal-b-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ □5 (`necessary-modal-five`); via necessary-modal-five-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ □Plenitude (`necessary-plenitude-r`); via necessary-plenitude-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ □Rigid Comprehension (`necessary-rigid-comprehension-r`); via maximalist-distinctness-incompatible-with-necessary-rigid-comprehension-r.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ □Tractarianism (`necessary-tractarianism-r`); via maximalist-distinctness-incompatible-with-necessary-tractarianism-r.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ No Pure Contingency (`no-pure-contingency-r`); via distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Distinctness (pure) (`distinctness-schema-r`) ⇒ ¬ Plenitude (`plenitude-r`); via plenitude-r-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ Converse Witnessed Possibility (`converse-witnessed-possibility-r`); via converse-witnessed-possibility-r-implies-no-pure-contingency-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ ND (`distinctness-necessary-r`); via distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ ND (type t) (`distinctness-necessary-t`); via distinctness-necessary-t-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ Extensionality (`extensionality-r`); via extensionality-r-implies-fregean-axiom, fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ Fregean Axiom (`fregean-axiom`); via fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ Functional Choice (`functional-choice-r`); via functional-choice-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ Logical Necessity (`logical-necessity-r`); via logical-necessity-r-implies-no-pure-contingency-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ B (`modal-b`); via modal-b-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ 5 (`modal-five`); via modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ □Actuality (`necessary-actuality`); via distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-actuality.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ □Atomicity (`necessary-atomicity-r`); via distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-atomicity-r.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ □BF (`necessary-barcan-r`); via distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ □Boolean Completeness (`necessary-boolean-completeness-r`); via distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ □ND (`necessary-distinctness-necessary-r`); via necessary-distinctness-necessary-r-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ □ND (type t) (`necessary-distinctness-necessary-t`); via necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ □Extensionality (`necessary-extensionality-r`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ □Fregean Axiom (`necessary-fregean-axiom`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ □Functionality (`necessary-functionality-r`); via distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-functionality-r.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ □B (`necessary-modal-b`); via necessary-modal-b-implies-modal-b, modal-b-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ □5 (`necessary-modal-five`); via necessary-modal-five-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ □Plenitude (`necessary-plenitude-r`); via necessary-plenitude-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ □Rigid Comprehension (`necessary-rigid-comprehension-r`); via distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-rigid-comprehension-r.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ □Tractarianism (`necessary-tractarianism-r`); via distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-tractarianism-r.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ No Pure Contingency (`no-pure-contingency-r`); via distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Distinctness (signature Σ) (`distinctness-signature-r`) ⇒ ¬ Plenitude (`plenitude-r`); via plenitude-r-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Extensionality (`extensionality-r`) ⇒ ¬ Atomlessness (`atomlessness`); via extensionality-r-implies-atomicity-r, atomicity-r-implies-atomicity-t, atomicity-t-incompatible-with-atomlessness.
- Extensionality (`extensionality-r`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Extensionality (`extensionality-r`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via extensionality-r-implies-fregean-axiom, fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Extensionality (`extensionality-r`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Extensionality (`extensionality-r`) ⇒ ¬ Infinity (type t) (`infinity-t`); via extensionality-r-implies-fregean-axiom, fregean-incompatible-with-infinity-t.
- Extensionality (`extensionality-r`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via extensionality-r-implies-fregean-axiom, fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Extensionality (`extensionality-r`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, possibility-and-no-pure-contingency-incompatible.
- Extensionality (`extensionality-r`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via extensionality-r-implies-fregean-axiom, fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Extensionality (`extensionality-r`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, strong-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Extensionality (`extensionality-r`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via extensionality-r-implies-fregean-axiom, fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Fregean Axiom (`fregean-axiom`) ⇒ ¬ Atomlessness (`atomlessness`); via fregean-axiom-implies-extensionality-r, extensionality-r-implies-atomicity-r, atomicity-r-implies-atomicity-t, atomicity-t-incompatible-with-atomlessness.
- Fregean Axiom (`fregean-axiom`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via fregean-axiom-implies-no-pure-contingency-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Fregean Axiom (`fregean-axiom`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Fregean Axiom (`fregean-axiom`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via fregean-axiom-implies-no-pure-contingency-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Fregean Axiom (`fregean-axiom`) ⇒ ¬ Infinity (type t) (`infinity-t`); via fregean-incompatible-with-infinity-t.
- Fregean Axiom (`fregean-axiom`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Fregean Axiom (`fregean-axiom`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via fregean-axiom-implies-no-pure-contingency-r, possibility-and-no-pure-contingency-incompatible.
- Fregean Axiom (`fregean-axiom`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Fregean Axiom (`fregean-axiom`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via fregean-axiom-implies-no-pure-contingency-r, strong-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Fregean Axiom (`fregean-axiom`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Functional Choice (`functional-choice-r`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via functional-choice-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- Functional Choice (`functional-choice-r`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via functional-choice-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Functional Choice (`functional-choice-r`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via functional-choice-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Functional Choice (`functional-choice-r`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via functional-choice-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Functional Choice (`functional-choice-r`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via functional-choice-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Functional Choice (`functional-choice-r`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via functional-choice-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Functional Choice (`functional-choice-r`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via functional-choice-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Functional Choice (`functional-choice-r`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via functional-choice-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ Converse Witnessed Possibility (`converse-witnessed-possibility-r`); via converse-witnessed-possibility-r-implies-no-pure-contingency-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ ND (`distinctness-necessary-r`); via fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ ND (type t) (`distinctness-necessary-t`); via distinctness-necessary-t-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ Extensionality (`extensionality-r`); via extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ Fregean Axiom (`fregean-axiom`); via fregean-axiom-implies-no-pure-contingency-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ Functional Choice (`functional-choice-r`); via functional-choice-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ Logical Necessity (`logical-necessity-r`); via logical-necessity-r-implies-no-pure-contingency-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ B (`modal-b`); via modal-b-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ 5 (`modal-five`); via modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ □Actuality (`necessary-actuality`); via fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-actuality.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ □Atomicity (`necessary-atomicity-r`); via fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-atomicity-r.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ □BF (`necessary-barcan-r`); via fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ □Boolean Completeness (`necessary-boolean-completeness-r`); via fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ □ND (`necessary-distinctness-necessary-r`); via necessary-distinctness-necessary-r-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ □ND (type t) (`necessary-distinctness-necessary-t`); via necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ □Extensionality (`necessary-extensionality-r`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ □Fregean Axiom (`necessary-fregean-axiom`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ □Functionality (`necessary-functionality-r`); via fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, necessary-functionality-r-implies-necessary-tractarianism-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ □B (`necessary-modal-b`); via necessary-modal-b-implies-modal-b, modal-b-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ □5 (`necessary-modal-five`); via necessary-modal-five-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ □Plenitude (`necessary-plenitude-r`); via necessary-plenitude-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ □Rigid Comprehension (`necessary-rigid-comprehension-r`); via fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, necessary-rigid-comprehension-r-implies-necessary-actuality, maximalist-distinctness-incompatible-with-necessary-actuality.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ □Tractarianism (`necessary-tractarianism-r`); via fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ No Pure Contingency (`no-pure-contingency-r`); via fundamental-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Fundamental Possibility (`fundamental-possibility-r`) ⇒ ¬ Plenitude (`plenitude-r`); via plenitude-r-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Infinity (type t) (`infinity-t`) ⇒ ¬ Extensionality (`extensionality-r`); via extensionality-r-implies-fregean-axiom, fregean-incompatible-with-infinity-t.
- Infinity (type t) (`infinity-t`) ⇒ ¬ Fregean Axiom (`fregean-axiom`); via fregean-incompatible-with-infinity-t.
- Infinity (type t) (`infinity-t`) ⇒ ¬ □Extensionality (`necessary-extensionality-r`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-fregean-axiom, fregean-incompatible-with-infinity-t.
- Infinity (type t) (`infinity-t`) ⇒ ¬ □Fregean Axiom (`necessary-fregean-axiom`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-incompatible-with-infinity-t.
- Logical Necessity (`logical-necessity-r`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via logical-necessity-r-implies-no-pure-contingency-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Logical Necessity (`logical-necessity-r`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via logical-necessity-r-implies-no-pure-contingency-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Logical Necessity (`logical-necessity-r`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via logical-necessity-r-implies-no-pure-contingency-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Logical Necessity (`logical-necessity-r`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via logical-necessity-r-implies-no-pure-contingency-r, possibility-plus-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Logical Necessity (`logical-necessity-r`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via logical-necessity-r-implies-no-pure-contingency-r, possibility-and-no-pure-contingency-incompatible.
- Logical Necessity (`logical-necessity-r`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via logical-necessity-r-implies-no-pure-contingency-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Logical Necessity (`logical-necessity-r`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via logical-necessity-r-implies-no-pure-contingency-r, strong-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Logical Necessity (`logical-necessity-r`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via logical-necessity-r-implies-no-pure-contingency-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- B (`modal-b`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via modal-b-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- B (`modal-b`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via modal-b-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- B (`modal-b`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via modal-b-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- B (`modal-b`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via modal-b-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- B (`modal-b`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via modal-b-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- B (`modal-b`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via modal-b-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- B (`modal-b`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via modal-b-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- B (`modal-b`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via modal-b-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- 5 (`modal-five`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- 5 (`modal-five`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- 5 (`modal-five`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- 5 (`modal-five`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- 5 (`modal-five`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- 5 (`modal-five`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- 5 (`modal-five`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- 5 (`modal-five`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □Actuality (`necessary-actuality`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via maximalist-distinctness-incompatible-with-necessary-actuality.
- □Actuality (`necessary-actuality`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-actuality.
- □Actuality (`necessary-actuality`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-actuality.
- □Actuality (`necessary-actuality`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-actuality.
- □Actuality (`necessary-actuality`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-actuality.
- □Actuality (`necessary-actuality`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-actuality.
- □Actuality (`necessary-actuality`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-actuality.
- □Actuality (`necessary-actuality`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-actuality.
- □Atomicity (`necessary-atomicity-r`) ⇒ ¬ Atomlessness (`atomlessness`); via necessary-atomicity-r-implies-atomicity-r, atomicity-r-implies-atomicity-t, atomicity-t-incompatible-with-atomlessness.
- □Atomicity (`necessary-atomicity-r`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via maximalist-distinctness-incompatible-with-necessary-atomicity-r.
- □Atomicity (`necessary-atomicity-r`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-atomicity-r.
- □Atomicity (`necessary-atomicity-r`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-atomicity-r.
- □Atomicity (`necessary-atomicity-r`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-atomicity-r.
- □Atomicity (`necessary-atomicity-r`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-atomicity-r.
- □Atomicity (`necessary-atomicity-r`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-atomicity-r.
- □Atomicity (`necessary-atomicity-r`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-atomicity-r.
- □Atomicity (`necessary-atomicity-r`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-atomicity-r.
- □BF (`necessary-barcan-r`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □BF (`necessary-barcan-r`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □BF (`necessary-barcan-r`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □BF (`necessary-barcan-r`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □BF (`necessary-barcan-r`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □BF (`necessary-barcan-r`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □BF (`necessary-barcan-r`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □BF (`necessary-barcan-r`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □Boolean Completeness (`necessary-boolean-completeness-r`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r.
- □Boolean Completeness (`necessary-boolean-completeness-r`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r.
- □Boolean Completeness (`necessary-boolean-completeness-r`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r.
- □Boolean Completeness (`necessary-boolean-completeness-r`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r.
- □Boolean Completeness (`necessary-boolean-completeness-r`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r.
- □Boolean Completeness (`necessary-boolean-completeness-r`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r.
- □Boolean Completeness (`necessary-boolean-completeness-r`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r.
- □Boolean Completeness (`necessary-boolean-completeness-r`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r.
- □ND (`necessary-distinctness-necessary-r`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via necessary-distinctness-necessary-r-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- □ND (`necessary-distinctness-necessary-r`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via necessary-distinctness-necessary-r-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □ND (`necessary-distinctness-necessary-r`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via necessary-distinctness-necessary-r-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □ND (`necessary-distinctness-necessary-r`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □ND (`necessary-distinctness-necessary-r`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □ND (`necessary-distinctness-necessary-r`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □ND (`necessary-distinctness-necessary-r`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via necessary-distinctness-necessary-r-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □ND (`necessary-distinctness-necessary-r`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via necessary-distinctness-necessary-r-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □ND (type t) (`necessary-distinctness-necessary-t`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- □ND (type t) (`necessary-distinctness-necessary-t`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □ND (type t) (`necessary-distinctness-necessary-t`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □ND (type t) (`necessary-distinctness-necessary-t`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □ND (type t) (`necessary-distinctness-necessary-t`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □ND (type t) (`necessary-distinctness-necessary-t`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □ND (type t) (`necessary-distinctness-necessary-t`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □ND (type t) (`necessary-distinctness-necessary-t`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □Extensionality (`necessary-extensionality-r`) ⇒ ¬ Atomlessness (`atomlessness`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-atomicity-r, atomicity-r-implies-atomicity-t, atomicity-t-incompatible-with-atomlessness.
- □Extensionality (`necessary-extensionality-r`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- □Extensionality (`necessary-extensionality-r`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- □Extensionality (`necessary-extensionality-r`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- □Extensionality (`necessary-extensionality-r`) ⇒ ¬ Infinity (type t) (`infinity-t`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-fregean-axiom, fregean-incompatible-with-infinity-t.
- □Extensionality (`necessary-extensionality-r`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, possibility-plus-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- □Extensionality (`necessary-extensionality-r`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, possibility-and-no-pure-contingency-incompatible.
- □Extensionality (`necessary-extensionality-r`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-fregean-axiom, fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □Extensionality (`necessary-extensionality-r`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, strong-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- □Extensionality (`necessary-extensionality-r`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-fregean-axiom, fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □Fregean Axiom (`necessary-fregean-axiom`) ⇒ ¬ Atomlessness (`atomlessness`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-axiom-implies-extensionality-r, extensionality-r-implies-atomicity-r, atomicity-r-implies-atomicity-t, atomicity-t-incompatible-with-atomlessness.
- □Fregean Axiom (`necessary-fregean-axiom`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- □Fregean Axiom (`necessary-fregean-axiom`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- □Fregean Axiom (`necessary-fregean-axiom`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- □Fregean Axiom (`necessary-fregean-axiom`) ⇒ ¬ Infinity (type t) (`infinity-t`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-incompatible-with-infinity-t.
- □Fregean Axiom (`necessary-fregean-axiom`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, possibility-plus-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- □Fregean Axiom (`necessary-fregean-axiom`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, possibility-and-no-pure-contingency-incompatible.
- □Fregean Axiom (`necessary-fregean-axiom`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □Fregean Axiom (`necessary-fregean-axiom`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, strong-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- □Fregean Axiom (`necessary-fregean-axiom`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □Functionality (`necessary-functionality-r`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via maximalist-distinctness-incompatible-with-necessary-functionality-r.
- □Functionality (`necessary-functionality-r`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-functionality-r.
- □Functionality (`necessary-functionality-r`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, necessary-functionality-r-implies-necessary-tractarianism-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □Functionality (`necessary-functionality-r`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, necessary-functionality-r-implies-necessary-tractarianism-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □Functionality (`necessary-functionality-r`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via possibility-schema-r-implies-distinctness-schema-r, necessary-functionality-r-implies-necessary-tractarianism-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □Functionality (`necessary-functionality-r`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, necessary-functionality-r-implies-necessary-tractarianism-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □Functionality (`necessary-functionality-r`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, necessary-functionality-r-implies-necessary-tractarianism-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □Functionality (`necessary-functionality-r`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, necessary-functionality-r-implies-necessary-tractarianism-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □B (`necessary-modal-b`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via necessary-modal-b-implies-modal-b, modal-b-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- □B (`necessary-modal-b`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via necessary-modal-b-implies-modal-b, modal-b-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □B (`necessary-modal-b`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via necessary-modal-b-implies-modal-b, modal-b-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □B (`necessary-modal-b`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via necessary-modal-b-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □B (`necessary-modal-b`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via necessary-modal-b-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □B (`necessary-modal-b`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via necessary-modal-b-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □B (`necessary-modal-b`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via necessary-modal-b-implies-modal-b, modal-b-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □B (`necessary-modal-b`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via necessary-modal-b-implies-modal-b, modal-b-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □5 (`necessary-modal-five`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via necessary-modal-five-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- □5 (`necessary-modal-five`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via necessary-modal-five-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □5 (`necessary-modal-five`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via necessary-modal-five-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □5 (`necessary-modal-five`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via necessary-modal-five-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □5 (`necessary-modal-five`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via necessary-modal-five-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □5 (`necessary-modal-five`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via necessary-modal-five-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □5 (`necessary-modal-five`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via necessary-modal-five-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □5 (`necessary-modal-five`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via necessary-modal-five-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □Plenitude (`necessary-plenitude-r`) ⇒ ¬ Atomlessness (`atomlessness`); via necessary-plenitude-r-implies-atomicity-r, atomicity-r-implies-atomicity-t, atomicity-t-incompatible-with-atomlessness.
- □Plenitude (`necessary-plenitude-r`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via necessary-plenitude-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- □Plenitude (`necessary-plenitude-r`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via necessary-plenitude-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □Plenitude (`necessary-plenitude-r`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via necessary-plenitude-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □Plenitude (`necessary-plenitude-r`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via necessary-plenitude-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □Plenitude (`necessary-plenitude-r`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via necessary-plenitude-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □Plenitude (`necessary-plenitude-r`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via necessary-plenitude-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □Plenitude (`necessary-plenitude-r`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via necessary-plenitude-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □Plenitude (`necessary-plenitude-r`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via necessary-plenitude-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- □Rigid Comprehension (`necessary-rigid-comprehension-r`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via maximalist-distinctness-incompatible-with-necessary-rigid-comprehension-r.
- □Rigid Comprehension (`necessary-rigid-comprehension-r`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-rigid-comprehension-r.
- □Rigid Comprehension (`necessary-rigid-comprehension-r`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, necessary-rigid-comprehension-r-implies-necessary-actuality, maximalist-distinctness-incompatible-with-necessary-actuality.
- □Rigid Comprehension (`necessary-rigid-comprehension-r`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, necessary-rigid-comprehension-r-implies-necessary-actuality, maximalist-distinctness-incompatible-with-necessary-actuality.
- □Rigid Comprehension (`necessary-rigid-comprehension-r`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via possibility-schema-r-implies-distinctness-schema-r, necessary-rigid-comprehension-r-implies-necessary-actuality, maximalist-distinctness-incompatible-with-necessary-actuality.
- □Rigid Comprehension (`necessary-rigid-comprehension-r`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, necessary-rigid-comprehension-r-implies-necessary-actuality, maximalist-distinctness-incompatible-with-necessary-actuality.
- □Rigid Comprehension (`necessary-rigid-comprehension-r`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, necessary-rigid-comprehension-r-implies-necessary-actuality, maximalist-distinctness-incompatible-with-necessary-actuality.
- □Rigid Comprehension (`necessary-rigid-comprehension-r`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, necessary-rigid-comprehension-r-implies-necessary-actuality, maximalist-distinctness-incompatible-with-necessary-actuality.
- □Tractarianism (`necessary-tractarianism-r`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via maximalist-distinctness-incompatible-with-necessary-tractarianism-r.
- □Tractarianism (`necessary-tractarianism-r`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-tractarianism-r.
- □Tractarianism (`necessary-tractarianism-r`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □Tractarianism (`necessary-tractarianism-r`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □Tractarianism (`necessary-tractarianism-r`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via possibility-schema-r-implies-distinctness-schema-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □Tractarianism (`necessary-tractarianism-r`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □Tractarianism (`necessary-tractarianism-r`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- □Tractarianism (`necessary-tractarianism-r`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- No Pure Contingency (`no-pure-contingency-r`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- No Pure Contingency (`no-pure-contingency-r`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- No Pure Contingency (`no-pure-contingency-r`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via fundamental-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- No Pure Contingency (`no-pure-contingency-r`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via possibility-plus-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- No Pure Contingency (`no-pure-contingency-r`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via possibility-and-no-pure-contingency-incompatible.
- No Pure Contingency (`no-pure-contingency-r`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- No Pure Contingency (`no-pure-contingency-r`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via strong-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- No Pure Contingency (`no-pure-contingency-r`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Plenitude (`plenitude-r`) ⇒ ¬ Distinctness (pure) (`distinctness-schema-r`); via plenitude-r-implies-distinctness-necessary-r, maximalist-distinctness-incompatible-with-nd.
- Plenitude (`plenitude-r`) ⇒ ¬ Distinctness (signature Σ) (`distinctness-signature-r`); via plenitude-r-implies-distinctness-necessary-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Plenitude (`plenitude-r`) ⇒ ¬ Fundamental Possibility (`fundamental-possibility-r`); via plenitude-r-implies-distinctness-necessary-r, fundamental-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Plenitude (`plenitude-r`) ⇒ ¬ Possibility+ (`possibility-plus-r`); via plenitude-r-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Plenitude (`plenitude-r`) ⇒ ¬ Possibility (pure) (`possibility-schema-r`); via plenitude-r-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Plenitude (`plenitude-r`) ⇒ ¬ Possibility (signature Σ) (`possibility-signature-r`); via plenitude-r-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Plenitude (`plenitude-r`) ⇒ ¬ Strong Possibility (pure) (`strong-possibility-r`); via plenitude-r-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Plenitude (`plenitude-r`) ⇒ ¬ Strong Possibility (signature Σ) (`strong-possibility-signature-r`); via plenitude-r-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ Converse Witnessed Possibility (`converse-witnessed-possibility-r`); via converse-witnessed-possibility-r-implies-no-pure-contingency-r, possibility-plus-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ ND (`distinctness-necessary-r`); via possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ ND (type t) (`distinctness-necessary-t`); via distinctness-necessary-t-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ Extensionality (`extensionality-r`); via extensionality-r-implies-fregean-axiom, fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ Fregean Axiom (`fregean-axiom`); via fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ Functional Choice (`functional-choice-r`); via functional-choice-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ Logical Necessity (`logical-necessity-r`); via logical-necessity-r-implies-no-pure-contingency-r, possibility-plus-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ B (`modal-b`); via modal-b-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ 5 (`modal-five`); via modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ □Actuality (`necessary-actuality`); via possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-actuality.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ □Atomicity (`necessary-atomicity-r`); via possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-atomicity-r.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ □BF (`necessary-barcan-r`); via possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ □Boolean Completeness (`necessary-boolean-completeness-r`); via possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ □ND (`necessary-distinctness-necessary-r`); via necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ □ND (type t) (`necessary-distinctness-necessary-t`); via necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ □Extensionality (`necessary-extensionality-r`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, possibility-plus-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ □Fregean Axiom (`necessary-fregean-axiom`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, possibility-plus-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ □Functionality (`necessary-functionality-r`); via possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, necessary-functionality-r-implies-necessary-tractarianism-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ □B (`necessary-modal-b`); via necessary-modal-b-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ □5 (`necessary-modal-five`); via necessary-modal-five-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ □Plenitude (`necessary-plenitude-r`); via necessary-plenitude-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ □Rigid Comprehension (`necessary-rigid-comprehension-r`); via possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, necessary-rigid-comprehension-r-implies-necessary-actuality, maximalist-distinctness-incompatible-with-necessary-actuality.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ □Tractarianism (`necessary-tractarianism-r`); via possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ No Pure Contingency (`no-pure-contingency-r`); via possibility-plus-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Possibility+ (`possibility-plus-r`) ⇒ ¬ Plenitude (`plenitude-r`); via plenitude-r-implies-distinctness-necessary-r, possibility-plus-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ Converse Witnessed Possibility (`converse-witnessed-possibility-r`); via converse-witnessed-possibility-r-implies-no-pure-contingency-r, possibility-and-no-pure-contingency-incompatible.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ ND (`distinctness-necessary-r`); via possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ ND (type t) (`distinctness-necessary-t`); via distinctness-necessary-t-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ Extensionality (`extensionality-r`); via extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, possibility-and-no-pure-contingency-incompatible.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ Fregean Axiom (`fregean-axiom`); via fregean-axiom-implies-no-pure-contingency-r, possibility-and-no-pure-contingency-incompatible.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ Functional Choice (`functional-choice-r`); via functional-choice-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ Logical Necessity (`logical-necessity-r`); via logical-necessity-r-implies-no-pure-contingency-r, possibility-and-no-pure-contingency-incompatible.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ B (`modal-b`); via modal-b-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ 5 (`modal-five`); via modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ □Actuality (`necessary-actuality`); via possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-actuality.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ □Atomicity (`necessary-atomicity-r`); via possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-atomicity-r.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ □BF (`necessary-barcan-r`); via possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ □Boolean Completeness (`necessary-boolean-completeness-r`); via possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ □ND (`necessary-distinctness-necessary-r`); via necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ □ND (type t) (`necessary-distinctness-necessary-t`); via necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ □Extensionality (`necessary-extensionality-r`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, possibility-and-no-pure-contingency-incompatible.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ □Fregean Axiom (`necessary-fregean-axiom`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, possibility-and-no-pure-contingency-incompatible.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ □Functionality (`necessary-functionality-r`); via possibility-schema-r-implies-distinctness-schema-r, necessary-functionality-r-implies-necessary-tractarianism-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ □B (`necessary-modal-b`); via necessary-modal-b-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ □5 (`necessary-modal-five`); via necessary-modal-five-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ □Plenitude (`necessary-plenitude-r`); via necessary-plenitude-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ □Rigid Comprehension (`necessary-rigid-comprehension-r`); via possibility-schema-r-implies-distinctness-schema-r, necessary-rigid-comprehension-r-implies-necessary-actuality, maximalist-distinctness-incompatible-with-necessary-actuality.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ □Tractarianism (`necessary-tractarianism-r`); via possibility-schema-r-implies-distinctness-schema-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ No Pure Contingency (`no-pure-contingency-r`); via possibility-and-no-pure-contingency-incompatible.
- Possibility (pure) (`possibility-schema-r`) ⇒ ¬ Plenitude (`plenitude-r`); via plenitude-r-implies-distinctness-necessary-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ Converse Witnessed Possibility (`converse-witnessed-possibility-r`); via converse-witnessed-possibility-r-implies-no-pure-contingency-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ ND (`distinctness-necessary-r`); via possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ ND (type t) (`distinctness-necessary-t`); via distinctness-necessary-t-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ Extensionality (`extensionality-r`); via extensionality-r-implies-fregean-axiom, fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ Fregean Axiom (`fregean-axiom`); via fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ Functional Choice (`functional-choice-r`); via functional-choice-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ Logical Necessity (`logical-necessity-r`); via logical-necessity-r-implies-no-pure-contingency-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ B (`modal-b`); via modal-b-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ 5 (`modal-five`); via modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ □Actuality (`necessary-actuality`); via possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-actuality.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ □Atomicity (`necessary-atomicity-r`); via possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-atomicity-r.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ □BF (`necessary-barcan-r`); via possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ □Boolean Completeness (`necessary-boolean-completeness-r`); via possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ □ND (`necessary-distinctness-necessary-r`); via necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ □ND (type t) (`necessary-distinctness-necessary-t`); via necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ □Extensionality (`necessary-extensionality-r`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-fregean-axiom, fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ □Fregean Axiom (`necessary-fregean-axiom`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ □Functionality (`necessary-functionality-r`); via possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, necessary-functionality-r-implies-necessary-tractarianism-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ □B (`necessary-modal-b`); via necessary-modal-b-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ □5 (`necessary-modal-five`); via necessary-modal-five-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ □Plenitude (`necessary-plenitude-r`); via necessary-plenitude-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ □Rigid Comprehension (`necessary-rigid-comprehension-r`); via possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, necessary-rigid-comprehension-r-implies-necessary-actuality, maximalist-distinctness-incompatible-with-necessary-actuality.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ □Tractarianism (`necessary-tractarianism-r`); via possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ No Pure Contingency (`no-pure-contingency-r`); via possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Possibility (signature Σ) (`possibility-signature-r`) ⇒ ¬ Plenitude (`plenitude-r`); via plenitude-r-implies-distinctness-necessary-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ Converse Witnessed Possibility (`converse-witnessed-possibility-r`); via converse-witnessed-possibility-r-implies-no-pure-contingency-r, strong-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ ND (`distinctness-necessary-r`); via strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ ND (type t) (`distinctness-necessary-t`); via distinctness-necessary-t-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ Extensionality (`extensionality-r`); via extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, strong-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ Fregean Axiom (`fregean-axiom`); via fregean-axiom-implies-no-pure-contingency-r, strong-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ Functional Choice (`functional-choice-r`); via functional-choice-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ Logical Necessity (`logical-necessity-r`); via logical-necessity-r-implies-no-pure-contingency-r, strong-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ B (`modal-b`); via modal-b-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ 5 (`modal-five`); via modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ □Actuality (`necessary-actuality`); via strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-actuality.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ □Atomicity (`necessary-atomicity-r`); via strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-atomicity-r.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ □BF (`necessary-barcan-r`); via strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ □Boolean Completeness (`necessary-boolean-completeness-r`); via strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ □ND (`necessary-distinctness-necessary-r`); via necessary-distinctness-necessary-r-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ □ND (type t) (`necessary-distinctness-necessary-t`); via necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ □Extensionality (`necessary-extensionality-r`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, strong-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ □Fregean Axiom (`necessary-fregean-axiom`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-axiom-implies-no-pure-contingency-r, strong-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ □Functionality (`necessary-functionality-r`); via strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, necessary-functionality-r-implies-necessary-tractarianism-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ □B (`necessary-modal-b`); via necessary-modal-b-implies-modal-b, modal-b-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ □5 (`necessary-modal-five`); via necessary-modal-five-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ □Plenitude (`necessary-plenitude-r`); via necessary-plenitude-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ □Rigid Comprehension (`necessary-rigid-comprehension-r`); via strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, necessary-rigid-comprehension-r-implies-necessary-actuality, maximalist-distinctness-incompatible-with-necessary-actuality.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ □Tractarianism (`necessary-tractarianism-r`); via strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ No Pure Contingency (`no-pure-contingency-r`); via strong-possibility-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Strong Possibility (pure) (`strong-possibility-r`) ⇒ ¬ Plenitude (`plenitude-r`); via plenitude-r-implies-distinctness-necessary-r, strong-possibility-r-implies-possibility-schema-r, possibility-schema-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ Converse Witnessed Possibility (`converse-witnessed-possibility-r`); via converse-witnessed-possibility-r-implies-no-pure-contingency-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ ND (`distinctness-necessary-r`); via strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ ND (type t) (`distinctness-necessary-t`); via distinctness-necessary-t-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ Extensionality (`extensionality-r`); via extensionality-r-implies-fregean-axiom, fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ Fregean Axiom (`fregean-axiom`); via fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ Functional Choice (`functional-choice-r`); via functional-choice-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ Logical Necessity (`logical-necessity-r`); via logical-necessity-r-implies-no-pure-contingency-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ B (`modal-b`); via modal-b-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ 5 (`modal-five`); via modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ □Actuality (`necessary-actuality`); via strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-actuality.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ □Atomicity (`necessary-atomicity-r`); via strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-atomicity-r.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ □BF (`necessary-barcan-r`); via strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ □Boolean Completeness (`necessary-boolean-completeness-r`); via strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ □ND (`necessary-distinctness-necessary-r`); via necessary-distinctness-necessary-r-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ □ND (type t) (`necessary-distinctness-necessary-t`); via necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ □Extensionality (`necessary-extensionality-r`); via necessary-extensionality-r-implies-extensionality-r, extensionality-r-implies-fregean-axiom, fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ □Fregean Axiom (`necessary-fregean-axiom`); via necessary-fregean-axiom-implies-fregean-axiom, fregean-axiom-implies-necessary-distinctness-necessary-r, necessary-distinctness-necessary-r-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ □Functionality (`necessary-functionality-r`); via strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, necessary-functionality-r-implies-necessary-tractarianism-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ □B (`necessary-modal-b`); via necessary-modal-b-implies-modal-b, modal-b-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ □5 (`necessary-modal-five`); via necessary-modal-five-implies-modal-five, modal-five-implies-modal-b, modal-b-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ □Plenitude (`necessary-plenitude-r`); via necessary-plenitude-r-implies-plenitude-r, plenitude-r-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ □Rigid Comprehension (`necessary-rigid-comprehension-r`); via strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, necessary-rigid-comprehension-r-implies-necessary-actuality, maximalist-distinctness-incompatible-with-necessary-actuality.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ □Tractarianism (`necessary-tractarianism-r`); via strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, necessary-tractarianism-r-implies-necessary-barcan-r, maximalist-distinctness-incompatible-with-necessary-barcan-r.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ No Pure Contingency (`no-pure-contingency-r`); via strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, distinctness-schema-r-implies-possibility-schema-r, possibility-and-no-pure-contingency-incompatible.
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`) ⇒ ¬ Plenitude (`plenitude-r`); via plenitude-r-implies-distinctness-necessary-r, strong-possibility-signature-r-implies-possibility-signature-r, possibility-signature-r-implies-distinctness-signature-r, distinctness-signature-r-implies-distinctness-schema-r, maximalist-distinctness-incompatible-with-nd.

### 6.5 What the recorded premise packages entail

Every multi-premise package used by a proved result, with its full consequence set.

#### □Atomicity + Boolean Completeness + BF

Assumes: `necessary-atomicity-r`, `boolean-completeness-r`, `barcan-r`.

- Rules out (entails their negations): Atomlessness (`atomlessness`), Distinctness (pure) (`distinctness-schema-r`), Distinctness (signature Σ) (`distinctness-signature-r`), Fundamental Possibility (`fundamental-possibility-r`), Possibility+ (`possibility-plus-r`), Possibility (pure) (`possibility-schema-r`), Possibility (signature Σ) (`possibility-signature-r`), Strong Possibility (pure) (`strong-possibility-r`), Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Entails: Actual Profile (`actual-profile-r`), Actuality (`actuality`), Atomicity (`atomicity-r`), Atomicity (type t) (`atomicity-t`), BF (type t) (`barcan-t`), Boolean Completeness (type t) (`boolean-completeness-t`), Broad Necessitism (`broad-necessitism-r`), CBF (`converse-barcan-r`), Existence (`existence-r`), Functionality (`functionality-r`), NI (`identity-necessary-r`), Inextensible Comprehension (`inextensible-comprehension-r`), Intensionality (`intensionality-r`), 4 (`modal-four`), K (`modal-k`), T (`modal-t`), Modalized Fregean Axiom (`modalized-fregean`), Modalized Functionality (`modalized-functionality-r`), □Actuality (`necessary-actuality`), □BF (`necessary-barcan-r`), □BF (type t) (`necessary-barcan-t`), □Functionality (`necessary-functionality-r`), □Tractarianism (`necessary-tractarianism-r`), Ordinary Comprehension (`ordinary-comprehension-r`), Persistent Comprehension (`persistent-comprehension-r`), Rigid Comprehension (`rigid-comprehension-r`), Tractarianism (`tractarianism-r`)
- Refuted (a model satisfies the package and violates these): ND (`distinctness-necessary-r`), ND (type t) (`distinctness-necessary-t`), Extensionality (`extensionality-r`), Fregean Axiom (`fregean-axiom`), Functional Choice (`functional-choice-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), B (`modal-b`), 5 (`modal-five`), □ND (`necessary-distinctness-necessary-r`), □ND (type t) (`necessary-distinctness-necessary-t`), □Extensionality (`necessary-extensionality-r`), □Fregean Axiom (`necessary-fregean-axiom`), □B (`necessary-modal-b`), □5 (`necessary-modal-five`), □Plenitude (`necessary-plenitude-r`), Plenitude (`plenitude-r`), Relational Choice (`relational-choice-r`)
- Open: All individuals fundamental (`all-individuals-fundamental`), Converse Witnessed Possibility (`converse-witnessed-possibility-r`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Logical Necessity (`logical-necessity-r`), □Boolean Completeness (`necessary-boolean-completeness-r`), □Rigid Comprehension (`necessary-rigid-comprehension-r`), No Pure Contingency (`no-pure-contingency-r`), B for pure sentences (`pure-b-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

#### □ND + Actuality

Assumes: `necessary-distinctness-necessary-r`, `actuality`.

- Rules out (entails their negations): Distinctness (pure) (`distinctness-schema-r`), Distinctness (signature Σ) (`distinctness-signature-r`), Fundamental Possibility (`fundamental-possibility-r`), Possibility+ (`possibility-plus-r`), Possibility (pure) (`possibility-schema-r`), Possibility (signature Σ) (`possibility-signature-r`), Strong Possibility (pure) (`strong-possibility-r`), Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Entails: Actual Profile (`actual-profile-r`), BF (`barcan-r`), BF (type t) (`barcan-t`), Boolean Completeness (`boolean-completeness-r`), Boolean Completeness (type t) (`boolean-completeness-t`), Broad Necessitism (`broad-necessitism-r`), CBF (`converse-barcan-r`), ND (`distinctness-necessary-r`), ND (type t) (`distinctness-necessary-t`), Existence (`existence-r`), Functionality (`functionality-r`), NI (`identity-necessary-r`), Inextensible Comprehension (`inextensible-comprehension-r`), Intensionality (`intensionality-r`), B (`modal-b`), 5 (`modal-five`), 4 (`modal-four`), K (`modal-k`), T (`modal-t`), Modalized Fregean Axiom (`modalized-fregean`), Modalized Functionality (`modalized-functionality-r`), □BF (`necessary-barcan-r`), □BF (type t) (`necessary-barcan-t`), □ND (type t) (`necessary-distinctness-necessary-t`), □Functionality (`necessary-functionality-r`), □B (`necessary-modal-b`), □5 (`necessary-modal-five`), □Tractarianism (`necessary-tractarianism-r`), Ordinary Comprehension (`ordinary-comprehension-r`), Persistent Comprehension (`persistent-comprehension-r`), Plenitude (`plenitude-r`), B for pure sentences (`pure-b-r`), Rigid Comprehension (`rigid-comprehension-r`), Tractarianism (`tractarianism-r`)
- Refuted (a model satisfies the package and violates these): Atomicity (`atomicity-r`), Atomicity (type t) (`atomicity-t`), Atomlessness (`atomlessness`), Extensionality (`extensionality-r`), Fregean Axiom (`fregean-axiom`), Functional Choice (`functional-choice-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), □Actuality (`necessary-actuality`), □Atomicity (`necessary-atomicity-r`), □Boolean Completeness (`necessary-boolean-completeness-r`), □Extensionality (`necessary-extensionality-r`), □Fregean Axiom (`necessary-fregean-axiom`), □Plenitude (`necessary-plenitude-r`), □Rigid Comprehension (`necessary-rigid-comprehension-r`), Relational Choice (`relational-choice-r`)
- Open: All individuals fundamental (`all-individuals-fundamental`), Converse Witnessed Possibility (`converse-witnessed-possibility-r`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Logical Necessity (`logical-necessity-r`), No Pure Contingency (`no-pure-contingency-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

#### Fundamental Possibility + All individuals fundamental

Assumes: `fundamental-possibility-r`, `all-individuals-fundamental`.

- Rules out (entails their negations): Converse Witnessed Possibility (`converse-witnessed-possibility-r`), ND (`distinctness-necessary-r`), ND (type t) (`distinctness-necessary-t`), Extensionality (`extensionality-r`), Fregean Axiom (`fregean-axiom`), Functional Choice (`functional-choice-r`), Logical Necessity (`logical-necessity-r`), B (`modal-b`), 5 (`modal-five`), □Actuality (`necessary-actuality`), □Atomicity (`necessary-atomicity-r`), □BF (`necessary-barcan-r`), □Boolean Completeness (`necessary-boolean-completeness-r`), □ND (`necessary-distinctness-necessary-r`), □ND (type t) (`necessary-distinctness-necessary-t`), □Extensionality (`necessary-extensionality-r`), □Fregean Axiom (`necessary-fregean-axiom`), □Functionality (`necessary-functionality-r`), □B (`necessary-modal-b`), □5 (`necessary-modal-five`), □Plenitude (`necessary-plenitude-r`), □Rigid Comprehension (`necessary-rigid-comprehension-r`), □Tractarianism (`necessary-tractarianism-r`), No Pure Contingency (`no-pure-contingency-r`), Plenitude (`plenitude-r`)
- Entails: Broad Necessitism (`broad-necessitism-r`), CBF (`converse-barcan-r`), Distinctness (pure) (`distinctness-schema-r`), Existence (`existence-r`), NI (`identity-necessary-r`), Intensionality (`intensionality-r`), 4 (`modal-four`), K (`modal-k`), T (`modal-t`), Modalized Fregean Axiom (`modalized-fregean`), Modalized Functionality (`modalized-functionality-r`), Ordinary Comprehension (`ordinary-comprehension-r`), Possibility+ (`possibility-plus-r`), Possibility (pure) (`possibility-schema-r`)
- Refuted (a model satisfies the package and violates these): nothing
- Open: Actual Profile (`actual-profile-r`), Actuality (`actuality`), Atomicity (`atomicity-r`), Atomicity (type t) (`atomicity-t`), Atomlessness (`atomlessness`), BF (`barcan-r`), BF (type t) (`barcan-t`), Boolean Completeness (`boolean-completeness-r`), Boolean Completeness (type t) (`boolean-completeness-t`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Distinctness (signature Σ) (`distinctness-signature-r`), Functionality (`functionality-r`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Inextensible Comprehension (`inextensible-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), □BF (type t) (`necessary-barcan-t`), Persistent Comprehension (`persistent-comprehension-r`), Possibility (signature Σ) (`possibility-signature-r`), B for pure sentences (`pure-b-r`), Relational Choice (`relational-choice-r`), Rigid Comprehension (`rigid-comprehension-r`), Separated Structure (`separated-structure-r`), Strong Possibility (pure) (`strong-possibility-r`), Strong Possibility (signature Σ) (`strong-possibility-signature-r`), Tractarianism (`tractarianism-r`), Witnessed Possibility (`witnessed-possibility-r`)

#### Atomicity + BF

Assumes: `atomicity-r`, `barcan-r`.

- Rules out (entails their negations): Atomlessness (`atomlessness`), Distinctness (pure) (`distinctness-schema-r`), Distinctness (signature Σ) (`distinctness-signature-r`), Fundamental Possibility (`fundamental-possibility-r`), Possibility+ (`possibility-plus-r`), Possibility (pure) (`possibility-schema-r`), Possibility (signature Σ) (`possibility-signature-r`), Strong Possibility (pure) (`strong-possibility-r`), Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Entails: Actual Profile (`actual-profile-r`), Actuality (`actuality`), Atomicity (type t) (`atomicity-t`), BF (type t) (`barcan-t`), Broad Necessitism (`broad-necessitism-r`), CBF (`converse-barcan-r`), Existence (`existence-r`), Functionality (`functionality-r`), NI (`identity-necessary-r`), Inextensible Comprehension (`inextensible-comprehension-r`), Intensionality (`intensionality-r`), 4 (`modal-four`), K (`modal-k`), T (`modal-t`), Modalized Fregean Axiom (`modalized-fregean`), Modalized Functionality (`modalized-functionality-r`), □Actuality (`necessary-actuality`), Ordinary Comprehension (`ordinary-comprehension-r`), Persistent Comprehension (`persistent-comprehension-r`), Tractarianism (`tractarianism-r`)
- Refuted (a model satisfies the package and violates these): Boolean Completeness (`boolean-completeness-r`), ND (`distinctness-necessary-r`), ND (type t) (`distinctness-necessary-t`), Extensionality (`extensionality-r`), Fregean Axiom (`fregean-axiom`), Functional Choice (`functional-choice-r`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), B (`modal-b`), 5 (`modal-five`), □Boolean Completeness (`necessary-boolean-completeness-r`), □ND (`necessary-distinctness-necessary-r`), □ND (type t) (`necessary-distinctness-necessary-t`), □Extensionality (`necessary-extensionality-r`), □Fregean Axiom (`necessary-fregean-axiom`), □B (`necessary-modal-b`), □5 (`necessary-modal-five`), □Plenitude (`necessary-plenitude-r`), □Rigid Comprehension (`necessary-rigid-comprehension-r`), Plenitude (`plenitude-r`), Relational Choice (`relational-choice-r`), Rigid Comprehension (`rigid-comprehension-r`)
- Open: All individuals fundamental (`all-individuals-fundamental`), Boolean Completeness (type t) (`boolean-completeness-t`), Converse Witnessed Possibility (`converse-witnessed-possibility-r`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Logical Necessity (`logical-necessity-r`), □Atomicity (`necessary-atomicity-r`), □BF (`necessary-barcan-r`), □BF (type t) (`necessary-barcan-t`), □Functionality (`necessary-functionality-r`), □Tractarianism (`necessary-tractarianism-r`), No Pure Contingency (`no-pure-contingency-r`), B for pure sentences (`pure-b-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

#### □ND + Atomicity

Assumes: `necessary-distinctness-necessary-r`, `atomicity-r`.

- Rules out (entails their negations): Atomlessness (`atomlessness`), Distinctness (pure) (`distinctness-schema-r`), Distinctness (signature Σ) (`distinctness-signature-r`), Fundamental Possibility (`fundamental-possibility-r`), Possibility+ (`possibility-plus-r`), Possibility (pure) (`possibility-schema-r`), Possibility (signature Σ) (`possibility-signature-r`), Strong Possibility (pure) (`strong-possibility-r`), Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Entails: Actual Profile (`actual-profile-r`), Actuality (`actuality`), Atomicity (type t) (`atomicity-t`), BF (`barcan-r`), BF (type t) (`barcan-t`), Boolean Completeness (`boolean-completeness-r`), Boolean Completeness (type t) (`boolean-completeness-t`), Broad Necessitism (`broad-necessitism-r`), CBF (`converse-barcan-r`), ND (`distinctness-necessary-r`), ND (type t) (`distinctness-necessary-t`), Existence (`existence-r`), Functionality (`functionality-r`), NI (`identity-necessary-r`), Inextensible Comprehension (`inextensible-comprehension-r`), Intensionality (`intensionality-r`), B (`modal-b`), 5 (`modal-five`), 4 (`modal-four`), K (`modal-k`), T (`modal-t`), Modalized Fregean Axiom (`modalized-fregean`), Modalized Functionality (`modalized-functionality-r`), □Actuality (`necessary-actuality`), □Atomicity (`necessary-atomicity-r`), □BF (`necessary-barcan-r`), □BF (type t) (`necessary-barcan-t`), □Boolean Completeness (`necessary-boolean-completeness-r`), □ND (type t) (`necessary-distinctness-necessary-t`), □Functionality (`necessary-functionality-r`), □B (`necessary-modal-b`), □5 (`necessary-modal-five`), □Plenitude (`necessary-plenitude-r`), □Rigid Comprehension (`necessary-rigid-comprehension-r`), □Tractarianism (`necessary-tractarianism-r`), Ordinary Comprehension (`ordinary-comprehension-r`), Persistent Comprehension (`persistent-comprehension-r`), Plenitude (`plenitude-r`), B for pure sentences (`pure-b-r`), Rigid Comprehension (`rigid-comprehension-r`), Tractarianism (`tractarianism-r`)
- Refuted (a model satisfies the package and violates these): Extensionality (`extensionality-r`), Fregean Axiom (`fregean-axiom`), Functional Choice (`functional-choice-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), □Extensionality (`necessary-extensionality-r`), □Fregean Axiom (`necessary-fregean-axiom`), Relational Choice (`relational-choice-r`)
- Open: All individuals fundamental (`all-individuals-fundamental`), Converse Witnessed Possibility (`converse-witnessed-possibility-r`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Logical Necessity (`logical-necessity-r`), No Pure Contingency (`no-pure-contingency-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

#### Atomicity (type t) + Atomlessness

Assumes: `atomicity-t`, `atomlessness`.

**Inconsistent:** these premises imply False via atomicity-t-incompatible-with-atomlessness. No consequences by explosion are listed.

#### Atomicity (type t) + BF

Assumes: `atomicity-t`, `barcan-r`.

- Rules out (entails their negations): Atomlessness (`atomlessness`), Distinctness (pure) (`distinctness-schema-r`), Distinctness (signature Σ) (`distinctness-signature-r`), Fundamental Possibility (`fundamental-possibility-r`), Possibility+ (`possibility-plus-r`), Possibility (pure) (`possibility-schema-r`), Possibility (signature Σ) (`possibility-signature-r`), Strong Possibility (pure) (`strong-possibility-r`), Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Entails: Actual Profile (`actual-profile-r`), Actuality (`actuality`), BF (type t) (`barcan-t`), Broad Necessitism (`broad-necessitism-r`), CBF (`converse-barcan-r`), Existence (`existence-r`), Functionality (`functionality-r`), NI (`identity-necessary-r`), Inextensible Comprehension (`inextensible-comprehension-r`), Intensionality (`intensionality-r`), 4 (`modal-four`), K (`modal-k`), T (`modal-t`), Modalized Fregean Axiom (`modalized-fregean`), Modalized Functionality (`modalized-functionality-r`), □Actuality (`necessary-actuality`), Ordinary Comprehension (`ordinary-comprehension-r`), Persistent Comprehension (`persistent-comprehension-r`), Tractarianism (`tractarianism-r`)
- Refuted (a model satisfies the package and violates these): Boolean Completeness (`boolean-completeness-r`), ND (`distinctness-necessary-r`), ND (type t) (`distinctness-necessary-t`), Extensionality (`extensionality-r`), Fregean Axiom (`fregean-axiom`), Functional Choice (`functional-choice-r`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), B (`modal-b`), 5 (`modal-five`), □Boolean Completeness (`necessary-boolean-completeness-r`), □ND (`necessary-distinctness-necessary-r`), □ND (type t) (`necessary-distinctness-necessary-t`), □Extensionality (`necessary-extensionality-r`), □Fregean Axiom (`necessary-fregean-axiom`), □B (`necessary-modal-b`), □5 (`necessary-modal-five`), □Plenitude (`necessary-plenitude-r`), □Rigid Comprehension (`necessary-rigid-comprehension-r`), Plenitude (`plenitude-r`), Relational Choice (`relational-choice-r`), Rigid Comprehension (`rigid-comprehension-r`)
- Open: All individuals fundamental (`all-individuals-fundamental`), Atomicity (`atomicity-r`), Boolean Completeness (type t) (`boolean-completeness-t`), Converse Witnessed Possibility (`converse-witnessed-possibility-r`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Logical Necessity (`logical-necessity-r`), □Atomicity (`necessary-atomicity-r`), □BF (`necessary-barcan-r`), □BF (type t) (`necessary-barcan-t`), □Functionality (`necessary-functionality-r`), □Tractarianism (`necessary-tractarianism-r`), No Pure Contingency (`no-pure-contingency-r`), B for pure sentences (`pure-b-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

#### ND + BF

Assumes: `distinctness-necessary-r`, `barcan-r`.

- Rules out (entails their negations): Distinctness (pure) (`distinctness-schema-r`), Distinctness (signature Σ) (`distinctness-signature-r`), Fundamental Possibility (`fundamental-possibility-r`), Possibility+ (`possibility-plus-r`), Possibility (pure) (`possibility-schema-r`), Possibility (signature Σ) (`possibility-signature-r`), Strong Possibility (pure) (`strong-possibility-r`), Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Entails: BF (type t) (`barcan-t`), Broad Necessitism (`broad-necessitism-r`), CBF (`converse-barcan-r`), ND (type t) (`distinctness-necessary-t`), Existence (`existence-r`), Functionality (`functionality-r`), NI (`identity-necessary-r`), Intensionality (`intensionality-r`), B (`modal-b`), 5 (`modal-five`), 4 (`modal-four`), K (`modal-k`), T (`modal-t`), Modalized Fregean Axiom (`modalized-fregean`), Modalized Functionality (`modalized-functionality-r`), □BF (`necessary-barcan-r`), □BF (type t) (`necessary-barcan-t`), □ND (`necessary-distinctness-necessary-r`), □ND (type t) (`necessary-distinctness-necessary-t`), □Functionality (`necessary-functionality-r`), □B (`necessary-modal-b`), □5 (`necessary-modal-five`), □Tractarianism (`necessary-tractarianism-r`), Ordinary Comprehension (`ordinary-comprehension-r`), B for pure sentences (`pure-b-r`), Tractarianism (`tractarianism-r`)
- Refuted (a model satisfies the package and violates these): Actual Profile (`actual-profile-r`), Actuality (`actuality`), Atomicity (`atomicity-r`), Atomicity (type t) (`atomicity-t`), Atomlessness (`atomlessness`), Boolean Completeness (`boolean-completeness-r`), Extensionality (`extensionality-r`), Fregean Axiom (`fregean-axiom`), Functional Choice (`functional-choice-r`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), □Actuality (`necessary-actuality`), □Atomicity (`necessary-atomicity-r`), □Boolean Completeness (`necessary-boolean-completeness-r`), □Extensionality (`necessary-extensionality-r`), □Fregean Axiom (`necessary-fregean-axiom`), □Plenitude (`necessary-plenitude-r`), □Rigid Comprehension (`necessary-rigid-comprehension-r`), Persistent Comprehension (`persistent-comprehension-r`), Plenitude (`plenitude-r`), Relational Choice (`relational-choice-r`), Rigid Comprehension (`rigid-comprehension-r`)
- Open: All individuals fundamental (`all-individuals-fundamental`), Boolean Completeness (type t) (`boolean-completeness-t`), Converse Witnessed Possibility (`converse-witnessed-possibility-r`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Inextensible Comprehension (`inextensible-comprehension-r`), Logical Necessity (`logical-necessity-r`), No Pure Contingency (`no-pure-contingency-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

#### Gallin Extensional Comprehension + BF

Assumes: `gallin-extensional-comprehension-r`, `barcan-r`.

- Rules out (entails their negations): Distinctness (pure) (`distinctness-schema-r`), Distinctness (signature Σ) (`distinctness-signature-r`), Fundamental Possibility (`fundamental-possibility-r`), Possibility+ (`possibility-plus-r`), Possibility (pure) (`possibility-schema-r`), Possibility (signature Σ) (`possibility-signature-r`), Strong Possibility (pure) (`strong-possibility-r`), Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Entails: Actual Profile (`actual-profile-r`), Actuality (`actuality`), BF (type t) (`barcan-t`), Boolean Completeness (`boolean-completeness-r`), Boolean Completeness (type t) (`boolean-completeness-t`), Broad Necessitism (`broad-necessitism-r`), CBF (`converse-barcan-r`), Existence (`existence-r`), Functionality (`functionality-r`), NI (`identity-necessary-r`), Inextensible Comprehension (`inextensible-comprehension-r`), Intensionality (`intensionality-r`), 4 (`modal-four`), K (`modal-k`), T (`modal-t`), Modalized Fregean Axiom (`modalized-fregean`), Modalized Functionality (`modalized-functionality-r`), □BF (`necessary-barcan-r`), □BF (type t) (`necessary-barcan-t`), □Functionality (`necessary-functionality-r`), □Tractarianism (`necessary-tractarianism-r`), Ordinary Comprehension (`ordinary-comprehension-r`), Persistent Comprehension (`persistent-comprehension-r`), Rigid Comprehension (`rigid-comprehension-r`), Tractarianism (`tractarianism-r`)
- Refuted (a model satisfies the package and violates these): nothing
- Open: All individuals fundamental (`all-individuals-fundamental`), Atomicity (`atomicity-r`), Atomicity (type t) (`atomicity-t`), Atomlessness (`atomlessness`), Converse Witnessed Possibility (`converse-witnessed-possibility-r`), ND (`distinctness-necessary-r`), ND (type t) (`distinctness-necessary-t`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Extensionality (`extensionality-r`), Fregean Axiom (`fregean-axiom`), Functional Choice (`functional-choice-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), Logical Necessity (`logical-necessity-r`), B (`modal-b`), 5 (`modal-five`), □Actuality (`necessary-actuality`), □Atomicity (`necessary-atomicity-r`), □Boolean Completeness (`necessary-boolean-completeness-r`), □ND (`necessary-distinctness-necessary-r`), □ND (type t) (`necessary-distinctness-necessary-t`), □Extensionality (`necessary-extensionality-r`), □Fregean Axiom (`necessary-fregean-axiom`), □B (`necessary-modal-b`), □5 (`necessary-modal-five`), □Plenitude (`necessary-plenitude-r`), □Rigid Comprehension (`necessary-rigid-comprehension-r`), No Pure Contingency (`no-pure-contingency-r`), Plenitude (`plenitude-r`), B for pure sentences (`pure-b-r`), Relational Choice (`relational-choice-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

#### Rigid Comprehension + BF

Assumes: `rigid-comprehension-r`, `barcan-r`.

- Rules out (entails their negations): Distinctness (pure) (`distinctness-schema-r`), Distinctness (signature Σ) (`distinctness-signature-r`), Fundamental Possibility (`fundamental-possibility-r`), Possibility+ (`possibility-plus-r`), Possibility (pure) (`possibility-schema-r`), Possibility (signature Σ) (`possibility-signature-r`), Strong Possibility (pure) (`strong-possibility-r`), Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Entails: Actual Profile (`actual-profile-r`), Actuality (`actuality`), BF (type t) (`barcan-t`), Boolean Completeness (`boolean-completeness-r`), Boolean Completeness (type t) (`boolean-completeness-t`), Broad Necessitism (`broad-necessitism-r`), CBF (`converse-barcan-r`), Existence (`existence-r`), Functionality (`functionality-r`), NI (`identity-necessary-r`), Inextensible Comprehension (`inextensible-comprehension-r`), Intensionality (`intensionality-r`), 4 (`modal-four`), K (`modal-k`), T (`modal-t`), Modalized Fregean Axiom (`modalized-fregean`), Modalized Functionality (`modalized-functionality-r`), □BF (`necessary-barcan-r`), □BF (type t) (`necessary-barcan-t`), □Functionality (`necessary-functionality-r`), □Tractarianism (`necessary-tractarianism-r`), Ordinary Comprehension (`ordinary-comprehension-r`), Persistent Comprehension (`persistent-comprehension-r`), Tractarianism (`tractarianism-r`)
- Refuted (a model satisfies the package and violates these): Atomicity (`atomicity-r`), Atomicity (type t) (`atomicity-t`), Atomlessness (`atomlessness`), ND (`distinctness-necessary-r`), ND (type t) (`distinctness-necessary-t`), Extensionality (`extensionality-r`), Fregean Axiom (`fregean-axiom`), Functional Choice (`functional-choice-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), B (`modal-b`), 5 (`modal-five`), □Actuality (`necessary-actuality`), □Atomicity (`necessary-atomicity-r`), □Boolean Completeness (`necessary-boolean-completeness-r`), □ND (`necessary-distinctness-necessary-r`), □ND (type t) (`necessary-distinctness-necessary-t`), □Extensionality (`necessary-extensionality-r`), □Fregean Axiom (`necessary-fregean-axiom`), □B (`necessary-modal-b`), □5 (`necessary-modal-five`), □Plenitude (`necessary-plenitude-r`), □Rigid Comprehension (`necessary-rigid-comprehension-r`), Plenitude (`plenitude-r`), Relational Choice (`relational-choice-r`)
- Open: All individuals fundamental (`all-individuals-fundamental`), Converse Witnessed Possibility (`converse-witnessed-possibility-r`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Logical Necessity (`logical-necessity-r`), No Pure Contingency (`no-pure-contingency-r`), B for pure sentences (`pure-b-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

#### □ND + Boolean Completeness

Assumes: `necessary-distinctness-necessary-r`, `boolean-completeness-r`.

- Rules out (entails their negations): Distinctness (pure) (`distinctness-schema-r`), Distinctness (signature Σ) (`distinctness-signature-r`), Fundamental Possibility (`fundamental-possibility-r`), Possibility+ (`possibility-plus-r`), Possibility (pure) (`possibility-schema-r`), Possibility (signature Σ) (`possibility-signature-r`), Strong Possibility (pure) (`strong-possibility-r`), Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Entails: Actual Profile (`actual-profile-r`), Actuality (`actuality`), BF (`barcan-r`), BF (type t) (`barcan-t`), Boolean Completeness (type t) (`boolean-completeness-t`), Broad Necessitism (`broad-necessitism-r`), CBF (`converse-barcan-r`), ND (`distinctness-necessary-r`), ND (type t) (`distinctness-necessary-t`), Existence (`existence-r`), Functionality (`functionality-r`), NI (`identity-necessary-r`), Inextensible Comprehension (`inextensible-comprehension-r`), Intensionality (`intensionality-r`), B (`modal-b`), 5 (`modal-five`), 4 (`modal-four`), K (`modal-k`), T (`modal-t`), Modalized Fregean Axiom (`modalized-fregean`), Modalized Functionality (`modalized-functionality-r`), □BF (`necessary-barcan-r`), □BF (type t) (`necessary-barcan-t`), □ND (type t) (`necessary-distinctness-necessary-t`), □Functionality (`necessary-functionality-r`), □B (`necessary-modal-b`), □5 (`necessary-modal-five`), □Tractarianism (`necessary-tractarianism-r`), Ordinary Comprehension (`ordinary-comprehension-r`), Persistent Comprehension (`persistent-comprehension-r`), Plenitude (`plenitude-r`), B for pure sentences (`pure-b-r`), Rigid Comprehension (`rigid-comprehension-r`), Tractarianism (`tractarianism-r`)
- Refuted (a model satisfies the package and violates these): Atomicity (`atomicity-r`), Atomicity (type t) (`atomicity-t`), Atomlessness (`atomlessness`), Extensionality (`extensionality-r`), Fregean Axiom (`fregean-axiom`), Functional Choice (`functional-choice-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), □Actuality (`necessary-actuality`), □Atomicity (`necessary-atomicity-r`), □Boolean Completeness (`necessary-boolean-completeness-r`), □Extensionality (`necessary-extensionality-r`), □Fregean Axiom (`necessary-fregean-axiom`), □Plenitude (`necessary-plenitude-r`), □Rigid Comprehension (`necessary-rigid-comprehension-r`), Relational Choice (`relational-choice-r`)
- Open: All individuals fundamental (`all-individuals-fundamental`), Converse Witnessed Possibility (`converse-witnessed-possibility-r`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Logical Necessity (`logical-necessity-r`), No Pure Contingency (`no-pure-contingency-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

#### Distinctness (pure) + ND

Assumes: `distinctness-schema-r`, `distinctness-necessary-r`.

**Inconsistent:** these premises imply False via maximalist-distinctness-incompatible-with-nd. No consequences by explosion are listed.

#### Rigid Comprehension + ND

Assumes: `rigid-comprehension-r`, `distinctness-necessary-r`.

- Rules out (entails their negations): Distinctness (pure) (`distinctness-schema-r`), Distinctness (signature Σ) (`distinctness-signature-r`), Fundamental Possibility (`fundamental-possibility-r`), Possibility+ (`possibility-plus-r`), Possibility (pure) (`possibility-schema-r`), Possibility (signature Σ) (`possibility-signature-r`), Strong Possibility (pure) (`strong-possibility-r`), Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Entails: Actual Profile (`actual-profile-r`), Actuality (`actuality`), Boolean Completeness (`boolean-completeness-r`), Boolean Completeness (type t) (`boolean-completeness-t`), Broad Necessitism (`broad-necessitism-r`), CBF (`converse-barcan-r`), ND (type t) (`distinctness-necessary-t`), Existence (`existence-r`), NI (`identity-necessary-r`), Inextensible Comprehension (`inextensible-comprehension-r`), Intensionality (`intensionality-r`), B (`modal-b`), 5 (`modal-five`), 4 (`modal-four`), K (`modal-k`), T (`modal-t`), Modalized Fregean Axiom (`modalized-fregean`), Modalized Functionality (`modalized-functionality-r`), Ordinary Comprehension (`ordinary-comprehension-r`), Persistent Comprehension (`persistent-comprehension-r`), Plenitude (`plenitude-r`), B for pure sentences (`pure-b-r`)
- Refuted (a model satisfies the package and violates these): Atomicity (`atomicity-r`), Atomicity (type t) (`atomicity-t`), Atomlessness (`atomlessness`), BF (`barcan-r`), Converse Witnessed Possibility (`converse-witnessed-possibility-r`), Extensionality (`extensionality-r`), Fregean Axiom (`fregean-axiom`), Functional Choice (`functional-choice-r`), Functionality (`functionality-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), Logical Necessity (`logical-necessity-r`), □Actuality (`necessary-actuality`), □Atomicity (`necessary-atomicity-r`), □BF (`necessary-barcan-r`), □Boolean Completeness (`necessary-boolean-completeness-r`), □ND (`necessary-distinctness-necessary-r`), □ND (type t) (`necessary-distinctness-necessary-t`), □Extensionality (`necessary-extensionality-r`), □Fregean Axiom (`necessary-fregean-axiom`), □Functionality (`necessary-functionality-r`), □B (`necessary-modal-b`), □5 (`necessary-modal-five`), □Plenitude (`necessary-plenitude-r`), □Rigid Comprehension (`necessary-rigid-comprehension-r`), □Tractarianism (`necessary-tractarianism-r`), No Pure Contingency (`no-pure-contingency-r`), Relational Choice (`relational-choice-r`), Tractarianism (`tractarianism-r`)
- Open: All individuals fundamental (`all-individuals-fundamental`), BF (type t) (`barcan-t`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), □BF (type t) (`necessary-barcan-t`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

#### Distinctness (pure) + □Actuality

Assumes: `distinctness-schema-r`, `necessary-actuality`.

**Inconsistent:** these premises imply False via maximalist-distinctness-incompatible-with-necessary-actuality. No consequences by explosion are listed.

#### Distinctness (pure) + □Atomicity

Assumes: `distinctness-schema-r`, `necessary-atomicity-r`.

**Inconsistent:** these premises imply False via maximalist-distinctness-incompatible-with-necessary-atomicity-r. No consequences by explosion are listed.

#### Distinctness (pure) + □BF

Assumes: `distinctness-schema-r`, `necessary-barcan-r`.

**Inconsistent:** these premises imply False via maximalist-distinctness-incompatible-with-necessary-barcan-r. No consequences by explosion are listed.

#### Distinctness (pure) + □Boolean Completeness

Assumes: `distinctness-schema-r`, `necessary-boolean-completeness-r`.

**Inconsistent:** these premises imply False via maximalist-distinctness-incompatible-with-necessary-boolean-completeness-r. No consequences by explosion are listed.

#### Distinctness (pure) + □Functionality

Assumes: `distinctness-schema-r`, `necessary-functionality-r`.

**Inconsistent:** these premises imply False via maximalist-distinctness-incompatible-with-necessary-functionality-r. No consequences by explosion are listed.

#### Distinctness (pure) + □Rigid Comprehension

Assumes: `distinctness-schema-r`, `necessary-rigid-comprehension-r`.

**Inconsistent:** these premises imply False via maximalist-distinctness-incompatible-with-necessary-rigid-comprehension-r. No consequences by explosion are listed.

#### Distinctness (pure) + □Tractarianism

Assumes: `distinctness-schema-r`, `necessary-tractarianism-r`.

**Inconsistent:** these premises imply False via maximalist-distinctness-incompatible-with-necessary-tractarianism-r. No consequences by explosion are listed.

#### Distinctness (pure) + Separated Structure

Assumes: `distinctness-schema-r`, `separated-structure-r`.

- Rules out (entails their negations): Converse Witnessed Possibility (`converse-witnessed-possibility-r`), ND (`distinctness-necessary-r`), ND (type t) (`distinctness-necessary-t`), Extensionality (`extensionality-r`), Fregean Axiom (`fregean-axiom`), Functional Choice (`functional-choice-r`), Logical Necessity (`logical-necessity-r`), B (`modal-b`), 5 (`modal-five`), □Actuality (`necessary-actuality`), □Atomicity (`necessary-atomicity-r`), □BF (`necessary-barcan-r`), □Boolean Completeness (`necessary-boolean-completeness-r`), □ND (`necessary-distinctness-necessary-r`), □ND (type t) (`necessary-distinctness-necessary-t`), □Extensionality (`necessary-extensionality-r`), □Fregean Axiom (`necessary-fregean-axiom`), □Functionality (`necessary-functionality-r`), □B (`necessary-modal-b`), □5 (`necessary-modal-five`), □Plenitude (`necessary-plenitude-r`), □Rigid Comprehension (`necessary-rigid-comprehension-r`), □Tractarianism (`necessary-tractarianism-r`), No Pure Contingency (`no-pure-contingency-r`), Plenitude (`plenitude-r`)
- Entails: Broad Necessitism (`broad-necessitism-r`), CBF (`converse-barcan-r`), Distinctness (signature Σ) (`distinctness-signature-r`), Existence (`existence-r`), NI (`identity-necessary-r`), Intensionality (`intensionality-r`), 4 (`modal-four`), K (`modal-k`), T (`modal-t`), Modalized Fregean Axiom (`modalized-fregean`), Modalized Functionality (`modalized-functionality-r`), Ordinary Comprehension (`ordinary-comprehension-r`), Possibility (pure) (`possibility-schema-r`), Possibility (signature Σ) (`possibility-signature-r`), Witnessed Possibility (`witnessed-possibility-r`)
- Refuted (a model satisfies the package and violates these): Strong Possibility (pure) (`strong-possibility-r`)
- Open: Actual Profile (`actual-profile-r`), Actuality (`actuality`), All individuals fundamental (`all-individuals-fundamental`), Atomicity (`atomicity-r`), Atomicity (type t) (`atomicity-t`), Atomlessness (`atomlessness`), BF (`barcan-r`), BF (type t) (`barcan-t`), Boolean Completeness (`boolean-completeness-r`), Boolean Completeness (type t) (`boolean-completeness-t`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Functionality (`functionality-r`), Fundamental Possibility (`fundamental-possibility-r`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Inextensible Comprehension (`inextensible-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), □BF (type t) (`necessary-barcan-t`), Persistent Comprehension (`persistent-comprehension-r`), Possibility+ (`possibility-plus-r`), B for pure sentences (`pure-b-r`), Relational Choice (`relational-choice-r`), Rigid Comprehension (`rigid-comprehension-r`), Strong Possibility (signature Σ) (`strong-possibility-signature-r`), Tractarianism (`tractarianism-r`)

#### Fregean Axiom + Infinity (type t)

Assumes: `fregean-axiom`, `infinity-t`.

**Inconsistent:** these premises imply False via fregean-incompatible-with-infinity-t. No consequences by explosion are listed.

#### □ND + □Actuality

Assumes: `necessary-distinctness-necessary-r`, `necessary-actuality`.

- Rules out (entails their negations): Atomlessness (`atomlessness`), Distinctness (pure) (`distinctness-schema-r`), Distinctness (signature Σ) (`distinctness-signature-r`), Fundamental Possibility (`fundamental-possibility-r`), Possibility+ (`possibility-plus-r`), Possibility (pure) (`possibility-schema-r`), Possibility (signature Σ) (`possibility-signature-r`), Strong Possibility (pure) (`strong-possibility-r`), Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Entails: Actual Profile (`actual-profile-r`), Actuality (`actuality`), Atomicity (`atomicity-r`), Atomicity (type t) (`atomicity-t`), BF (`barcan-r`), BF (type t) (`barcan-t`), Boolean Completeness (`boolean-completeness-r`), Boolean Completeness (type t) (`boolean-completeness-t`), Broad Necessitism (`broad-necessitism-r`), CBF (`converse-barcan-r`), ND (`distinctness-necessary-r`), ND (type t) (`distinctness-necessary-t`), Existence (`existence-r`), Functionality (`functionality-r`), NI (`identity-necessary-r`), Inextensible Comprehension (`inextensible-comprehension-r`), Intensionality (`intensionality-r`), B (`modal-b`), 5 (`modal-five`), 4 (`modal-four`), K (`modal-k`), T (`modal-t`), Modalized Fregean Axiom (`modalized-fregean`), Modalized Functionality (`modalized-functionality-r`), □Atomicity (`necessary-atomicity-r`), □BF (`necessary-barcan-r`), □BF (type t) (`necessary-barcan-t`), □Boolean Completeness (`necessary-boolean-completeness-r`), □ND (type t) (`necessary-distinctness-necessary-t`), □Functionality (`necessary-functionality-r`), □B (`necessary-modal-b`), □5 (`necessary-modal-five`), □Plenitude (`necessary-plenitude-r`), □Rigid Comprehension (`necessary-rigid-comprehension-r`), □Tractarianism (`necessary-tractarianism-r`), Ordinary Comprehension (`ordinary-comprehension-r`), Persistent Comprehension (`persistent-comprehension-r`), Plenitude (`plenitude-r`), B for pure sentences (`pure-b-r`), Rigid Comprehension (`rigid-comprehension-r`), Tractarianism (`tractarianism-r`)
- Refuted (a model satisfies the package and violates these): Extensionality (`extensionality-r`), Fregean Axiom (`fregean-axiom`), Functional Choice (`functional-choice-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), □Extensionality (`necessary-extensionality-r`), □Fregean Axiom (`necessary-fregean-axiom`), Relational Choice (`relational-choice-r`)
- Open: All individuals fundamental (`all-individuals-fundamental`), Converse Witnessed Possibility (`converse-witnessed-possibility-r`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Logical Necessity (`logical-necessity-r`), No Pure Contingency (`no-pure-contingency-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

#### □ND + □Boolean Completeness

Assumes: `necessary-distinctness-necessary-r`, `necessary-boolean-completeness-r`.

- Rules out (entails their negations): Atomlessness (`atomlessness`), Distinctness (pure) (`distinctness-schema-r`), Distinctness (signature Σ) (`distinctness-signature-r`), Fundamental Possibility (`fundamental-possibility-r`), Possibility+ (`possibility-plus-r`), Possibility (pure) (`possibility-schema-r`), Possibility (signature Σ) (`possibility-signature-r`), Strong Possibility (pure) (`strong-possibility-r`), Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Entails: Actual Profile (`actual-profile-r`), Actuality (`actuality`), Atomicity (`atomicity-r`), Atomicity (type t) (`atomicity-t`), BF (`barcan-r`), BF (type t) (`barcan-t`), Boolean Completeness (`boolean-completeness-r`), Boolean Completeness (type t) (`boolean-completeness-t`), Broad Necessitism (`broad-necessitism-r`), CBF (`converse-barcan-r`), ND (`distinctness-necessary-r`), ND (type t) (`distinctness-necessary-t`), Existence (`existence-r`), Functionality (`functionality-r`), NI (`identity-necessary-r`), Inextensible Comprehension (`inextensible-comprehension-r`), Intensionality (`intensionality-r`), B (`modal-b`), 5 (`modal-five`), 4 (`modal-four`), K (`modal-k`), T (`modal-t`), Modalized Fregean Axiom (`modalized-fregean`), Modalized Functionality (`modalized-functionality-r`), □Actuality (`necessary-actuality`), □Atomicity (`necessary-atomicity-r`), □BF (`necessary-barcan-r`), □BF (type t) (`necessary-barcan-t`), □ND (type t) (`necessary-distinctness-necessary-t`), □Functionality (`necessary-functionality-r`), □B (`necessary-modal-b`), □5 (`necessary-modal-five`), □Plenitude (`necessary-plenitude-r`), □Rigid Comprehension (`necessary-rigid-comprehension-r`), □Tractarianism (`necessary-tractarianism-r`), Ordinary Comprehension (`ordinary-comprehension-r`), Persistent Comprehension (`persistent-comprehension-r`), Plenitude (`plenitude-r`), B for pure sentences (`pure-b-r`), Rigid Comprehension (`rigid-comprehension-r`), Tractarianism (`tractarianism-r`)
- Refuted (a model satisfies the package and violates these): Extensionality (`extensionality-r`), Fregean Axiom (`fregean-axiom`), Functional Choice (`functional-choice-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), □Extensionality (`necessary-extensionality-r`), □Fregean Axiom (`necessary-fregean-axiom`), Relational Choice (`relational-choice-r`)
- Open: All individuals fundamental (`all-individuals-fundamental`), Converse Witnessed Possibility (`converse-witnessed-possibility-r`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Logical Necessity (`logical-necessity-r`), No Pure Contingency (`no-pure-contingency-r`), Separated Structure (`separated-structure-r`), Witnessed Possibility (`witnessed-possibility-r`)

#### Possibility (pure) + No Pure Contingency

Assumes: `possibility-schema-r`, `no-pure-contingency-r`.

**Inconsistent:** these premises imply False via possibility-and-no-pure-contingency-incompatible. No consequences by explosion are listed.

#### Witnessed Possibility + No Pure Contingency

Assumes: `witnessed-possibility-r`, `no-pure-contingency-r`.

- Rules out (entails their negations): Distinctness (pure) (`distinctness-schema-r`), Distinctness (signature Σ) (`distinctness-signature-r`), Fundamental Possibility (`fundamental-possibility-r`), Possibility+ (`possibility-plus-r`), Possibility (pure) (`possibility-schema-r`), Possibility (signature Σ) (`possibility-signature-r`), Strong Possibility (pure) (`strong-possibility-r`), Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Entails: Broad Necessitism (`broad-necessitism-r`), CBF (`converse-barcan-r`), Converse Witnessed Possibility (`converse-witnessed-possibility-r`), Existence (`existence-r`), NI (`identity-necessary-r`), Intensionality (`intensionality-r`), Logical Necessity (`logical-necessity-r`), 4 (`modal-four`), K (`modal-k`), T (`modal-t`), Modalized Fregean Axiom (`modalized-fregean`), Modalized Functionality (`modalized-functionality-r`), Ordinary Comprehension (`ordinary-comprehension-r`), B for pure sentences (`pure-b-r`)
- Refuted (a model satisfies the package and violates these): nothing
- Open: Actual Profile (`actual-profile-r`), Actuality (`actuality`), All individuals fundamental (`all-individuals-fundamental`), Atomicity (`atomicity-r`), Atomicity (type t) (`atomicity-t`), Atomlessness (`atomlessness`), BF (`barcan-r`), BF (type t) (`barcan-t`), Boolean Completeness (`boolean-completeness-r`), Boolean Completeness (type t) (`boolean-completeness-t`), ND (`distinctness-necessary-r`), ND (type t) (`distinctness-necessary-t`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Extensionality (`extensionality-r`), Fregean Axiom (`fregean-axiom`), Functional Choice (`functional-choice-r`), Functionality (`functionality-r`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Inextensible Comprehension (`inextensible-comprehension-r`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`), B (`modal-b`), 5 (`modal-five`), □Actuality (`necessary-actuality`), □Atomicity (`necessary-atomicity-r`), □BF (`necessary-barcan-r`), □BF (type t) (`necessary-barcan-t`), □Boolean Completeness (`necessary-boolean-completeness-r`), □ND (`necessary-distinctness-necessary-r`), □ND (type t) (`necessary-distinctness-necessary-t`), □Extensionality (`necessary-extensionality-r`), □Fregean Axiom (`necessary-fregean-axiom`), □Functionality (`necessary-functionality-r`), □B (`necessary-modal-b`), □5 (`necessary-modal-five`), □Plenitude (`necessary-plenitude-r`), □Rigid Comprehension (`necessary-rigid-comprehension-r`), □Tractarianism (`necessary-tractarianism-r`), Persistent Comprehension (`persistent-comprehension-r`), Plenitude (`plenitude-r`), Relational Choice (`relational-choice-r`), Rigid Comprehension (`rigid-comprehension-r`), Separated Structure (`separated-structure-r`), Tractarianism (`tractarianism-r`)

#### Relational Choice + Plenitude

Assumes: `relational-choice-r`, `plenitude-r`.

- Rules out (entails their negations): Distinctness (pure) (`distinctness-schema-r`), Distinctness (signature Σ) (`distinctness-signature-r`), Fundamental Possibility (`fundamental-possibility-r`), Possibility+ (`possibility-plus-r`), Possibility (pure) (`possibility-schema-r`), Possibility (signature Σ) (`possibility-signature-r`), Strong Possibility (pure) (`strong-possibility-r`), Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Entails: Actual Profile (`actual-profile-r`), Actuality (`actuality`), Broad Necessitism (`broad-necessitism-r`), CBF (`converse-barcan-r`), ND (`distinctness-necessary-r`), ND (type t) (`distinctness-necessary-t`), Existence (`existence-r`), Functional Choice (`functional-choice-r`), NI (`identity-necessary-r`), Inextensible Comprehension (`inextensible-comprehension-r`), Intensionality (`intensionality-r`), B (`modal-b`), 5 (`modal-five`), 4 (`modal-four`), K (`modal-k`), T (`modal-t`), Modalized Fregean Axiom (`modalized-fregean`), Modalized Functionality (`modalized-functionality-r`), Ordinary Comprehension (`ordinary-comprehension-r`), Persistent Comprehension (`persistent-comprehension-r`), B for pure sentences (`pure-b-r`)
- Refuted (a model satisfies the package and violates these): Atomlessness (`atomlessness`), Infinity (type e) (`infinity-e`), Infinity (type t) (`infinity-t`)
- Open: All individuals fundamental (`all-individuals-fundamental`), Atomicity (`atomicity-r`), Atomicity (type t) (`atomicity-t`), BF (`barcan-r`), BF (type t) (`barcan-t`), Boolean Completeness (`boolean-completeness-r`), Boolean Completeness (type t) (`boolean-completeness-t`), Converse Witnessed Possibility (`converse-witnessed-possibility-r`), Distinctness-preserving collapse (`distinctness-preserving-collapse`), Extensionality (`extensionality-r`), Fregean Axiom (`fregean-axiom`), Functionality (`functionality-r`), Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`), Logical Necessity (`logical-necessity-r`), □Actuality (`necessary-actuality`), □Atomicity (`necessary-atomicity-r`), □BF (`necessary-barcan-r`), □BF (type t) (`necessary-barcan-t`), □Boolean Completeness (`necessary-boolean-completeness-r`), □ND (`necessary-distinctness-necessary-r`), □ND (type t) (`necessary-distinctness-necessary-t`), □Extensionality (`necessary-extensionality-r`), □Fregean Axiom (`necessary-fregean-axiom`), □Functionality (`necessary-functionality-r`), □B (`necessary-modal-b`), □5 (`necessary-modal-five`), □Plenitude (`necessary-plenitude-r`), □Rigid Comprehension (`necessary-rigid-comprehension-r`), □Tractarianism (`necessary-tractarianism-r`), No Pure Contingency (`no-pure-contingency-r`), Rigid Comprehension (`rigid-comprehension-r`), Separated Structure (`separated-structure-r`), Tractarianism (`tractarianism-r`), Witnessed Possibility (`witnessed-possibility-r`)

## Literature

### Source literature

- Bacon, Andrew, and Cian Dorr. Classicism. Draft dated 16 May 2023, 87 pages. All page, proposition and footnote locators in this map refer to this draft.
- Barcan, Ruth C. (1946). A Functional Calculus of First Order Based on Strict Implication. Journal of Symbolic Logic 11, 1–16. Bibliography and attribution as given in Classicism.
- Prior, A. N. (1963). Formal Logic. Oxford University Press. Pages 206–207, as credited in Classicism, Proposition 2.2.
- Prior, A. N. (1956). Modality and Quantification in S5. Journal of Symbolic Logic 21(1), 60–62. See also Prior (1967), Past, Present, and Future, p. 146, crediting E. J. Lemmon’s simplified proof. Attribution as given in Classicism, Proposition 2.3.
- Gallin, Daniel (1975). Intensional and Higher-Order Modal Logic: With Applications to Montague Semantics. North-Holland. Page 77, as cited in Classicism, n. 37.
- Bacon, Andrew (2020). Logical Combinatorialism. Philosophical Review 129(4), 537–589. As cited in Classicism, §§2.5 and 3.5.
- Goodsell, Zachary, and Juhani Yli-Vakkuri. Logical Foundations of Philosophy. Unpublished work cited in Classicism, p. 27; no proof from that work is imported here.

### Other relevant literature

- Bacon, Andrew (2018). The Broadest Necessity. Journal of Philosophical Logic 47(5), 733–783. As credited in Classicism, §1.5.
- Burgess, John P. (2014). On a Derivation of the Necessity of Identity. Synthese 191(7). Historical reference for Quine’s argument, as cited in Classicism, §1.5.
- Goodsell, Zachary. Personal communication reported by Bacon and Dorr in Classicism, p. 41, concerning Rigid Comprehension and Maximalist Classicism.


## 8. Where this came from

The paper catalogue is `topics/classicism/papers.yaml`; any included source documents are in `topics/classicism/sources/`. The extraction log, with transcription decisions and deliberately deferred items, is `topics/classicism/extraction.md`. Read it before trusting any single page reference.
