# Open questions — Classicism [Draft]

Recorded conjectures, their current answers, and remaining gaps where a new result or model would contribute to the map.

**"Open" means not settled by the records in this bundle.** It does not mean unsolved in the literature, and it does not mean hard. Many entries below are routine and simply have not been added yet. Check the sources before assuming a question is new.

## 1. Recorded conjectures and their answers

Answers below are recomputed from proved records under the fixed topic background. A conjectured record supplies no evidence for its own answer. Records marked was_conjectured remain in this history after promotion to proved; their proved status, rather than the historical marker, determines whether they supply evidence. Original sources and notes are retained below each answer.

### 1.1 Unresolved (4)

#### □ND ∧ Atomicity ⇒ No Pure Contingency — `c5-and-atomicity-imply-no-pure-contingency`

**Answer: Open.**

Original record notes:

Reported by the source as a theorem; conjectured is the map’s pending-verification status, not the source authors’ classification.

Source report / verification needed: The source attributes this theorem to Goodsell and Yli-Vakkuri (unpublished) but does not reproduce a proof. Obtain and check that proof for the source schema before promoting this record.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, p. 27.

Record: `topics/classicism/results/c5-and-atomicity-imply-no-pure-contingency.yaml`.

#### Possible Infinity (type e) ⇒ Axiom of Infinity (type e) — `possible-infinity-e-implies-axiom-of-infinity-e`

**Answer: Open.**

Original record notes:

Equivalent to the claim that a finite count of individuals is necessary whenever it is true. It holds with No Pure Contingency and with BF, by the recorded results. A countermodel would need a world with finitely many individuals that can see one with more, and must violate both BF at type $e$ and No Pure Contingency; the coalesced sums on the map do not supply one, since their roots have infinitely many individuals.

- **Dorr 20 Sep** — Cian Dorr, question of 20 September 2026.

Record: `topics/classicism/results/possible-infinity-e-implies-axiom-of-infinity-e.yaml`.

#### Possible Infinity (type t) ⇒ Axiom of Infinity (type t) — `possible-infinity-t-implies-axiom-of-infinity-t`

**Answer: Open.**

Original record notes:

Equivalent to the claim that a finite count of propositions is necessary whenever it is true. It holds with No Pure Contingency and with BF (type $t$), by the recorded results. If some finite $Z$ holds of $\lambda p\, .\,\top$ then every proposition is one of finitely many, and NI carries each identity across, but collecting them under a box is an instance of BF at type $t$, which C does not prove. A proof would need to bypass that; a countermodel would need a world with finitely many propositions that can see one with more, and must violate both BF (type $t$) and No Pure Contingency.

- **Dorr 20 Sep** — Cian Dorr, question of 20 September 2026.

Record: `topics/classicism/results/possible-infinity-t-implies-axiom-of-infinity-t.yaml`.

#### Coalesced sum: singleton individual root — `coalesced-single-individual-root`

**Answer: Open.**

Original record notes:

The source establishes the displayed package in the pure language. The topic also fixes nonlogical constants, including individual constants. An expansion of this particular singleton-root construction to that signature preserving the listed assertions still needs to be supplied; its conjectured status concerns only that expansion. See Appendix E, p. 83 for the distinction between a singleton root without individual constants and the alternative root indexed by individual constants.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, pp. 41–42 and n. 61; Appendix E, p. 83.

Record: `topics/classicism/models/coalesced-single-individual-root.yaml`.

### 1.2 Resolved (18)

#### Distinctness (pure) ∧ Rigid Comprehension ⇒ False (⊥) — `maximalist-distinctness-incompatible-with-rigid-comprehension`

**Answer: Proved.**

Supporting result ids: `maximalist-distinctness-incompatible-with-rigid-comprehension`.

Original record notes:

Recorded on 17 September 2026 as a reported theorem awaiting a supplied proof. The proof is now Goodsell's own, imported from Arithmetic is Necessary, and the record is derivable from the recorded chain through Boolean Completeness, Countable Boolean Completeness and the Necessity of Arithmetic.

- **Arithmetic is Necessary** — Zachary Goodsell, Arithmetic is Necessary, draft of 5 June 2024, §6, Theorem 11 and the remark following it, p. 25.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 41.

Record: `topics/classicism/results/maximalist-distinctness-incompatible-with-rigid-comprehension.yaml`.

#### Coalesced sum: maximalist root — `coalesced-maximalist-root`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `coalesced-maximalist-root`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Theorem 3.26, §§3.6, pp. 62–64; Appendix E, pp. 80–83; §2.6, p. 41.

Record: `topics/classicism/models/coalesced-maximalist-root.yaml`.

#### Finite-support action model: dyadic roundings of N — `finite-support-dyadic-roundings`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `rigid-comprehension-r-implies-boolean-completeness-r`.

Model witness ids: `finite-support-dyadic-roundings`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(7), pp. 74–75; construction p. 78, Part 7; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-dyadic-roundings.yaml`.

#### Finite-support action model: identity-or-collapse monotone surjections — `finite-support-identity-or-collapse-surjections`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `rigid-comprehension-r-implies-boolean-completeness-r`.

Model witness ids: `finite-support-identity-or-collapse-surjections`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(5), pp. 74–75; construction p. 78, Part 5; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-identity-or-collapse-surjections.yaml`.

#### Finite-support action model: identity-or-collapse monotone maps — `finite-support-identity-or-collapse`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `rigid-comprehension-r-implies-boolean-completeness-r`.

Model witness ids: `finite-support-identity-or-collapse`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(4), pp. 74–75; construction p. 78, Part 4; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-identity-or-collapse.yaml`.

#### Finite-support action model: monotone maps of N — `finite-support-monotone-maps`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-r-implies-atomicity-t`, `atomicity-t-incompatible-with-atomlessness`, `actuality-incompatible-with-atomlessness`, `rigid-comprehension-r-implies-actuality`.

Model witness ids: `finite-support-monotone-maps`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(3), pp. 74–75; construction p. 77; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-monotone-maps.yaml`.

#### Finite-support action model: monotone surjections of N — `finite-support-monotone-surjections`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-r-implies-atomicity-t`, `atomicity-t-incompatible-with-atomlessness`, `actuality-incompatible-with-atomlessness`, `rigid-comprehension-r-implies-actuality`.

Model witness ids: `finite-support-monotone-surjections`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(2), pp. 74–75; construction pp. 76–77; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-monotone-surjections.yaml`.

#### Finite-support action model: permutations of N — `finite-support-permutations`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-r-implies-atomicity-t`, `atomicity-t-incompatible-with-atomlessness`, `actuality-incompatible-with-atomlessness`, `c5-and-completeness-imply-actuality`, `rigid-comprehension-r-implies-actuality`.

Model witness ids: `finite-support-permutations`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(1), pp. 74–75; construction pp. 75–76; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-permutations.yaml`.

#### Finite-support action model: qualitative contrast — `finite-support-qualitative-contrast`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `c5-and-atomicity-imply-necessary-plenitude`, `necessary-plenitude-r-implies-necessary-actuality`.

Model witness ids: `finite-support-qualitative-contrast`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, final construction (two copies of N).

Record: `topics/classicism/models/finite-support-qualitative-contrast.yaml`.

#### Finite-support action model: truncated shifts of N — `finite-support-truncated-shifts`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `rigid-comprehension-r-implies-boolean-completeness-r`.

Model witness ids: `finite-support-truncated-shifts`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(8), pp. 74–75; construction pp. 78–79, Part 8; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-truncated-shifts.yaml`.

#### Finite-support action model: truncations of N — `finite-support-truncations`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-and-bf-imply-necessary-actuality`, `necessary-actuality-implies-actuality`, `rigid-comprehension-r-implies-actuality`.

Model witness ids: `finite-support-truncations`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(6), pp. 74–75; construction p. 78, Part 6; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-truncations.yaml`.

#### Finite-support action model: N and singleton, all maps — `finite-support-two-object-all-maps`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Model witness ids: `finite-support-two-object-all-maps`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, paragraph beginning “One particularly interesting result”.

Record: `topics/classicism/models/finite-support-two-object-all-maps.yaml`.

#### Full action model: idempotent two-arrow monoid — `full-idempotent-monoid`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t`, `necessary-distinctness-necessary-t-implies-distinctness-necessary-t`.

Model witness ids: `full-idempotent-monoid`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, first paragraph; p. 61 (full-model principles).

Record: `topics/classicism/models/full-idempotent-monoid.yaml`.

#### Full action model: two-element group — `full-involution-group`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Model witness ids: `full-involution-group`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, second paragraph; p. 61.

Record: `topics/classicism/models/full-involution-group.yaml`.

#### Full action model: surjections of an infinite set — `full-surjection-monoid`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Model witness ids: `full-surjection-monoid`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: two-object chain — `full-two-object-chain`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Model witness ids: `full-two-object-chain`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fourth paragraph; p. 61.

Record: `topics/classicism/models/full-two-object-chain.yaml`.

#### Full action model: two-object retract — `full-two-object-retract`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `no-pure-contingency-and-nd-t-imply-necessary-nd-t`.

Model witness ids: `full-two-object-retract`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fifth paragraph and n. 81; p. 61.

Record: `topics/classicism/models/full-two-object-retract.yaml`.

#### Henkin model: base without a choice function — `henkin-without-relational-choice`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Model witness ids: `henkin-without-relational-choice`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, n. 46, p. 32.

Record: `topics/classicism/models/henkin-without-relational-choice.yaml`.

### 1.3 Incompatible with background (0)

None.

## 2. Lynchpin conjectures

Answering a lynchpin conjecture settles many other open questions. A question is S ⇒ c for S at most two principle classes (True, with none) and c a class or False, asked only where no smaller premise set already proves or excludes c; S ⇒ False asks whether S is consistent. A question is settled alike by a proof, by an exclusion (S ∧ c ⇒ False) or by a recorded model that holds S and fails c. Each row scores an open question by the number of *other* open questions that stop being open once the answer joins the proved records. Both answers are scored, because proving a strong conjecture settles everything below it while refuting a weak one settles everything above it; a question with two high scores is worth answering either way. A refutation is scored by its least informative countermodel, so an actual model settles at least as much. A model check (model: principle) scores deciding an unknown verdict inside a recorded model, which settles questions exactly as a proof does. Under a background, only models of that background count and the class of its theorems is named after it (True, with no preset). Recompute with `python3 scripts/pmap.py lynchpins classicism`.

### Under no extra assumptions

45 classes and 26 fitting models; 9426 open questions. 57% of questions with up to two premises settled (13015 of 22441).

| Question | if yes | if no |
|---|---:|---:|
| Witnessed Possibility ⇒ Strong Possibility (signature Σ) | 1379 | 0 |
| Witnessed Possibility ⇒ Possibility+ | 1357 | 0 |
| Witnessed Possibility ⇒ Distinctness (signature Σ) | 1325 | 1 |
| Witnessed Possibility ⇒ Distinctness (pure) | 1281 | 3 |
| True (⊤) ⇒ Distinctness-preserving collapse | 1227 | 0 |

### Under C5

27 classes and 6 fitting models; 664 open questions. 48% of questions with up to two premises settled (624 of 1288).

| Question | if yes | if no |
|---|---:|---:|
| Distinctness-preserving collapse ⇒ Extensionality | 185 | 0 |
| True (⊤) ⇒ Distinctness-preserving collapse | 153 | 0 |
| Relational Choice ⇒ Atomicity | 145 | 0 |
| Distinctness-preserving collapse ⇒ Functional Choice | 131 | 0 |
| Distinctness-preserving collapse ⇒ Atomicity | 126 | 1 |

### Under C5 + Atomicity

20 classes and 4 fitting models; 117 open questions. 47% of questions with up to two premises settled (107 of 224).

| Question | if yes | if no |
|---|---:|---:|
| Infinity Schema (type t) ⇒ False (⊥) | 65 | 0 |
| Infinity Schema (type e) ⇒ Extensionality | 49 | 0 |
| Infinity Schema (type e) ∧ Infinity Schema (type t) ⇒ False (⊥) | 35 | 2 |
| Axiom of Infinity (type t) ⇒ False (⊥) | 35 | 1 |
| Distinctness-preserving collapse ⇒ Extensionality | 33 | 0 |

### Under Extensionalism

19 classes and 3 fitting models; 14 open questions. 77% of questions with up to two premises settled (47 of 61).

| Question | if yes | if no |
|---|---:|---:|
| True (⊤) ⇒ Distinctness-preserving collapse | 6 | 0 |
| Axiom of Infinity (type e) ∧ Functional Choice ⇒ Distinctness-preserving collapse | 0 | 5 |
| Axiom of Infinity (type e) ∧ Distinctness-preserving collapse ⇒ Functional Choice | 0 | 4 |
| Functional Choice ∧ Infinity Schema (type e) ⇒ Distinctness-preserving collapse | 1 | 3 |
| Infinity Schema (type e) ⇒ Distinctness-preserving collapse | 3 | 1 |

### Under Pure Maximalist Classicism

53 classes and 1 fitting models; 2838 open questions. 4% of questions with up to two premises settled (128 of 2966).

| Question | if yes | if no |
|---|---:|---:|
| True (⊤) ⇒ BF | 1234 | 0 |
| BF (type t) ⇒ False (⊥) | 1101 | 0 |
| Infinity Schema (type e) ⇒ False (⊥) | 1101 | 0 |
| True (⊤) ⇒ Atomicity | 873 | 0 |
| True (⊤) ⇒ Atomicity (type t) | 730 | 1 |

## 3. Open questions under each recorded package

The most useful place to work: these are open *given* assumptions the sources already make.

### C5

Assuming `necessary-distinctness-necessary-r`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### C5 + Atomicity

Assuming `necessary-distinctness-necessary-r`, `atomicity-r`, these remain open:

- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- No Pure Contingency (`no-pure-contingency-r`)

### Extensionalism

Assuming `extensionality-r`, these remain open:

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)

### Pure Maximalist Classicism

Assuming `distinctness-schema-r`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Distinctness (signature Σ) (`distinctness-signature-r`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- □BF (type t) (`necessary-barcan-t`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Possibility+ (`possibility-plus-r`)
- Possibility (signature Σ) (`possibility-signature-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Tractarianism (`tractarianism-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### □Atomicity + Boolean Completeness + BF

Assuming `necessary-atomicity-r`, `boolean-completeness-r`, `barcan-r`, these remain open:

- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- B for pure sentences (`pure-b-r`)

### Boolean Completeness + Actuality

Assuming `boolean-completeness-r`, `actuality`, these remain open:

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- B for pure sentences (`pure-b-r`)

### □ND + Actuality

Assuming `necessary-distinctness-necessary-r`, `actuality`, these remain open:

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)

### No Pure Contingency + Actuality

Assuming `no-pure-contingency-r`, `actuality`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)

### Atomicity + BF

Assuming `atomicity-r`, `barcan-r`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- No Pure Contingency (`no-pure-contingency-r`)
- B for pure sentences (`pure-b-r`)

### No Pure Contingency + Atomicity

Assuming `no-pure-contingency-r`, `atomicity-r`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)

### Atomicity (type t) + BF

Assuming `atomicity-t`, `barcan-r`, these remain open:

- Atomicity (`atomicity-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- No Pure Contingency (`no-pure-contingency-r`)
- B for pure sentences (`pure-b-r`)

### ND + BF

Assuming `distinctness-necessary-r`, `barcan-r`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### Gallin Extensional Comprehension + BF

Assuming `gallin-extensional-comprehension-r`, `barcan-r`, these remain open:

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)

### No Pure Contingency + BF

Assuming `no-pure-contingency-r`, `barcan-r`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)

### Possible Infinity (type e) + BF

Assuming `possible-infinity-e`, `barcan-r`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □BF (type t) (`necessary-barcan-t`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)

### Rigid Comprehension + BF

Assuming `rigid-comprehension-r`, `barcan-r`, these remain open:

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- B for pure sentences (`pure-b-r`)

### No Pure Contingency + BF (type t)

Assuming `no-pure-contingency-r`, `barcan-t`, these remain open:

- BF (`barcan-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □BF (`necessary-barcan-r`)
- □Functionality (`necessary-functionality-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Tractarianism (`tractarianism-r`)

### Possible Infinity (type t) + BF (type t)

Assuming `possible-infinity-t`, `barcan-t`, these remain open:

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- BF (`barcan-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- □BF (type t) (`necessary-barcan-t`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Possible Infinity (type e) (`possible-infinity-e`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Tractarianism (`tractarianism-r`)

### □ND + Boolean Completeness

Assuming `necessary-distinctness-necessary-r`, `boolean-completeness-r`, these remain open:

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)

### No Pure Contingency + Boolean Completeness

Assuming `no-pure-contingency-r`, `boolean-completeness-r`, these remain open:

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)

### No Pure Contingency + ND

Assuming `no-pure-contingency-r`, `distinctness-necessary-r`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)

### Rigid Comprehension + ND

Assuming `rigid-comprehension-r`, `distinctness-necessary-r`, these remain open:

- BF (type t) (`barcan-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- □BF (type t) (`necessary-barcan-t`)

### No Pure Contingency + ND (type t)

Assuming `no-pure-contingency-r`, `distinctness-necessary-t`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)

### Distinctness (pure) + Separated Structure

Assuming `distinctness-schema-r`, `separated-structure-r`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- □BF (type t) (`necessary-barcan-t`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Possibility+ (`possibility-plus-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Tractarianism (`tractarianism-r`)

### No Pure Contingency + Extensionality

Assuming `no-pure-contingency-r`, `extensionality-r`, these remain open:

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)

### No Pure Contingency + Fregean Axiom

Assuming `no-pure-contingency-r`, `fregean-axiom`, these remain open:

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)

### No Pure Contingency + Functionality

Assuming `no-pure-contingency-r`, `functionality-r`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)

### No Pure Contingency + Gallin Extensional Comprehension

Assuming `no-pure-contingency-r`, `gallin-extensional-comprehension-r`, these remain open:

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)

### No Pure Contingency + B

Assuming `no-pure-contingency-r`, `modal-b`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)

### No Pure Contingency + 5

Assuming `no-pure-contingency-r`, `modal-five`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)

### □ND + □Actuality

Assuming `necessary-distinctness-necessary-r`, `necessary-actuality`, these remain open:

- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- No Pure Contingency (`no-pure-contingency-r`)

### □ND + □Boolean Completeness

Assuming `necessary-distinctness-necessary-r`, `necessary-boolean-completeness-r`, these remain open:

- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- No Pure Contingency (`no-pure-contingency-r`)

### □ND + □Rigid Comprehension

Assuming `necessary-distinctness-necessary-r`, `necessary-rigid-comprehension-r`, these remain open:

- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- No Pure Contingency (`no-pure-contingency-r`)

### □ND + Persistent Comprehension

Assuming `necessary-distinctness-necessary-r`, `persistent-comprehension-r`, these remain open:

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)

### No Pure Contingency + Plenitude

Assuming `no-pure-contingency-r`, `plenitude-r`, these remain open:

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)

### Possible Infinity (type e) + No Pure Contingency

Assuming `possible-infinity-e`, `no-pure-contingency-r`, these remain open:

- BF (type t) (`barcan-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □BF (type t) (`necessary-barcan-t`)
- Relational Choice (`relational-choice-r`)

### Possible Infinity (type t) + No Pure Contingency

Assuming `possible-infinity-t`, `no-pure-contingency-r`, these remain open:

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- □BF (type t) (`necessary-barcan-t`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Relational Choice (`relational-choice-r`)

### No Pure Contingency + Rigid Comprehension

Assuming `no-pure-contingency-r`, `rigid-comprehension-r`, these remain open:

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)

### No Pure Contingency + Tractarianism

Assuming `no-pure-contingency-r`, `tractarianism-r`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)

### Witnessed Possibility + No Pure Contingency

Assuming `witnessed-possibility-r`, `no-pure-contingency-r`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Atomlessness (`atomlessness`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- Infinity Schema (type t) (`infinity-t`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Functionality (`necessary-functionality-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)
- Relational Choice (`relational-choice-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Separated Structure (`separated-structure-r`)
- Tractarianism (`tractarianism-r`)
- Very Weak Rigid Comprehension (`very-weak-rigid-comprehension-r`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)

### Relational Choice + Plenitude

Assuming `relational-choice-r`, `plenitude-r`, these remain open:

- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Very Weak Rigid Comprehension (`very-weak-rigid-comprehension-r`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)

## 4. Unknown verdicts inside each model

For these principles the model has not been checked either way. Deciding one is a self-contained calculation in a construction that is already written down.

### Coalesced sum: root over all finite individual domains — `coalesced-all-finite-individual-domains`

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Atomlessness (`atomlessness`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Distinctness (pure) (`distinctness-schema-r`)
- Distinctness (signature Σ) (`distinctness-signature-r`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Logical Necessity (`logical-necessity-r`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Functionality (`necessary-functionality-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- No Pure Contingency (`no-pure-contingency-r`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Possibility+ (`possibility-plus-r`)
- Possibility (pure) (`possibility-schema-r`)
- Possibility (signature Σ) (`possibility-signature-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Separated Structure (`separated-structure-r`)
- Strong Possibility (pure) (`strong-possibility-r`)
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Tractarianism (`tractarianism-r`)
- Very Weak Rigid Comprehension (`very-weak-rigid-comprehension-r`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Coalesced sum: maximalist root — `coalesced-maximalist-root`

- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Functionality (`functionality-r`)
- Infinity Schema (type e) (`infinity-e`)
- □BF (type t) (`necessary-barcan-t`)
- Possibility+ (`possibility-plus-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Tractarianism (`tractarianism-r`)

### Coalesced sum: singleton individual root — `coalesced-single-individual-root`

Fully determined; nothing unknown.

### Finite-support action model: dyadic roundings of N — `finite-support-dyadic-roundings`

- BF (type t) (`barcan-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Logical Necessity (`logical-necessity-r`)
- □BF (type t) (`necessary-barcan-t`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: identity-or-collapse monotone surjections — `finite-support-identity-or-collapse-surjections`

- Atomicity (type t) (`atomicity-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Logical Necessity (`logical-necessity-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: identity-or-collapse monotone maps — `finite-support-identity-or-collapse`

- Atomicity (type t) (`atomicity-t`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Logical Necessity (`logical-necessity-r`)
- □BF (type t) (`necessary-barcan-t`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: monotone maps of N — `finite-support-monotone-maps`

- BF (type t) (`barcan-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Logical Necessity (`logical-necessity-r`)
- □BF (type t) (`necessary-barcan-t`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: monotone surjections of N — `finite-support-monotone-surjections`

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Logical Necessity (`logical-necessity-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: permutations of N — `finite-support-permutations`

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Relational Choice (`relational-choice-r`)

### Finite-support action model: qualitative contrast — `finite-support-qualitative-contrast`

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Functional Choice (`functional-choice-r`)
- Relational Choice (`relational-choice-r`)

### Finite-support action model: truncated shifts of N — `finite-support-truncated-shifts`

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Logical Necessity (`logical-necessity-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: truncations of N — `finite-support-truncations`

- BF (type t) (`barcan-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Logical Necessity (`logical-necessity-r`)
- □BF (type t) (`necessary-barcan-t`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: N and singleton, all maps — `finite-support-two-object-all-maps`

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Distinctness (pure) (`distinctness-schema-r`)
- Distinctness (signature Σ) (`distinctness-signature-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Possibility+ (`possibility-plus-r`)
- Possibility (pure) (`possibility-schema-r`)
- Possibility (signature Σ) (`possibility-signature-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Strong Possibility (pure) (`strong-possibility-r`)
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Very Weak Rigid Comprehension (`very-weak-rigid-comprehension-r`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Full Henkin model: countably infinite individual domain — `full-henkin-infinite-base`

Fully determined; nothing unknown.

### Full Henkin model: singleton individual domain — `full-henkin-singleton-base`

Fully determined; nothing unknown.

### Full action model: idempotent two-arrow monoid — `full-idempotent-monoid`

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Infinity Schema (type e) (`infinity-e`)
- Logical Necessity (`logical-necessity-r`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Full action model: two-element group — `full-involution-group`

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Infinity Schema (type e) (`infinity-e`)
- Possible Infinity (type e) (`possible-infinity-e`)

### Full action model: surjections of an infinite set — `full-surjection-monoid`

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Logical Necessity (`logical-necessity-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Full action model: two-object chain — `full-two-object-chain`

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- ND (`distinctness-necessary-r`)
- ND (type t) (`distinctness-necessary-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Functional Choice (`functional-choice-r`)
- Functionality (`functionality-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- B (`modal-b`)
- 5 (`modal-five`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □ND (`necessary-distinctness-necessary-r`)
- □ND (type t) (`necessary-distinctness-necessary-t`)
- □Functionality (`necessary-functionality-r`)
- □Gallin Extensional Comprehension (`necessary-gallin-extensional-comprehension-r`)
- □B (`necessary-modal-b`)
- □5 (`necessary-modal-five`)
- □Plenitude (`necessary-plenitude-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Plenitude (`plenitude-r`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)
- B for pure sentences (`pure-b-r`)
- Separated Structure (`separated-structure-r`)
- Tractarianism (`tractarianism-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Full action model: two-object retract — `full-two-object-retract`

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- BF (type t) (`barcan-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- Infinity Schema (type t) (`infinity-t`)
- □BF (type t) (`necessary-barcan-t`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)

### Henkin model: base without a choice function — `henkin-without-relational-choice`

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Infinity Schema (type e) (`infinity-e`)
- Possible Infinity (type e) (`possible-infinity-e`)

### Symmetric ideally-full model: all surjections of N (Base 1) — `symmetric-all-surjections`

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Logical Necessity (`logical-necessity-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Symmetric ideally-full model: permutations and collapsers of a fixed pair (Base 2) — `symmetric-collapse-pair`

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Logical Necessity (`logical-necessity-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Symmetric ideally-full model: qualitative link structure (Base 3) — `symmetric-qualitative-links`

- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Functionality (`functionality-r`)
- Logical Necessity (`logical-necessity-r`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Tractarianism (`tractarianism-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Symmetric ideally-full model: arrows omitting or reserving a fixed individual — `symmetric-range-gap-without-actuality`

- BF (type t) (`barcan-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Logical Necessity (`logical-necessity-r`)
- □BF (type t) (`necessary-barcan-t`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Symmetric ideally-full model: arrows omitting a fixed individual — `symmetric-range-gap`

- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- BF (type t) (`barcan-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Logical Necessity (`logical-necessity-r`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Symmetric ideally-full model: two objects, the second unpinned — `symmetric-two-object-unpinned`

- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Functionality (`functionality-r`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (type t) (`necessary-barcan-t`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Tractarianism (`tractarianism-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

## 5. Open single-premise pairs (652)

*A ⇒ B ?* means neither implication nor incompatibility nor a countermodel is currently recorded. Grouped by antecedent. Most are open only because the obvious model has not been added.

- **4** (`modal-four`) ⇒ B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension
- **5** (`modal-five`) ⇒ BF (type t), Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic, □BF (type t)
- **Actual Profile** (`actual-profile-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse
- **Actuality** (`actuality`) ⇒ B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse
- **Atomicity** (`atomicity-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic, □Atomicity
- **Atomicity (type t)** (`atomicity-t`) ⇒ Atomicity, B for pure sentences, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic, □Atomicity
- **Atomlessness** (`atomlessness`) ⇒ Axiom of Infinity (type e), B for pure sentences, BF (type t), Boolean Completeness (type t), Converse Witnessed Possibility, Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type e), Necessity of Arithmetic, No Pure Contingency, Possible Infinity (type e), Relational Choice, □BF (type t)
- **Axiom of Infinity (type e)** (`axiom-of-infinity-e`) ⇒ B for pure sentences, BF (type t), Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic, Relational Choice, □BF (type t)
- **Axiom of Infinity (type t)** (`axiom-of-infinity-t`) ⇒ Axiom of Infinity (type e), B for pure sentences, BF (type t), Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type e), Possible Infinity (type e), Relational Choice, □BF (type t)
- **B** (`modal-b`) ⇒ BF (type t), Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic, □BF (type t)
- **B for pure sentences** (`pure-b-r`) ⇒ Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic
- **BF** (`barcan-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic, □BF (type t)
- **BF (type t)** (`barcan-t`) ⇒ B for pure sentences, BF, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Functionality, Inextensible Comprehension, Necessity of Arithmetic, Tractarianism, □BF (type t)
- **Boolean Completeness** (`boolean-completeness-r`) ⇒ B for pure sentences, Distinctness-preserving collapse, Inextensible Comprehension
- **Boolean Completeness (type t)** (`boolean-completeness-t`) ⇒ B for pure sentences, Boolean Completeness, Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic
- **Broad Necessitism** (`broad-necessitism-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension
- **CBF** (`converse-barcan-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension
- **Converse Witnessed Possibility** (`converse-witnessed-possibility-r`) ⇒ Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension
- **Countable Boolean Completeness** (`countable-boolean-completeness-r`) ⇒ B for pure sentences, Boolean Completeness, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension
- **Distinctness (pure)** (`distinctness-schema-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Axiom of Infinity (type e), B for pure sentences, BF, BF (type t), Boolean Completeness (type t), Distinctness (signature Σ), Distinctness-preserving collapse, Functionality, Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Possibility (signature Σ), Possibility+, Relational Choice, Separated Structure, Strong Possibility (signature Σ), Tractarianism, Witnessed Possibility, □BF (type t)
- **Distinctness (signature Σ)** (`distinctness-signature-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Axiom of Infinity (type e), B for pure sentences, BF, BF (type t), Boolean Completeness (type t), Distinctness-preserving collapse, Functionality, Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Possibility+, Relational Choice, Strong Possibility (signature Σ), Tractarianism, □BF (type t)
- **Distinctness-preserving collapse** (`distinctness-preserving-collapse`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), B for pure sentences, BF, BF (type t), Boolean Completeness (type t), Functionality, Inextensible Comprehension, Persistent Comprehension, Relational Choice, Tractarianism, □BF (type t)
- **Existence** (`existence-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension
- **Extensionality** (`extensionality-r`) ⇒ Distinctness-preserving collapse
- **Fregean Axiom** (`fregean-axiom`) ⇒ Distinctness-preserving collapse
- **Functional Choice** (`functional-choice-r`) ⇒ Atomicity, Atomicity (type t), BF (type t), Boolean Completeness, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Gallin Extensional Comprehension, Necessity of Arithmetic, Rigid Comprehension, Very Weak Rigid Comprehension, Weak Rigid Comprehension, □Actuality, □Atomicity, □BF (type t), □Boolean Completeness, □Rigid Comprehension
- **Functionality** (`functionality-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic, □BF (type t)
- **Gallin Extensional Comprehension** (`gallin-extensional-comprehension-r`) ⇒ Actual Profile, Actuality, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Functionality, Inextensible Comprehension, Necessity of Arithmetic, Persistent Comprehension, Plenitude, Rigid Comprehension, Tractarianism, Very Weak Rigid Comprehension, Weak Rigid Comprehension, □5, □B, □BF, □BF (type t), □Functionality, □ND, □ND (type t), □Tractarianism
- **Inextensible Comprehension** (`inextensible-comprehension-r`) ⇒ Actual Profile, Actuality, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Persistent Comprehension
- **Infinity Schema (type e)** (`infinity-e`) ⇒ Axiom of Infinity (type e), B for pure sentences, BF (type t), Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic, Possible Infinity (type e), Relational Choice, □BF (type t)
- **Infinity Schema (type t)** (`infinity-t`) ⇒ Axiom of Infinity (type e), Axiom of Infinity (type t), B for pure sentences, BF (type t), Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type e), Possible Infinity (type e), Possible Infinity (type t), Relational Choice, □BF (type t)
- **Intensionality** (`intensionality-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension
- **K** (`modal-k`) ⇒ B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension
- **Logical Necessity** (`logical-necessity-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Atomlessness, Axiom of Infinity (type e), Axiom of Infinity (type t), BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Functionality, Inextensible Comprehension, Infinity Schema (type e), Infinity Schema (type t), Persistent Comprehension, Possible Infinity (type e), Possible Infinity (type t), Relational Choice, Rigid Comprehension, Separated Structure, Tractarianism, Very Weak Rigid Comprehension, Weak Rigid Comprehension, □Actuality, □Atomicity, □BF, □BF (type t), □Boolean Completeness, □Functionality, □Rigid Comprehension, □Tractarianism
- **Modalized Fregean Axiom** (`modalized-fregean`) ⇒ B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension
- **Modalized Functionality** (`modalized-functionality-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension
- **ND** (`distinctness-necessary-r`) ⇒ BF (type t), Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic, □BF (type t)
- **ND (type t)** (`distinctness-necessary-t`) ⇒ BF (type t), Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic, □BF (type t)
- **NI** (`identity-necessary-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension
- **Necessity of Arithmetic** (`necessity-of-arithmetic`) ⇒ B for pure sentences, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension
- **No Pure Contingency** (`no-pure-contingency-r`) ⇒ Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension
- **Ordinary Comprehension** (`ordinary-comprehension-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension
- **Persistent Comprehension** (`persistent-comprehension-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse
- **Plenitude** (`plenitude-r`) ⇒ BF (type t), Boolean Completeness, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Gallin Extensional Comprehension, Necessity of Arithmetic, Rigid Comprehension, Very Weak Rigid Comprehension, Weak Rigid Comprehension, □BF (type t)
- **Possibility (pure)** (`possibility-schema-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Axiom of Infinity (type e), B for pure sentences, BF, BF (type t), Boolean Completeness (type t), Distinctness (signature Σ), Distinctness-preserving collapse, Functionality, Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Possibility (signature Σ), Possibility+, Relational Choice, Separated Structure, Strong Possibility (signature Σ), Tractarianism, Witnessed Possibility, □BF (type t)
- **Possibility (signature Σ)** (`possibility-signature-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Axiom of Infinity (type e), B for pure sentences, BF, BF (type t), Boolean Completeness (type t), Distinctness-preserving collapse, Functionality, Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Possibility+, Relational Choice, Strong Possibility (signature Σ), Tractarianism, □BF (type t)
- **Possibility+** (`possibility-plus-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Atomlessness, Axiom of Infinity (type e), B for pure sentences, BF, BF (type t), Boolean Completeness (type t), Distinctness (signature Σ), Distinctness-preserving collapse, Functionality, Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Possibility (signature Σ), Relational Choice, Separated Structure, Strong Possibility (pure), Strong Possibility (signature Σ), Tractarianism, Witnessed Possibility, □BF (type t)
- **Possible Infinity (type e)** (`possible-infinity-e`) ⇒ Axiom of Infinity (type e), B for pure sentences, BF (type t), Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type e), Relational Choice, □BF (type t)
- **Possible Infinity (type t)** (`possible-infinity-t`) ⇒ Axiom of Infinity (type e), Axiom of Infinity (type t), B for pure sentences, BF (type t), Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type e), Infinity Schema (type t), Possible Infinity (type e), Relational Choice, □BF (type t)
- **Relational Choice** (`relational-choice-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), B for pure sentences, Boolean Completeness, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic, Persistent Comprehension, Rigid Comprehension, Very Weak Rigid Comprehension, Weak Rigid Comprehension, □Actuality, □Atomicity, □Boolean Completeness, □Rigid Comprehension
- **Rigid Comprehension** (`rigid-comprehension-r`) ⇒ B for pure sentences, Distinctness-preserving collapse
- **Separated Structure** (`separated-structure-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Axiom of Infinity (type e), Axiom of Infinity (type t), B for pure sentences, BF, BF (type t), Boolean Completeness (type t), Distinctness (pure), Distinctness (signature Σ), Distinctness-preserving collapse, Functionality, Inextensible Comprehension, Infinity Schema (type e), Infinity Schema (type t), Persistent Comprehension, Possibility (pure), Possibility (signature Σ), Possibility+, Possible Infinity (type e), Possible Infinity (type t), Relational Choice, Strong Possibility (signature Σ), Tractarianism, Witnessed Possibility, □BF (type t)
- **Strong Possibility (pure)** (`strong-possibility-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Atomlessness, Axiom of Infinity (type e), B for pure sentences, BF, BF (type t), Boolean Completeness (type t), Distinctness (signature Σ), Distinctness-preserving collapse, Functionality, Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Possibility (signature Σ), Possibility+, Relational Choice, Separated Structure, Strong Possibility (signature Σ), Tractarianism, Witnessed Possibility, □BF (type t)
- **Strong Possibility (signature Σ)** (`strong-possibility-signature-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Atomlessness, Axiom of Infinity (type e), B for pure sentences, BF, BF (type t), Boolean Completeness (type t), Distinctness-preserving collapse, Functionality, Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Possibility+, Relational Choice, Strong Possibility (pure), Tractarianism, □BF (type t)
- **T** (`modal-t`) ⇒ B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension
- **Tractarianism** (`tractarianism-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic, □BF (type t)
- **Very Weak Rigid Comprehension** (`very-weak-rigid-comprehension-r`) ⇒ B for pure sentences, Distinctness-preserving collapse
- **Weak Rigid Comprehension** (`weak-rigid-comprehension-r`) ⇒ B for pure sentences, Distinctness-preserving collapse
- **Witnessed Possibility** (`witnessed-possibility-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Axiom of Infinity (type e), Axiom of Infinity (type t), B for pure sentences, BF, BF (type t), Boolean Completeness (type t), Distinctness (pure), Distinctness (signature Σ), Distinctness-preserving collapse, Functionality, Inextensible Comprehension, Infinity Schema (type e), Infinity Schema (type t), Persistent Comprehension, Possibility (pure), Possibility (signature Σ), Possibility+, Possible Infinity (type e), Possible Infinity (type t), Relational Choice, Separated Structure, Strong Possibility (signature Σ), Tractarianism, □BF (type t)
- **□5** (`necessary-modal-five`) ⇒ Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic
- **□Actuality** (`necessary-actuality`) ⇒ B for pure sentences, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Necessity of Arithmetic
- **□Atomicity** (`necessary-atomicity-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic
- **□B** (`necessary-modal-b`) ⇒ Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic
- **□BF** (`necessary-barcan-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic
- **□BF (type t)** (`necessary-barcan-t`) ⇒ B for pure sentences, BF, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Functionality, Inextensible Comprehension, Necessity of Arithmetic, Tractarianism, □BF, □Functionality, □Tractarianism
- **□Boolean Completeness** (`necessary-boolean-completeness-r`) ⇒ B for pure sentences, Distinctness-preserving collapse, Inextensible Comprehension
- **□Extensionality** (`necessary-extensionality-r`) ⇒ Distinctness-preserving collapse
- **□Fregean Axiom** (`necessary-fregean-axiom`) ⇒ Distinctness-preserving collapse
- **□Functionality** (`necessary-functionality-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic
- **□Gallin Extensional Comprehension** (`necessary-gallin-extensional-comprehension-r`) ⇒ Converse Witnessed Possibility, Distinctness-preserving collapse, No Pure Contingency
- **□ND** (`necessary-distinctness-necessary-r`) ⇒ Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic
- **□ND (type t)** (`necessary-distinctness-necessary-t`) ⇒ Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic
- **□Plenitude** (`necessary-plenitude-r`) ⇒ Converse Witnessed Possibility, Distinctness-preserving collapse, No Pure Contingency
- **□Rigid Comprehension** (`necessary-rigid-comprehension-r`) ⇒ B for pure sentences, Distinctness-preserving collapse
- **□Tractarianism** (`necessary-tractarianism-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Inextensible Comprehension, Necessity of Arithmetic

## 6. Deliberately deferred

`topics/classicism/extraction.md` has a section listing claims that were **not** recorded because they need a further reading of the sources. Those are marked deferred rather than open: the answer is likely in the literature and needs transcribing, not discovering. Read that section before starting work.

## 7. How to record an answer

- Proved an implication? Add `topics/classicism/results/<id>.yaml` with the full premise list and the proof.
- Refuted one? Add `topics/classicism/models/<id>.yaml` listing what you verified in `satisfies` and `violates`.
- Settling an existing conjecture? For a proof of the same statement, keep its ID, set `was_conjectured: true`, and change its status to `proved`. If the statement changes substantially, retain the original and add a separate record. Refuted proposals stay `status: conjectured`, with proved refuting evidence recorded separately. Answers under extra exploration assumptions are contextual, not global record statuses.
- Not sure? Add it with `status: conjectured`, an empty proof, and say in `notes` what would settle it.
- Then run `python3 scripts/pmap.py validate` and `status`. Never hand-edit the derived counts.

`README.md` has the exact record shapes and the sourcing rules. Follow them; an unsourced or misattributed record is worse than an absent one.
