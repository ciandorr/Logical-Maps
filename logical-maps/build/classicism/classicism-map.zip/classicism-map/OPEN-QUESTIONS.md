# Open questions — Classicism [Draft]

Recorded conjectures, their current answers, and remaining gaps where a new result or model would contribute to the map.

**"Open" means not settled by the records in this bundle.** It does not mean unsolved in the literature, and it does not mean hard. Many entries below are routine and simply have not been added yet. Check the sources before assuming a question is new.

## 1. Recorded conjectures and their answers

Answers below are recomputed from proved records under the fixed topic background. A conjectured record supplies no evidence for its own answer. Records marked was_conjectured remain in this history after promotion to proved; their proved status, rather than the historical marker, determines whether they supply evidence. Original sources and notes are retained below each answer.

### 1.1 Unresolved (3)

#### □ND ∧ Atomicity ⇒ No Pure Contingency — `c5-and-atomicity-imply-no-pure-contingency`

**Answer: Open.**

Original record notes:

Reported by the source as a theorem; conjectured is the map’s pending-verification status, not the source authors’ classification.

Source report / verification needed: The source attributes this theorem to Goodsell and Yli-Vakkuri (unpublished) but does not reproduce a proof. Obtain and check that proof for the source schema before promoting this record.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, p. 27.

Record: `topics/classicism/results/c5-and-atomicity-imply-no-pure-contingency.yaml`.

#### Distinctness (pure) ∧ Rigid Comprehension ⇒ False (⊥) — `maximalist-distinctness-incompatible-with-rigid-comprehension`

**Answer: Open.**

Original record notes:

A reported theorem awaiting a supplied proof in this map; not presented as a conjecture by the source.

Source report / verification needed: The paper credits Zach Goodsell (personal communication) with this incompatibility, but supplies no proof. A checked proof of the stated source-scope incompatibility is still needed.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 41.

Record: `topics/classicism/results/maximalist-distinctness-incompatible-with-rigid-comprehension.yaml`.

#### Coalesced sum: singleton individual root — `coalesced-single-individual-root`

**Answer: Open.**

Original record notes:

The source establishes the displayed package in the pure language. The topic also fixes nonlogical constants, including individual constants. An expansion of this particular singleton-root construction to that signature preserving the listed assertions still needs to be supplied; its conjectured status concerns only that expansion. See Appendix E, p. 83 for the distinction between a singleton root without individual constants and the alternative root indexed by individual constants.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, pp. 41–42 and n. 61; Appendix E, p. 83.

Record: `topics/classicism/models/coalesced-single-individual-root.yaml`.

### 1.2 Resolved (17)

#### Coalesced sum: maximalist root — `coalesced-maximalist-root`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `coalesced-maximalist-root`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Theorem 3.26, §§3.6, pp. 62–64; Appendix E, pp. 80–83; §2.6, p. 41.

Record: `topics/classicism/models/coalesced-maximalist-root.yaml`.

#### Finite-support action model: dyadic roundings of N — `finite-support-dyadic-roundings`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `rigid-comprehension-r-implies-boolean-completeness-r`.

Model witness ids: `finite-support-dyadic-roundings`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(7), pp. 74–75; construction p. 78, Part 7; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-dyadic-roundings.yaml`.

#### Finite-support action model: identity-or-collapse monotone surjections — `finite-support-identity-or-collapse-surjections`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `rigid-comprehension-r-implies-boolean-completeness-r`.

Model witness ids: `finite-support-identity-or-collapse-surjections`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(5), pp. 74–75; construction p. 78, Part 5; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-identity-or-collapse-surjections.yaml`.

#### Finite-support action model: identity-or-collapse monotone maps — `finite-support-identity-or-collapse`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `rigid-comprehension-r-implies-boolean-completeness-r`.

Model witness ids: `finite-support-identity-or-collapse`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(4), pp. 74–75; construction p. 78, Part 4; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-identity-or-collapse.yaml`.

#### Finite-support action model: monotone maps of N — `finite-support-monotone-maps`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-r-implies-atomicity-t`, `atomicity-t-incompatible-with-atomlessness`, `rigid-comprehension-r-implies-actuality`.

Model witness ids: `finite-support-monotone-maps`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(3), pp. 74–75; construction p. 77; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-monotone-maps.yaml`.

#### Finite-support action model: monotone surjections of N — `finite-support-monotone-surjections`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-r-implies-atomicity-t`, `atomicity-t-incompatible-with-atomlessness`, `rigid-comprehension-r-implies-actuality`.

Model witness ids: `finite-support-monotone-surjections`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(2), pp. 74–75; construction pp. 76–77; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-monotone-surjections.yaml`.

#### Finite-support action model: permutations of N — `finite-support-permutations`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-r-implies-atomicity-t`, `atomicity-t-incompatible-with-atomlessness`, `c5-and-completeness-imply-actuality`, `rigid-comprehension-r-implies-actuality`.

Model witness ids: `finite-support-permutations`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(1), pp. 74–75; construction pp. 75–76; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-permutations.yaml`.

#### Finite-support action model: qualitative contrast — `finite-support-qualitative-contrast`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `c5-and-atomicity-imply-necessary-plenitude`, `necessary-plenitude-r-implies-necessary-actuality`.

Model witness ids: `finite-support-qualitative-contrast`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, final construction (two copies of N).

Record: `topics/classicism/models/finite-support-qualitative-contrast.yaml`.

#### Finite-support action model: truncated shifts of N — `finite-support-truncated-shifts`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `rigid-comprehension-r-implies-boolean-completeness-r`.

Model witness ids: `finite-support-truncated-shifts`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(8), pp. 74–75; construction pp. 78–79, Part 8; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-truncated-shifts.yaml`.

#### Finite-support action model: truncations of N — `finite-support-truncations`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-and-bf-imply-necessary-actuality`, `necessary-actuality-implies-actuality`, `rigid-comprehension-r-implies-actuality`.

Model witness ids: `finite-support-truncations`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5(6), pp. 74–75; construction p. 78, Part 6; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-truncations.yaml`.

#### Finite-support action model: N and singleton, all maps — `finite-support-two-object-all-maps`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Model witness ids: `finite-support-two-object-all-maps`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, paragraph beginning “One particularly interesting result”.

Record: `topics/classicism/models/finite-support-two-object-all-maps.yaml`.

#### Full action model: idempotent two-arrow monoid — `full-idempotent-monoid`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t`, `necessary-distinctness-necessary-t-implies-distinctness-necessary-t`.

Model witness ids: `full-idempotent-monoid`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, first paragraph; p. 61 (full-model principles).

Record: `topics/classicism/models/full-idempotent-monoid.yaml`.

#### Full action model: two-element group — `full-involution-group`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Model witness ids: `full-involution-group`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, second paragraph; p. 61.

Record: `topics/classicism/models/full-involution-group.yaml`.

#### Full action model: surjections of an infinite set — `full-surjection-monoid`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Model witness ids: `full-surjection-monoid`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: two-object chain — `full-two-object-chain`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Model witness ids: `full-two-object-chain`, `full-two-object-retract`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fourth paragraph; p. 61.

Record: `topics/classicism/models/full-two-object-chain.yaml`.

#### Full action model: two-object retract — `full-two-object-retract`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Model witness ids: `full-two-object-retract`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fifth paragraph and n. 81; p. 61.

Record: `topics/classicism/models/full-two-object-retract.yaml`.

#### Henkin model: base without a choice function — `henkin-without-relational-choice`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Model witness ids: `henkin-without-relational-choice`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, n. 46, p. 32.

Record: `topics/classicism/models/henkin-without-relational-choice.yaml`.

### 1.3 Incompatible with background (0)

None.

## 2. Open questions under each recorded package

The most useful place to work: these are open *given* assumptions the sources already make.

### C5

Assuming `necessary-distinctness-necessary-r`, these remain open:

- All individuals fundamental (`all-individuals-fundamental`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Logical Necessity (`logical-necessity-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### C5 + Atomicity

Assuming `necessary-distinctness-necessary-r`, `atomicity-r`, these remain open:

- All individuals fundamental (`all-individuals-fundamental`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Logical Necessity (`logical-necessity-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Extensionalism

Assuming `extensionality-r`, these remain open:

- All individuals fundamental (`all-individuals-fundamental`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Logical Necessity (`logical-necessity-r`)
- □Extensionality (`necessary-extensionality-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Pure Maximalist Classicism

Assuming `distinctness-schema-r`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- All individuals fundamental (`all-individuals-fundamental`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Atomlessness (`atomlessness`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Distinctness (signature Σ) (`distinctness-signature-r`)
- Functionality (`functionality-r`)
- Fundamental Possibility (`fundamental-possibility-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- □BF (type t) (`necessary-barcan-t`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Possibility+ (`possibility-plus-r`)
- Possibility (signature Σ) (`possibility-signature-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Separated Structure (`separated-structure-r`)
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Tractarianism (`tractarianism-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### □Atomicity + Boolean Completeness + BF

Assuming `necessary-atomicity-r`, `boolean-completeness-r`, `barcan-r`, these remain open:

- All individuals fundamental (`all-individuals-fundamental`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Logical Necessity (`logical-necessity-r`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- B for pure sentences (`pure-b-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### □ND + Actuality

Assuming `necessary-distinctness-necessary-r`, `actuality`, these remain open:

- All individuals fundamental (`all-individuals-fundamental`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Logical Necessity (`logical-necessity-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Fundamental Possibility + All individuals fundamental

Assuming `fundamental-possibility-r`, `all-individuals-fundamental`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Atomlessness (`atomlessness`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Distinctness (signature Σ) (`distinctness-signature-r`)
- Functionality (`functionality-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- □BF (type t) (`necessary-barcan-t`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Possibility (signature Σ) (`possibility-signature-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Separated Structure (`separated-structure-r`)
- Strong Possibility (pure) (`strong-possibility-r`)
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Tractarianism (`tractarianism-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Atomicity + BF

Assuming `atomicity-r`, `barcan-r`, these remain open:

- All individuals fundamental (`all-individuals-fundamental`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Logical Necessity (`logical-necessity-r`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- B for pure sentences (`pure-b-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Atomicity (type t) + BF

Assuming `atomicity-t`, `barcan-r`, these remain open:

- All individuals fundamental (`all-individuals-fundamental`)
- Atomicity (`atomicity-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Logical Necessity (`logical-necessity-r`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- B for pure sentences (`pure-b-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### ND + BF

Assuming `distinctness-necessary-r`, `barcan-r`, these remain open:

- All individuals fundamental (`all-individuals-fundamental`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Logical Necessity (`logical-necessity-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Gallin Extensional Comprehension + BF

Assuming `gallin-extensional-comprehension-r`, `barcan-r`, these remain open:

- All individuals fundamental (`all-individuals-fundamental`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Atomlessness (`atomlessness`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- ND (`distinctness-necessary-r`)
- ND (type t) (`distinctness-necessary-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Extensionality (`extensionality-r`)
- Fregean Axiom (`fregean-axiom`)
- Functional Choice (`functional-choice-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- Logical Necessity (`logical-necessity-r`)
- B (`modal-b`)
- 5 (`modal-five`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □ND (`necessary-distinctness-necessary-r`)
- □ND (type t) (`necessary-distinctness-necessary-t`)
- □Extensionality (`necessary-extensionality-r`)
- □Fregean Axiom (`necessary-fregean-axiom`)
- □B (`necessary-modal-b`)
- □5 (`necessary-modal-five`)
- □Plenitude (`necessary-plenitude-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Plenitude (`plenitude-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Rigid Comprehension + BF

Assuming `rigid-comprehension-r`, `barcan-r`, these remain open:

- All individuals fundamental (`all-individuals-fundamental`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Logical Necessity (`logical-necessity-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- B for pure sentences (`pure-b-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### □ND + Boolean Completeness

Assuming `necessary-distinctness-necessary-r`, `boolean-completeness-r`, these remain open:

- All individuals fundamental (`all-individuals-fundamental`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Logical Necessity (`logical-necessity-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Rigid Comprehension + ND

Assuming `rigid-comprehension-r`, `distinctness-necessary-r`, these remain open:

- All individuals fundamental (`all-individuals-fundamental`)
- BF (type t) (`barcan-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- □BF (type t) (`necessary-barcan-t`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Distinctness (pure) + Separated Structure

Assuming `distinctness-schema-r`, `separated-structure-r`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- All individuals fundamental (`all-individuals-fundamental`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Atomlessness (`atomlessness`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Functionality (`functionality-r`)
- Fundamental Possibility (`fundamental-possibility-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- □BF (type t) (`necessary-barcan-t`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Possibility+ (`possibility-plus-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Tractarianism (`tractarianism-r`)

### □ND + □Actuality

Assuming `necessary-distinctness-necessary-r`, `necessary-actuality`, these remain open:

- All individuals fundamental (`all-individuals-fundamental`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Logical Necessity (`logical-necessity-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### □ND + □Boolean Completeness

Assuming `necessary-distinctness-necessary-r`, `necessary-boolean-completeness-r`, these remain open:

- All individuals fundamental (`all-individuals-fundamental`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Logical Necessity (`logical-necessity-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Witnessed Possibility + No Pure Contingency

Assuming `witnessed-possibility-r`, `no-pure-contingency-r`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- All individuals fundamental (`all-individuals-fundamental`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Atomlessness (`atomlessness`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- ND (`distinctness-necessary-r`)
- ND (type t) (`distinctness-necessary-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Extensionality (`extensionality-r`)
- Fregean Axiom (`fregean-axiom`)
- Functional Choice (`functional-choice-r`)
- Functionality (`functionality-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- B (`modal-b`)
- 5 (`modal-five`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □ND (`necessary-distinctness-necessary-r`)
- □ND (type t) (`necessary-distinctness-necessary-t`)
- □Extensionality (`necessary-extensionality-r`)
- □Fregean Axiom (`necessary-fregean-axiom`)
- □Functionality (`necessary-functionality-r`)
- □B (`necessary-modal-b`)
- □5 (`necessary-modal-five`)
- □Plenitude (`necessary-plenitude-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Plenitude (`plenitude-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Separated Structure (`separated-structure-r`)
- Tractarianism (`tractarianism-r`)

### Relational Choice + Plenitude

Assuming `relational-choice-r`, `plenitude-r`, these remain open:

- All individuals fundamental (`all-individuals-fundamental`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Extensionality (`extensionality-r`)
- Fregean Axiom (`fregean-axiom`)
- Functionality (`functionality-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Logical Necessity (`logical-necessity-r`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □ND (`necessary-distinctness-necessary-r`)
- □ND (type t) (`necessary-distinctness-necessary-t`)
- □Extensionality (`necessary-extensionality-r`)
- □Fregean Axiom (`necessary-fregean-axiom`)
- □Functionality (`necessary-functionality-r`)
- □B (`necessary-modal-b`)
- □5 (`necessary-modal-five`)
- □Plenitude (`necessary-plenitude-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Separated Structure (`separated-structure-r`)
- Tractarianism (`tractarianism-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

## 3. Unknown verdicts inside each model

For these principles the model has not been checked either way. Deciding one is a self-contained calculation in a construction that is already written down.

### Coalesced sum: maximalist root — `coalesced-maximalist-root`

- All individuals fundamental (`all-individuals-fundamental`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Atomlessness (`atomlessness`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Functionality (`functionality-r`)
- Fundamental Possibility (`fundamental-possibility-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- □BF (type t) (`necessary-barcan-t`)
- Possibility+ (`possibility-plus-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Tractarianism (`tractarianism-r`)

### Coalesced sum: singleton individual root — `coalesced-single-individual-root`

Fully determined; nothing unknown.

### Finite-support action model: dyadic roundings of N — `finite-support-dyadic-roundings`

- All individuals fundamental (`all-individuals-fundamental`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- Logical Necessity (`logical-necessity-r`)
- □BF (type t) (`necessary-barcan-t`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: identity-or-collapse monotone surjections — `finite-support-identity-or-collapse-surjections`

- All individuals fundamental (`all-individuals-fundamental`)
- Atomicity (type t) (`atomicity-t`)
- Atomlessness (`atomlessness`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- Logical Necessity (`logical-necessity-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: identity-or-collapse monotone maps — `finite-support-identity-or-collapse`

- All individuals fundamental (`all-individuals-fundamental`)
- Atomicity (type t) (`atomicity-t`)
- Atomlessness (`atomlessness`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- Logical Necessity (`logical-necessity-r`)
- □BF (type t) (`necessary-barcan-t`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: monotone maps of N — `finite-support-monotone-maps`

- All individuals fundamental (`all-individuals-fundamental`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- Logical Necessity (`logical-necessity-r`)
- □BF (type t) (`necessary-barcan-t`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: monotone surjections of N — `finite-support-monotone-surjections`

- All individuals fundamental (`all-individuals-fundamental`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- Logical Necessity (`logical-necessity-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: permutations of N — `finite-support-permutations`

- All individuals fundamental (`all-individuals-fundamental`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- Logical Necessity (`logical-necessity-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: qualitative contrast — `finite-support-qualitative-contrast`

- All individuals fundamental (`all-individuals-fundamental`)
- Atomlessness (`atomlessness`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Functional Choice (`functional-choice-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- Logical Necessity (`logical-necessity-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: truncated shifts of N — `finite-support-truncated-shifts`

- All individuals fundamental (`all-individuals-fundamental`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- Logical Necessity (`logical-necessity-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: truncations of N — `finite-support-truncations`

- All individuals fundamental (`all-individuals-fundamental`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- Logical Necessity (`logical-necessity-r`)
- □BF (type t) (`necessary-barcan-t`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: N and singleton, all maps — `finite-support-two-object-all-maps`

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- All individuals fundamental (`all-individuals-fundamental`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Atomlessness (`atomlessness`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Distinctness (pure) (`distinctness-schema-r`)
- Distinctness (signature Σ) (`distinctness-signature-r`)
- Fundamental Possibility (`fundamental-possibility-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- Logical Necessity (`logical-necessity-r`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Possibility+ (`possibility-plus-r`)
- Possibility (pure) (`possibility-schema-r`)
- Possibility (signature Σ) (`possibility-signature-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Strong Possibility (pure) (`strong-possibility-r`)
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Full Henkin model: singleton individual domain — `full-henkin-singleton-base`

- All individuals fundamental (`all-individuals-fundamental`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Logical Necessity (`logical-necessity-r`)
- □Extensionality (`necessary-extensionality-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Full action model: idempotent two-arrow monoid — `full-idempotent-monoid`

- All individuals fundamental (`all-individuals-fundamental`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- Logical Necessity (`logical-necessity-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Full action model: two-element group — `full-involution-group`

- All individuals fundamental (`all-individuals-fundamental`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Functional Choice (`functional-choice-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- Logical Necessity (`logical-necessity-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Full action model: surjections of an infinite set — `full-surjection-monoid`

- All individuals fundamental (`all-individuals-fundamental`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- Logical Necessity (`logical-necessity-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Full action model: two-object chain — `full-two-object-chain`

- All individuals fundamental (`all-individuals-fundamental`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- ND (`distinctness-necessary-r`)
- ND (type t) (`distinctness-necessary-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Functional Choice (`functional-choice-r`)
- Functionality (`functionality-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- B (`modal-b`)
- 5 (`modal-five`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □ND (`necessary-distinctness-necessary-r`)
- □ND (type t) (`necessary-distinctness-necessary-t`)
- □Functionality (`necessary-functionality-r`)
- □B (`necessary-modal-b`)
- □5 (`necessary-modal-five`)
- □Plenitude (`necessary-plenitude-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Plenitude (`plenitude-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Tractarianism (`tractarianism-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Full action model: two-object retract — `full-two-object-retract`

- All individuals fundamental (`all-individuals-fundamental`)
- BF (type t) (`barcan-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Functional Choice (`functional-choice-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Infinity (type t) (`infinity-t`)
- □BF (type t) (`necessary-barcan-t`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Henkin model: base without a choice function — `henkin-without-relational-choice`

- All individuals fundamental (`all-individuals-fundamental`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Infinity (type e) (`infinity-e`)
- Logical Necessity (`logical-necessity-r`)
- □Extensionality (`necessary-extensionality-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

## 4. Open single-premise pairs (1076)

*A ⇒ B ?* means neither implication nor incompatibility nor a countermodel is currently recorded. Grouped by antecedent. Most are open only because the obvious model has not been added.

- **4** (`modal-four`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility
- **5** (`modal-five`) ⇒ All individuals fundamental, BF (type t), Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility, □BF (type t)
- **Actual Profile** (`actual-profile-r`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Separated Structure, Witnessed Possibility
- **Actuality** (`actuality`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Separated Structure, Witnessed Possibility
- **All individuals fundamental** (`all-individuals-fundamental`) ⇒ 5, Actual Profile, Actuality, Atomicity, Atomicity (type t), Atomlessness, B, B for pure sentences, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness (pure), Distinctness (signature Σ), Distinctness-preserving collapse, Extensionality, Fregean Axiom, Functional Choice, Functionality, Fundamental Possibility, Gallin Extensional Comprehension, Inextensible Comprehension, Infinity (type e), Infinity (type t), Logical Necessity, ND, ND (type t), No Pure Contingency, Persistent Comprehension, Plenitude, Possibility (pure), Possibility (signature Σ), Possibility+, Relational Choice, Rigid Comprehension, Separated Structure, Strong Possibility (pure), Strong Possibility (signature Σ), Tractarianism, Witnessed Possibility, □5, □Actuality, □Atomicity, □B, □BF, □BF (type t), □Boolean Completeness, □Extensionality, □Fregean Axiom, □Functionality, □ND, □ND (type t), □Plenitude, □Rigid Comprehension, □Tractarianism
- **Atomicity** (`atomicity-r`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility, □Atomicity
- **Atomicity (type t)** (`atomicity-t`) ⇒ All individuals fundamental, Atomicity, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility, □Atomicity
- **Atomlessness** (`atomlessness`) ⇒ All individuals fundamental, B for pure sentences, BF (type t), Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness-preserving collapse, Inextensible Comprehension, Infinity (type e), Infinity (type t), Logical Necessity, No Pure Contingency, Relational Choice, Separated Structure, Witnessed Possibility, □BF (type t)
- **B** (`modal-b`) ⇒ All individuals fundamental, BF (type t), Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility, □BF (type t)
- **B for pure sentences** (`pure-b-r`) ⇒ All individuals fundamental, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility
- **BF** (`barcan-r`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness-preserving collapse, Inextensible Comprehension, Logical Necessity, No Pure Contingency, Separated Structure, Witnessed Possibility, □BF (type t)
- **BF (type t)** (`barcan-t`) ⇒ All individuals fundamental, B for pure sentences, BF, Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness-preserving collapse, Functionality, Inextensible Comprehension, Logical Necessity, No Pure Contingency, Separated Structure, Tractarianism, Witnessed Possibility, □BF (type t)
- **Boolean Completeness** (`boolean-completeness-r`) ⇒ Actual Profile, Actuality, All individuals fundamental, B for pure sentences, Distinctness-preserving collapse, Gallin Extensional Comprehension, Inextensible Comprehension, Persistent Comprehension, Rigid Comprehension, Separated Structure, Witnessed Possibility
- **Boolean Completeness (type t)** (`boolean-completeness-t`) ⇒ Actual Profile, Actuality, All individuals fundamental, B for pure sentences, Boolean Completeness, Distinctness-preserving collapse, Gallin Extensional Comprehension, Inextensible Comprehension, Persistent Comprehension, Rigid Comprehension, Separated Structure, Witnessed Possibility
- **Broad Necessitism** (`broad-necessitism-r`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility
- **CBF** (`converse-barcan-r`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility
- **Converse Witnessed Possibility** (`converse-witnessed-possibility-r`) ⇒ All individuals fundamental, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Logical Necessity, Separated Structure, Witnessed Possibility
- **Distinctness (pure)** (`distinctness-schema-r`) ⇒ Actual Profile, Actuality, All individuals fundamental, Atomicity, Atomicity (type t), Atomlessness, B for pure sentences, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Distinctness (signature Σ), Distinctness-preserving collapse, Functionality, Fundamental Possibility, Gallin Extensional Comprehension, Inextensible Comprehension, Infinity (type e), Infinity (type t), Persistent Comprehension, Possibility (signature Σ), Possibility+, Relational Choice, Rigid Comprehension, Separated Structure, Strong Possibility (signature Σ), Tractarianism, Witnessed Possibility, □BF (type t)
- **Distinctness (signature Σ)** (`distinctness-signature-r`) ⇒ Actual Profile, Actuality, All individuals fundamental, Atomicity, Atomicity (type t), Atomlessness, B for pure sentences, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Distinctness-preserving collapse, Functionality, Fundamental Possibility, Gallin Extensional Comprehension, Inextensible Comprehension, Infinity (type e), Infinity (type t), Persistent Comprehension, Possibility+, Relational Choice, Rigid Comprehension, Strong Possibility (signature Σ), Tractarianism, □BF (type t)
- **Distinctness-preserving collapse** (`distinctness-preserving-collapse`) ⇒ Actual Profile, Actuality, All individuals fundamental, Atomicity, Atomicity (type t), B for pure sentences, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Functionality, Gallin Extensional Comprehension, Inextensible Comprehension, Persistent Comprehension, Relational Choice, Rigid Comprehension, Separated Structure, Tractarianism, Witnessed Possibility, □BF (type t)
- **Existence** (`existence-r`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility
- **Extensionality** (`extensionality-r`) ⇒ All individuals fundamental, Distinctness-preserving collapse, Gallin Extensional Comprehension, Logical Necessity, Separated Structure, Witnessed Possibility, □Extensionality
- **Fregean Axiom** (`fregean-axiom`) ⇒ All individuals fundamental, Distinctness-preserving collapse, Gallin Extensional Comprehension, Logical Necessity, Separated Structure, Witnessed Possibility, □Extensionality
- **Functional Choice** (`functional-choice-r`) ⇒ All individuals fundamental, Atomicity, Atomicity (type t), BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness-preserving collapse, Extensionality, Fregean Axiom, Functionality, Gallin Extensional Comprehension, Logical Necessity, No Pure Contingency, Rigid Comprehension, Separated Structure, Tractarianism, Witnessed Possibility, □5, □Actuality, □Atomicity, □B, □BF, □BF (type t), □Boolean Completeness, □Extensionality, □Fregean Axiom, □Functionality, □ND, □ND (type t), □Plenitude, □Rigid Comprehension, □Tractarianism
- **Functionality** (`functionality-r`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness-preserving collapse, Inextensible Comprehension, Logical Necessity, No Pure Contingency, Separated Structure, Witnessed Possibility, □BF (type t)
- **Fundamental Possibility** (`fundamental-possibility-r`) ⇒ Actual Profile, Actuality, All individuals fundamental, Atomicity, Atomicity (type t), Atomlessness, B for pure sentences, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Distinctness (signature Σ), Distinctness-preserving collapse, Functionality, Gallin Extensional Comprehension, Inextensible Comprehension, Infinity (type e), Infinity (type t), Persistent Comprehension, Possibility (signature Σ), Possibility+, Relational Choice, Rigid Comprehension, Separated Structure, Strong Possibility (pure), Strong Possibility (signature Σ), Tractarianism, Witnessed Possibility, □BF (type t)
- **Gallin Extensional Comprehension** (`gallin-extensional-comprehension-r`) ⇒ 5, Actual Profile, Actuality, All individuals fundamental, Atomicity, Atomicity (type t), Atomlessness, B, B for pure sentences, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness (pure), Distinctness (signature Σ), Distinctness-preserving collapse, Extensionality, Fregean Axiom, Functional Choice, Functionality, Fundamental Possibility, Inextensible Comprehension, Infinity (type e), Infinity (type t), Logical Necessity, ND, ND (type t), No Pure Contingency, Persistent Comprehension, Plenitude, Possibility (pure), Possibility (signature Σ), Possibility+, Relational Choice, Rigid Comprehension, Separated Structure, Strong Possibility (pure), Strong Possibility (signature Σ), Tractarianism, Witnessed Possibility, □5, □Actuality, □Atomicity, □B, □BF, □BF (type t), □Boolean Completeness, □Extensionality, □Fregean Axiom, □Functionality, □ND, □ND (type t), □Plenitude, □Rigid Comprehension, □Tractarianism
- **Inextensible Comprehension** (`inextensible-comprehension-r`) ⇒ Actual Profile, Actuality, All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Persistent Comprehension, Separated Structure, Witnessed Possibility
- **Infinity (type e)** (`infinity-e`) ⇒ 5, Actual Profile, Actuality, All individuals fundamental, Atomicity, Atomicity (type t), Atomlessness, B, B for pure sentences, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness (pure), Distinctness (signature Σ), Distinctness-preserving collapse, Extensionality, Fregean Axiom, Functional Choice, Functionality, Fundamental Possibility, Gallin Extensional Comprehension, Inextensible Comprehension, Infinity (type t), Logical Necessity, ND, ND (type t), No Pure Contingency, Persistent Comprehension, Plenitude, Possibility (pure), Possibility (signature Σ), Possibility+, Relational Choice, Rigid Comprehension, Separated Structure, Strong Possibility (pure), Strong Possibility (signature Σ), Tractarianism, Witnessed Possibility, □5, □Actuality, □Atomicity, □B, □BF, □BF (type t), □Boolean Completeness, □Extensionality, □Fregean Axiom, □Functionality, □ND, □ND (type t), □Plenitude, □Rigid Comprehension, □Tractarianism
- **Infinity (type t)** (`infinity-t`) ⇒ 5, Actual Profile, Actuality, All individuals fundamental, Atomicity, Atomicity (type t), Atomlessness, B, B for pure sentences, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness (pure), Distinctness (signature Σ), Distinctness-preserving collapse, Functional Choice, Functionality, Fundamental Possibility, Gallin Extensional Comprehension, Inextensible Comprehension, Infinity (type e), Logical Necessity, ND, ND (type t), No Pure Contingency, Persistent Comprehension, Plenitude, Possibility (pure), Possibility (signature Σ), Possibility+, Relational Choice, Rigid Comprehension, Separated Structure, Strong Possibility (pure), Strong Possibility (signature Σ), Tractarianism, Witnessed Possibility, □5, □Actuality, □Atomicity, □B, □BF, □BF (type t), □Boolean Completeness, □Functionality, □ND, □ND (type t), □Plenitude, □Rigid Comprehension, □Tractarianism
- **Intensionality** (`intensionality-r`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility
- **K** (`modal-k`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility
- **Logical Necessity** (`logical-necessity-r`) ⇒ 5, Actual Profile, Actuality, All individuals fundamental, Atomicity, Atomicity (type t), Atomlessness, B, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Distinctness-preserving collapse, Extensionality, Fregean Axiom, Functional Choice, Functionality, Gallin Extensional Comprehension, Inextensible Comprehension, Infinity (type e), Infinity (type t), ND, ND (type t), Persistent Comprehension, Plenitude, Relational Choice, Rigid Comprehension, Separated Structure, Tractarianism, □5, □Actuality, □Atomicity, □B, □BF, □BF (type t), □Boolean Completeness, □Extensionality, □Fregean Axiom, □Functionality, □ND, □ND (type t), □Plenitude, □Rigid Comprehension, □Tractarianism
- **Modalized Fregean Axiom** (`modalized-fregean`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility
- **Modalized Functionality** (`modalized-functionality-r`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility
- **ND** (`distinctness-necessary-r`) ⇒ All individuals fundamental, BF (type t), Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility, □BF (type t)
- **ND (type t)** (`distinctness-necessary-t`) ⇒ All individuals fundamental, BF (type t), Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility, □BF (type t)
- **NI** (`identity-necessary-r`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility
- **No Pure Contingency** (`no-pure-contingency-r`) ⇒ All individuals fundamental, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Logical Necessity, Separated Structure, Witnessed Possibility
- **Ordinary Comprehension** (`ordinary-comprehension-r`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility
- **Persistent Comprehension** (`persistent-comprehension-r`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Separated Structure, Witnessed Possibility
- **Plenitude** (`plenitude-r`) ⇒ All individuals fundamental, BF (type t), Boolean Completeness, Boolean Completeness (type t), Distinctness-preserving collapse, Gallin Extensional Comprehension, Rigid Comprehension, Separated Structure, Witnessed Possibility, □BF (type t)
- **Possibility (pure)** (`possibility-schema-r`) ⇒ Actual Profile, Actuality, All individuals fundamental, Atomicity, Atomicity (type t), Atomlessness, B for pure sentences, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Distinctness (signature Σ), Distinctness-preserving collapse, Functionality, Fundamental Possibility, Gallin Extensional Comprehension, Inextensible Comprehension, Infinity (type e), Infinity (type t), Persistent Comprehension, Possibility (signature Σ), Possibility+, Relational Choice, Rigid Comprehension, Separated Structure, Strong Possibility (signature Σ), Tractarianism, Witnessed Possibility, □BF (type t)
- **Possibility (signature Σ)** (`possibility-signature-r`) ⇒ Actual Profile, Actuality, All individuals fundamental, Atomicity, Atomicity (type t), Atomlessness, B for pure sentences, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Distinctness-preserving collapse, Functionality, Fundamental Possibility, Gallin Extensional Comprehension, Inextensible Comprehension, Infinity (type e), Infinity (type t), Persistent Comprehension, Possibility+, Relational Choice, Rigid Comprehension, Strong Possibility (signature Σ), Tractarianism, □BF (type t)
- **Possibility+** (`possibility-plus-r`) ⇒ Actual Profile, Actuality, All individuals fundamental, Atomicity, Atomicity (type t), Atomlessness, B for pure sentences, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Distinctness (signature Σ), Distinctness-preserving collapse, Functionality, Fundamental Possibility, Gallin Extensional Comprehension, Inextensible Comprehension, Infinity (type e), Infinity (type t), Persistent Comprehension, Possibility (signature Σ), Relational Choice, Rigid Comprehension, Separated Structure, Strong Possibility (pure), Strong Possibility (signature Σ), Tractarianism, Witnessed Possibility, □BF (type t)
- **Relational Choice** (`relational-choice-r`) ⇒ 5, Actual Profile, Actuality, All individuals fundamental, Atomicity, Atomicity (type t), B, B for pure sentences, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness-preserving collapse, Extensionality, Fregean Axiom, Functional Choice, Functionality, Gallin Extensional Comprehension, Inextensible Comprehension, Logical Necessity, ND, ND (type t), No Pure Contingency, Persistent Comprehension, Plenitude, Rigid Comprehension, Separated Structure, Tractarianism, Witnessed Possibility, □5, □Actuality, □Atomicity, □B, □BF, □BF (type t), □Boolean Completeness, □Extensionality, □Fregean Axiom, □Functionality, □ND, □ND (type t), □Plenitude, □Rigid Comprehension, □Tractarianism
- **Rigid Comprehension** (`rigid-comprehension-r`) ⇒ All individuals fundamental, B for pure sentences, Distinctness-preserving collapse, Gallin Extensional Comprehension, Separated Structure, Witnessed Possibility
- **Separated Structure** (`separated-structure-r`) ⇒ Actual Profile, Actuality, All individuals fundamental, Atomicity, Atomicity (type t), Atomlessness, B for pure sentences, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Distinctness (pure), Distinctness (signature Σ), Distinctness-preserving collapse, Functionality, Fundamental Possibility, Gallin Extensional Comprehension, Inextensible Comprehension, Infinity (type e), Infinity (type t), Persistent Comprehension, Possibility (pure), Possibility (signature Σ), Possibility+, Relational Choice, Rigid Comprehension, Strong Possibility (signature Σ), Tractarianism, Witnessed Possibility, □BF (type t)
- **Strong Possibility (pure)** (`strong-possibility-r`) ⇒ Actual Profile, Actuality, All individuals fundamental, Atomicity, Atomicity (type t), Atomlessness, B for pure sentences, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Distinctness (signature Σ), Distinctness-preserving collapse, Functionality, Fundamental Possibility, Gallin Extensional Comprehension, Inextensible Comprehension, Infinity (type e), Infinity (type t), Persistent Comprehension, Possibility (signature Σ), Possibility+, Relational Choice, Rigid Comprehension, Separated Structure, Strong Possibility (signature Σ), Tractarianism, Witnessed Possibility, □BF (type t)
- **Strong Possibility (signature Σ)** (`strong-possibility-signature-r`) ⇒ Actual Profile, Actuality, All individuals fundamental, Atomicity, Atomicity (type t), Atomlessness, B for pure sentences, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Distinctness-preserving collapse, Functionality, Fundamental Possibility, Gallin Extensional Comprehension, Inextensible Comprehension, Infinity (type e), Infinity (type t), Persistent Comprehension, Possibility+, Relational Choice, Rigid Comprehension, Strong Possibility (pure), Tractarianism, □BF (type t)
- **T** (`modal-t`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility
- **Tractarianism** (`tractarianism-r`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness-preserving collapse, Inextensible Comprehension, Logical Necessity, No Pure Contingency, Separated Structure, Witnessed Possibility, □BF (type t)
- **Witnessed Possibility** (`witnessed-possibility-r`) ⇒ Actual Profile, Actuality, All individuals fundamental, Atomicity, Atomicity (type t), Atomlessness, B for pure sentences, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Distinctness (pure), Distinctness (signature Σ), Distinctness-preserving collapse, Functionality, Fundamental Possibility, Gallin Extensional Comprehension, Inextensible Comprehension, Infinity (type e), Infinity (type t), Persistent Comprehension, Possibility (pure), Possibility (signature Σ), Possibility+, Relational Choice, Rigid Comprehension, Separated Structure, Strong Possibility (signature Σ), Tractarianism, □BF (type t)
- **□5** (`necessary-modal-five`) ⇒ All individuals fundamental, Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness-preserving collapse, Inextensible Comprehension, Logical Necessity, No Pure Contingency, Separated Structure, Witnessed Possibility
- **□Actuality** (`necessary-actuality`) ⇒ All individuals fundamental, Atomicity (type t), B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Separated Structure, Witnessed Possibility
- **□Atomicity** (`necessary-atomicity-r`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Distinctness-preserving collapse, Inextensible Comprehension, Separated Structure, Witnessed Possibility
- **□B** (`necessary-modal-b`) ⇒ All individuals fundamental, Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness-preserving collapse, Inextensible Comprehension, Logical Necessity, No Pure Contingency, Separated Structure, Witnessed Possibility
- **□BF** (`necessary-barcan-r`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness-preserving collapse, Inextensible Comprehension, Logical Necessity, No Pure Contingency, Separated Structure, Witnessed Possibility
- **□BF (type t)** (`necessary-barcan-t`) ⇒ All individuals fundamental, B for pure sentences, BF, Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness-preserving collapse, Functionality, Inextensible Comprehension, Logical Necessity, No Pure Contingency, Separated Structure, Tractarianism, Witnessed Possibility, □BF, □Functionality, □Tractarianism
- **□Boolean Completeness** (`necessary-boolean-completeness-r`) ⇒ Actual Profile, Actuality, All individuals fundamental, Atomicity, Atomicity (type t), B for pure sentences, Distinctness-preserving collapse, Gallin Extensional Comprehension, Inextensible Comprehension, Persistent Comprehension, Rigid Comprehension, Separated Structure, Witnessed Possibility, □Actuality, □Atomicity, □Rigid Comprehension
- **□Extensionality** (`necessary-extensionality-r`) ⇒ All individuals fundamental, Distinctness-preserving collapse, Functional Choice, Gallin Extensional Comprehension, Infinity (type e), Logical Necessity, Relational Choice, Separated Structure, Witnessed Possibility
- **□Fregean Axiom** (`necessary-fregean-axiom`) ⇒ All individuals fundamental, Distinctness-preserving collapse, Gallin Extensional Comprehension, Logical Necessity, Separated Structure, Witnessed Possibility, □Extensionality
- **□Functionality** (`necessary-functionality-r`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness-preserving collapse, Inextensible Comprehension, Logical Necessity, No Pure Contingency, Separated Structure, Witnessed Possibility
- **□ND** (`necessary-distinctness-necessary-r`) ⇒ All individuals fundamental, Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness-preserving collapse, Inextensible Comprehension, Logical Necessity, No Pure Contingency, Separated Structure, Witnessed Possibility
- **□ND (type t)** (`necessary-distinctness-necessary-t`) ⇒ All individuals fundamental, Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness-preserving collapse, Inextensible Comprehension, Logical Necessity, No Pure Contingency, Separated Structure, Witnessed Possibility
- **□Plenitude** (`necessary-plenitude-r`) ⇒ All individuals fundamental, Converse Witnessed Possibility, Distinctness-preserving collapse, Gallin Extensional Comprehension, Logical Necessity, No Pure Contingency, Separated Structure, Witnessed Possibility
- **□Rigid Comprehension** (`necessary-rigid-comprehension-r`) ⇒ All individuals fundamental, Atomicity, Atomicity (type t), B for pure sentences, Distinctness-preserving collapse, Gallin Extensional Comprehension, Separated Structure, Witnessed Possibility, □Atomicity
- **□Tractarianism** (`necessary-tractarianism-r`) ⇒ All individuals fundamental, B for pure sentences, Boolean Completeness (type t), Converse Witnessed Possibility, Distinctness-preserving collapse, Inextensible Comprehension, Logical Necessity, No Pure Contingency, Separated Structure, Witnessed Possibility

## 5. Deliberately deferred

`topics/classicism/extraction.md` has a section listing claims that were **not** recorded because they need a further reading of the sources. Those are marked deferred rather than open: the answer is likely in the literature and needs transcribing, not discovering. Read that section before starting work.

## 6. How to record an answer

- Proved an implication? Add `topics/classicism/results/<id>.yaml` with the full premise list and the proof.
- Refuted one? Add `topics/classicism/models/<id>.yaml` listing what you verified in `satisfies` and `violates`.
- Settling an existing conjecture? For a proof of the same statement, keep its ID, set `was_conjectured: true`, and change its status to `proved`. If the statement changes substantially, retain the original and add a separate record. Refuted proposals stay `status: conjectured`, with proved refuting evidence recorded separately. Answers under extra exploration assumptions are contextual, not global record statuses.
- Not sure? Add it with `status: conjectured`, an empty proof, and say in `notes` what would settle it.
- Then run `python3 scripts/pmap.py validate` and `status`. Never hand-edit the derived counts.

`README.md` has the exact record shapes and the sourcing rules. Follow them; an unsourced or misattributed record is worse than an absent one.
