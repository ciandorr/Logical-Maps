# Open questions — Classicism [Draft]

Recorded conjectures, their current answers, and remaining gaps where a new result or model would contribute to the map.

**"Open" means not settled by the records in this bundle.** It does not mean unsolved in the literature, and it does not mean hard. Many entries below are routine and simply have not been added yet. Check the sources before assuming a question is new.

## 1. Recorded conjectures and their answers

Answers below are recomputed from proved records under the fixed topic background. A conjectured record supplies no evidence for its own answer. Records marked was_conjectured remain in this history after promotion to proved; their proved status, rather than the historical marker, determines whether they supply evidence. Original sources and notes are retained below each answer.

### 1.1 Unresolved (3)

#### □ND ∧ Atomicity ⇒ No Pure Contingency — `c5-and-atomicity-imply-no-pure-contingency`

**Answer: Open.**

Original record notes:

Reported by the source as a theorem; conjectured is the map’s pending-verification status, not the source authors’ classification.

Source report / verification needed: The source attributes this theorem to Goodsell and Yli-Vakkuri (unpublished) but does not reproduce a proof. Obtain and check that proof for the source schema before promoting this record.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, p. 27.

Record: `topics/classicism/results/c5-and-atomicity-imply-no-pure-contingency.yaml`.

#### Possible Infinity (type t) ⇒ Axiom of Infinity (type t) — `possible-infinity-t-implies-axiom-of-infinity-t`

**Answer: Open.**

Original record notes:

Equivalent to the claim that a finite count of propositions is necessary whenever it is true. It holds with No Pure Contingency and with BF (type $t$), by the recorded results. If some finite $Z$ holds of $\lambda p\, .\,\top$ then every proposition is one of finitely many, and NI carries each identity across, but collecting them under a box is an instance of BF at type $t$, which C does not prove. A proof would need to bypass that; a countermodel would need a world with finitely many propositions that can see one with more, and must violate both BF (type $t$) and No Pure Contingency.

- **Dorr 20 Sep** — Cian Dorr, question of 20 September 2026.

Record: `topics/classicism/results/possible-infinity-t-implies-axiom-of-infinity-t.yaml`.

#### Strong Possibility (signature Σ) ⇒ Strong Possibility (pure) — `strong-possibility-signature-r-implies-strong-possibility-r`

**Answer: Open.**

Original record notes:

The restriction of the signature schema to pure P gives ◇≠P for every pure P consistent with Max(C(Σ)); the pure schema asks for every pure P consistent with Max(C). So the arrow holds iff Max(C(Σ)), equivalently Max(C) plus Separated Structure, is conservative over Max(C) for pure sentences: every pure sentence consistent with Pure Maximalist Classicism must remain consistent when Separated Structure is added. Adjoining constants is conservative for C, which is why Possibility (signature Σ) implies Possibility (pure), but for the maximalization a model of Max(C) + P would need its constants interpreted so that each realizes every consistent role at some truncation, which is not automatic. A proof of that conservativity, or a pure sentence consistent with Max(C) but not with Max(C) + Separated Structure, would settle it.

- **Dorr 22 Sep** — Cian Dorr, suggestion of 22 September 2026.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, p. 39; §2.6, p. 42.

Record: `topics/classicism/results/strong-possibility-signature-r-implies-strong-possibility-r.yaml`.

### 1.2 Resolved (21)

#### Distinctness (pure) ∧ Rigid Comprehension ⇒ False (⊥) — `maximalist-distinctness-incompatible-with-rigid-comprehension`

**Answer: Proved.**

Supporting result ids: `maximalist-distinctness-incompatible-with-rigid-comprehension`.

Original record notes:

Recorded on 17 September 2026 as a reported theorem awaiting a supplied proof. The proof is now Goodsell's own, imported from Arithmetic is Necessary, and the record is derivable from the recorded chain through Boolean Completeness, Countable Boolean Completeness and the Necessity of Arithmetic.

- **Arithmetic is Necessary** — Zachary Goodsell, Arithmetic is Necessary, draft of 5 June 2024, §6, Theorem 11 and the remark following it, p. 25.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 41.

Record: `topics/classicism/results/maximalist-distinctness-incompatible-with-rigid-comprehension.yaml`.

#### Possible Infinity (type e) ⇒ Axiom of Infinity (type e) — `possible-infinity-e-implies-axiom-of-infinity-e`

**Answer: Refuted.**

Supporting result ids: `possibility-plus-r-implies-possibility-schema-r`, `possibility-schema-r-implies-possible-infinity-e`, `axiom-of-infinity-e-implies-infinity-e`.

Model witness ids: `coalesced-single-individual-root`.

Original record notes:

Equivalent to the claim that a finite count of individuals is necessary whenever it is true. It holds with No Pure Contingency and with BF, by the recorded results. A countermodel would need a world with finitely many individuals that can see one with more, and must violate both BF at type $e$ and No Pure Contingency; the coalesced sums on the map do not supply one, since their roots have infinitely many individuals.

- **Dorr 20 Sep** — Cian Dorr, question of 20 September 2026.

Record: `topics/classicism/results/possible-infinity-e-implies-axiom-of-infinity-e.yaml`.

#### Coalesced sum: maximalist root — `coalesced-maximalist-root`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `strong-possibility-and-distinctness-preserving-collapse-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`, `distinctness-signature-r-implies-possibility-signature-r`, `possibility-signature-r-implies-possibility-schema-r`, `possibility-and-necessary-relational-choice-incompatible`, `boolean-completeness-r-implies-countable-boolean-completeness-r`, `possibility-and-countable-boolean-completeness-incompatible`.

Model witness ids: `coalesced-maximalist-root`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. BF fails at the root. C is complete for the component set, so some component $M$ refutes BF at its root $M_0$, at type $t$ say: some $F$ in $M_0$’s domain has $\forall y\, .\,\Box Fy$ true and $\Diamond\exists y\, .\,\neg Fy$ true at $M_0$. Because the root’s domains are as full as possible, the thread $F^{\prime}$ that is universal at the root and in every other component and is carried onto $F$ by the distinguished arrow to $M_0$ is in the root domain. Every arrow from the root into $M$ factors through that distinguished arrow, so $\forall y\, .\,\Box F^{\prime}y$ at the root reduces to $\forall y\, .\,\Box Fy$ at $M_0$ together with trivial checks elsewhere, and $\Diamond\exists y\, .\,\neg F^{\prime}y$ at the root follows from $\Diamond\exists y\, .\,\neg Fy$ at $M_0$ through the same factorization. Observation of Cian Dorr, 22 September 2026. Root domains are as full as compatibility allows: a root proposition is a choice, for each component, of a proposition of that component’s root domain, together with a truth value at the root’s identity arrow, and a root entity of a relational type is likewise a family of component entities with a root component that is an arbitrary function of the root arguments. Atomicity fails at type t: C is complete for the components, so some component $M$ refutes Atomicity at its root, by a proposition $p_M$ with no atom below it in $M$’s domain; the root proposition that is $p_M$ on $M$, empty on every other component and false at the root has as its root lower bounds exactly the root propositions that are lower bounds of $p_M$ on $M$ and empty elsewhere, so it has no atom below it either. Boolean Completeness fails, at type $e\to t$, for the same reason: a component $M$ refutes it by a property $X_M$ of propositions without a greatest lower bound in $M$’s domain, and the root property holding of a root proposition iff $X_M$ holds of its $M$-component has no greatest lower bound at the root, since such a bound’s $M$-component would be one for $X_M$. Relational Choice holds at the root, contrary to a first guess: the functionality of a subrelation is evaluated at the root’s identity arrow only, while the subrelation condition is boxed; so for a serial root relation take the subrelation whose root component is a functional choice from the root component, by choice in the metatheory, and whose component parts are empty. Its necessitation fails, since some component refutes Relational Choice at its root. The Axiom of Infinity at type e holds: the root individuals are all families of component individuals, infinitely many since components have arbitrarily many individuals; identity at the root is identity of families; and the property of cardinalities that is true of exactly the standard numerals at the root and universal in every component is a root entity, so a finite cardinality at the root is a standard numeral, and no standard numeral holds of the universal property over an infinite domain. Possibility+ (pure) fails: some component $N$ satisfies necessarily that there are at least three individuals, since that sentence is consistent; take two root individuals that differ at $N$ and agree everywhere else; the pure formula saying that $x\ne y$ and there are exactly two individuals is consistent, but at the root there are infinitely many individuals, under every arrow into another component the two collapse, and under every arrow into $N$ there are at least three. □Relational Choice fails, as the notes on Relational Choice explain: some component refutes Relational Choice at its root, which is accessible from the root.  Correction of 23 September 2026: the components are only known to refute Boolean Completeness at type $e\to t$ (Classicism, n. 92, conjectures failures at type $t$ but has none), so the transfer argument refutes the type schema of Boolean Completeness at the root, not its type-$t$ instance, which is left unknown; the same transfer, applied to the countable family of haecceities that witnesses the component failure, refutes Countable Boolean Completeness.  Boolean Completeness fails at type $t$ (restoring the claim corrected earlier in the day): the truncation model of Appendix D, part 6, refutes it at type $t$, as its record now shows, and the components are complete for C, so one of them does; the root propositions false at every arrow except those into that component form a copy of its propositional domain under the root’s entailment order, and a root property of propositions holding exactly of the copies of the members of that component’s counterexample family has no least upper bound at the root. Cian Dorr’s argument, 23 September 2026.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Theorem 3.26, §§3.6, pp. 62–64; Appendix E, pp. 80–83; §2.6, p. 41.

Record: `topics/classicism/models/coalesced-maximalist-root.yaml`.

#### Coalesced sum: singleton individual root — `coalesced-single-individual-root`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `strong-possibility-and-distinctness-preserving-collapse-incompatible`, `possibility-plus-r-implies-possibility-schema-r`, `possibility-schema-r-implies-possible-infinity-e`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `axiom-of-infinity-e-implies-infinity-e`, `possibility-and-necessary-relational-choice-incompatible`, `boolean-completeness-r-implies-countable-boolean-completeness-r`, `possibility-and-countable-boolean-completeness-incompatible`.

Model witness ids: `coalesced-single-individual-root`.

Original record notes:

Promoted on 22 September 2026 for the pure package, which the source establishes; the earlier conjectured status concerned an expansion to the map’s signature Σ. That expansion exists exactly when Σ has at most one individual constant: with two, the unique root individual would have to be carried to two different interpretations in a component where they differ, which no arrow can do. So the signature principles are not listed; for a signature with individual constants see the constant-indexed root. Actuality holds by the singleton root proposition; Infinity at type e fails at the root, where there is one individual, although infinitely many are possible. BF fails at the root. C is complete for the component set, so some component $M$ refutes BF at its root $M_0$, at type $t$ say: some $F$ in $M_0$’s domain has $\forall y\, .\,\Box Fy$ true and $\Diamond\exists y\, .\,\neg Fy$ true at $M_0$. Because the root’s domains are as full as possible, the thread $F^{\prime}$ that is universal at the root and in every other component and is carried onto $F$ by the distinguished arrow to $M_0$ is in the root domain. Every arrow from the root into $M$ factors through that distinguished arrow, so $\forall y\, .\,\Box F^{\prime}y$ at the root reduces to $\forall y\, .\,\Box Fy$ at $M_0$ together with trivial checks elsewhere, and $\Diamond\exists y\, .\,\neg F^{\prime}y$ at the root follows from $\Diamond\exists y\, .\,\neg Fy$ at $M_0$ through the same factorization. Observation of Cian Dorr, 22 September 2026. Root domains are as full as compatibility allows: a root proposition is a choice, for each component, of a proposition of that component’s root domain, together with a truth value at the root’s identity arrow, and a root entity of a relational type is likewise a family of component entities with a root component that is an arbitrary function of the root arguments. Atomicity fails at type t: C is complete for the components, so some component $M$ refutes Atomicity at its root, by a proposition $p_M$ with no atom below it in $M$’s domain; the root proposition that is $p_M$ on $M$, empty on every other component and false at the root has as its root lower bounds exactly the root propositions that are lower bounds of $p_M$ on $M$ and empty elsewhere, so it has no atom below it either. Boolean Completeness fails, at type $e\to t$, for the same reason: a component $M$ refutes it by a property $X_M$ of propositions without a greatest lower bound in $M$’s domain, and the root property holding of a root proposition iff $X_M$ holds of its $M$-component has no greatest lower bound at the root, since such a bound’s $M$-component would be one for $X_M$. Relational Choice holds at the root, contrary to a first guess: the functionality of a subrelation is evaluated at the root’s identity arrow only, while the subrelation condition is boxed; so for a serial root relation take the subrelation whose root component is a functional choice from the root component, by choice in the metatheory, and whose component parts are empty. Its necessitation fails, since some component refutes Relational Choice at its root. □Relational Choice fails, as the notes on Relational Choice explain: some component refutes Relational Choice at its root, which is accessible from the root.  Correction of 23 September 2026: the components are only known to refute Boolean Completeness at type $e\to t$ (Classicism, n. 92, conjectures failures at type $t$ but has none), so the transfer argument refutes the type schema of Boolean Completeness at the root, not its type-$t$ instance, which is left unknown; the same transfer, applied to the countable family of haecceities that witnesses the component failure, refutes Countable Boolean Completeness.  Boolean Completeness fails at type $t$ (restoring the claim corrected earlier in the day): the truncation model of Appendix D, part 6, refutes it at type $t$, as its record now shows, and the components are complete for C, so one of them does; the root propositions false at every arrow except those into that component form a copy of its propositional domain under the root’s entailment order, and a root property of propositions holding exactly of the copies of the members of that component’s counterexample family has no least upper bound at the root. Cian Dorr’s argument, 23 September 2026.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, pp. 41–42 and n. 61; Appendix E, p. 83.

Record: `topics/classicism/models/coalesced-single-individual-root.yaml`.

#### Finite-support action model: dyadic roundings of N — `finite-support-dyadic-roundings`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `axiom-of-infinity-t-implies-infinity-t`, `fregean-incompatible-with-infinity-t`, `rigid-comprehension-r-implies-boolean-completeness-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-actuality`.

Model witness ids: `finite-support-dyadic-roundings`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance. Interpretation of Σ, fixed for this record: one designated relational constant $c$ of type $\tau=\bar\sigma t$ denotes $\lambda\bar x\, .\,a$, where $a$ is the unique true atom of the model, the actual-world proposition described above; every other relational constant denotes the top element of its type and every individual constant one fixed individual. Under it: No Contingency (signature Σ) fails, since the Σ-sentence $\forall\bar x\, .\,c\bar x$ denotes $a$, true and contingent; B for sentences of Σ fails, since under any arrow that no arrow composes back into $a$, $\Diamond a$ is false, so $\Box\Diamond a$ fails; Witnessed Possibility fails for the pure formula $x=\top_\tau$, witnessed by $\top_\tau$, since $\Diamond(c=\top_\tau)$ is $\Diamond\Box a$ and $a$ is necessary at no arrow; Separated Structure fails with it, being equivalent to Possibly Witnessed Possibility; Independence (signature Σ) and Distinctness (signature Σ) fail through the other relational constants, Σ being assumed to contain at least one: such a constant $c'$ of type $\tau'$ denotes what the closed pure term $\top_{\tau'}$ denotes, and $c'=\top_{\tau'}$ is a true identity that C(Σ) does not prove. The designated constant refutes neither: closed pure terms denote entities fixed by every arrow (Classicism, §3.5, p. 58), whereas $a$ is fixed by no arrow but the identity, so no closed pure term denotes $\lambda\bar x\, .\,a$. Everything that implies these fails with them. Countable Boolean Completeness fails as well, at type $e\to t$: the property $E$ that the source shows to lack a least upper bound has as its extension a countable family of haecceities, and the extensional fullness the source invokes to put $E$ in the domain also puts in the relation pairing the haecceity of the $k$-th member of that family with the numeral $k$, which injects $E$ into the numerals. Observation of 23 September 2026. Distinctness-preserving collapse holds: for a true proposition $p$ pinned down by a finite set take as the witness $q$ the actual-world proposition $\{f_1\}$: under $f_n$ with $n>1$, $\Diamond q$ would need $k\circ f_n$ to be the identity, impossible since $f_n$ is not injective. Relational Choice holds, necessarily. The model is ideally full, hence extensionally full at every object (Appendix D, the remark after Definition D.3): for any set $R$ of tuples from the domains at an object $V$, the intension that assigns to every arrow out of $V$ into an object $U$ a fixed set $R_U$ of tuples from $U$’s domains, with $R_V=R$, is pinned down by $\emptyset$, so it is the intension of an element of $V^{\bar\sigma\to t}$ with extension $R$ at $1_V$. Given a relation $U$ serial at $V$, choose for each $x$ a $y$ with $(Ux)y$, by choice in the metatheory; the graph is such an $R$, and its element $S$ is functional and a subrelation of $U$ at $1_V$, both conditions being unboxed. The closed Relational Choice instance is true at an arrow $h\colon W_0\to V$ iff it is true at $1_V$ in the truncation by $h$, whose domains at $V$ are those of the model, so it holds at every arrow and $\Box$Relational Choice follows. Cian Dorr’s observation of 23 September 2026.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 7, pp. 74, 78; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-dyadic-roundings.yaml`.

#### Finite-support action model: identity-or-collapse monotone surjections — `finite-support-identity-or-collapse-surjections`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `axiom-of-infinity-t-implies-infinity-t`, `fregean-incompatible-with-infinity-t`, `rigid-comprehension-r-implies-boolean-completeness-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-actuality`.

Model witness ids: `finite-support-identity-or-collapse-surjections`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance. Interpretation of Σ, fixed for this record: one designated relational constant $c$ of type $\tau=\bar\sigma t$ denotes $\lambda\bar x\, .\,a$, where $a$ is the unique true atom of the model, the actual-world proposition described above; every other relational constant denotes the top element of its type and every individual constant one fixed individual. Under it: No Contingency (signature Σ) fails, since the Σ-sentence $\forall\bar x\, .\,c\bar x$ denotes $a$, true and contingent; B for sentences of Σ fails, since under any arrow that no arrow composes back into $a$, $\Diamond a$ is false, so $\Box\Diamond a$ fails; Witnessed Possibility fails for the pure formula $x=\top_\tau$, witnessed by $\top_\tau$, since $\Diamond(c=\top_\tau)$ is $\Diamond\Box a$ and $a$ is necessary at no arrow; Separated Structure fails with it, being equivalent to Possibly Witnessed Possibility; Independence (signature Σ) and Distinctness (signature Σ) fail through the other relational constants, Σ being assumed to contain at least one: such a constant $c'$ of type $\tau'$ denotes what the closed pure term $\top_{\tau'}$ denotes, and $c'=\top_{\tau'}$ is a true identity that C(Σ) does not prove. The designated constant refutes neither: closed pure terms denote entities fixed by every arrow (Classicism, §3.5, p. 58), whereas $a$ is fixed by no arrow but the identity, so no closed pure term denotes $\lambda\bar x\, .\,a$. Everything that implies these fails with them. Countable Boolean Completeness fails as well, at type $e\to t$: the property $E$ that the source shows to lack a least upper bound has as its extension a countable family of haecceities, and the extensional fullness the source invokes to put $E$ in the domain also puts in the relation pairing the haecceity of the $k$-th member of that family with the numeral $k$, which injects $E$ into the numerals. Observation of 23 September 2026. Distinctness-preserving collapse holds: for a true proposition $p$ pinned down by a finite set take as the witness $q$ the actual-world proposition $\{1_{\mathbb N}\}$: under any other arrow $h$, $\Diamond q$ would need $k\circ h=1_{\mathbb N}$, impossible since $h$ is not injective. Relational Choice holds, necessarily. The model is ideally full, hence extensionally full at every object (Appendix D, the remark after Definition D.3): for any set $R$ of tuples from the domains at an object $V$, the intension that assigns to every arrow out of $V$ into an object $U$ a fixed set $R_U$ of tuples from $U$’s domains, with $R_V=R$, is pinned down by $\emptyset$, so it is the intension of an element of $V^{\bar\sigma\to t}$ with extension $R$ at $1_V$. Given a relation $U$ serial at $V$, choose for each $x$ a $y$ with $(Ux)y$, by choice in the metatheory; the graph is such an $R$, and its element $S$ is functional and a subrelation of $U$ at $1_V$, both conditions being unboxed. The closed Relational Choice instance is true at an arrow $h\colon W_0\to V$ iff it is true at $1_V$ in the truncation by $h$, whose domains at $V$ are those of the model, so it holds at every arrow and $\Box$Relational Choice follows. Cian Dorr’s observation of 23 September 2026.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 5, pp. 74, 78; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-identity-or-collapse-surjections.yaml`.

#### Finite-support action model: identity-or-collapse monotone maps — `finite-support-identity-or-collapse`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `axiom-of-infinity-t-implies-infinity-t`, `fregean-incompatible-with-infinity-t`, `rigid-comprehension-r-implies-boolean-completeness-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-actuality`.

Model witness ids: `finite-support-identity-or-collapse`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance. Interpretation of Σ, fixed for this record: one designated relational constant $c$ of type $\tau=\bar\sigma t$ denotes $\lambda\bar x\, .\,a$, where $a$ is the unique true atom of the model, the actual-world proposition described above; every other relational constant denotes the top element of its type and every individual constant one fixed individual. Under it: No Contingency (signature Σ) fails, since the Σ-sentence $\forall\bar x\, .\,c\bar x$ denotes $a$, true and contingent; B for sentences of Σ fails, since under any arrow that no arrow composes back into $a$, $\Diamond a$ is false, so $\Box\Diamond a$ fails; Witnessed Possibility fails for the pure formula $x=\top_\tau$, witnessed by $\top_\tau$, since $\Diamond(c=\top_\tau)$ is $\Diamond\Box a$ and $a$ is necessary at no arrow; Separated Structure fails with it, being equivalent to Possibly Witnessed Possibility; Independence (signature Σ) and Distinctness (signature Σ) fail through the other relational constants, Σ being assumed to contain at least one: such a constant $c'$ of type $\tau'$ denotes what the closed pure term $\top_{\tau'}$ denotes, and $c'=\top_{\tau'}$ is a true identity that C(Σ) does not prove. The designated constant refutes neither: closed pure terms denote entities fixed by every arrow (Classicism, §3.5, p. 58), whereas $a$ is fixed by no arrow but the identity, so no closed pure term denotes $\lambda\bar x\, .\,a$. Everything that implies these fails with them. Countable Boolean Completeness fails as well, at type $e\to t$: the property $E$ that the source shows to lack a least upper bound has as its extension a countable family of haecceities, and the extensional fullness the source invokes to put $E$ in the domain also puts in the relation pairing the haecceity of the $k$-th member of that family with the numeral $k$, which injects $E$ into the numerals. Observation of 23 September 2026. Distinctness-preserving collapse holds: for a true proposition $p$ pinned down by a finite set take as the witness $q$ the actual-world proposition $\{1_{\mathbb N}\}$: under any other arrow $h$, $\Diamond q$ would need $k\circ h=1_{\mathbb N}$, impossible since $h$ is not injective. Relational Choice holds, necessarily. The model is ideally full, hence extensionally full at every object (Appendix D, the remark after Definition D.3): for any set $R$ of tuples from the domains at an object $V$, the intension that assigns to every arrow out of $V$ into an object $U$ a fixed set $R_U$ of tuples from $U$’s domains, with $R_V=R$, is pinned down by $\emptyset$, so it is the intension of an element of $V^{\bar\sigma\to t}$ with extension $R$ at $1_V$. Given a relation $U$ serial at $V$, choose for each $x$ a $y$ with $(Ux)y$, by choice in the metatheory; the graph is such an $R$, and its element $S$ is functional and a subrelation of $U$ at $1_V$, both conditions being unboxed. The closed Relational Choice instance is true at an arrow $h\colon W_0\to V$ iff it is true at $1_V$ in the truncation by $h$, whose domains at $V$ are those of the model, so it holds at every arrow and $\Box$Relational Choice follows. Cian Dorr’s observation of 23 September 2026.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 4, pp. 74, 78 and n. 97; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-identity-or-collapse.yaml`.

#### Finite-support action model: monotone maps of N — `finite-support-monotone-maps`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-r-implies-atomicity-t`, `atomicity-t-incompatible-with-atomlessness`, `actuality-incompatible-with-atomlessness`, `rigid-comprehension-r-implies-actuality`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-possibility-signature-r`, `possibility-signature-r-implies-possibility-schema-r`, `no-pure-contingency-r-implies-pure-b-r`, `pure-b-and-pure-possibility-incompatible`.

Model witness ids: `finite-support-monotone-maps`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance. Interpretation of Σ, fixed for this record: one designated relational constant $c$ of type $\tau=\bar\sigma t$ denotes $\lambda\bar x\, .\,p_0$, where $p_0$ is the proposition that the arrow fixes $0$, pinned down by $\{0\}$; every other relational constant denotes the top element of its type and every individual constant one fixed individual. Under it No Contingency (signature Σ) fails, since $\forall\bar x\, .\,c\bar x$ denotes $p_0$, true and false at the constant map to $1$. Witnessed Possibility fails for the pure formula $x=\top_\tau$, witnessed by $\top_\tau$: $\Diamond(c=\top_\tau)$ is $\Diamond\Box p_0$, and $\Box p_0$ holds at no arrow $h$, since the constant map to $1$ composed after $h$ moves $0$. Separated Structure fails with it, being equivalent to Possibly Witnessed Possibility. Distinctness (signature Σ) fails by derivation, since Possibility (pure) fails here. Whether $c$ denotes what some closed pure term denotes is not settled, so Independence (signature Σ) is left unknown. The choice of a contingent rather than a pure denotation is deliberate: this is the only recorded model of Atomlessness in which No Contingency (signature Σ) is refuted, the others being one-object models with pure interpretations of the constants. Countable Boolean Completeness fails as well, at type $e\to t$: the property $E$ that the source shows to lack a least upper bound has as its extension a countable family of haecceities, and the extensional fullness the source invokes to put $E$ in the domain also puts in the relation pairing the haecceity of the $k$-th member of that family with the numeral $k$, which injects $E$ into the numerals. Observation of 23 September 2026. Distinctness-preserving collapse fails: the shift $h$ that fixes $0,\ldots,m-1$ and adds one to everything from $m$ on is a monotone injection, so for any true $q$ pinned down by a finite $Y$ a monotone $k$ with $k(hy)=y$ on $Y$ exists and $k\circ h\in q$; thus $\Diamond q$ holds at $h$, while the true proposition that $m$ is fixed is false there. Relational Choice holds, necessarily. The model is ideally full, hence extensionally full at every object (Appendix D, the remark after Definition D.3): for any set $R$ of tuples from the domains at an object $V$, the intension that assigns to every arrow out of $V$ into an object $U$ a fixed set $R_U$ of tuples from $U$’s domains, with $R_V=R$, is pinned down by $\emptyset$, so it is the intension of an element of $V^{\bar\sigma\to t}$ with extension $R$ at $1_V$. Given a relation $U$ serial at $V$, choose for each $x$ a $y$ with $(Ux)y$, by choice in the metatheory; the graph is such an $R$, and its element $S$ is functional and a subrelation of $U$ at $1_V$, both conditions being unboxed. The closed Relational Choice instance is true at an arrow $h\colon W_0\to V$ iff it is true at $1_V$ in the truncation by $h$, whose domains at $V$ are those of the model, so it holds at every arrow and $\Box$Relational Choice follows. Cian Dorr’s observation of 23 September 2026.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 3, pp. 74, 77; n. 96; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-monotone-maps.yaml`.

#### Finite-support action model: monotone surjections of N — `finite-support-monotone-surjections`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `atomlessness-implies-infinity-t`, `fregean-incompatible-with-infinity-t`, `atomicity-r-implies-atomicity-t`, `atomicity-t-incompatible-with-atomlessness`, `actuality-incompatible-with-atomlessness`, `rigid-comprehension-r-implies-actuality`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-barcan-r`.

Model witness ids: `finite-support-monotone-surjections`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance. Interpretation of Σ, fixed for this record: each relational constant denotes the top element of its type and each individual constant denotes one fixed individual. Under it the signature schemata fail. Let $c\in\Sigma$ have relational type $\tau$, so $c=\top_\tau$ necessarily. Witnessed Possibility fails for the pure formula $x\ne\top_\tau$, witnessed by $\bot_\tau$ but impossible of $c$; Separated Structure fails since $\lambda x\, .\,x$ and $\lambda x\, .\,\top_\tau$ agree on $c$ and differ; Independence (signature Σ) fails since $c$ denotes what the closed pure term $\top_\tau$ denotes; Distinctness (signature Σ) fails since $c=\top_\tau$ is a true identity that C(Σ) does not prove. Everything that implies these fails with them. Countable Boolean Completeness fails as well, at type $e\to t$: the property $E$ that the source shows to lack a least upper bound has as its extension a countable family of haecceities, and the extensional fullness the source invokes to put $E$ in the domain also puts in the relation pairing the haecceity of the $k$-th member of that family with the numeral $k$, which injects $E$ into the numerals. Observation of 23 September 2026. Distinctness-preserving collapse holds: for a true proposition $p$ pinned down by a finite set take as the witness $q$ the proposition that the arrow fixes $0,\ldots,N$ for $N$ beyond the pinning set. An arrow fixing $0,\ldots,N$ agrees with the identity on that set and so is in $p$. An arrow $h$ that does not, with least moved point $m\le N$, has $hm<m$ by monotone surjectivity and so collapses $m-1$ and $m$; then no $k\circ h$ can fix both, so $\Diamond q$ fails at $h$. Hence $\Box(\Diamond q\to p)$. Relational Choice holds, necessarily. The model is ideally full, hence extensionally full at every object (Appendix D, the remark after Definition D.3): for any set $R$ of tuples from the domains at an object $V$, the intension that assigns to every arrow out of $V$ into an object $U$ a fixed set $R_U$ of tuples from $U$’s domains, with $R_V=R$, is pinned down by $\emptyset$, so it is the intension of an element of $V^{\bar\sigma\to t}$ with extension $R$ at $1_V$. Given a relation $U$ serial at $V$, choose for each $x$ a $y$ with $(Ux)y$, by choice in the metatheory; the graph is such an $R$, and its element $S$ is functional and a subrelation of $U$ at $1_V$, both conditions being unboxed. The closed Relational Choice instance is true at an arrow $h\colon W_0\to V$ iff it is true at $1_V$ in the truncation by $h$, whose domains at $V$ are those of the model, so it holds at every arrow and $\Box$Relational Choice follows. Cian Dorr’s observation of 23 September 2026.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 2, pp. 74, 76–77; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-monotone-surjections.yaml`.

#### Finite-support action model: permutations of N — `finite-support-permutations`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-r-implies-atomicity-t`, `atomicity-t-incompatible-with-atomlessness`, `actuality-incompatible-with-atomlessness`, `c5-and-completeness-imply-actuality`, `rigid-comprehension-r-implies-actuality`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`, `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `atomlessness-implies-infinity-t`, `fregean-incompatible-with-infinity-t`.

Model witness ids: `finite-support-permutations`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance. Interpretation of Σ, fixed for this record: each relational constant denotes the top element of its type and each individual constant denotes one fixed individual $d$. Under it the signature schemata that give the constants a special role fail: with $c\in\Sigma$ of relational type $\tau$, $c=\top_\tau$ necessarily, so Witnessed Possibility fails for the pure formula $x\ne\top_\tau$, Separated Structure fails since $\lambda x\, .\,x$ and $\lambda x\, .\,\top_\tau$ agree on $c$, Independence (signature Σ) fails since $c$ denotes what a closed pure term denotes, and Distinctness (signature Σ) fails since $c=\top_\tau$ is true and unprovable. But No Contingency (signature Σ), and with it B for sentences of Σ, hold. The relational constants denote pure entities, so a closed Σ-sentence denotes what some $P(d,\ldots,d)$ denotes for a pure formula $P$; the model’s automorphisms carry every individual to every other, so $P(d,\ldots,d)$ is materially equivalent to the pure sentence $\forall x\, .\,P(x,\ldots,x)$ and its negation to $\forall x\, .\,\neg P(x,\ldots,x)$; whichever is true is necessary by No Pure Contingency, and instantiation under the box gives $\Box P(d,\ldots,d)$ or $\Box\neg P(d,\ldots,d)$. Boolean Completeness fails here through C5 and the failure of Actuality (Propositions 2.5–2.6), which gives nothing about countable families; but the part 2 argument transfers: the strongest persistent property pinned down by a finite $X$ whose extension contains the even numbers has, at an arrow $h$, the extension $h(X\cap\text{evens})\cup(\mathbb N\setminus hX)$, which strictly shrinks as $X$ grows, so the haecceities of the even numbers have no least upper bound. Countable Boolean Completeness fails as well, at type $e\to t$: the property $E$ that the source shows to lack a least upper bound has as its extension a countable family of haecceities, and the extensional fullness the source invokes to put $E$ in the domain also puts in the relation pairing the haecceity of the $k$-th member of that family with the numeral $k$, which injects $E$ into the numerals. Observation of 23 September 2026. Distinctness-preserving collapse fails: every arrow $h$ has an inverse, so for any true $q$ the arrow $q$-member$\circ h^{-1}$ carries $h$ into $q$, making $\Diamond q$ true everywhere; so $\Box(\Diamond q\to p)$ would need $p=\top$, and the true proposition that $0$ is fixed is not $\top$. Relational Choice holds, necessarily. The model is ideally full, hence extensionally full at every object (Appendix D, the remark after Definition D.3): for any set $R$ of tuples from the domains at an object $V$, the intension that assigns to every arrow out of $V$ into an object $U$ a fixed set $R_U$ of tuples from $U$’s domains, with $R_V=R$, is pinned down by $\emptyset$, so it is the intension of an element of $V^{\bar\sigma\to t}$ with extension $R$ at $1_V$. Given a relation $U$ serial at $V$, choose for each $x$ a $y$ with $(Ux)y$, by choice in the metatheory; the graph is such an $R$, and its element $S$ is functional and a subrelation of $U$ at $1_V$, both conditions being unboxed. The closed Relational Choice instance is true at an arrow $h\colon W_0\to V$ iff it is true at $1_V$ in the truncation by $h$, whose domains at $V$ are those of the model, so it holds at every arrow and $\Box$Relational Choice follows. Cian Dorr’s observation of 23 September 2026.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 1, pp. 74–76; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-permutations.yaml`.

#### Finite-support action model: qualitative contrast — `finite-support-qualitative-contrast`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `c5-and-atomicity-imply-necessary-plenitude`, `necessary-plenitude-r-implies-necessary-actuality`, `actuality-implies-persistent-comprehension-r`, `c5-and-persistent-comprehension-imply-gallin`, `gallin-comprehension-implies-nd`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`, `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `axiom-of-infinity-t-implies-infinity-t`, `fregean-incompatible-with-infinity-t`.

Model witness ids: `finite-support-qualitative-contrast`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Interpretation of Σ, fixed for this record: each relational constant denotes the top element of its type and each individual constant denotes one fixed individual. Under it the signature schemata fail. Let $c\in\Sigma$ have relational type $\tau$, so $c=\top_\tau$ necessarily. Witnessed Possibility fails for the pure formula $x\ne\top_\tau$, witnessed by $\bot_\tau$ but impossible of $c$; Separated Structure fails since $\lambda x\, .\,x$ and $\lambda x\, .\,\top_\tau$ agree on $c$ and differ; Independence (signature Σ) fails since $c$ denotes what the closed pure term $\top_\tau$ denotes; Distinctness (signature Σ) fails since $c=\top_\tau$ is a true identity that C(Σ) does not prove. Everything that implies these fails with them. Distinctness-preserving collapse fails at $W_0$: every arrow has an inverse, so $\Diamond q$ holds at every arrow for every true $q$, and $\Box(\Diamond q\to p)$ would force every true $p$ to contain every arrow; but the true proposition consisting of all arrows $W_0\to W_0$ together with the arrows into $W_1$ fixing $0$ is pinned down by $\{0\}$, meets the closure constraint, and omits arrows. Relational Choice is left unknown here: the construction constrains $W_i^t$ beyond ideal fullness, so the paper’s remark that ideally full models are extensionally full does not apply to it as stated, and no other argument has been checked.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, final construction (two copies of N).

Record: `topics/classicism/models/finite-support-qualitative-contrast.yaml`.

#### Finite-support action model: truncated shifts of N — `finite-support-truncated-shifts`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `axiom-of-infinity-t-implies-infinity-t`, `fregean-incompatible-with-infinity-t`, `rigid-comprehension-r-implies-boolean-completeness-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-actuality`.

Model witness ids: `finite-support-truncated-shifts`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance. Interpretation of Σ, fixed for this record: one designated relational constant $c$ of type $\tau=\bar\sigma t$ denotes $\lambda\bar x\, .\,a$, where $a$ is the unique true atom of the model, the actual-world proposition described above; every other relational constant denotes the top element of its type and every individual constant one fixed individual. Under it: No Contingency (signature Σ) fails, since the Σ-sentence $\forall\bar x\, .\,c\bar x$ denotes $a$, true and contingent; B for sentences of Σ fails, since under any arrow that no arrow composes back into $a$, $\Diamond a$ is false, so $\Box\Diamond a$ fails; Witnessed Possibility fails for the pure formula $x=\top_\tau$, witnessed by $\top_\tau$, since $\Diamond(c=\top_\tau)$ is $\Diamond\Box a$ and $a$ is necessary at no arrow; Separated Structure fails with it, being equivalent to Possibly Witnessed Possibility; Independence (signature Σ) and Distinctness (signature Σ) fail through the other relational constants, Σ being assumed to contain at least one: such a constant $c'$ of type $\tau'$ denotes what the closed pure term $\top_{\tau'}$ denotes, and $c'=\top_{\tau'}$ is a true identity that C(Σ) does not prove. The designated constant refutes neither: closed pure terms denote entities fixed by every arrow (Classicism, §3.5, p. 58), whereas $a$ is fixed by no arrow but the identity, so no closed pure term denotes $\lambda\bar x\, .\,a$. Everything that implies these fails with them. Countable Boolean Completeness fails as well, at type $e\to t$: the property $E$ that the source shows to lack a least upper bound has as its extension a countable family of haecceities, and the extensional fullness the source invokes to put $E$ in the domain also puts in the relation pairing the haecceity of the $k$-th member of that family with the numeral $k$, which injects $E$ into the numerals. Observation of 23 September 2026. Distinctness-preserving collapse holds: for a true proposition $p$ pinned down by a finite set take as the witness $q$ the actual-world proposition $\{k_0\}$: under $k_n$ with $n>0$, $\Diamond q$ would need $k\circ k_n$ to be the identity, impossible since $k_n$ is not injective. Relational Choice holds, necessarily. The model is ideally full, hence extensionally full at every object (Appendix D, the remark after Definition D.3): for any set $R$ of tuples from the domains at an object $V$, the intension that assigns to every arrow out of $V$ into an object $U$ a fixed set $R_U$ of tuples from $U$’s domains, with $R_V=R$, is pinned down by $\emptyset$, so it is the intension of an element of $V^{\bar\sigma\to t}$ with extension $R$ at $1_V$. Given a relation $U$ serial at $V$, choose for each $x$ a $y$ with $(Ux)y$, by choice in the metatheory; the graph is such an $R$, and its element $S$ is functional and a subrelation of $U$ at $1_V$, both conditions being unboxed. The closed Relational Choice instance is true at an arrow $h\colon W_0\to V$ iff it is true at $1_V$ in the truncation by $h$, whose domains at $V$ are those of the model, so it holds at every arrow and $\Box$Relational Choice follows. Cian Dorr’s observation of 23 September 2026.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 8, pp. 74, 78–79; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-truncated-shifts.yaml`.

#### Finite-support action model: truncations of N — `finite-support-truncations`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `axiom-of-infinity-t-implies-infinity-t`, `fregean-incompatible-with-infinity-t`, `atomicity-and-bf-imply-necessary-actuality`, `necessary-actuality-implies-actuality`, `rigid-comprehension-r-implies-actuality`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`.

Model witness ids: `finite-support-truncations`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Boxed positive flags use the source’s explicit one-object No Pure Contingency observation, applied separately to each closed instance. Interpretation of Σ, fixed for this record: each relational constant denotes the top element of its type and each individual constant denotes one fixed individual. Under it the signature schemata fail. Let $c\in\Sigma$ have relational type $\tau$, so $c=\top_\tau$ necessarily. Witnessed Possibility fails for the pure formula $x\ne\top_\tau$, witnessed by $\bot_\tau$ but impossible of $c$; Separated Structure fails since $\lambda x\, .\,x$ and $\lambda x\, .\,\top_\tau$ agree on $c$ and differ; Independence (signature Σ) fails since $c$ denotes what the closed pure term $\top_\tau$ denotes; Distinctness (signature Σ) fails since $c=\top_\tau$ is a true identity that C(Σ) does not prove. Everything that implies these fails with them. Countable Boolean Completeness fails as well, at type $e\to t$: the property $E$ that the source shows to lack a least upper bound has as its extension a countable family of haecceities, and the extensional fullness the source invokes to put $E$ in the domain also puts in the relation pairing the haecceity of the $k$-th member of that family with the numeral $k$, which injects $E$ into the numerals. Observation of 23 September 2026. Distinctness-preserving collapse holds: for a true proposition $p$ pinned down by a finite set take as the witness $q$ the strongest true proposition pinned down by $\{0,\ldots,N\}$ for $N$ beyond the pinning set of $p$, namely $\{1_{\mathbb N}\}\cup\{g_m:m\ge N\}$. Under $g_n$ the only arrows reachable are $g_m$ with $m\le n$, so $\Diamond q$ holds at $g_n$ only if $n\ge N$, and then $g_n$ agrees with the identity on the pinning set of $p$ and is in $p$. Boolean Completeness fails at type $t$ as well, which the source (n. 92) conjectures but does not show. Let $X$ be the family of singletons $\{g_n\}$ for even $n$. An upper bound of $X$ pinned down by $\{0,\ldots,N\}$ contains, with any $g_m$ for $m\ge N$, every arrow agreeing with it on $\{0,\ldots,N\}$, so the least upper bound pinned down by that set is $X\cup\{1_{\mathbb N}\}\cup\{g_m : m\ge N\}$, which strictly shrinks as $N$ grows; hence $X$ has no least upper bound. $X$ is the extension of an element of the domain at type $t\to t$: the profile $\Phi\langle h,p\rangle:=\{i : i^tp\in X\}$ satisfies the coherence condition $i^t\Phi\langle h,p\rangle=\Phi\langle i\circ h,i^tp\rangle$, and each of its values is pinned down by a finite set, the value at $\{g_n\}$ being $\{1_{\mathbb N}\}\cup\{g_m : m>n\}$, pinned down by $\{0,\ldots,n+1\}$, and the value at other propositions being computed likewise from the truncation order. Observation of Claude Fable 5.1 (Anthropic), 23 September 2026, prompted by Cian Dorr; not in the source. Relational Choice holds, necessarily. The model is ideally full, hence extensionally full at every object (Appendix D, the remark after Definition D.3): for any set $R$ of tuples from the domains at an object $V$, the intension that assigns to every arrow out of $V$ into an object $U$ a fixed set $R_U$ of tuples from $U$’s domains, with $R_V=R$, is pinned down by $\emptyset$, so it is the intension of an element of $V^{\bar\sigma\to t}$ with extension $R$ at $1_V$. Given a relation $U$ serial at $V$, choose for each $x$ a $y$ with $(Ux)y$, by choice in the metatheory; the graph is such an $R$, and its element $S$ is functional and a subrelation of $U$ at $1_V$, both conditions being unboxed. The closed Relational Choice instance is true at an arrow $h\colon W_0\to V$ iff it is true at $1_V$ in the truncation by $h$, whose domains at $V$ are those of the model, so it holds at every arrow and $\Box$Relational Choice follows. Cian Dorr’s observation of 23 September 2026.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 6, pp. 74, 78; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-truncations.yaml`.

#### Finite-support action model: N and singleton, all maps — `finite-support-two-object-all-maps`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-possibility-signature-r`, `possibility-signature-r-implies-possibility-schema-r`, `possibility-and-necessary-relational-choice-incompatible`.

Model witness ids: `finite-support-two-object-all-maps`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Interpretation of Σ, fixed for this record: each relational constant denotes the top element of its type and each individual constant denotes one fixed individual. Under it the signature schemata fail. Let $c\in\Sigma$ have relational type $\tau$, so $c=\top_\tau$ necessarily. Witnessed Possibility fails for the pure formula $x\ne\top_\tau$, witnessed by $\bot_\tau$ but impossible of $c$; Separated Structure fails since $\lambda x\, .\,x$ and $\lambda x\, .\,\top_\tau$ agree on $c$ and differ; Independence (signature Σ) fails since $c$ denotes what the closed pure term $\top_\tau$ denotes; Distinctness (signature Σ) fails since $c=\top_\tau$ is a true identity that C(Σ) does not prove. Everything that implies these fails with them. Distinctness-preserving collapse fails at $W_0$: the transposition of $5$ and $6$ is an arrow with an inverse, so for any true $q$ the composite of a member of $q$ with the inverse carries the transposition into $q$, making $\Diamond q$ true there, while the true proposition that $5$ is fixed is false there. Relational Choice holds, necessarily. The model is ideally full, hence extensionally full at every object (Appendix D, the remark after Definition D.3): for any set $R$ of tuples from the domains at an object $V$, the intension that assigns to every arrow out of $V$ into an object $U$ a fixed set $R_U$ of tuples from $U$’s domains, with $R_V=R$, is pinned down by $\emptyset$, so it is the intension of an element of $V^{\bar\sigma\to t}$ with extension $R$ at $1_V$. Given a relation $U$ serial at $V$, choose for each $x$ a $y$ with $(Ux)y$, by choice in the metatheory; the graph is such an $R$, and its element $S$ is functional and a subrelation of $U$ at $1_V$, both conditions being unboxed. The closed Relational Choice instance is true at an arrow $h\colon W_0\to V$ iff it is true at $1_V$ in the truncation by $h$, whose domains at $V$ are those of the model, so it holds at every arrow and $\Box$Relational Choice follows. Cian Dorr’s observation of 23 September 2026.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, paragraph beginning “One particularly interesting result”.

Record: `topics/classicism/models/finite-support-two-object-all-maps.yaml`.

#### Full action model: free monoid on countably many generators, glued constants, thread individuals — `full-free-monoid-glued-constants`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `axiom-of-infinity-t-implies-infinity-t`, `fregean-incompatible-with-infinity-t`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-distinctness-necessary-r`, `logical-necessity-r-implies-separated-structure-r`, `separated-structure-incompatible-with-nd`, `necessary-barcan-r-implies-necessary-barcan-t`, `possibility-and-necessary-barcan-t-incompatible`.

Model witness ids: `full-free-monoid-glued-constants`.

Original record notes:

Promoted from conjectured on 22 September 2026. The gap in the source was its Theorem A.8, stated without proof, and the deferred type-e case; the write-up closes both by choosing a self-similar individual domain and applying the book’s coalesced sums. The signature is assumed countable; for a larger signature use a tree with as many branches. Distinct constants of one type denote distinct entities at the root, since every domain, including the individuals, has more than one element; they are also possibly identical. ND and B fail at type t already. Possibility (pure) fails because Actuality is necessary while its negation is consistent with C. Everything else follows from the listed principles by the map’s results. Bacon’s interpretation of his predicates Pure and Fun in this model, and the principles stated with them, are not recorded, following Zachary Goodsell’s decision to keep the map to the logical vocabulary and the constants of Σ. □Relational Choice holds: every truncation is a standard model over a frame isomorphic to the original, and Relational Choice holds in every full model given choice in the metatheory. Distinctness-preserving collapse holds: let $a$ be the proposition true at the actual world alone (the identity arrow). For any true $p$, take $q:=a$ in the definition of $\Box_{\ne}p$: under a non-identity arrow $i$, $\Diamond a$ would need an arrow $k$ with $k\circ i$ the identity, and none exists, since no arrow leads back to the actual world; under the identity, $p$ holds. So every truth is $\Box_{\ne}$-necessary, although ND fails.

- **Logical Combinatorialism** — Andrew Bacon, Logical Combinatorialism, Philosophical Review 129 (2020), Appendix A.2–A.3, pp. 580–587; §2, n. 15, p. 547; §4, n. 48, p. 566.
- **Philosophical Introduction to HOL** — Andrew Bacon, A Philosophical Introduction to Higher-Order Logics, Routledge, 2024, §18.1, Definition 18.1, pp. 391–392; §18.3, Definition 18.6, p. 395; §18.6, Definitions 18.14–18.15, Proposition 18.7, Theorem 18.5 and Exercise 18.23, pp. 405–410.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.4–3.5, pp. 55–61 (full action models and the principles they validate); Appendix E, pp. 80–83 (truncations).
- **Fable 22 Sep** — Claude Fable 5.1 (Anthropic), verification of 22 September 2026 (see the write-up).

Record: `topics/classicism/models/full-free-monoid-glued-constants.yaml`.

#### Full action model: idempotent two-arrow monoid — `full-idempotent-monoid`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t`, `necessary-distinctness-necessary-t-implies-distinctness-necessary-t`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-actuality`.

Model witness ids: `full-idempotent-monoid`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Interpretation of Σ, fixed for this record: one designated relational constant $c$ of type $\tau=\bar\sigma t$ denotes $\lambda\bar x\, .\,a$, where $a$ is the unique true atom of the model, the actual-world proposition described above; every other relational constant denotes the top element of its type and every individual constant one fixed individual. Under it: No Contingency (signature Σ) fails, since the Σ-sentence $\forall\bar x\, .\,c\bar x$ denotes $a$, true and contingent; B for sentences of Σ fails, since under any arrow that no arrow composes back into $a$, $\Diamond a$ is false, so $\Box\Diamond a$ fails; Witnessed Possibility fails for the pure formula $x=\top_\tau$, witnessed by $\top_\tau$, since $\Diamond(c=\top_\tau)$ is $\Diamond\Box a$ and $a$ is necessary at no arrow; Separated Structure fails with it, being equivalent to Possibly Witnessed Possibility; Independence (signature Σ) and Distinctness (signature Σ) fail through the other relational constants, Σ being assumed to contain at least one: such a constant $c'$ of type $\tau'$ denotes what the closed pure term $\top_{\tau'}$ denotes, and $c'=\top_{\tau'}$ is a true identity that C(Σ) does not prove. The designated constant refutes neither: closed pure terms denote entities fixed by every arrow (Classicism, §3.5, p. 58), whereas $a$ is fixed by no arrow but the identity, so no closed pure term denotes $\lambda\bar x\, .\,a$. Everything that implies these fails with them. In a one-object action model whose propositions are all the sets of arrows, every singleton $\{h\}$ is a strong world proposition: seen from an arrow $i$ it becomes $\{j : j\circ i=h\}$, and every proposition at that world is the shift $\{j : j\circ i\in Y\}$ of a root proposition $Y$, whose membership for such $j$ depends only on whether $h\in Y$; so it entails every proposition or its negation, at every world. Any possible proposition contains some arrow, so the type-t Strong Leibniz Biconditionals hold at every world. □Relational Choice holds: the truncation of a full action model at any arrow is again a full action model, its domains at the reachable objects being unchanged, and Relational Choice holds in every full model given choice in the metatheory (Classicism, p. 61). Distinctness-preserving collapse holds: for a true $p$ take $q:=\{1\}$; under $k$, $\Diamond\{1\}$ would need $x\circ k=1$, but $x\circ k=k$ for both arrows, so it fails there, and under $1$, $p$ holds.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, first paragraph; p. 61 (full-model principles).

Record: `topics/classicism/models/full-idempotent-monoid.yaml`.

#### Full action model: two-element group — `full-involution-group`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-distinctness-necessary-r-implies-distinctness-necessary-r`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-actuality`.

Model witness ids: `full-involution-group`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Interpretation of Σ, fixed for this record: one designated relational constant $c$ of type $\tau=\bar\sigma t$ denotes $\lambda\bar x\, .\,a$, where $a$ is the unique true atom of the model, the actual-world proposition described above; every other relational constant denotes the top element of its type and every individual constant one fixed individual. Under it: No Contingency (signature Σ) fails, since the Σ-sentence $\forall\bar x\, .\,c\bar x$ denotes $a$, true and contingent; Witnessed Possibility fails for the pure formula $x=\top_\tau$, witnessed by $\top_\tau$, since $\Diamond(c=\top_\tau)$ is $\Diamond\Box a$ and $a$ is necessary at no arrow; Separated Structure fails with it, being equivalent to Possibly Witnessed Possibility; Independence (signature Σ) and Distinctness (signature Σ) fail through the other relational constants, Σ being assumed to contain at least one: such a constant $c'$ of type $\tau'$ denotes what the closed pure term $\top_{\tau'}$ denotes, and $c'=\top_{\tau'}$ is a true identity that C(Σ) does not prove. The designated constant refutes neither: closed pure terms denote entities fixed by every arrow (Classicism, §3.5, p. 58), whereas $a$ is fixed by no arrow but the identity, so no closed pure term denotes $\lambda\bar x\, .\,a$. Everything that implies these fails with them. In a one-object action model whose propositions are all the sets of arrows, every singleton $\{h\}$ is a strong world proposition: seen from an arrow $i$ it becomes $\{j : j\circ i=h\}$, and every proposition at that world is the shift $\{j : j\circ i\in Y\}$ of a root proposition $Y$, whose membership for such $j$ depends only on whether $h\in Y$; so it entails every proposition or its negation, at every world. Any possible proposition contains some arrow, so the type-t Strong Leibniz Biconditionals hold at every world. □Relational Choice holds: the truncation of a full action model at any arrow is again a full action model, its domains at the reachable objects being unchanged, and Relational Choice holds in every full model given choice in the metatheory (Classicism, p. 61).

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, second paragraph; p. 61.

Record: `topics/classicism/models/full-involution-group.yaml`.

#### Full action model: surjections of an infinite set — `full-surjection-monoid`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-actuality`.

Model witness ids: `full-surjection-monoid`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Interpretation of Σ, fixed for this record: each relational constant denotes the top element of its type and each individual constant denotes one fixed individual $d$. Under it the signature schemata that give the constants a special role fail: with $c\in\Sigma$ of relational type $\tau$, $c=\top_\tau$ necessarily, so Witnessed Possibility fails for the pure formula $x\ne\top_\tau$, Separated Structure fails since $\lambda x\, .\,x$ and $\lambda x\, .\,\top_\tau$ agree on $c$, Independence (signature Σ) fails since $c$ denotes what a closed pure term denotes, and Distinctness (signature Σ) fails since $c=\top_\tau$ is true and unprovable. But No Contingency (signature Σ), and with it B for sentences of Σ, hold. The relational constants denote pure entities, so a closed Σ-sentence denotes what some $P(d,\ldots,d)$ denotes for a pure formula $P$; the model’s automorphisms carry every individual to every other, so $P(d,\ldots,d)$ is materially equivalent to the pure sentence $\forall x\, .\,P(x,\ldots,x)$ and its negation to $\forall x\, .\,\neg P(x,\ldots,x)$; whichever is true is necessary by No Pure Contingency, and instantiation under the box gives $\Box P(d,\ldots,d)$ or $\Box\neg P(d,\ldots,d)$. In a one-object action model whose propositions are all the sets of arrows, every singleton $\{h\}$ is a strong world proposition: seen from an arrow $i$ it becomes $\{j : j\circ i=h\}$, and every proposition at that world is the shift $\{j : j\circ i\in Y\}$ of a root proposition $Y$, whose membership for such $j$ depends only on whether $h\in Y$; so it entails every proposition or its negation, at every world. Any possible proposition contains some arrow, so the type-t Strong Leibniz Biconditionals hold at every world. □Relational Choice holds: the truncation of a full action model at any arrow is again a full action model, its domains at the reachable objects being unchanged, and Relational Choice holds in every full model given choice in the metatheory (Classicism, p. 61). Distinctness-preserving collapse fails: let $p:=\{\mathrm{id}\}$, true. Any witness $q$ for $\Box_{\ne}p$ is true, so contains the identity, and for a non-identity bijection $i$ the arrow $i^{-1}$ gives $i^{-1}\circ i\in q$, so $\Diamond q$ holds under $i$ while $p$ does not. So no true $q$ has $\Box(\Diamond q\to p)$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: two-object chain — `full-two-object-chain`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-actuality`.

Model witness ids: `full-two-object-chain`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Interpretation of Σ, fixed for this record: each relational constant denotes the top element of its type and each individual constant denotes one fixed individual. Under it the signature schemata fail. Let $c\in\Sigma$ have relational type $\tau$, so $c=\top_\tau$ necessarily. Witnessed Possibility fails for the pure formula $x\ne\top_\tau$, witnessed by $\bot_\tau$ but impossible of $c$; Separated Structure fails since $\lambda x\, .\,x$ and $\lambda x\, .\,\top_\tau$ agree on $c$ and differ; Independence (signature Σ) fails since $c$ denotes what the closed pure term $\top_\tau$ denotes; Distinctness (signature Σ) fails since $c=\top_\tau$ is a true identity that C(Σ) does not prove. Everything that implies these fails with them. The type-t Strong Leibniz Biconditionals hold necessarily: at $W_0$ the singleton $\{k\}$ becomes $\{\mathrm{id}_{W_1}\}$ under $k$ and $\{\mathrm{id}_{W_0}\}$ becomes empty, so both singletons are strong worlds; at $W_1$ there is one arrow and one non-bottom proposition. □Relational Choice holds: the truncation of a full action model at any arrow is again a full action model, its domains at the reachable objects being unchanged, and Relational Choice holds in every full model given choice in the metatheory (Classicism, p. 61). Distinctness-preserving collapse holds: let $a$ be the proposition true at the actual world alone (the identity arrow). For any true $p$, take $q:=a$ in the definition of $\Box_{\ne}p$: under a arrow $k$ to $W_1$, $\Diamond a$ would need an arrow back to $W_0$, and none exists, since no arrow leads back to the actual world; under the identity, $p$ holds. So every truth is $\Box_{\ne}$-necessary, although ND fails.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fourth paragraph; p. 61.

Record: `topics/classicism/models/full-two-object-chain.yaml`.

#### Full action model: two-object retract — `full-two-object-retract`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `no-pure-contingency-and-nd-t-imply-necessary-nd-t`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-signature-b-r`, `signature-b-and-witnessed-possibility-incompatible`, `modal-b-implies-distinctness-necessary-r`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-actuality`, `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-distinctness-necessary-t`.

Model witness ids: `full-two-object-retract`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Interpretation of Σ, fixed for this record: each relational constant denotes the top element of its type and each individual constant denotes one fixed individual. Under it the signature schemata fail. Let $c\in\Sigma$ have relational type $\tau$, so $c=\top_\tau$ necessarily. Witnessed Possibility fails for the pure formula $x\ne\top_\tau$, witnessed by $\bot_\tau$ but impossible of $c$; Separated Structure fails since $\lambda x\, .\,x$ and $\lambda x\, .\,\top_\tau$ agree on $c$ and differ; Independence (signature Σ) fails since $c$ denotes what the closed pure term $\top_\tau$ denotes; Distinctness (signature Σ) fails since $c=\top_\tau$ is a true identity that C(Σ) does not prove. Everything that implies these fails with them. The type-t Strong Leibniz Biconditionals fail at $W_0$: the possible proposition $\{h\}$ has only itself as a candidate strong world below it, but under $h$ it becomes $\{x : x\circ h=h\}=\{\mathrm{id}_{W_1},k\}$, which the proposition $\{\mathrm{id}_{W_1}\}$ of $W_1$’s full domain separates, so $\{h\}$ does not necessarily settle every proposition. Since Atomicity holds in this full model, this shows that Atomicity (type t) alone does not yield the type-t Strong Leibniz Biconditionals; BF (type t) fails here, $h$ acting non-surjectively from a four-element to an eight-element domain. □Relational Choice holds: the truncation of a full action model at any arrow is again a full action model, its domains at the reachable objects being unchanged, and Relational Choice holds in every full model given choice in the metatheory (Classicism, p. 61). Distinctness-preserving collapse fails at $W_0$: let $p:=\{\mathrm{id}_{W_0}\}$, true. A witness $q$ contains $\mathrm{id}_{W_0}$, and $j\circ h=\mathrm{id}_{W_0}$, so $\Diamond q$ holds under $h$ while $p$ does not.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fifth paragraph and n. 81; p. 61.

Record: `topics/classicism/models/full-two-object-retract.yaml`.

#### Henkin model: base without a choice function — `henkin-without-relational-choice`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-no-contingency-signature-r`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-distinctness-necessary-r`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `extensionality-r-implies-rigid-comprehension-r`, `maximalist-distinctness-incompatible-with-rigid-comprehension`.

Model witness ids: `henkin-without-relational-choice`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Interpretation of Σ, fixed for this record: each relational constant denotes the top element of its type and each individual constant denotes one fixed individual. Under it the signature schemata fail. Let $c\in\Sigma$ have relational type $\tau$, so $c=\top_\tau$ necessarily. Witnessed Possibility fails for the pure formula $x\ne\top_\tau$, witnessed by $\bot_\tau$ but impossible of $c$; Separated Structure fails since $\lambda x\, .\,x$ and $\lambda x\, .\,\top_\tau$ agree on $c$ and differ; Independence (signature Σ) fails since $c$ denotes what the closed pure term $\top_\tau$ denotes; Distinctness (signature Σ) fails since $c=\top_\tau$ is a true identity that C(Σ) does not prove. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, n. 46, p. 32.

Record: `topics/classicism/models/henkin-without-relational-choice.yaml`.

### 1.3 Incompatible with background (0)

None.

## 2. Lynchpin conjectures

Answering a lynchpin conjecture settles many other open questions. A question is S ⇒ c for S at most two principle classes (True, with none) and c a class or False, asked only where no smaller premise set already proves or excludes c; S ⇒ False asks whether S is consistent. A question is settled alike by a proof, by an exclusion (S ∧ c ⇒ False) or by a recorded model that holds S and fails c. Each row scores an open question by the number of *other* open questions that stop being open once the answer joins the proved records. Both answers are scored, because proving a strong conjecture settles everything below it while refuting a weak one settles everything above it; a question with two high scores is worth answering either way. A refutation is scored by its least informative countermodel, so an actual model settles at least as much. A model check (model: principle) scores deciding an unknown verdict inside a recorded model, which settles questions exactly as a proof does. Under a background, only models of that background count and the class of its theorems is named after it (True, with no preset). Recompute with `python3 scripts/pmap.py lynchpins classicism`.

### Under no extra assumptions

56 classes and 32 fitting models; 11879 open questions. 72% of questions with up to two premises settled (31048 of 42927).

| Question | if yes | if no |
|---|---:|---:|
| Atomicity (type t) ⇒ □Atomicity | 945 | 0 |
| B for pure sentences ∧ Strong Leibniz Biconditionals (type t) ⇒ Modal Freedom (signature Σ) | 881 | 0 |
| Strong Leibniz Biconditionals (type t) ⇒ □Actuality | 870 | 0 |
| Atomicity (type t) ∧ Infinity Schema (type t) ⇒ □Strong Leibniz Biconditionals | 856 | 0 |
| Atomicity (type t) ∧ Possible Infinity (type e) ⇒ □Strong Leibniz Biconditionals | 856 | 0 |

### Under C5

34 classes and 8 fitting models; 986 open questions. 60% of questions with up to two premises settled (1487 of 2473).

| Question | if yes | if no |
|---|---:|---:|
| Independence (signature Σ) ⇒ False (⊥) | 324 | 0 |
| Independence (signature Σ) ∧ Necessity of Arithmetic ⇒ False (⊥) | 236 | 1 |
| Independence (signature Σ) ⇒ Distinctness-preserving collapse | 224 | 1 |
| Relational Choice ⇒ Modal Freedom (signature Σ) | 213 | 0 |
| Independence (signature Σ) ⇒ □Functional Choice | 173 | 1 |

### Under C5 + Atomicity

26 classes and 6 fitting models; 227 open questions. 55% of questions with up to two premises settled (287 of 514).

| Question | if yes | if no |
|---|---:|---:|
| Independence (signature Σ) ⇒ False (⊥) | 97 | 0 |
| True (⊤) ⇒ Modal Freedom (signature Σ) | 65 | 0 |
| Independence (signature Σ) ⇒ Distinctness-preserving collapse | 59 | 1 |
| Converse Witnessed Possibility ∧ Independence (signature Σ) ⇒ False (⊥) | 57 | 1 |
| Independence (signature Σ) ∧ Modal Freedom (signature Σ) ⇒ False (⊥) | 43 | 2 |

### Under Extensionalism

22 classes and 3 fitting models; 16 open questions. 76% of questions with up to two premises settled (51 of 67).

| Question | if yes | if no |
|---|---:|---:|
| Independence (signature Σ) ⇒ False (⊥) | 11 | 0 |
| Independence (signature Σ) ∧ Infinity Schema (type e) ⇒ False (⊥) | 8 | 1 |
| Axiom of Infinity (type e) ∧ Independence (signature Σ) ⇒ Functional Choice | 0 | 7 |
| Functional Choice ∧ Independence (signature Σ) ⇒ False (⊥) | 5 | 1 |
| Functional Choice ∧ Independence (signature Σ) ⇒ Infinity Schema (type e) | 0 | 5 |

### Under Pure Maximalist Classicism

64 classes and 3 fitting models; 2668 open questions. 24% of questions with up to two premises settled (868 of 3536).

| Question | if yes | if no |
|---|---:|---:|
| Atomicity (type t) ⇒ False (⊥) | 1226 | 0 |
| True (⊤) ⇒ Distinctness-preserving collapse | 916 | 0 |
| Strong Leibniz Biconditionals (type t) ⇒ False (⊥) | 751 | 1 |
| BF (type t) ⇒ False (⊥) | 688 | 0 |
| Atomicity ⇒ False (⊥) | 661 | 1 |

## 3. Open questions under each recorded package

The most useful place to work: these are open *given* assumptions the sources already make.

### C5

Assuming `necessary-distinctness-necessary-r`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### C5 + Atomicity

Assuming `necessary-distinctness-necessary-r`, `atomicity-r`, these remain open:

- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- No Pure Contingency (`no-pure-contingency-r`)

### Pure Maximalist Classicism

Assuming `distinctness-schema-r`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Distinctness (signature Σ) (`distinctness-signature-r`)
- General Separated Structure (`general-separated-structure-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Possibility (signature Σ) (`possibility-signature-r`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### □Atomicity + Boolean Completeness + BF

Assuming `necessary-atomicity-r`, `boolean-completeness-r`, `barcan-r`, these remain open:

- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- B for pure sentences (`pure-b-r`)

### Boolean Completeness + Actuality

Assuming `boolean-completeness-r`, `actuality`, these remain open:

- B for pure sentences (`pure-b-r`)

### No Pure Contingency + Actuality

Assuming `no-pure-contingency-r`, `actuality`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Atomicity + BF

Assuming `atomicity-r`, `barcan-r`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- □Tractarianism (`necessary-tractarianism-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- No Pure Contingency (`no-pure-contingency-r`)
- B for pure sentences (`pure-b-r`)

### No Pure Contingency + Atomicity

Assuming `no-pure-contingency-r`, `atomicity-r`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- Strong Leibniz Biconditionals (type t) (`strong-leibniz-t`)

### Atomicity (type t) + BF

Assuming `atomicity-t`, `barcan-r`, these remain open:

- Atomicity (`atomicity-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- □Tractarianism (`necessary-tractarianism-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- B for pure sentences (`pure-b-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)

### Atomicity (type t) + BF (type t)

Assuming `atomicity-t`, `barcan-t`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- Atomicity (`atomicity-r`)
- BF (`barcan-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- □Tractarianism (`necessary-tractarianism-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Persistent Comprehension (`persistent-comprehension-r`)
- B for pure sentences (`pure-b-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Tractarianism (`tractarianism-r`)

### ND + BF

Assuming `distinctness-necessary-r`, `barcan-r`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### No Pure Contingency + BF

Assuming `no-pure-contingency-r`, `barcan-r`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Possible Infinity (type e) + BF

Assuming `possible-infinity-e`, `barcan-r`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Relational Choice (`necessary-relational-choice-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)

### Rigid Comprehension + BF

Assuming `rigid-comprehension-r`, `barcan-r`, these remain open:

- B for pure sentences (`pure-b-r`)

### No Pure Contingency + BF (type t)

Assuming `no-pure-contingency-r`, `barcan-t`, these remain open:

- BF (`barcan-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □BF (`necessary-barcan-r`)
- □Functionality (`necessary-functionality-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Tractarianism (`tractarianism-r`)

### Possible Infinity (type t) + BF (type t)

Assuming `possible-infinity-t`, `barcan-t`, these remain open:

- BF (`barcan-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Relational Choice (`necessary-relational-choice-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Tractarianism (`tractarianism-r`)

### No Pure Contingency + Boolean Completeness

Assuming `no-pure-contingency-r`, `boolean-completeness-r`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + ND

Assuming `no-pure-contingency-r`, `distinctness-necessary-r`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Rigid Comprehension + ND

Assuming `rigid-comprehension-r`, `distinctness-necessary-r`, these remain open:

- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)

### No Pure Contingency + ND (type t)

Assuming `no-pure-contingency-r`, `distinctness-necessary-t`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Distinctness (pure) + Separated Structure

Assuming `distinctness-schema-r`, `separated-structure-r`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Relational Choice (`relational-choice-r`)

### No Pure Contingency + Functional Choice

Assuming `no-pure-contingency-r`, `functional-choice-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Functionality

Assuming `no-pure-contingency-r`, `functionality-r`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Gallin Extensional Comprehension

Assuming `no-pure-contingency-r`, `gallin-extensional-comprehension-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + B

Assuming `no-pure-contingency-r`, `modal-b`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + 5

Assuming `no-pure-contingency-r`, `modal-five`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### □ND + □Actuality

Assuming `necessary-distinctness-necessary-r`, `necessary-actuality`, these remain open:

- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- No Pure Contingency (`no-pure-contingency-r`)

### □Atomicity + □BF

Assuming `necessary-atomicity-r`, `necessary-barcan-r`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- No Pure Contingency (`no-pure-contingency-r`)
- B for pure sentences (`pure-b-r`)

### □Atomicity + □BF (type t)

Assuming `necessary-atomicity-r`, `necessary-barcan-t`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- BF (`barcan-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Actuality (`necessary-actuality`)
- □BF (`necessary-barcan-r`)
- □Functionality (`necessary-functionality-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- No Pure Contingency (`no-pure-contingency-r`)
- Persistent Comprehension (`persistent-comprehension-r`)
- B for pure sentences (`pure-b-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Tractarianism (`tractarianism-r`)

### □ND + □Boolean Completeness

Assuming `necessary-distinctness-necessary-r`, `necessary-boolean-completeness-r`, these remain open:

- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- No Pure Contingency (`no-pure-contingency-r`)

### □ND + □Rigid Comprehension

Assuming `necessary-distinctness-necessary-r`, `necessary-rigid-comprehension-r`, these remain open:

- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- No Pure Contingency (`no-pure-contingency-r`)

### □Relational Choice + □Plenitude

Assuming `necessary-relational-choice-r`, `necessary-plenitude-r`, these remain open:

- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- No Pure Contingency (`no-pure-contingency-r`)

### □Strong Leibniz Biconditionals + Rigid Comprehension

Assuming `necessary-strong-leibniz-r`, `rigid-comprehension-r`, these remain open:

- BF (`barcan-r`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Functionality (`functionality-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Actuality (`necessary-actuality`)
- □BF (`necessary-barcan-r`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Functionality (`necessary-functionality-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- B for pure sentences (`pure-b-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Tractarianism (`tractarianism-r`)

### No Pure Contingency + Plenitude

Assuming `no-pure-contingency-r`, `plenitude-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Possible Infinity (type e) + No Pure Contingency

Assuming `possible-infinity-e`, `no-pure-contingency-r`, these remain open:

- BF (type t) (`barcan-t`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Relational Choice (`necessary-relational-choice-r`)
- Relational Choice (`relational-choice-r`)

### Possible Infinity (type t) + No Pure Contingency

Assuming `possible-infinity-t`, `no-pure-contingency-r`, these remain open:

- BF (type t) (`barcan-t`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Relational Choice (`necessary-relational-choice-r`)
- Relational Choice (`relational-choice-r`)

### No Pure Contingency + Relational Choice

Assuming `no-pure-contingency-r`, `relational-choice-r`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Rigid Comprehension

Assuming `no-pure-contingency-r`, `rigid-comprehension-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Strong Leibniz Biconditionals

Assuming `no-pure-contingency-r`, `strong-leibniz-r`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Actuality (`necessary-actuality`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Tractarianism (`tractarianism-r`)

### No Pure Contingency + Strong Leibniz Biconditionals (type t)

Assuming `no-pure-contingency-r`, `strong-leibniz-t`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- Atomicity (`atomicity-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- Persistent Comprehension (`persistent-comprehension-r`)

### No Pure Contingency + Tractarianism

Assuming `no-pure-contingency-r`, `tractarianism-r`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Witnessed Possibility + No Pure Contingency

Assuming `witnessed-possibility-r`, `no-pure-contingency-r`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type t) (`infinity-t`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Functionality (`necessary-functionality-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- □Tractarianism (`necessary-tractarianism-r`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Possible Infinity (type t) (`possible-infinity-t`)
- Relational Choice (`relational-choice-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Strong Leibniz Biconditionals (type t) (`strong-leibniz-t`)
- Tractarianism (`tractarianism-r`)
- Very Weak Rigid Comprehension (`very-weak-rigid-comprehension-r`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)

### Relational Choice + Plenitude

Assuming `relational-choice-r`, `plenitude-r`, these remain open:

- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Very Weak Rigid Comprehension (`very-weak-rigid-comprehension-r`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)

## 4. Unknown verdicts inside each model

For these principles the model has not been checked either way. Deciding one is a self-contained calculation in a construction that is already written down.

### Coalesced sum: root over all finite individual domains — `coalesced-all-finite-individual-domains`

- Atomicity (`atomicity-r`)
- Boolean Completeness (`boolean-completeness-r`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- B for pure sentences (`pure-b-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- B for sentences of Σ (`signature-b-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Very Weak Rigid Comprehension (`very-weak-rigid-comprehension-r`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)

### Coalesced sum: root individuals indexed by infinitely many individual constants — `coalesced-constant-indexed-root`

Fully determined; nothing unknown.

### Coalesced sum: maximalist root — `coalesced-maximalist-root`

Fully determined; nothing unknown.

### Coalesced sum: singleton individual root — `coalesced-single-individual-root`

- Distinctness (signature Σ) (`distinctness-signature-r`)
- General Separated Structure (`general-separated-structure-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Possibility+ (signature Σ) (`possibility-plus-signature-r`)
- Possibility (signature Σ) (`possibility-signature-r`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: dyadic roundings of N — `finite-support-dyadic-roundings`

- BF (type t) (`barcan-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Strong Leibniz Biconditionals (type t) (`strong-leibniz-t`)

### Finite-support action model: identity-or-collapse monotone surjections — `finite-support-identity-or-collapse-surjections`

- Atomicity (type t) (`atomicity-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- Strong Leibniz Biconditionals (type t) (`strong-leibniz-t`)

### Finite-support action model: identity-or-collapse monotone maps — `finite-support-identity-or-collapse`

- Atomicity (type t) (`atomicity-t`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- Strong Leibniz Biconditionals (type t) (`strong-leibniz-t`)

### Finite-support action model: monotone maps of N — `finite-support-monotone-maps`

- BF (type t) (`barcan-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Independence (signature Σ) (`independence-signature-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □BF (type t) (`necessary-barcan-t`)
- B for sentences of Σ (`signature-b-r`)

### Finite-support action model: monotone surjections of N — `finite-support-monotone-surjections`

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- No Contingency (signature Σ) (`no-contingency-signature-r`)
- B for sentences of Σ (`signature-b-r`)

### Finite-support action model: permutations of N — `finite-support-permutations`

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Inextensible Comprehension (`inextensible-comprehension-r`)

### Finite-support action model: qualitative contrast — `finite-support-qualitative-contrast`

- Functional Choice (`functional-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- Relational Choice (`relational-choice-r`)

### Finite-support action model: truncated shifts of N — `finite-support-truncated-shifts`

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Finite-support action model: truncations of N — `finite-support-truncations`

- BF (type t) (`barcan-t`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- No Contingency (signature Σ) (`no-contingency-signature-r`)
- B for sentences of Σ (`signature-b-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Strong Leibniz Biconditionals (type t) (`strong-leibniz-t`)

### Finite-support action model: N and singleton, all maps — `finite-support-two-object-all-maps`

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Persistent Comprehension (`persistent-comprehension-r`)
- B for pure sentences (`pure-b-r`)
- B for sentences of Σ (`signature-b-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Strong Leibniz Biconditionals (type t) (`strong-leibniz-t`)
- Very Weak Rigid Comprehension (`very-weak-rigid-comprehension-r`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)

### Full action model: free monoid on countably many generators, glued constants, singleton individuals — `full-free-monoid-glued-constants-singleton`

Fully determined; nothing unknown.

### Full action model: free monoid on countably many generators, glued constants, thread individuals — `full-free-monoid-glued-constants`

Fully determined; nothing unknown.

### Full Henkin model: countably infinite individual domain — `full-henkin-infinite-base`

Fully determined; nothing unknown.

### Full Henkin model: singleton individual domain — `full-henkin-singleton-base`

Fully determined; nothing unknown.

### Full action model: idempotent two-arrow monoid — `full-idempotent-monoid`

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Infinity Schema (type e) (`infinity-e`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Possible Infinity (type e) (`possible-infinity-e`)

### Full action model: two-element group — `full-involution-group`

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Infinity Schema (type e) (`infinity-e`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Possible Infinity (type e) (`possible-infinity-e`)

### Full action model: permutations of an infinite set — `full-permutation-group-infinite-set`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set, one individual — `full-permutation-group-one-individual`

Fully determined; nothing unknown.

### Full action model: surjections of an infinite set — `full-surjection-monoid`

Fully determined; nothing unknown.

### Full action model: two-object chain — `full-two-object-chain`

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Functionality (`functionality-r`)
- Infinity Schema (type e) (`infinity-e`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)
- B for pure sentences (`pure-b-r`)
- B for sentences of Σ (`signature-b-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Tractarianism (`tractarianism-r`)

### Full action model: two-object retract — `full-two-object-retract`

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- Infinity Schema (type t) (`infinity-t`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)

### Henkin model: base without a choice function — `henkin-without-relational-choice`

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Infinity Schema (type e) (`infinity-e`)
- Possible Infinity (type e) (`possible-infinity-e`)

### Symmetric ideally-full model: all surjections of N (Base 1) — `symmetric-all-surjections`

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- Relational Choice (`relational-choice-r`)

### Symmetric ideally-full model: permutations and collapsers of a fixed pair (Base 2) — `symmetric-collapse-pair`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- Relational Choice (`relational-choice-r`)

### Symmetric ideally-full model: qualitative link structure (Base 3) — `symmetric-qualitative-links`

- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Functionality (`functionality-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- □Tractarianism (`necessary-tractarianism-r`)
- Relational Choice (`relational-choice-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Strong Leibniz Biconditionals (type t) (`strong-leibniz-t`)
- Tractarianism (`tractarianism-r`)

### Symmetric ideally-full model: arrows omitting or reserving a fixed individual — `symmetric-range-gap-without-actuality`

- BF (type t) (`barcan-t`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Relational Choice (`necessary-relational-choice-r`)
- No Contingency (signature Σ) (`no-contingency-signature-r`)
- Relational Choice (`relational-choice-r`)
- B for sentences of Σ (`signature-b-r`)

### Symmetric ideally-full model: arrows omitting a fixed individual — `symmetric-range-gap`

- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- BF (type t) (`barcan-t`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- Relational Choice (`relational-choice-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Strong Leibniz Biconditionals (type t) (`strong-leibniz-t`)

### Symmetric ideally-full model: two objects, the second unpinned — `symmetric-two-object-unpinned`

- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Functionality (`functionality-r`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- B for sentences of Σ (`signature-b-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Strong Leibniz Biconditionals (type t) (`strong-leibniz-t`)
- Tractarianism (`tractarianism-r`)

## 5. Open single-premise pairs (501)

*A ⇒ B ?* means neither implication nor incompatibility nor a countermodel is currently recorded. Grouped by antecedent. Most are open only because the obvious model has not been added.

- **4** (`modal-four`) ⇒ Inextensible Comprehension
- **5** (`modal-five`) ⇒ Boolean Completeness (type t), Inextensible Comprehension, Necessity of Arithmetic
- **Atomicity** (`atomicity-r`) ⇒ B for pure sentences, Inextensible Comprehension, Necessity of Arithmetic, □Atomicity
- **Atomicity (type t)** (`atomicity-t`) ⇒ Atomicity, B for pure sentences, Inextensible Comprehension, Necessity of Arithmetic, □Atomicity
- **Atomlessness** (`atomlessness`) ⇒ Axiom of Infinity (type e), B for pure sentences, B for sentences of Σ, BF (type t), Boolean Completeness (type t), Converse Witnessed Possibility, Inextensible Comprehension, Infinity Schema (type e), Modal Freedom (signature Σ), Necessity of Arithmetic, No Pure Contingency, Possible Infinity (type e), Relational Choice, □BF (type t), □Relational Choice
- **Axiom of Infinity (type e)** (`axiom-of-infinity-e`) ⇒ Inextensible Comprehension, Relational Choice
- **Axiom of Infinity (type t)** (`axiom-of-infinity-t`) ⇒ Inextensible Comprehension, Relational Choice
- **B** (`modal-b`) ⇒ Boolean Completeness (type t), Inextensible Comprehension, Necessity of Arithmetic
- **B for pure sentences** (`pure-b-r`) ⇒ Inextensible Comprehension, Necessity of Arithmetic
- **B for sentences of Σ** (`signature-b-r`) ⇒ Boolean Completeness (type t), Inextensible Comprehension, Necessity of Arithmetic
- **BF** (`barcan-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Inextensible Comprehension, Necessity of Arithmetic, □BF (type t)
- **BF (type t)** (`barcan-t`) ⇒ B for pure sentences, BF, Boolean Completeness (type t), Functionality, Inextensible Comprehension, Necessity of Arithmetic, Tractarianism, □BF (type t)
- **Boolean Completeness** (`boolean-completeness-r`) ⇒ B for pure sentences, Inextensible Comprehension
- **Boolean Completeness (type t)** (`boolean-completeness-t`) ⇒ B for pure sentences, Boolean Completeness, Countable Boolean Completeness, Inextensible Comprehension, Necessity of Arithmetic
- **Broad Necessitism** (`broad-necessitism-r`) ⇒ Inextensible Comprehension
- **CBF** (`converse-barcan-r`) ⇒ Inextensible Comprehension
- **Converse Witnessed Possibility** (`converse-witnessed-possibility-r`) ⇒ Inextensible Comprehension, Modal Freedom (signature Σ)
- **Countable Boolean Completeness** (`countable-boolean-completeness-r`) ⇒ B for pure sentences, Boolean Completeness, Boolean Completeness (type t), Inextensible Comprehension
- **Distinctness (pure)** (`distinctness-schema-r`) ⇒ Actual Profile, Actuality, Distinctness (signature Σ), Distinctness-preserving collapse, General Separated Structure, Independence (signature Σ), Inextensible Comprehension, Persistent Comprehension, Possibility (signature Σ), Possibly Witnessed Possibility, Relational Choice, Separated Structure, Witnessed Possibility
- **Distinctness (signature Σ)** (`distinctness-signature-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type e), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Relational Choice
- **Distinctness-preserving collapse** (`distinctness-preserving-collapse`) ⇒ Inextensible Comprehension
- **Existence** (`existence-r`) ⇒ Inextensible Comprehension
- **Functional Choice** (`functional-choice-r`) ⇒ Atomicity, Atomicity (type t), Boolean Completeness, Boolean Completeness (type t), Countable Boolean Completeness, Gallin Extensional Comprehension, Necessity of Arithmetic, Rigid Comprehension, Very Weak Rigid Comprehension, Weak Rigid Comprehension, □Actuality, □Atomicity, □Boolean Completeness, □Relational Choice, □Rigid Comprehension
- **Functionality** (`functionality-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Inextensible Comprehension, Necessity of Arithmetic, □BF (type t)
- **Gallin Extensional Comprehension** (`gallin-extensional-comprehension-r`) ⇒ Actual Profile, Actuality, BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Countable Boolean Completeness, Functionality, Inextensible Comprehension, Necessity of Arithmetic, Persistent Comprehension, Plenitude, Rigid Comprehension, Tractarianism, Very Weak Rigid Comprehension, Weak Rigid Comprehension, □5, □B, □BF, □BF (type t), □Functionality, □ND, □ND (type t), □Tractarianism
- **General Separated Structure** (`general-separated-structure-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type t), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type t), Persistent Comprehension, Possible Infinity (type t), Relational Choice
- **Independence (signature Σ)** (`independence-signature-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type t), Distinctness-preserving collapse, General Separated Structure, Inextensible Comprehension, Infinity Schema (type t), Persistent Comprehension, Possible Infinity (type t), Possibly Witnessed Possibility, Relational Choice, Separated Structure, Witnessed Possibility
- **Inextensible Comprehension** (`inextensible-comprehension-r`) ⇒ Actual Profile, Actuality, Persistent Comprehension
- **Infinity Schema (type e)** (`infinity-e`) ⇒ Axiom of Infinity (type e), Inextensible Comprehension, Possible Infinity (type e), Relational Choice
- **Infinity Schema (type t)** (`infinity-t`) ⇒ Axiom of Infinity (type t), Inextensible Comprehension, Possible Infinity (type t), Relational Choice
- **Intensionality** (`intensionality-r`) ⇒ Inextensible Comprehension
- **K** (`modal-k`) ⇒ Inextensible Comprehension
- **Logical Necessity** (`logical-necessity-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Axiom of Infinity (type t), BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Functionality, Inextensible Comprehension, Infinity Schema (type t), Persistent Comprehension, Possible Infinity (type t), Relational Choice, Rigid Comprehension, Strong Leibniz Biconditionals, Strong Leibniz Biconditionals (type t), Tractarianism, Very Weak Rigid Comprehension, Weak Rigid Comprehension, □Actuality, □Atomicity, □BF, □BF (type t), □Boolean Completeness, □Functionality, □Relational Choice, □Rigid Comprehension, □Strong Leibniz Biconditionals, □Strong Leibniz Biconditionals (type t), □Tractarianism
- **Modal Freedom (signature Σ)** (`modal-freedom-signature-r`) ⇒ BF, BF (type t), Boolean Completeness (type t), Functionality, Inextensible Comprehension, Tractarianism, □BF, □BF (type t), □Functionality, □Tractarianism
- **Modalized Fregean Axiom** (`modalized-fregean`) ⇒ Inextensible Comprehension
- **Modalized Functionality** (`modalized-functionality-r`) ⇒ Inextensible Comprehension
- **ND** (`distinctness-necessary-r`) ⇒ Boolean Completeness (type t), Inextensible Comprehension, Necessity of Arithmetic
- **ND (type t)** (`distinctness-necessary-t`) ⇒ Boolean Completeness (type t), Inextensible Comprehension, Necessity of Arithmetic
- **NI** (`identity-necessary-r`) ⇒ Inextensible Comprehension
- **Necessity of Arithmetic** (`necessity-of-arithmetic`) ⇒ B for pure sentences, Inextensible Comprehension
- **No Contingency (signature Σ)** (`no-contingency-signature-r`) ⇒ BF, BF (type t), Boolean Completeness (type t), Functionality, Inextensible Comprehension, Tractarianism, □BF, □BF (type t), □Functionality, □Tractarianism
- **No Pure Contingency** (`no-pure-contingency-r`) ⇒ Inextensible Comprehension, Modal Freedom (signature Σ)
- **Ordinary Comprehension** (`ordinary-comprehension-r`) ⇒ Inextensible Comprehension
- **Plenitude** (`plenitude-r`) ⇒ Boolean Completeness, Boolean Completeness (type t), Countable Boolean Completeness, Gallin Extensional Comprehension, Necessity of Arithmetic, Rigid Comprehension, Very Weak Rigid Comprehension, Weak Rigid Comprehension
- **Possibility (pure)** (`possibility-schema-r`) ⇒ Actual Profile, Actuality, Distinctness (signature Σ), Distinctness-preserving collapse, General Separated Structure, Independence (signature Σ), Inextensible Comprehension, Persistent Comprehension, Possibility (signature Σ), Possibly Witnessed Possibility, Relational Choice, Separated Structure, Witnessed Possibility
- **Possibility (signature Σ)** (`possibility-signature-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type e), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Relational Choice
- **Possibility+ (pure)** (`possibility-plus-r`) ⇒ Actual Profile, Actuality, Distinctness (signature Σ), Distinctness-preserving collapse, General Separated Structure, Independence (signature Σ), Inextensible Comprehension, Persistent Comprehension, Possibility (signature Σ), Possibility+ (signature Σ), Possibly Witnessed Possibility, Relational Choice, Separated Structure, Witnessed Possibility
- **Possibility+ (signature Σ)** (`possibility-plus-signature-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type e), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Relational Choice
- **Possible Infinity (type e)** (`possible-infinity-e`) ⇒ Inextensible Comprehension, Relational Choice
- **Possible Infinity (type t)** (`possible-infinity-t`) ⇒ Axiom of Infinity (type t), Inextensible Comprehension, Infinity Schema (type t), Relational Choice
- **Possibly Witnessed Possibility** (`possibly-witnessed-possibility-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type t), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type t), Persistent Comprehension, Possible Infinity (type t), Relational Choice
- **Relational Choice** (`relational-choice-r`) ⇒ Inextensible Comprehension
- **Rigid Comprehension** (`rigid-comprehension-r`) ⇒ B for pure sentences
- **Separated Structure** (`separated-structure-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type t), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type t), Persistent Comprehension, Possible Infinity (type t), Relational Choice
- **Strong Leibniz Biconditionals** (`strong-leibniz-r`) ⇒ Actual Profile, Actuality, B for pure sentences, BF, BF (type t), Boolean Completeness (type t), Converse Witnessed Possibility, Functionality, Inextensible Comprehension, Modal Freedom (signature Σ), Necessity of Arithmetic, No Pure Contingency, Persistent Comprehension, Tractarianism, □Actuality, □Atomicity, □BF, □BF (type t), □Functionality, □Strong Leibniz Biconditionals, □Strong Leibniz Biconditionals (type t), □Tractarianism
- **Strong Leibniz Biconditionals (type t)** (`strong-leibniz-t`) ⇒ Actual Profile, Actuality, Atomicity, B for pure sentences, Boolean Completeness (type t), Inextensible Comprehension, Necessity of Arithmetic, Persistent Comprehension, □Actuality, □Atomicity, □Strong Leibniz Biconditionals (type t)
- **Strong Possibility (pure)** (`strong-possibility-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Atomlessness, Axiom of Infinity (type e), BF, BF (type t), Boolean Completeness (type t), Distinctness (signature Σ), Functionality, General Separated Structure, Independence (signature Σ), Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Possibility (signature Σ), Possibility+ (pure), Possibility+ (signature Σ), Possibly Witnessed Possibility, Relational Choice, Separated Structure, Strong Leibniz Biconditionals, Strong Leibniz Biconditionals (type t), Strong Possibility (signature Σ), Tractarianism, Witnessed Possibility
- **Strong Possibility (signature Σ)** (`strong-possibility-signature-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Atomlessness, Axiom of Infinity (type e), BF, BF (type t), Boolean Completeness (type t), Functionality, Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Possibility+ (pure), Possibility+ (signature Σ), Relational Choice, Strong Leibniz Biconditionals, Strong Leibniz Biconditionals (type t), Strong Possibility (pure), Tractarianism
- **T** (`modal-t`) ⇒ Inextensible Comprehension
- **Tractarianism** (`tractarianism-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Inextensible Comprehension, Necessity of Arithmetic, □BF (type t)
- **Very Weak Rigid Comprehension** (`very-weak-rigid-comprehension-r`) ⇒ B for pure sentences
- **Weak Rigid Comprehension** (`weak-rigid-comprehension-r`) ⇒ B for pure sentences
- **Witnessed Possibility** (`witnessed-possibility-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type t), Distinctness-preserving collapse, General Separated Structure, Independence (signature Σ), Inextensible Comprehension, Infinity Schema (type t), Persistent Comprehension, Possible Infinity (type t), Possibly Witnessed Possibility, Relational Choice, Separated Structure
- **□5** (`necessary-modal-five`) ⇒ Boolean Completeness (type t), Inextensible Comprehension, Necessity of Arithmetic
- **□Actuality** (`necessary-actuality`) ⇒ B for pure sentences, Boolean Completeness (type t), Necessity of Arithmetic
- **□Atomicity** (`necessary-atomicity-r`) ⇒ B for pure sentences, Inextensible Comprehension, Necessity of Arithmetic
- **□B** (`necessary-modal-b`) ⇒ Boolean Completeness (type t), Inextensible Comprehension, Necessity of Arithmetic
- **□BF** (`necessary-barcan-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Inextensible Comprehension, Necessity of Arithmetic
- **□BF (type t)** (`necessary-barcan-t`) ⇒ B for pure sentences, BF, Boolean Completeness (type t), Functionality, Inextensible Comprehension, Necessity of Arithmetic, Tractarianism, □BF, □Functionality, □Tractarianism
- **□Boolean Completeness** (`necessary-boolean-completeness-r`) ⇒ B for pure sentences, Inextensible Comprehension
- **□Functional Choice** (`necessary-functional-choice-r`) ⇒ Converse Witnessed Possibility, Modal Freedom (signature Σ), No Pure Contingency
- **□Functionality** (`necessary-functionality-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Inextensible Comprehension, Necessity of Arithmetic
- **□Gallin Extensional Comprehension** (`necessary-gallin-extensional-comprehension-r`) ⇒ Converse Witnessed Possibility, Modal Freedom (signature Σ), No Pure Contingency
- **□ND** (`necessary-distinctness-necessary-r`) ⇒ Boolean Completeness (type t), Inextensible Comprehension, Necessity of Arithmetic
- **□ND (type t)** (`necessary-distinctness-necessary-t`) ⇒ Boolean Completeness (type t), Inextensible Comprehension, Necessity of Arithmetic
- **□Plenitude** (`necessary-plenitude-r`) ⇒ Converse Witnessed Possibility, Modal Freedom (signature Σ), No Pure Contingency
- **□Relational Choice** (`necessary-relational-choice-r`) ⇒ B for pure sentences, Inextensible Comprehension, Necessity of Arithmetic
- **□Rigid Comprehension** (`necessary-rigid-comprehension-r`) ⇒ B for pure sentences
- **□Strong Leibniz Biconditionals** (`necessary-strong-leibniz-r`) ⇒ Actual Profile, Actuality, B for pure sentences, BF, BF (type t), Boolean Completeness (type t), Converse Witnessed Possibility, Functionality, Inextensible Comprehension, Modal Freedom (signature Σ), Necessity of Arithmetic, No Pure Contingency, Persistent Comprehension, Strong Leibniz Biconditionals, Tractarianism, □Actuality, □BF, □BF (type t), □Functionality, □Tractarianism
- **□Strong Leibniz Biconditionals (type t)** (`necessary-strong-leibniz-t`) ⇒ Actual Profile, Actuality, Atomicity, B for pure sentences, Boolean Completeness (type t), Inextensible Comprehension, Necessity of Arithmetic, Persistent Comprehension, □Actuality, □Atomicity
- **□Tractarianism** (`necessary-tractarianism-r`) ⇒ B for pure sentences, Boolean Completeness (type t), Inextensible Comprehension, Necessity of Arithmetic

## 6. Deliberately deferred

`topics/classicism/extraction.md` has a section listing claims that were **not** recorded because they need a further reading of the sources. Those are marked deferred rather than open: the answer is likely in the literature and needs transcribing, not discovering. Read that section before starting work.

## 7. How to record an answer

- Proved an implication? Add `topics/classicism/results/<id>.yaml` with the full premise list and the proof.
- Refuted one? Add `topics/classicism/models/<id>.yaml` listing what you verified in `satisfies` and `violates`.
- Settling an existing conjecture? For a proof of the same statement, keep its ID, set `was_conjectured: true`, and change its status to `proved`. If the statement changes substantially, retain the original and add a separate record. Refuted proposals stay `status: conjectured`, with proved refuting evidence recorded separately. Answers under extra exploration assumptions are contextual, not global record statuses.
- Not sure? Add it with `status: conjectured`, an empty proof, and say in `notes` what would settle it.
- Then run `python3 scripts/pmap.py validate` and `status`. Never hand-edit the derived counts.

`README.md` has the exact record shapes and the sourcing rules. Follow them; an unsourced or misattributed record is worse than an absent one.
