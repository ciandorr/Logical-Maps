# Preference axioms over lotteries — complete map

Topic `decision-theory`. Generated 2026-09-23T22:14:50+00:00.

12 principles, 16 proved results, 2 recorded conjectures, 9 models.

This file is self-contained. Every principle statement, every proof, every model construction and every derived verdict in the database is reproduced below. `README.md` gives the semantics and the rules for adding to it; `OPEN-QUESTIONS.md` lists what is not settled.

## 1. Framework


≽ a reflexive binary relation on Δ(X), X finite with |X| ≥ 3; ≻, ~ its asymmetric and symmetric parts.

**Fixed background assumptions.** None. Every principle below is optional and must be assumed explicitly.

## 2. Background and standing conventions

*Reproduced from `topics/decision-theory/background.md`.*

$\succeq a$ reflexive binary relation on $\Delta (X), X$ finite with $|X| \ge 3; \succ , \sim$ its asymmetric and symmetric parts. *(placeholder)*

### Notation

*(placeholder)*

### Conventions

*(placeholder — e.g. which form of independence is meant, what "continuity" means by default)*

### Certificates

*(placeholder — what human / human-assisted / AI / Lean mean here)*

### Literature

*(placeholder)*

## 3. Principles

### All principles

#### Acyclicity — `acyclicity`


There is no finite cycle of strict preferences $p_{1} \succ p_{2} \succ \ldots \succ p_{n} \succ p_{1}$.

Formal: `$\forall n \forall p_{1}\ldots p_{n}. \neg (p_{1} \succ p_{2} \land \ldots \land p_{n} \succ p_{1})$`

Tags: ordering.

Sources:

- Sen (1970), Collective Choice and Social Welfare, ch. 1*



#### Archimedean — `archimedean`


For all $p, q, r \in \Delta (X)$: if $p \succ q \succ r$ then there are $\alpha , \beta \in (0,1)$ with $\alpha p + (1- \alpha )r \succ q$ and $q \succ \beta p + (1- \beta )r$.

Formal: `$\forall p q r. p \succ q \succ r \to \exists \alpha \beta \in (0,1). \alpha p+(1- \alpha )r \succ q \land q \succ \beta p+(1- \beta )r$`

Tags: axiom, topological.

Sources:

- Jensen (1967), An introduction to Bernoullian utility theory I, Swedish Journal of Economics 69



#### Betweenness — `betweenness`


For all $p, q \in \Delta (X)$ and $\lambda \in (0,1)$: if $p \succ q$ then $p \succ \lambda p + (1- \lambda )q \succ q$, and if $p \sim q$ then $p \sim \lambda p + (1- \lambda )q$.

Formal: `$\forall p q, \forall \lambda \in (0,1). (p \succ q \to p \succ \lambda p+(1- \lambda )q \succ q) \land (p \sim q \to p \sim \lambda p+(1- \lambda )q)$`

Tags: axiom, mixture.

Sources:

- Chew (1983), A generalization of the quasilinear mean…, Econometrica 51
- Dekel (1986), An axiomatic characterization of preferences under uncertainty, JET 40



#### Closed-graph continuity — `closed-graph-continuity`


The set $\{(p, q) \in \Delta (X) \times \Delta (X) : p \succeq q\}$ is closed in the product topology.

Formal: `$\operatorname{IsClosed} \{(p,q) | p \succeq q\}$`

Tags: axiom, topological.

Sources:

- Dubra, Maccheroni & Ok (2004), JET 115, Axiom C



#### Completeness — `completeness`


For all $p, q \in \Delta (X): p \succeq q$ or $q \succeq p$.

Formal: `$\forall p q. p \succeq q \lor q \succeq p$`

Tags: ordering.

Sources:

- von Neumann & Morgenstern (1944), Theory of Games and Economic Behavior, §3.5



#### Mixture continuity — `continuity`


For all $p, q, r \in \Delta (X)$ the sets $\{\lambda \in [0,1] : \lambda p + (1- \lambda )q \succeq r\}$ and $\{\lambda \in [0,1] : r \succeq \lambda p + (1- \lambda )q\}$ are closed.

Formal: `$\forall p q r$. closed $\{\lambda | \lambda p+(1- \lambda )q \succeq r\} \land$ closed $\{\lambda | r \succeq \lambda p+(1- \lambda )q\}$`

Tags: axiom, topological.

Sources:

- Herstein & Milnor (1953), Econometrica 21, Axiom 2



#### Expected-utility representation — `eu-representation`


There is a function $u : X \to \mathbb{R}$ such that for all $p, q \in \Delta (X): p \succeq q$ if and only if $\operatorname{EU}_u(p) \ge \operatorname{EU}_u(q)$.

Formal: `$\exists u:X\to \mathbb{R} . \forall p q. p \succeq q \leftrightarrow \sum _x p(x)u(x) \ge \sum _x q(x)u(x)$`

Tags: representation.

Sources:

- von Neumann & Morgenstern (1944)



#### Independence — `independence`


For all $p, q, r \in \Delta (X)$ and $\lambda \in (0,1]: p \succeq q$ if and only if $\lambda p + (1- \lambda )r \succeq \lambda q + (1- \lambda )r$.

Formal: `$\forall p q r, \forall \lambda \in (0,1]. p \succeq q \leftrightarrow \lambda p+(1- \lambda )r \succeq \lambda q+(1- \lambda )r$`

Tags: axiom, mixture.

Sources:

- Marschak (1950), Rational behavior, uncertain prospects, and measurable utility, Econometrica 18
- Herstein & Milnor (1953), An axiomatic approach to measurable utility, Econometrica 21



#### Expected multi-utility representation — `multi-utility`


There is a set U of functions $u : X \to \mathbb{R}$ such that for all $p, q \in \Delta (X): p \succeq q$ if and only if $\operatorname{EU}_u(p) \ge \operatorname{EU}_u(q)$ for every $u \in U$.

Formal: `$\exists U \subseteq (X\to \mathbb{R} ). \forall p q. p \succeq q \leftrightarrow \forall u\in U. \operatorname{EU}_u(p) \ge \operatorname{EU}_u(q)$`

Tags: representation.

Sources:

- Aumann (1962), Utility theory without the completeness axiom, Econometrica 30
- Dubra, Maccheroni & Ok (2004), Expected utility theory without the completeness axiom, JET 115



#### Quasi-transitivity — `quasi-transitivity`


Strict preference is transitive: if $p \succ q$ and $q \succ r$ then $p \succ r$.

Formal: `$\forall p q r. p \succ q \to q \succ r \to p \succ r$`

Tags: ordering.

Sources:

- Sen (1969), Quasi-transitivity, rational choice and collective decisions, Review of Economic Studies 36



#### Transitivity — `transitivity`


For all $p, q, r \in \Delta (X)$: if $p \succeq q$ and $q \succeq r$ then $p \succeq r$.

Formal: `$\forall p q r. p \succeq q \to q \succeq r \to p \succeq r$`

Tags: ordering.

Sources:

- von Neumann & Morgenstern (1944), §3.5



#### Weak order — `weak-order`


$\succeq$ is complete and transitive.

Formal: `$\operatorname{Completeness} \land \operatorname{Transitivity}$`

Tags: ordering, bundle.

Sources:

- (none recorded)



## 4. Results

Each result is a Horn clause: the conjunction of its premises entails its conclusion, relative to the framework above. Premises are sufficient; minimality is not claimed.

### 4.1 Proved

#### Closed-graph continuity ⇒ Mixture continuity — `closed-graph-implies-mixture-continuity`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Closed-graph continuity (`closed-graph-continuity`)

Conclusion: Mixture continuity (`continuity`)

Proof.

$\lambda$ ↦ $(\lambda p+(1- \lambda )q, r)$ and $\lambda$ ↦ $(r, \lambda p+(1- \lambda )q)$ are continuous maps
$[0,1] \to \Delta (X)\times \Delta (X)$; the two sections are their preimages of the closed
graph of $\succeq$.

Sources:

- (none recorded)



Record: `topics/decision-theory/results/closed-graph-implies-mixture-continuity.yaml`.

#### Mixture continuity ∧ Completeness ⇒ Archimedean — `continuity-completeness-imply-archimedean`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Mixture continuity (`continuity`)
- Completeness (`completeness`)

Conclusion: Archimedean (`archimedean`)

Proof.

Let $p \succ q \succ r$ and set $A = \{\lambda : \lambda p+(1- \lambda )r \succeq q\}, B = \{\lambda : q \succeq \lambda p+(1- \lambda )r\}$.
Both are closed by continuity and $A \cup B = [0,1]$ by completeness. Since
$1 \notin B$ (as $p \succ q$) and $[0,1]\setminus B$ is open, some interval $(1- \epsilon , 1]$ lies in
$[0,1]\setminus B \subseteq A$; any $\alpha$ in it with $\alpha < 1$ gives $\alpha p+(1- \alpha )r \succ q$. Symmetrically,
$0 \notin A$ (as $q \succ r$) yields $[0, \epsilon ) \subseteq B\setminus A$ and any $\beta$ in it with $\beta > 0$ gives
$q \succ \beta p+(1- \beta )r$.

Notes. Completeness is used to conclude $\lambda \in A$ from $\lambda \notin B$; whether continuity alone suffices is left open here.

Sources:

- (none recorded)



Record: `topics/decision-theory/results/continuity-completeness-imply-archimedean.yaml`.

#### Transitivity ∧ Independence ∧ Closed-graph continuity ⇒ Expected multi-utility representation — `dmo-theorem`

Proved result; source **Misc.**; legacy provenance human; produced by literature; checked by nobody; 2026-09-08.

Premises:

- Transitivity (`transitivity`)
- Independence (`independence`)
- Closed-graph continuity (`closed-graph-continuity`)

Conclusion: Expected multi-utility representation (`multi-utility`)

Proof.

Dubra–Maccheroni–Ok, Theorem 1, for compact metric X (finite X is a
special case): a reflexive transitive relation on $\Delta (X)$ satisfying
independence and closed-graph continuity has an expected multi-utility
representation. The proof identifies $\succeq$ with a closed convex cone of
signed measures and takes U to be the dual cone.

Notes. Reflexivity is a standing assumption of the framework.

Sources:

- Dubra, Maccheroni & Ok (2004), Expected utility theory without the completeness axiom, JET 115, Theorem 1



Record: `topics/decision-theory/results/dmo-theorem.yaml`.

#### Expected-utility representation ⇒ Completeness — `eu-implies-completeness`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Expected-utility representation (`eu-representation`)

Conclusion: Completeness (`completeness`)

Proof.

Real numbers are totally ordered: $\operatorname{EU}_u(p) \ge \operatorname{EU}_u(q)$ or $\operatorname{EU}_u(q) \ge \operatorname{EU}_u(p)$.

Sources:

- (none recorded)



Record: `topics/decision-theory/results/eu-implies-completeness.yaml`.

#### Expected-utility representation ⇒ Expected multi-utility representation — `eu-implies-multi-utility`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Expected-utility representation (`eu-representation`)

Conclusion: Expected multi-utility representation (`multi-utility`)

Proof.

Take $U = \{u\}$.

Sources:

- (none recorded)



Record: `topics/decision-theory/results/eu-implies-multi-utility.yaml`.

#### Independence ⇒ Betweenness — `independence-implies-betweenness`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Independence (`independence`)

Conclusion: Betweenness (`betweenness`)

Proof.

Fix $\lambda \in (0,1)$ and write $m = \lambda p + (1- \lambda )q$. Independence with $r = p$ and
mixing weight $1- \lambda$ gives $p \succeq q \Longleftrightarrow (1- \lambda )p+\lambda p \succeq (1- \lambda )q+\lambda p, i.e. p \succeq q \Longleftrightarrow p \succeq m$,
and likewise $q \succeq p \Longleftrightarrow m \succeq p$. Hence $p \succ q \Longleftrightarrow p \succ m$ and $p \sim q \Longleftrightarrow p \sim m$.
Independence with $r = q$ and weight $\lambda$ gives $p \succeq q \Longleftrightarrow m \succeq q$ and
$q \succeq p \Longleftrightarrow q \succeq m$, so $p \succ q \Longleftrightarrow m \succ q$. Together: $p \succ q \Longrightarrow p \succ m \succ q$ and
$p \sim q \Longrightarrow p \sim m$.

Notes. No ordering assumptions are needed because independence is taken in the biconditional form.

Sources:

- (none recorded)



Record: `topics/decision-theory/results/independence-implies-betweenness.yaml`.

#### Transitivity ∧ Independence ∧ Mixture continuity ⇒ Closed-graph continuity — `mixture-continuity-implies-closed-graph`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Transitivity (`transitivity`)
- Independence (`independence`)
- Mixture continuity (`continuity`)

Conclusion: Closed-graph continuity (`closed-graph-continuity`)

Proof.

Let $V = \{x \in \mathbb{R} ^X : \sum x = 0\}$ and $D = \Delta (X) - \Delta (X) \subseteq V$ (compact, convex,
contains 0). Put $K = \{q - p : q \succeq p\}$.

(i) Membership in K depends only on the difference: if $q - p = q' - p'$
then $\frac{1}{2} q + \frac{1}{2} p' = \frac{1}{2} q' + \frac{1}{2} p$, and by independence $(\lambda = \frac{1}{2}$, mixing with p'
resp. $p) q \succeq p \Longleftrightarrow \frac{1}{2} q+\frac{1}{2} p' \succeq \frac{1}{2} p+\frac{1}{2} p'$ and $q' \succeq p' \Longleftrightarrow \frac{1}{2} q'+\frac{1}{2} p \succeq \frac{1}{2} p'+\frac{1}{2} p$; the two
right-hand sides are the same pair. So "$x \in K$" is well defined for $x \in D$.

(ii) K is a cone in D: if $x \in K$ and $tx \in D (t > 0)$ then $tx \in K$. For
$t < 1$ use independence with $r = p: q \succeq p \Longrightarrow tq+(1- t)p \succeq p$, whose
difference is $t(q- p)$. For $t > 1$ apply the $t < 1$ case to tx.

(iii) K is convex: with $x = q- p, y = q'- p'$ in K, independence gives
$\frac{1}{2} q+\frac{1}{2} q' \succeq \frac{1}{2} p+\frac{1}{2} q'$ and $\frac{1}{2} q'+\frac{1}{2} p \succeq \frac{1}{2} p'+\frac{1}{2} p$, and transitivity gives
$\frac{1}{2} q+\frac{1}{2} q' \succeq \frac{1}{2} p+\frac{1}{2} p'$, whose difference is $\frac{1}{2} x+\frac{1}{2} y$.

(iv) K is closed along every line. Let $[x_{0}, x_{1}] = \ell \cap D$ for a line $\ell$ and
$x(\lambda ) = \lambda x_{1} + (1- \lambda )x_{0}$. Pick $\epsilon > 0$ and the uniform lottery c so that
$c + \epsilon x(\lambda ) \in \Delta (X)$ for all $\lambda \in [0,1]$. By (ii)$, x(\lambda ) \in K \Longleftrightarrow \epsilon x(\lambda ) \in K \Longleftrightarrow$
$c + \epsilon x(\lambda ) \succeq c$. Since $c + \epsilon x(\lambda ) = \lambda (c+\epsilon x_{1}) + (1- \lambda )(c+\epsilon x_{0})$, the set
$\{\lambda : x(\lambda ) \in K\}$ is a section of the form $\{\lambda : \lambda a+(1- \lambda )b \succeq c\}$, closed by
mixture continuity.

(v) A convex subset of a finite-dimensional space that meets every line
in a closed set is closed (if $x \in$ cl $K \setminus K$ and y is in the relative
interior of K then $[y, x) \subseteq K$ by the accessibility lemma, so $K \cap$ line(y,x)
is not closed). Hence K is closed, and if $(p_{n}, q_{n}) \to (p, q)$ with $q_{n} \succeq p_{n}$
then $q_{n} - p_{n} \in K \to q - p \in K, i.e. q \succeq p$.

Notes. This is the bridge between the mixture-continuity axiom used in the vNM literature and the closed-graph axiom used by Dubra–Maccheroni–Ok. It has not been checked by a human; if it fails, the map still reaches multi-utility from closed-graph continuity via dmo-theorem.

Sources:

- (none recorded)



Record: `topics/decision-theory/results/mixture-continuity-implies-closed-graph.yaml`.

<details><summary>Hand-written write-up</summary>

#### Transitivity ∧ Independence ∧ Mixture continuity ⇒ Closed-graph continuity

<p class='cert'>Result — ai; produced by Claude Fable 5.1 (Cowork session), 2026-09-08. Not yet checked.</p>

**Claim.** If $\succcurlyeq$ is reflexive and transitive, satisfies independence, and has closed sections $\{\lambda : \lambda p + (1-\lambda) q \succcurlyeq r\}$ and $\{\lambda : r \succcurlyeq \lambda p + (1-\lambda) q\}$, then $\{(p,q) : p \succcurlyeq q\}$ is closed in $\Delta(X)^2$.

**Proof.** Let $V = \{x \in \mathbb{R}^X : \sum_x x = 0\}$ and $D = \Delta(X) - \Delta(X) \subseteq V$, which is compact, convex, and contains $0$. Put
$$K = \{\, q - p : q \succcurlyeq p \,\}.$$

*(i) $K$ depends only on differences.* If $q - p = q' - p'$ then $\tfrac12 q + \tfrac12 p' = \tfrac12 q' + \tfrac12 p$. By independence with $\lambda = \tfrac12$, $q \succcurlyeq p \iff \tfrac12 q + \tfrac12 p' \succcurlyeq \tfrac12 p + \tfrac12 p'$ and $q' \succcurlyeq p' \iff \tfrac12 q' + \tfrac12 p \succcurlyeq \tfrac12 p' + \tfrac12 p$. The two right-hand sides are the same pair.

*(ii) $K$ is a cone in $D$.* If $x \in K$, $t > 0$ and $tx \in D$, then $tx \in K$. For $t < 1$: from $q \succcurlyeq p$, independence with $r = p$ gives $tq + (1-t)p \succcurlyeq p$, whose difference is $t(q-p)$. For $t > 1$ apply the previous case to $tx$.

*(iii) $K$ is convex.* For $x = q - p$ and $y = q' - p'$ in $K$, independence gives $\tfrac12 q + \tfrac12 q' \succcurlyeq \tfrac12 p + \tfrac12 q'$ and $\tfrac12 q' + \tfrac12 p \succcurlyeq \tfrac12 p' + \tfrac12 p$; transitivity gives $\tfrac12 q + \tfrac12 q' \succcurlyeq \tfrac12 p + \tfrac12 p'$, with difference $\tfrac12 x + \tfrac12 y$.

*(iv) $K$ is closed along every line.* Let $[x_0, x_1] = \ell \cap D$ and $x(\lambda) = \lambda x_1 + (1-\lambda) x_0$. Choose $\varepsilon > 0$ and the uniform lottery $c$ with $c + \varepsilon x(\lambda) \in \Delta(X)$ for all $\lambda$. By (ii), $x(\lambda) \in K \iff \varepsilon x(\lambda) \in K \iff c + \varepsilon x(\lambda) \succcurlyeq c$, and $c + \varepsilon x(\lambda) = \lambda(c + \varepsilon x_1) + (1-\lambda)(c + \varepsilon x_0)$, so $\{\lambda : x(\lambda) \in K\}$ is a section, closed by mixture continuity.

*(v)* A convex subset of a finite-dimensional space meeting every line in a closed set is closed: for $x \in \overline{K} \setminus K$ and $y$ in the relative interior of $K$, $[y, x) \subseteq K$ by the accessibility lemma, so $K \cap \mathrm{line}(y,x)$ is not closed. Hence $K$ is closed, and $(p_n, q_n) \to (p, q)$ with $q_n \succcurlyeq p_n$ gives $q - p \in K$. ∎

**Remark.** This bridges the mixture-continuity axiom of the vNM literature and the closed-graph axiom of Dubra–Maccheroni–Ok. The map reaches the multi-utility representation from closed-graph continuity without it.

</details>

#### Expected multi-utility representation ⇒ Closed-graph continuity — `multi-utility-implies-closed-graph`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Expected multi-utility representation (`multi-utility`)

Conclusion: Closed-graph continuity (`closed-graph-continuity`)

Proof.

$\{(p,q) : p \succeq q\} =$ ⋂$_{u\in U} \{(p,q) : \operatorname{EU}_u(p) - \operatorname{EU}_u(q) \ge 0\}$, an intersection
of preimages of $[0,\infty )$ under continuous (indeed linear) maps on $\Delta (X)\times \Delta (X)$.

Sources:

- (none recorded)



Record: `topics/decision-theory/results/multi-utility-implies-closed-graph.yaml`.

#### Expected multi-utility representation ⇒ Independence — `multi-utility-implies-independence`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Expected multi-utility representation (`multi-utility`)

Conclusion: Independence (`independence`)

Proof.

$\operatorname{EU}_u$ is affine in mixtures, so for $\lambda \in (0,1]$:
$\operatorname{EU}_u(\lambda p+(1- \lambda )r) - \operatorname{EU}_u(\lambda q+(1- \lambda )r) = \lambda (\operatorname{EU}_u(p) - \operatorname{EU}_u(q))$,
which is $\ge 0$ iff $\operatorname{EU}_u(p) \ge \operatorname{EU}_u(q)$. Quantify over $u \in U$.

Sources:

- (none recorded)



Record: `topics/decision-theory/results/multi-utility-implies-independence.yaml`.

#### Expected multi-utility representation ⇒ Transitivity — `multi-utility-implies-transitivity`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Expected multi-utility representation (`multi-utility`)

Conclusion: Transitivity (`transitivity`)

Proof.

If $\operatorname{EU}_u(p) \ge \operatorname{EU}_u(q)$ and $\operatorname{EU}_u(q) \ge \operatorname{EU}_u(r)$ for every $u \in U$ then
$\operatorname{EU}_u(p) \ge \operatorname{EU}_u(r)$ for every $u \in U$.

Sources:

- (none recorded)



Record: `topics/decision-theory/results/multi-utility-implies-transitivity.yaml`.

#### Quasi-transitivity ⇒ Acyclicity — `quasi-transitivity-implies-acyclicity`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Quasi-transitivity (`quasi-transitivity`)

Conclusion: Acyclicity (`acyclicity`)

Proof.

If $p_{1} \succ p_{2} \succ \ldots \succ p_{n} \succ p_{1}$ then by induction on n, transitivity of $\succ$ gives
$p_{1} \succ p_{n}$, and with $p_{n} \succ p_{1}$ this contradicts asymmetry of $\succ$.

Sources:

- (none recorded)



Record: `topics/decision-theory/results/quasi-transitivity-implies-acyclicity.yaml`.

#### Transitivity ⇒ Quasi-transitivity — `transitivity-implies-quasi-transitivity`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Transitivity (`transitivity`)

Conclusion: Quasi-transitivity (`quasi-transitivity`)

Proof.

Let $p \succ q \succ r$. Then $p \succeq q \succeq r$, so $p \succeq r$. If also $r \succeq p$ then $r \succeq p \succeq q$
gives $r \succeq q$, contradicting $q \succ r$. So $p \succ r$.

Sources:

- (none recorded)



Record: `topics/decision-theory/results/transitivity-implies-quasi-transitivity.yaml`.

#### Completeness ∧ Transitivity ∧ Independence ∧ Mixture continuity ⇒ Expected-utility representation — `vnm-theorem`

Proved result; source **Misc.**; legacy provenance human; produced by literature; checked by nobody; 2026-09-08.

Premises:

- Completeness (`completeness`)
- Transitivity (`transitivity`)
- Independence (`independence`)
- Mixture continuity (`continuity`)

Conclusion: Expected-utility representation (`eu-representation`)

Proof.

The von Neumann–Morgenstern theorem in the Herstein–Milnor mixture-set form.
Continuity plus weak order give, for any $p \succeq q \succeq r$ with $p \succ r, a$ unique
$\lambda$ with $q \sim \lambda p + (1- \lambda )r$ (connectedness of [0,1] and closedness of both
sections). Fix a best and a worst lottery (exist since X is finite and $\succeq$
is a weak order respecting mixtures), define $U(q)$ as that $\lambda$, and use
independence to show U is affine in mixtures; then $u(x) = U(\delta _x)$
represents $\succeq$ by expected utility.

Sources:

- von Neumann & Morgenstern (1944), Theory of Games and Economic Behavior, appendix
- Herstein & Milnor (1953), An axiomatic approach to measurable utility, Econometrica 21, Theorem 8
- Kreps (1988), Notes on the Theory of Choice, Theorem 5.15



Record: `topics/decision-theory/results/vnm-theorem.yaml`.

#### Weak order ⇒ Completeness — `weak-order-def-completeness`

Proved result; source **Misc.**; legacy provenance human; produced by definition; checked by nobody; 2026-09-08.

Premises:

- Weak order (`weak-order`)

Conclusion: Completeness (`completeness`)

Proof.

By definition of weak order.

Sources:

- (none recorded)



Record: `topics/decision-theory/results/weak-order-def-completeness.yaml`.

#### Completeness ∧ Transitivity ⇒ Weak order — `weak-order-def-forward`

Proved result; source **Misc.**; legacy provenance human; produced by definition; checked by nobody; 2026-09-08.

Premises:

- Completeness (`completeness`)
- Transitivity (`transitivity`)

Conclusion: Weak order (`weak-order`)

Proof.

By definition of weak order.

Sources:

- (none recorded)



Record: `topics/decision-theory/results/weak-order-def-forward.yaml`.

#### Weak order ⇒ Transitivity — `weak-order-def-transitivity`

Proved result; source **Misc.**; legacy provenance human; produced by definition; checked by nobody; 2026-09-08.

Premises:

- Weak order (`weak-order`)

Conclusion: Transitivity (`transitivity`)

Proof.

By definition of weak order.

Sources:

- (none recorded)



Record: `topics/decision-theory/results/weak-order-def-transitivity.yaml`.

### 4.2 Conjectures

These are displayed but never used as evidence in any derivation below.

#### Transitivity ∧ Independence ∧ Archimedean ⇒ Mixture continuity — `archimedean-independence-imply-continuity`

Conjecture; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Transitivity (`transitivity`)
- Independence (`independence`)
- Archimedean (`archimedean`)

Conclusion: Mixture continuity (`continuity`)

No proof is recorded. This is a conjecture only.

Notes. Known with completeness added (Jensen 1967). Without it the cone $K = \{q - p : q \succeq p\}$ is convex; the question is whether the Archimedean axiom forces it to be closed.

Sources:

- (none recorded)



Record: `topics/decision-theory/results/archimedean-independence-imply-continuity.yaml`.

#### Completeness ∧ Closed-graph continuity ∧ Betweenness ⇒ Transitivity — `betweenness-continuity-imply-transitivity`

Conjecture; source **Misc.**; legacy provenance human; produced by ZG; checked by nobody; 2026-09-08.

Premises:

- Completeness (`completeness`)
- Closed-graph continuity (`closed-graph-continuity`)
- Betweenness (`betweenness`)

Conclusion: Transitivity (`transitivity`)

No proof is recorded. This is a conjecture only.

Notes. Sample conjecture.

Sources:

- (none recorded)



Record: `topics/decision-theory/results/betweenness-continuity-imply-transitivity.yaml`.

## 5. Models

A model witnesses consistency, and so refutes every implication from what it satisfies to what it violates. Independence is never recorded directly; the model is the record.

### Band relation — `band-relation`

Model; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Satisfies:

- Completeness (`completeness`)
- Acyclicity (`acyclicity`)

Violates:

- Quasi-transitivity (`quasi-transitivity`)

Unknown in this model: Archimedean (`archimedean`), Betweenness (`betweenness`), Closed-graph continuity (`closed-graph-continuity`), Mixture continuity (`continuity`), Independence (`independence`)

Construction.

Fix $u : X \to \mathbb{R}$ non-constant and $\epsilon > 0$. Define an asymmetric relation P by
p P q iff $\operatorname{EU}_u(p) - \operatorname{EU}_u(q) \in (\epsilon , 2\epsilon ]$, and let $p \succeq q$ iff not q P p. Then
$\succeq$ is complete (P is asymmetric) and $\succ = P$. P is acyclic because $\operatorname{EU}_u$
strictly increases along any P-chain. But P is not transitive: with
$\operatorname{EU}_u(p), \operatorname{EU}_u(q), \operatorname{EU}_u(r) = 3\epsilon , 1.5\epsilon , 0$ we have p P q and q P r while
$\operatorname{EU}_u(p) - \operatorname{EU}_u(r) = 3\epsilon \notin (\epsilon , 2\epsilon ]$.

Executable checks: `topics/decision-theory/checks/countermodels.py`.

Notes. Sanity-checked numerically in checks/countermodels.py. Not yet checked by a human.

Sources:

- (none recorded)



Record: `topics/decision-theory/models/band-relation.yaml`.

### Incomplete, continuous, non-Archimedean — `incomplete-continuous-non-archimedean`

Conjectured model; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Satisfies:

- Transitivity (`transitivity`)
- Mixture continuity (`continuity`)

Violates:

- Archimedean (`archimedean`)

Unknown in this model: nothing; every principle is settled.

Notes. Completeness is used essentially in continuity-completeness-imply-archimedean; no countermodel yet.

Sources:

- (none recorded)



Record: `topics/decision-theory/models/incomplete-continuous-non-archimedean.yaml`.

### Lexicographic EU — `lexicographic-eu`

Model; source **Misc.**; legacy provenance human; produced by literature; checked by nobody; 2026-09-08.

Satisfies:

- Completeness (`completeness`)
- Transitivity (`transitivity`)
- Independence (`independence`)

Violates:

- Mixture continuity (`continuity`)
- Archimedean (`archimedean`)

Unknown in this model: nothing; every principle is settled.

Construction.

Lexicographic expected utility. With $X = \{a, b, c\}$ let $p \succeq q$ iff
$p(a) > q(a)$, or $p(a) = q(a)$ and $p(b) \ge q(b)$. This is complete and
transitive (a lexicographic order on $\mathbb{R} ^{2}$), and satisfies independence
because mixing with r multiplies the vector of differences by $\lambda$, which
preserves lexicographic sign. But $\{\lambda : \lambda \delta _a + (1- \lambda )\delta _c \succeq \delta _b\} = (0, 1]$,
which is not closed.

The same lexicographic order $(p \succeq q$ iff $p(a) > q(a)$, or $p(a) = q(a)$ and
$p(b) \ge q(b)$). Here $\delta _a \succ \delta _b \succ \delta _c$, but every mixture $\beta \delta _a + (1- \beta )\delta _c$
with $\beta > 0$ puts positive weight on a and so is strictly preferred to
$\delta _b$; no $\beta$ with $\delta _b \succ \beta \delta _a + (1- \beta )\delta _c$ exists.

Notes. Derivable from lexicographic-not-archimedean together with continuity-completeness-imply-archimedean (the validator reports it as redundant); kept because it is the form the literature states.

Sources:

- Hausner (1954), Multidimensional utilities, in Decision Processes (Thrall, Coombs & Davis eds.)
- Fishburn (1971), A study of lexicographic expected utility, Management Science 17
- Hausner (1954), Multidimensional utilities
- Fishburn (1971), A study of lexicographic expected utility, Management Science 17



Record: `topics/decision-theory/models/lexicographic-eu.yaml`.

### Non-convex cone — `non-convex-cone`

Model; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Satisfies:

- Completeness (`completeness`)
- Independence (`independence`)
- Closed-graph continuity (`closed-graph-continuity`)

Violates:

- Transitivity (`transitivity`)

Unknown in this model: Acyclicity (`acyclicity`), Quasi-transitivity (`quasi-transitivity`)

Construction.

Let $X = \{a, b, c\}$ and identify a difference q − p of lotteries with the
point $(q(a) - p(a), q(b) - p(b)) \in \mathbb{R} ^{2}$. Let $C \subseteq \mathbb{R} ^{2}$ be the closed upper
half-plane together with the closed sector of directions [225°, 270°],
and define $q \succeq p$ iff $q - p \in C$.

$\operatorname{Completeness}: C \cup (- C) = \mathbb{R} ^{2}$ since −C contains the closed lower
half-plane. Independence: mixing both sides with r multiplies the
difference by $\lambda > 0$, and C is a cone. Closed graph: (p, q) ↦ q − p is
continuous and C is closed. Reflexivity: $0 \in C$.

Transitivity fails: take x at direction 240° and y at direction 170°,
both in C and small enough that $p, q = p + x\ldots$ are lotteries; $x + y$ has
direction $\approx 205$°, which is not in C. So with $q - p = x$ and $r - q = y$ we
have $q \succeq p$ and $r \succeq q$ but not $r \succeq p$.

Executable checks: `topics/decision-theory/checks/countermodels.py`.

Notes. Sanity-checked numerically in checks/countermodels.py (completeness and independence hold, transitivity fails on random samples). Not yet checked by a human. Any non-convex closed cone C with $C \cup - C = \mathbb{R} ^{2}$ works.

Sources:

- (none recorded)



Record: `topics/decision-theory/models/non-convex-cone.yaml`.

### Rational levels — `rational-levels`

Model; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Satisfies:

- Completeness (`completeness`)
- Transitivity (`transitivity`)
- Archimedean (`archimedean`)

Violates:

- Mixture continuity (`continuity`)

Unknown in this model: Betweenness (`betweenness`), Independence (`independence`)

Construction.

Let $X = \{a, b, c\}$ and define a three-valued function V on $\Delta (X)$:
$V(p) = 2$ if $p(a) \in \mathbb{Q} ; V(p) = 1$ if $p(a) \notin \mathbb{Q}$ and $p(b) \in \mathbb{Q} ; V(p) = 0$
otherwise. Let $p \succeq q$ iff $V(p) \ge V(q)$. This is a weak order.

Mixture continuity fails: along the line from $\delta _a$ to $\delta _b$ the mixture
$\lambda \delta _a + (1- \lambda )\delta _b$ has $V = 2$ exactly when $\lambda \in \mathbb{Q}$, so
$\{\lambda : \lambda \delta _a + (1- \lambda )\delta _b \succeq \delta _c\} = \mathbb{Q} \cap [0,1]$ is not closed.

Archimedean holds: a chain $p \succ q \succ r$ forces $V(p) = 2, V(q) = 1, V(r) = 0$,
so $p(a) \in \mathbb{Q}$ and $r(a) \notin \mathbb{Q}$, in particular $p(a) \ne r(a)$. Along
$m(\alpha ) = \alpha p + (1- \alpha )r$ the coordinate $m(\alpha )(a) = r(a) + \alpha (p(a) - r(a))$ is
rational for a dense set of $\alpha$, so some $\alpha \in (0,1)$ close to 1 has
$V(m(\alpha )) = 2 > V(q)$. For the other half, $m(\beta )(a)$ is irrational for all but
countably many $\beta$; and $m(\beta )(b) = r(b) + \beta (p(b) - r(b))$ is irrational for
all but countably many $\beta$ when $p(b) \ne r(b)$, and equals $r(b) \notin \mathbb{Q}$ when
$p(b) = r(b)$ (because $V(r) = 0$). So some $\beta \in (0,1)$ close to 0 has
$V(m(\beta )) = 0 < V(q)$.

Notes. The construction is deliberately artificial: it shows that the Archimedean axiom cannot replace mixture continuity even for weak orders, unless something like independence is added. Not yet checked by a human.

Sources:

- (none recorded)



Record: `topics/decision-theory/models/rational-levels.yaml`.

### Semiorder — `semiorder`

Model; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Satisfies:

- Completeness (`completeness`)
- Quasi-transitivity (`quasi-transitivity`)
- Closed-graph continuity (`closed-graph-continuity`)

Violates:

- Transitivity (`transitivity`)
- Independence (`independence`)

Unknown in this model: Betweenness (`betweenness`)

Construction.

A semiorder with a just-noticeable difference. Fix $u : X \to \mathbb{R}$ non-constant
and $\epsilon > 0$, and let $p \succeq q$ iff $\operatorname{EU}_u(p) \ge \operatorname{EU}_u(q) - \epsilon . \operatorname{Completeness}$: one of
the two differences is $\ge 0 > - \epsilon$. Quasi-transitivity: $p \succ q$ iff
$\operatorname{EU}_u(p) > \operatorname{EU}_u(q) + \epsilon$, and this is transitive. Closed graph: the graph is
the preimage of $[- \epsilon , \infty )$ under a continuous map. Transitivity fails: pick
p, q, r with $\operatorname{EU}_u$ equal to $0, - 0.8\epsilon , - 1.6\epsilon$; then $p \succeq q \succeq r$ but not $p \succeq r$.

Executable checks: `topics/decision-theory/checks/countermodels.py`.

Notes. Sanity-checked numerically in checks/countermodels.py. The relation is Luce's semiorder; the verification that it fits this framework is AI-produced and unchecked.

Sources:

- Luce (1956), Semiorders and a theory of utility discrimination, Econometrica 24



Record: `topics/decision-theory/models/semiorder.yaml`.

### SSB utility — `ssb`

Conjectured model; source **Misc.**; legacy provenance human; produced by ZG; checked by nobody; 2026-09-08.

Satisfies:

- Completeness (`completeness`)
- Closed-graph continuity (`closed-graph-continuity`)
- Archimedean (`archimedean`)

Violates:

- Transitivity (`transitivity`)
- Independence (`independence`)

Unknown in this model: nothing; every principle is settled.

Notes. Sample conjecture; which of betweenness and quasi-transitivity hold is to be checked.

Sources:

- Fishburn (1982), Nontransitive measurable utility, Journal of Mathematical Psychology 26



Record: `topics/decision-theory/models/ssb.yaml`.

### Unanimity over two utilities — `unanimity-two-utilities`

Model; source **Misc.**; legacy provenance human; produced by literature; checked by nobody; 2026-09-08.

Satisfies:

- Transitivity (`transitivity`)
- Independence (`independence`)
- Closed-graph continuity (`closed-graph-continuity`)
- Expected multi-utility representation (`multi-utility`)

Violates:

- Completeness (`completeness`)

Unknown in this model: Archimedean (`archimedean`)

Construction.

Unanimity over two utilities. With $X = \{a, b, c\}$ let $p \succeq q$ iff
$p(a) \ge q(a)$ and $p(b) \ge q(b) (U = \{u_{1}, u_{2}\}$ with $u_{1} = 1_a, u_{2} = 1_b$).
This is an expected multi-utility representation, hence transitive,
independent and closed-graph continuous; but $\delta _a$ and $\delta _b$ are
incomparable.

Sources:

- Aumann (1962), Utility theory without the completeness axiom, Econometrica 30
- Dubra, Maccheroni & Ok (2004), JET 115



Record: `topics/decision-theory/models/unanimity-two-utilities.yaml`.

### Weighted utility — `weighted-utility`

Model; source **Misc.**; legacy provenance human; produced by literature; checked by nobody; 2026-09-08.

Satisfies:

- Completeness (`completeness`)
- Transitivity (`transitivity`)
- Closed-graph continuity (`closed-graph-continuity`)
- Betweenness (`betweenness`)

Violates:

- Independence (`independence`)

Unknown in this model: nothing; every principle is settled.

Construction.

Weighted utility. Fix $u : X \to \mathbb{R}$ and a weight $w : X \to (0,\infty )$ that is not
constant, and let $V(p) = \sum p(x)w(x)u(x) / \sum p(x)w(x)$; put $p \succeq q$ iff
$V(p) \ge V(q)$. V is continuous on $\Delta (X)$, so $\succeq$ is a weak order with closed
graph. Its indifference sets are the intersections of $\Delta (X)$ with
hyperplanes $\{p : \sum p(x)w(x)(u(x) - v) = 0\}$, which are straight, so
betweenness holds. Since w is not constant these hyperplanes are not
parallel, so $\succeq$ is not an expected-utility order and (being a continuous
weak order) must violate independence.

Sources:

- Chew (1983), A generalization of the quasilinear mean with applications to the measurement of income inequality and decision theory resolving the Allais paradox, Econometrica 51
- Dekel (1986), An axiomatic characterization of preferences under uncertainty: weakening the independence axiom, JET 40



Record: `topics/decision-theory/models/weighted-utility.yaml`.

## 6. Derived state

Computed from the proved records only, by the closure rules in `README.md`. Conjectures take no part. A missing entry means *not recorded*, not *false*.

### 6.1 Interderivable principles

No two principles are currently interderivable.

### 6.2 Settled single-premise implications (27)

| From | To | Via |
| --- | --- | --- |
| Closed-graph continuity | Mixture continuity | `closed-graph-implies-mixture-continuity` |
| Expected-utility representation | Acyclicity | `eu-implies-multi-utility`, `multi-utility-implies-transitivity`, `transitivity-implies-quasi-transitivity`, `quasi-transitivity-implies-acyclicity` |
| Expected-utility representation | Archimedean | `eu-implies-completeness`, `eu-implies-multi-utility`, `multi-utility-implies-closed-graph`, `closed-graph-implies-mixture-continuity`, `continuity-completeness-imply-archimedean` |
| Expected-utility representation | Betweenness | `eu-implies-multi-utility`, `multi-utility-implies-independence`, `independence-implies-betweenness` |
| Expected-utility representation | Closed-graph continuity | `eu-implies-multi-utility`, `multi-utility-implies-closed-graph` |
| Expected-utility representation | Completeness | `eu-implies-completeness` |
| Expected-utility representation | Mixture continuity | `eu-implies-multi-utility`, `multi-utility-implies-closed-graph`, `closed-graph-implies-mixture-continuity` |
| Expected-utility representation | Independence | `eu-implies-multi-utility`, `multi-utility-implies-independence` |
| Expected-utility representation | Expected multi-utility representation | `eu-implies-multi-utility` |
| Expected-utility representation | Quasi-transitivity | `eu-implies-multi-utility`, `multi-utility-implies-transitivity`, `transitivity-implies-quasi-transitivity` |
| Expected-utility representation | Transitivity | `eu-implies-multi-utility`, `multi-utility-implies-transitivity` |
| Expected-utility representation | Weak order | `eu-implies-completeness`, `eu-implies-multi-utility`, `multi-utility-implies-transitivity`, `weak-order-def-forward` |
| Independence | Betweenness | `independence-implies-betweenness` |
| Expected multi-utility representation | Acyclicity | `multi-utility-implies-transitivity`, `transitivity-implies-quasi-transitivity`, `quasi-transitivity-implies-acyclicity` |
| Expected multi-utility representation | Betweenness | `multi-utility-implies-independence`, `independence-implies-betweenness` |
| Expected multi-utility representation | Closed-graph continuity | `multi-utility-implies-closed-graph` |
| Expected multi-utility representation | Mixture continuity | `multi-utility-implies-closed-graph`, `closed-graph-implies-mixture-continuity` |
| Expected multi-utility representation | Independence | `multi-utility-implies-independence` |
| Expected multi-utility representation | Quasi-transitivity | `multi-utility-implies-transitivity`, `transitivity-implies-quasi-transitivity` |
| Expected multi-utility representation | Transitivity | `multi-utility-implies-transitivity` |
| Quasi-transitivity | Acyclicity | `quasi-transitivity-implies-acyclicity` |
| Transitivity | Acyclicity | `transitivity-implies-quasi-transitivity`, `quasi-transitivity-implies-acyclicity` |
| Transitivity | Quasi-transitivity | `transitivity-implies-quasi-transitivity` |
| Weak order | Acyclicity | `weak-order-def-transitivity`, `transitivity-implies-quasi-transitivity`, `quasi-transitivity-implies-acyclicity` |
| Weak order | Completeness | `weak-order-def-completeness` |
| Weak order | Quasi-transitivity | `weak-order-def-transitivity`, `transitivity-implies-quasi-transitivity` |
| Weak order | Transitivity | `weak-order-def-transitivity` |

### 6.3 Refuted single-premise implications (81)

Read *A ⇏ B*: assuming A alone does not yield B, as the named model shows.

| From | To | Witness model |
| --- | --- | --- |
| Acyclicity | Archimedean | `lexicographic-eu` |
| Acyclicity | Closed-graph continuity | `lexicographic-eu`, `rational-levels` |
| Acyclicity | Completeness | `unanimity-two-utilities` |
| Acyclicity | Mixture continuity | `lexicographic-eu`, `rational-levels` |
| Acyclicity | Expected-utility representation | `band-relation`, `lexicographic-eu`, `rational-levels`, `semiorder`, `unanimity-two-utilities`, `weighted-utility` |
| Acyclicity | Independence | `semiorder`, `weighted-utility` |
| Acyclicity | Expected multi-utility representation | `band-relation`, `lexicographic-eu`, `rational-levels`, `semiorder`, `weighted-utility` |
| Acyclicity | Quasi-transitivity | `band-relation` |
| Acyclicity | Transitivity | `band-relation`, `semiorder` |
| Acyclicity | Weak order | `band-relation`, `semiorder`, `unanimity-two-utilities` |
| Archimedean | Closed-graph continuity | `rational-levels` |
| Archimedean | Mixture continuity | `rational-levels` |
| Archimedean | Expected-utility representation | `non-convex-cone`, `rational-levels`, `semiorder`, `weighted-utility` |
| Archimedean | Independence | `semiorder`, `weighted-utility` |
| Archimedean | Expected multi-utility representation | `non-convex-cone`, `rational-levels`, `semiorder`, `weighted-utility` |
| Archimedean | Transitivity | `non-convex-cone`, `semiorder` |
| Archimedean | Weak order | `non-convex-cone`, `semiorder` |
| Betweenness | Archimedean | `lexicographic-eu` |
| Betweenness | Closed-graph continuity | `lexicographic-eu` |
| Betweenness | Completeness | `unanimity-two-utilities` |
| Betweenness | Mixture continuity | `lexicographic-eu` |
| Betweenness | Expected-utility representation | `lexicographic-eu`, `non-convex-cone`, `unanimity-two-utilities`, `weighted-utility` |
| Betweenness | Independence | `weighted-utility` |
| Betweenness | Expected multi-utility representation | `lexicographic-eu`, `non-convex-cone`, `weighted-utility` |
| Betweenness | Transitivity | `non-convex-cone` |
| Betweenness | Weak order | `non-convex-cone`, `unanimity-two-utilities` |
| Closed-graph continuity | Completeness | `unanimity-two-utilities` |
| Closed-graph continuity | Expected-utility representation | `non-convex-cone`, `semiorder`, `unanimity-two-utilities`, `weighted-utility` |
| Closed-graph continuity | Independence | `semiorder`, `weighted-utility` |
| Closed-graph continuity | Expected multi-utility representation | `non-convex-cone`, `semiorder`, `weighted-utility` |
| Closed-graph continuity | Transitivity | `non-convex-cone`, `semiorder` |
| Closed-graph continuity | Weak order | `non-convex-cone`, `semiorder`, `unanimity-two-utilities` |
| Completeness | Archimedean | `lexicographic-eu` |
| Completeness | Closed-graph continuity | `lexicographic-eu`, `rational-levels` |
| Completeness | Mixture continuity | `lexicographic-eu`, `rational-levels` |
| Completeness | Expected-utility representation | `band-relation`, `lexicographic-eu`, `non-convex-cone`, `rational-levels`, `semiorder`, `weighted-utility` |
| Completeness | Independence | `semiorder`, `weighted-utility` |
| Completeness | Expected multi-utility representation | `band-relation`, `lexicographic-eu`, `non-convex-cone`, `rational-levels`, `semiorder`, `weighted-utility` |
| Completeness | Quasi-transitivity | `band-relation` |
| Completeness | Transitivity | `band-relation`, `non-convex-cone`, `semiorder` |
| Completeness | Weak order | `band-relation`, `non-convex-cone`, `semiorder` |
| Mixture continuity | Completeness | `unanimity-two-utilities` |
| Mixture continuity | Expected-utility representation | `non-convex-cone`, `semiorder`, `unanimity-two-utilities`, `weighted-utility` |
| Mixture continuity | Independence | `semiorder`, `weighted-utility` |
| Mixture continuity | Expected multi-utility representation | `non-convex-cone`, `semiorder`, `weighted-utility` |
| Mixture continuity | Transitivity | `non-convex-cone`, `semiorder` |
| Mixture continuity | Weak order | `non-convex-cone`, `semiorder`, `unanimity-two-utilities` |
| Independence | Archimedean | `lexicographic-eu` |
| Independence | Closed-graph continuity | `lexicographic-eu` |
| Independence | Completeness | `unanimity-two-utilities` |
| Independence | Mixture continuity | `lexicographic-eu` |
| Independence | Expected-utility representation | `lexicographic-eu`, `non-convex-cone`, `unanimity-two-utilities` |
| Independence | Expected multi-utility representation | `lexicographic-eu`, `non-convex-cone` |
| Independence | Transitivity | `non-convex-cone` |
| Independence | Weak order | `non-convex-cone`, `unanimity-two-utilities` |
| Expected multi-utility representation | Completeness | `unanimity-two-utilities` |
| Expected multi-utility representation | Expected-utility representation | `unanimity-two-utilities` |
| Expected multi-utility representation | Weak order | `unanimity-two-utilities` |
| Quasi-transitivity | Archimedean | `lexicographic-eu` |
| Quasi-transitivity | Closed-graph continuity | `lexicographic-eu`, `rational-levels` |
| Quasi-transitivity | Completeness | `unanimity-two-utilities` |
| Quasi-transitivity | Mixture continuity | `lexicographic-eu`, `rational-levels` |
| Quasi-transitivity | Expected-utility representation | `lexicographic-eu`, `rational-levels`, `semiorder`, `unanimity-two-utilities`, `weighted-utility` |
| Quasi-transitivity | Independence | `semiorder`, `weighted-utility` |
| Quasi-transitivity | Expected multi-utility representation | `lexicographic-eu`, `rational-levels`, `semiorder`, `weighted-utility` |
| Quasi-transitivity | Transitivity | `semiorder` |
| Quasi-transitivity | Weak order | `semiorder`, `unanimity-two-utilities` |
| Transitivity | Archimedean | `lexicographic-eu` |
| Transitivity | Closed-graph continuity | `lexicographic-eu`, `rational-levels` |
| Transitivity | Completeness | `unanimity-two-utilities` |
| Transitivity | Mixture continuity | `lexicographic-eu`, `rational-levels` |
| Transitivity | Expected-utility representation | `lexicographic-eu`, `rational-levels`, `unanimity-two-utilities`, `weighted-utility` |
| Transitivity | Independence | `weighted-utility` |
| Transitivity | Expected multi-utility representation | `lexicographic-eu`, `rational-levels`, `weighted-utility` |
| Transitivity | Weak order | `unanimity-two-utilities` |
| Weak order | Archimedean | `lexicographic-eu` |
| Weak order | Closed-graph continuity | `lexicographic-eu`, `rational-levels` |
| Weak order | Mixture continuity | `lexicographic-eu`, `rational-levels` |
| Weak order | Expected-utility representation | `lexicographic-eu`, `rational-levels`, `weighted-utility` |
| Weak order | Independence | `weighted-utility` |
| Weak order | Expected multi-utility representation | `lexicographic-eu`, `rational-levels`, `weighted-utility` |

### 6.4 Open single-premise pairs (24)

Listed in `OPEN-QUESTIONS.md`.

### Negative implications (0)

Read A ⇒ ¬B: A and B cannot hold together. This does not by itself witness a model of A.

None.

### 6.5 What the recorded premise packages entail

Every multi-premise package used by a proved result, with its full consequence set.

#### Completeness + Transitivity + Independence + Mixture continuity

Assumes: `completeness`, `transitivity`, `independence`, `continuity`.

- Rules out (entails their negations): nothing further
- Entails: Acyclicity (`acyclicity`), Archimedean (`archimedean`), Betweenness (`betweenness`), Closed-graph continuity (`closed-graph-continuity`), Expected-utility representation (`eu-representation`), Expected multi-utility representation (`multi-utility`), Quasi-transitivity (`quasi-transitivity`), Weak order (`weak-order`)
- Refuted (a model satisfies the package and violates these): nothing
- Open: nothing

#### Transitivity + Independence + Closed-graph continuity

Assumes: `transitivity`, `independence`, `closed-graph-continuity`.

- Rules out (entails their negations): nothing further
- Entails: Acyclicity (`acyclicity`), Betweenness (`betweenness`), Mixture continuity (`continuity`), Expected multi-utility representation (`multi-utility`), Quasi-transitivity (`quasi-transitivity`)
- Refuted (a model satisfies the package and violates these): Completeness (`completeness`), Expected-utility representation (`eu-representation`), Weak order (`weak-order`)
- Open: Archimedean (`archimedean`)

#### Transitivity + Independence + Mixture continuity

Assumes: `transitivity`, `independence`, `continuity`.

- Rules out (entails their negations): nothing further
- Entails: Acyclicity (`acyclicity`), Betweenness (`betweenness`), Closed-graph continuity (`closed-graph-continuity`), Expected multi-utility representation (`multi-utility`), Quasi-transitivity (`quasi-transitivity`)
- Refuted (a model satisfies the package and violates these): Completeness (`completeness`), Expected-utility representation (`eu-representation`), Weak order (`weak-order`)
- Open: Archimedean (`archimedean`)

#### Mixture continuity + Completeness

Assumes: `continuity`, `completeness`.

- Rules out (entails their negations): nothing further
- Entails: Archimedean (`archimedean`)
- Refuted (a model satisfies the package and violates these): Expected-utility representation (`eu-representation`), Independence (`independence`), Expected multi-utility representation (`multi-utility`), Transitivity (`transitivity`), Weak order (`weak-order`)
- Open: Acyclicity (`acyclicity`), Betweenness (`betweenness`), Closed-graph continuity (`closed-graph-continuity`), Quasi-transitivity (`quasi-transitivity`)

#### Completeness + Transitivity

Assumes: `completeness`, `transitivity`.

- Rules out (entails their negations): nothing further
- Entails: Acyclicity (`acyclicity`), Quasi-transitivity (`quasi-transitivity`), Weak order (`weak-order`)
- Refuted (a model satisfies the package and violates these): Archimedean (`archimedean`), Closed-graph continuity (`closed-graph-continuity`), Mixture continuity (`continuity`), Expected-utility representation (`eu-representation`), Independence (`independence`), Expected multi-utility representation (`multi-utility`)
- Open: Betweenness (`betweenness`)

## 8. Where this came from

The paper catalogue is `topics/decision-theory/papers.yaml`; any included source documents are in `topics/decision-theory/sources/`. The extraction log, with transcription decisions and deliberately deferred items, is `topics/decision-theory/extraction.md`. Read it before trusting any single page reference.
