# Open questions — Preference axioms over lotteries

Conjectures, their current answers, and remaining gaps where a new result or model would contribute to the map.

**"Open" means not settled by the records in this bundle.** It does not mean unsolved in the literature, and it does not mean hard. Many entries below are routine and simply have not been added yet. Check the sources before assuming a question is new.

## 1. Conjectures and their answers

Answers below are recomputed from proved records under the fixed topic background. A conjectured record supplies no evidence for its own answer. Records marked was_conjectured remain in this history after promotion to proved; their proved status, rather than the historical marker, determines whether they supply evidence. Original sources and notes are retained below each answer.

### 1.1 Unresolved (2)

#### Transitivity ∧ Independence ∧ Archimedean ⇒ Mixture continuity — `archimedean-independence-imply-continuity`

**Answer: Open.**

Original record notes:

Known with completeness added (Jensen 1967). Without it the cone $K = \{q - p : q \succeq p\}$ is convex; the question is whether the Archimedean axiom forces it to be closed.

- (none recorded)

Record: `topics/decision-theory/results/archimedean-independence-imply-continuity.yaml`.

#### Incomplete, continuous, non-Archimedean — `incomplete-continuous-non-archimedean`

**Answer: Open.**

Original record notes:

Completeness is used essentially in continuity-completeness-imply-archimedean; no countermodel yet.

- (none recorded)

Record: `topics/decision-theory/models/incomplete-continuous-non-archimedean.yaml`.

### 1.2 Resolved (2)

#### Completeness ∧ Closed-graph continuity ∧ Betweenness ⇒ Transitivity — `betweenness-continuity-imply-transitivity`

**Answer: Refuted.**

Supporting result ids: `independence-implies-betweenness`.

Model witness ids: `non-convex-cone`.

Original record notes:

Sample conjecture.

- (none recorded)

Record: `topics/decision-theory/results/betweenness-continuity-imply-transitivity.yaml`.

#### SSB utility — `ssb`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `closed-graph-implies-mixture-continuity`, `continuity-completeness-imply-archimedean`.

Model witness ids: `semiorder`.

Original record notes:

Sample conjecture; which of betweenness and quasi-transitivity hold is to be checked.

- Fishburn (1982), Nontransitive measurable utility, Journal of Mathematical Psychology 26

Record: `topics/decision-theory/models/ssb.yaml`.

### 1.3 Incompatible with background (0)

None.

## 2. Central questions

Answering a central question settles many other open questions. A question is S ⊢ c, whether S entails c, for S at most two principle classes (True, with none) and c a class or False, asked only where no smaller premise set already proves or excludes c; S ⊢ False asks whether S is inconsistent. "No" denies the entailment, not the conditional. A question is settled alike by a proof, by an exclusion (S ∧ c ⇒ False) or by a recorded model that holds S and fails c. Each row scores an open question by the number of *other* open questions that stop being open once the answer joins the proved records. Both answers are scored, because proving a strong conjecture settles everything below it while refuting a weak one settles everything above it; a question with two high scores is worth answering either way. A refutation is scored by its least informative countermodel, so an actual model settles at least as much. A model check (model: principle) scores deciding an unknown verdict inside a recorded model, which settles questions exactly as a proof does. Under a background, only models of that background count and the class of its theorems is named after it (True, with no preset). Recompute with `python3 scripts/pmap.py lynchpins decision-theory`.

### Under no extra assumptions

12 classes and 7 fitting models; 118 open questions. 76% of questions with up to two premises settled (391 of 509).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | Archimedean ∧ Expected multi-utility representation ⊢ Completeness | 15 | 12 |
| 2 | Archimedean ∧ Expected multi-utility representation ⊢ Expected-utility representation | 15 | 12 |
| 3 | Archimedean ∧ Expected multi-utility representation ⊢ Weak order | 15 | 12 |
| 4 | unanimity-two-utilities: Archimedean | 13 | 13 |
| 5 | Expected multi-utility representation ⊢ Archimedean | 13 | 12 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| 33 | Mixture continuity ∧ Transitivity ⊬ Archimedean ★ bronze | 3 | 15 | `incomplete-continuous-non-archimedean` |
| — | Closed-graph continuity ∧ Completeness ⊬ False (⊥) ★ bronze  [proved] | — | — | `ssb` |
| — | Mixture continuity ∧ Transitivity ⊬ False (⊥) ★ bronze  [proved] | — | — | `incomplete-continuous-non-archimedean` |
| — | Archimedean ∧ Independence ∧ Transitivity ⊢ Mixture continuity ★ bronze  [more than two premises] | — | — | `archimedean-independence-imply-continuity` |
| — | Betweenness ∧ Closed-graph continuity ∧ Completeness ⊢ Transitivity ★ bronze  [more than two premises] | — | — | `betweenness-continuity-imply-transitivity` |
| — | Closed-graph continuity ∧ Completeness ⊬ Independence ★ bronze  [proved] | — | — | `ssb` |
| — | Closed-graph continuity ∧ Completeness ⊬ Transitivity ★ bronze  [proved] | — | — | `ssb` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| No Rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | Acyclicity ∧ Betweenness ⊬ Transitivity | 0 | 63 |
| 2 | Acyclicity ∧ Independence ⊬ Transitivity | 1 | 40 |
| 3 | Betweenness ∧ Quasi-transitivity ⊬ Transitivity | 1 | 39 |
| 4 | non-convex-cone: Acyclicity | 2 | 38 |
| 5 | True (⊤) ⊬ Betweenness | 0 | 35 |

## 3. Open questions under each recorded package

The most useful place to work: these are open *given* assumptions the sources already make.

### Transitivity + Independence + Closed-graph continuity

Assuming `transitivity`, `independence`, `closed-graph-continuity`, these remain open:

- Archimedean (`archimedean`)

### Transitivity + Independence + Mixture continuity

Assuming `transitivity`, `independence`, `continuity`, these remain open:

- Archimedean (`archimedean`)

### Mixture continuity + Completeness

Assuming `continuity`, `completeness`, these remain open:

- Acyclicity (`acyclicity`)
- Betweenness (`betweenness`)
- Closed-graph continuity (`closed-graph-continuity`)
- Quasi-transitivity (`quasi-transitivity`)

### Completeness + Transitivity

Assuming `completeness`, `transitivity`, these remain open:

- Betweenness (`betweenness`)

## 4. Unknown verdicts inside each model

For these principles the model has not been checked either way. Deciding one is a self-contained calculation in a construction that is already written down.

### Band relation — `band-relation`

- Archimedean (`archimedean`)
- Betweenness (`betweenness`)
- Closed-graph continuity (`closed-graph-continuity`)
- Mixture continuity (`continuity`)
- Independence (`independence`)

### Incomplete, continuous, non-Archimedean — `incomplete-continuous-non-archimedean`

Fully determined; nothing unknown.

### Lexicographic EU — `lexicographic-eu`

Fully determined; nothing unknown.

### Non-convex cone — `non-convex-cone`

- Acyclicity (`acyclicity`)
- Quasi-transitivity (`quasi-transitivity`)

### Rational levels — `rational-levels`

- Betweenness (`betweenness`)
- Independence (`independence`)

### Semiorder — `semiorder`

- Betweenness (`betweenness`)

### SSB utility — `ssb`

Fully determined; nothing unknown.

### Unanimity over two utilities — `unanimity-two-utilities`

- Archimedean (`archimedean`)

### Weighted utility — `weighted-utility`

Fully determined; nothing unknown.

## 5. Open single-premise pairs (24)

*A ⇒ B ?* means neither implication nor incompatibility nor a countermodel is currently recorded. Grouped by antecedent. Most are open only because the obvious model has not been added.

- **Acyclicity** (`acyclicity`) ⇒ Betweenness
- **Archimedean** (`archimedean`) ⇒ Acyclicity, Betweenness, Completeness, Quasi-transitivity
- **Betweenness** (`betweenness`) ⇒ Acyclicity, Quasi-transitivity
- **Closed-graph continuity** (`closed-graph-continuity`) ⇒ Acyclicity, Archimedean, Betweenness, Quasi-transitivity
- **Completeness** (`completeness`) ⇒ Acyclicity, Betweenness
- **Expected multi-utility representation** (`multi-utility`) ⇒ Archimedean
- **Independence** (`independence`) ⇒ Acyclicity, Quasi-transitivity
- **Mixture continuity** (`continuity`) ⇒ Acyclicity, Archimedean, Betweenness, Closed-graph continuity, Quasi-transitivity
- **Quasi-transitivity** (`quasi-transitivity`) ⇒ Betweenness
- **Transitivity** (`transitivity`) ⇒ Betweenness
- **Weak order** (`weak-order`) ⇒ Betweenness

## 6. Deliberately deferred

`topics/decision-theory/extraction.md` has a section listing claims that were **not** recorded because they need a further reading of the sources. Those are marked deferred rather than open: the answer is likely in the literature and needs transcribing, not discovering. Read that section before starting work.

## 7. How to record an answer

- Proved an implication? Add `topics/decision-theory/results/<id>.yaml` with the full premise list and the proof.
- Refuted one? Add `topics/decision-theory/models/<id>.yaml` listing what you verified in `satisfies` and `violates`.
- Settling an existing conjecture? For a proof of the same statement, keep its ID, set `was_conjectured: true`, and change its status to `proved`. If the statement changes substantially, retain the original and add a separate record. Refuted proposals stay `status: conjectured`, with proved refuting evidence recorded separately. Answers under extra exploration assumptions are contextual, not global record statuses.
- Worked on a question without settling it? Put what you tried and what would settle it in the conjecture's `notes`; that alone earns it a bronze lynchpin star. Say in the notes whether you think it deserves silver or gold, by importance and difficulty, and why. Only a human sets `tier: silver` or `tier: gold`; an agent never does.
- Not sure? Add it with `status: conjectured`, an empty proof, and say in `notes` what would settle it.
- Then run `python3 scripts/pmap.py validate` and `status`. Never hand-edit the derived counts.

`README.md` has the exact record shapes and the sourcing rules. Follow them; an unsourced or misattributed record is worse than an absent one.
