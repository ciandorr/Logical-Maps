# Open questions — Preference axioms over lotteries

Recorded conjectures, their current answers, and remaining gaps where a new result or model would contribute to the map.

**"Open" means not settled by the records in this bundle.** It does not mean unsolved in the literature, and it does not mean hard. Many entries below are routine and simply have not been added yet. Check the sources before assuming a question is new.

## 1. Recorded conjectures and their answers

Answers below are recomputed from proved records under the fixed topic background. A conjectured record supplies no evidence for its own answer. Records marked was_conjectured remain in this history after promotion to proved; their proved status, rather than the historical marker, determines whether they supply evidence. Original sources and notes are retained below each answer.

### 1.1 Unresolved (2)

#### Transitivity ∧ Independence ∧ Archimedean ⇒ Mixture continuity — `archimedean-independence-imply-continuity`

**Answer: Open.**

Original record notes:

Known with completeness added (Jensen 1967). Without it the cone $K = \{q - p : q \succeq p\}$ is convex; the question is whether the Archimedean axiom forces it to be closed.

- (none recorded)

Record: `topics/decision-theory/results/archimedean-independence-imply-continuity.yaml`.

#### Incomplete, continuous, non-Archimedean — `incomplete-continuous-non-archimedean`

**Answer: Open.**

Original record notes:

Completeness is used essentially in continuity-completeness-imply-archimedean; no countermodel yet.

- (none recorded)

Record: `topics/decision-theory/models/incomplete-continuous-non-archimedean.yaml`.

### 1.2 Resolved (2)

#### Completeness ∧ Closed-graph continuity ∧ Betweenness ⇒ Transitivity — `betweenness-continuity-imply-transitivity`

**Answer: Refuted.**

Supporting result ids: `independence-implies-betweenness`.

Model witness ids: `non-convex-cone`.

Original record notes:

Sample conjecture.

- (none recorded)

Record: `topics/decision-theory/results/betweenness-continuity-imply-transitivity.yaml`.

#### SSB utility — `ssb`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `closed-graph-implies-mixture-continuity`, `continuity-completeness-imply-archimedean`.

Model witness ids: `semiorder`.

Original record notes:

Sample conjecture; which of betweenness and quasi-transitivity hold is to be checked.

- Fishburn (1982), Nontransitive measurable utility, Journal of Mathematical Psychology 26

Record: `topics/decision-theory/models/ssb.yaml`.

### 1.3 Incompatible with background (0)

None.

## 2. Lynchpin conjectures

Answering a lynchpin conjecture settles many other open questions. Each row scores an open question by the number of *other* open questions, between equivalence classes, that stop being open once the answer joins the proved records: implications, joint consistency of two principles, and consistency of one. Both answers are scored, because proving a strong conjecture settles everything below it while refuting a weak one settles everything above it; a question with two high scores is worth answering either way. A refutation is scored by its least informative countermodel, so an actual model settles at least as much. Model checks score deciding an unknown verdict inside a recorded model. Under a background, only models of that background count and the class of its theorems is named after it (True, with no preset). Recompute with `python3 scripts/pmap.py lynchpins decision-theory`.

### Under no extra assumptions

12 classes and 7 fitting models. Open: 24 implications, 14 joint-consistency questions, 1 consistency questions.

| Implication | if proved | if refuted |
|---|---:|---:|
| Betweenness ⇒ Quasi-transitivity | 5 | 0 |
| Acyclicity ⇒ Betweenness | 4 | 0 |
| Mixture continuity ⇒ Archimedean | 4 | 0 |
| Closed-graph continuity ⇒ Archimedean | 3 | 1 |
| Archimedean ⇒ Completeness | 3 | 0 |
| Expected multi-utility representation ⇒ Archimedean | 2 | 2 |
| Quasi-transitivity ⇒ Betweenness | 2 | 1 |
| Transitivity ⇒ Betweenness | 1 | 2 |
| Betweenness ⇒ Acyclicity | 1 | 1 |

| Consistency | if a model | if excluded |
|---|---:|---:|
| Archimedean ∧ Expected multi-utility representation | 0 | 17 |
| Expected-utility representation | 14 | 13 |
| Acyclicity ∧ Expected-utility representation | 14 | 13 |
| Archimedean ∧ Expected-utility representation | 14 | 13 |
| Betweenness ∧ Expected-utility representation | 14 | 13 |

| Model check | if satisfies | if violates |
|---|---:|---:|
| `non-convex-cone`: Acyclicity | 0 | 11 |
| `rational-levels`: Betweenness | 0 | 6 |
| `semiorder`: Betweenness | 0 | 6 |
| `non-convex-cone`: Quasi-transitivity | 0 | 5 |
| `unanimity-two-utilities`: Archimedean | 2 | 3 |

## 3. Open questions under each recorded package

The most useful place to work: these are open *given* assumptions the sources already make.

### Transitivity + Independence + Closed-graph continuity

Assuming `transitivity`, `independence`, `closed-graph-continuity`, these remain open:

- Archimedean (`archimedean`)

### Transitivity + Independence + Mixture continuity

Assuming `transitivity`, `independence`, `continuity`, these remain open:

- Archimedean (`archimedean`)

### Mixture continuity + Completeness

Assuming `continuity`, `completeness`, these remain open:

- Acyclicity (`acyclicity`)
- Betweenness (`betweenness`)
- Closed-graph continuity (`closed-graph-continuity`)
- Quasi-transitivity (`quasi-transitivity`)

### Completeness + Transitivity

Assuming `completeness`, `transitivity`, these remain open:

- Betweenness (`betweenness`)

## 4. Unknown verdicts inside each model

For these principles the model has not been checked either way. Deciding one is a self-contained calculation in a construction that is already written down.

### Band relation — `band-relation`

- Archimedean (`archimedean`)
- Betweenness (`betweenness`)
- Closed-graph continuity (`closed-graph-continuity`)
- Mixture continuity (`continuity`)
- Independence (`independence`)

### Incomplete, continuous, non-Archimedean — `incomplete-continuous-non-archimedean`

Fully determined; nothing unknown.

### Lexicographic EU — `lexicographic-eu`

Fully determined; nothing unknown.

### Non-convex cone — `non-convex-cone`

- Acyclicity (`acyclicity`)
- Quasi-transitivity (`quasi-transitivity`)

### Rational levels — `rational-levels`

- Betweenness (`betweenness`)
- Independence (`independence`)

### Semiorder — `semiorder`

- Betweenness (`betweenness`)

### SSB utility — `ssb`

Fully determined; nothing unknown.

### Unanimity over two utilities — `unanimity-two-utilities`

- Archimedean (`archimedean`)

### Weighted utility — `weighted-utility`

Fully determined; nothing unknown.

## 5. Open single-premise pairs (24)

*A ⇒ B ?* means neither implication nor incompatibility nor a countermodel is currently recorded. Grouped by antecedent. Most are open only because the obvious model has not been added.

- **Acyclicity** (`acyclicity`) ⇒ Betweenness
- **Archimedean** (`archimedean`) ⇒ Acyclicity, Betweenness, Completeness, Quasi-transitivity
- **Betweenness** (`betweenness`) ⇒ Acyclicity, Quasi-transitivity
- **Closed-graph continuity** (`closed-graph-continuity`) ⇒ Acyclicity, Archimedean, Betweenness, Quasi-transitivity
- **Completeness** (`completeness`) ⇒ Acyclicity, Betweenness
- **Expected multi-utility representation** (`multi-utility`) ⇒ Archimedean
- **Independence** (`independence`) ⇒ Acyclicity, Quasi-transitivity
- **Mixture continuity** (`continuity`) ⇒ Acyclicity, Archimedean, Betweenness, Closed-graph continuity, Quasi-transitivity
- **Quasi-transitivity** (`quasi-transitivity`) ⇒ Betweenness
- **Transitivity** (`transitivity`) ⇒ Betweenness
- **Weak order** (`weak-order`) ⇒ Betweenness

## 6. Deliberately deferred

`topics/decision-theory/extraction.md` has a section listing claims that were **not** recorded because they need a further reading of the sources. Those are marked deferred rather than open: the answer is likely in the literature and needs transcribing, not discovering. Read that section before starting work.

## 7. How to record an answer

- Proved an implication? Add `topics/decision-theory/results/<id>.yaml` with the full premise list and the proof.
- Refuted one? Add `topics/decision-theory/models/<id>.yaml` listing what you verified in `satisfies` and `violates`.
- Settling an existing conjecture? For a proof of the same statement, keep its ID, set `was_conjectured: true`, and change its status to `proved`. If the statement changes substantially, retain the original and add a separate record. Refuted proposals stay `status: conjectured`, with proved refuting evidence recorded separately. Answers under extra exploration assumptions are contextual, not global record statuses.
- Not sure? Add it with `status: conjectured`, an empty proof, and say in `notes` what would settle it.
- Then run `python3 scripts/pmap.py validate` and `status`. Never hand-edit the derived counts.

`README.md` has the exact record shapes and the sourcing rules. Follow them; an unsourced or misattributed record is worse than an absent one.
