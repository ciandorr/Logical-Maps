# Contribute

Email me (Zach) at [zacharyw.goodsell@gmail.com](mailto:zacharyw.goodsell@gmail.com?subject=%5BLogical%20Maps%5D%20Intuitionisticism) with further suggestions.

To contribute to Intuitionisticism, please include **[Logical Maps] Intuitionisticism** in the subject line of your email. You can suggest a new principle, establish a new result, or define a new model, along with supporting documents if necessary (e.g. a PDF or Markdown file). I will be sure to record your role in the contribution if I add it to this page. Thank you!

To contribute to the Logical Maps project in general, please include **[Logical Maps]** in the subject line.
