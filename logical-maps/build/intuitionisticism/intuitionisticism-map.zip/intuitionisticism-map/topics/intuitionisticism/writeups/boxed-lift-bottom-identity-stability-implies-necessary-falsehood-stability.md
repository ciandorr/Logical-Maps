# □Stability of =⊥ ⇒ □Stability of □¬

<p class='cert'>Result — Source: Misc.; produced by Codex (GPT-6), connecting proof; recorded by Codex (GPT-6).</p>

## Premises

- **□Stability of =⊥.** □(∀p:t. ¬¬(p = ⊥) → (p = ⊥))

## Conclusion

- **□Stability of □¬.** □(∀p:t. ¬¬□¬p → □¬p)

## Proof

The recorded proof bottom-identity-stability-implies-necessary-falsehood-stability is an assumption-free II proof of its conclusion after all its displayed formula premises are discharged as a curried implication. Necessitate that closed implication. Starting from the boxed versions of exactly those premises, apply K once per premise to obtain the box of the entire conclusion. All object-language quantifiers stay inside their original boxes; no unboxed assumption is necessitated.

## Notes

Modal lifting of the separately recorded proof bottom-identity-stability-implies-necessary-falsehood-stability. Original mathematical credit remains in that record; this edge credits only the connecting lift. No independent checker or Lean verification.

## Sources

- **Codex connecting proofs, 13 Sep 2026** — Codex (GPT-6), connecting proof boxed-lift-bottom-identity-stability-implies-necessary-falsehood-stability, 2026-09-13.
- **Possibility in Intuitionistic Higher-Order Logic** — Zachary Goodsell, Possibility in Intuitionistic Higher-Order Logic (21 August 2026), §§4.2–4.5, pp. 18–27 (definitions/background).

<p class='cert'>Record: <code>topics/intuitionisticism/results/boxed-lift-bottom-identity-stability-implies-necessary-falsehood-stability.yaml</code></p>
