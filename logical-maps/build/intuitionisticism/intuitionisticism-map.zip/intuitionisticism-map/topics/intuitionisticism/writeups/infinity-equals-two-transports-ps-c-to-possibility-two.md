# $\Diamond_\infty$ = ◇₂ ∧ PSc ($\Diamond_\infty$) ⇒ PSc (◇₂)

<p class='cert'>Result — Source: Misc.; produced by Codex (GPT-6), 13 September 2026; recorded by Codex (GPT-6), manuscript transcription.</p>

## Premises

- **$\Diamond_\infty$ = ◇₂.** $\Diamond_\infty$ $= \Diamond _{2}$
- **PSc ($\Diamond_\infty$).** For every p and q, $\Diamond_\infty$$(p \lor q)$ implies $\Diamond_\infty$$(p) \lor$ $\Diamond_\infty$(q).

## Conclusion

- **PSc (◇₂).** For every p and $q, \Diamond _{2}(p \lor q)$ implies $\Diamond _{2}(p) \lor \Diamond _{2}(q)$.

## Proof

Use the selected identity of the two defined operators in Leibniz’s Law with the whole quantified PS condition as the predicate of that operator. This directly replaces the operator under every connective and quantifier, leaving $\Box =(=\top )$ unchanged.

## Notes

Informal proof; no independent checker or Lean verification.

## Sources

- **Codex connecting proof, 13 Sep 2026** — Codex (GPT-6), connecting proof recorded 13 September 2026 in infinity-equals-two-transports-ps-c-to-possibility-two.
- **Possibility in Intuitionistic Higher-Order Logic** — Zachary Goodsell, Possibility in Intuitionistic Higher-Order Logic (21 August 2026), §4.4, p. 24; §4.5, pp. 26–27; §5.4, p. 34.

<p class='cert'>Record: <code>topics/intuitionisticism/results/infinity-equals-two-transports-ps-c-to-possibility-two.yaml</code></p>
