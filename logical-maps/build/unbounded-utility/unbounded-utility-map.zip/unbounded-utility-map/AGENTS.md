# Instructions for AI agents working in this bundle

Read `MAP.md` before answering anything about this subject. It is the whole database. `OPEN-QUESTIONS.md` lists what is unsettled. `README.md` has the semantics and the record formats. This file is the short version of the rules.

## Always

- Run `python3 scripts/pmap.py validate` after every batch of edits. It must pass.
- After changing the engine or viewer, run `python3 scripts/pmap.py selftest` and `python3 scripts/check_falsity.py` (requires Node).
- Give every new result and model a nonempty `sources` with theorem/section and page, and set `certificate.source_id` to the direct source: `decision-theory-unbound`, `symmetries-of-value`, `seidenfeld-schervish-kadane-2009`, `russell-isaacs-2021`, `unpublished-background-risk`, `misc`.
- Record independence as a **model**, never as a result.
- Name models by their construction or ordering rule: family first, then the rule and any distinguishing variant. Match the write-up title. Keep authorship, conjecture status, and lists of satisfied/violated principles in their own fields. For conjectured extensions, do not invent an unknown construction. Keep existing record IDs unchanged.
- List in a model's `satisfies` and `violates` only what you actually verified. The engine derives the rest and reports what stays unknown.
- Log every later addition to an existing record in its `changes` list (date, by, summary, and for models the newly verified `satisfies`/`violates` ids). Never move `certificate.date`.
- Write the real proof in `proof`, at referee detail. Put anything longer than a paragraph in `topics/unbounded-utility/writeups/<id>.md` instead.
- Prefer `status: conjectured` with an empty proof and a note saying what would settle it, over a `proved` you are not certain of.

## Never

- Never invent an author, date, page, DOI or submission label. Unsure means say so in `notes`.
- Never cite a paper as `source_id` for a proof you produced yourself. That is `misc`.
- Never put anything in `checked_by` unless a named person actually checked it.
- Never change the mathematical content of an existing published or human-authored proof. Add a note or a new record.
- Never rename an `id` that other files reference. File name equals id.
- Record incompatible premises with `conclusion: false`, not a duplicate failure principle. Never use false as a principle, premise, model assertion, or background assumption.
- Never treat a missing arrow as a proof of non-implication. Missing means not recorded.
- Never use a conjecture as evidence for anything.
- Never edit `Statements.lean`; it is generated from the records by `pmap lean`.
- Never set `lean: verified` by hand. Only `pmap lean-check` may conclude that, and only
for a proof that inhabits the generated statement without `sorryAx`.

## Reading the derived state

`MAP.md` §6 and `derived.json` are computed from the proved records by closure. Do not hand-edit them; they regenerate. If a verdict looks wrong, the fix is in the YAML.

