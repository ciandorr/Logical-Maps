# Unbounded Utility — complete map

Topic `unbounded-utility`. Generated 2026-09-23T22:35:49+00:00.

39 principles, 84 proved results, 3 recorded conjectures, 16 models.

This file is self-contained. Every principle statement, every proof, every model construction and every derived verdict in the database is reproduced below. `README.md` gives the semantics and the rules for adding to it; `OPEN-QUESTIONS.md` lists what is not settled.

## 1. Framework


Gambles are measurable outcome-valued random variables on an atomless standard probability space. All such variables are available (Prospect Richness is standing). ≽ is reflexive and transitive, not assumed total or law-invariant. Outcomes are linearly ordered, with distinct reference outcomes 0 and 1, and sure-indifferent outcomes identified. A possibly partial real utility chart is defined by binary certainty comparisons; see background.md. Rich Outcomes supplies all real levels; Archimedean Outcomes rules out outcomes beyond the finite chart. M_p(X,Y) is randomized selection, never the pointwise sum pX+(1-p)Y.

**Notation.** X ≽ Y; X ≻ Y iff X ≽ Y and not Y ≽ X; X ~ Y iff both. L(X) is the law, X|E is X on E and sure 0 elsewhere. Numerical expressions use the normalized utility chart.

**Fixed background assumptions.** None. Every principle below is optional and must be assumed explicitly.

**Named package `du` (DU).** Rich Outcomes (`rich-outcomes`), Archimedean Outcomes (`archimedean-outcomes`), Stochastic Equivalence (`stochastic-equivalence`), Stochastic Dominance (`stochastic-dominance`), Mixture Independence (`independence`). Loaded by default in the viewer.

**Named package `dtu` (DTU).** Rich Outcomes (`rich-outcomes`), Archimedean Outcomes (`archimedean-outcomes`), Totality (`totality`), Stochastic Equivalence (`stochastic-equivalence`), Stochastic Dominance (`stochastic-dominance`), Mixture Independence (`independence`).

## 2. Background and standing conventions

*Reproduced from `topics/unbounded-utility/background.md`.*

This map records logical connections between principles analysed in my **Decision theory unbound** (2024) and **Symmetries of value** (2026), as well as an unpublished work-in-progress called **Unbounded Utility and Background Risk**.

### Setup

A gamble is a measurable outcome-valued random variable X on a fixed
atomless standard probability space, which can be represented by [0,1] with
Lebesgue measure or by countably many independent fair coin tosses. All such
variables are available. 

The primitive preference relation $\succeq$ on gambles is always assumed reflexive and transitive. Outcomes are ordered by preference over certain gambles. Indifferent outcomes are identified. The optional Outcome Richness axiom says there are outcomes of every real utility value, and the optional Archimedean axiom says that there are no infinitesimal or infinite difference in utility levels.

The theory **DU** is the weakest background considered in my papers. In addition to Outcome Richness and Archimedean axioms, it has:
(a) The Sure-Thing principle/Independence.
(b) Stochastic Equivalence (equally distributed gambles are equally good).
(c) Statewise Dominance.

### Literature

#### Source literature

- Colyvan, M. (2008). Relative expectation theory. Journal of Philosophy, 105(1), 37–44. [Paper](https://doi.org/10.5840/jphil200810519)
- Nover, H., & Hájek, A. (2004). Vexing expectations. Mind, 113(450), 237–249. [Paper](https://doi.org/10.1093/mind/113.450.237)
- Russell, J. S., & Isaacs, Y. (2021). Infinite prospects. Philosophy and Phenomenological Research, 103(1), 178–198. [Paper](https://doi.org/10.1111/phpr.12704)
- Seidenfeld, T., Schervish, M., & Kadane, J. (2009). Preference for equivalent random variables: A price for unbounded utilities. Journal of Mathematical Economics, 45, 329–340. [Paper](https://doi.org/10.1016/j.jmateco.2008.12.002)
- Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. [Paper](https://doi.org/10.1111/nous.12473)
- Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. [Paper](https://doi.org/10.1111/nous.12549)
- Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. Full text is not included. The record-specific references retain warnings about gaps and withdrawn arguments.
- Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. [Paper](https://doi.org/10.1111/nous.12530)
- Fred Espen Benth, Giulia Di Nunno and Dennis Schroers (2022). Copula measures and Sklar’s theorem in arbitrary dimensions. Scandinavian Journal of Statistics. [Paper](https://doi.org/10.1111/sjos.12559)

#### Other relevant literature

- Arntzenius, F., Elga, A., & Hawthorne, J. (2004). Bayesianism, infinite decisions, and binding. Mind, 113(450), 251–283.
- Bartha, P. (2016). Making do without expectations. Mind, 125(499), 799–827.
- Dietrich, F., & List, C. (2005). The two-envelope paradox: An axiomatic approach. Mind, 114(454), 239–248.
- Easwaran, K. (2008). Strong and weak expectations. Mind, 117(467), 633–641.
- Easwaran, K. (2014a). Decision theory without representation theorems. Philosophers' Imprint, 14.
- Easwaran, K. (2014b). Principal values and weak expectations. Mind, 123(490), 517–531.
- Fine, T. (2008). Evaluating the Pasadena, Altadena, and St Petersburg gambles. Mind, 117(467), 613–632.
- Hájek, A. (2014). Unexpected expectations. Mind, 123(490), 533–567.
- Lauwers, L. (2016). Why decision theory remains constructively incomplete. Mind, 125(500), 1033–1043.
- Lauwers, L., & Vallentyne, P. (2016). Decision theory without finite standard expected value. Economics and Philosophy, 32(3), 383–407.
- Lauwers, L., & Vallentyne, P. (2017). A tree can make a difference. Journal of Philosophy, 114(1), 33–42.
- McGee, V. (1999). An airtight Dutch book. Analysis, 59(4), 257–265.
- Meacham, C. J. G. (2019). Difference minimizing theory. Ergo, 6. [Paper](https://quod.lib.umich.edu/e/ergo/12405314.0006.035/--difference-minimizing-theory?rgn=main;view=fulltext)
- Russell, J. S. (2020). Non-Archimedean preferences over countable lotteries. Journal of Mathematical Economics, 88, 180–186.
- Russell, J. S. (forthcoming). Fixing stochastic dominance. British Journal for the Philosophy of Science.
- Smith, N. J. J. (2014). Is evaluative compositionality a requirement of rationality? Mind, 123(490), 457–502.

## 3. Principles

### Basic decision theory

#### Archimedean Gambles — `archimedean-gambles`


For any gambles $X \succ Y \succ Z$, there is $p \in (0,1)$ with $Y \sim M_p(X,Z)$. Unlike Archimedean Outcomes, X,Y,Z may themselves be unbounded gambles.

Tags: mixture, continuity.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 22, footnote 3

- **Formulation: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3, p. 22, footnote 3

#### Archimedean Outcomes — `archimedean-outcomes`


For any three sure outcomes $a \succ b \succ c$, some nontrivial mixture of the outer two is equally good as the intermediate one: $b \sim M_p(a,c)$ for some $p \in (0,1)$. Only the three inputs are sure outcomes. This is the no-infinite-ratios condition, not continuity of preferences over arbitrary gambles.

Formal: `$a \succ b \succ c \Rightarrow \exists p\in (0,1): b \sim M_p(a,c)$`

Tags: outcomes.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 22, footnote 3
- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 678



#### Countable Sure-Thing — `countable-sure-thing`


For every countable measurable partition $(E_n)$ into events of positive probability, if $X|E_n \succeq Y|E_n$ for every n, then $X \succeq Y$. If one conditional comparison is strict, $X \succ Y$.

Tags: conditioning, countable.

Sources:

- **Russell & Isaacs (2021)** — Russell, J. S., & Isaacs, Y. (2021). Infinite prospects. Philosophy and Phenomenological Research, 103(1), 178–198. §2; author’s April 2020 manuscript, pp. 6–7. https://doi.org/10.1111/phpr.12704
- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.2, p. 674

- **Origin: [Infinite prospects](https://doi.org/10.1111/phpr.12704).** Russell, J. S., & Isaacs, Y. (2021). Infinite prospects. Philosophy and Phenomenological Research, 103(1), 178–198. — §2; author’s April 2020 manuscript, pp. 6–7. Countable Sure-Thing, translated into conditional gambles on the map’s fixed probability space.
- **Formulation: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §2.2, p. 674

#### Mixture Independence — `independence`


For all X,Y,Z and $0<p<1, X \succeq Y$ iff $M_p(X,Z) \succeq M_p(Y,Z)$, where M is the fixed randomized-selection construction described in the background.

Formal: `$X \succeq Y \Leftrightarrow M_p(X,Z) \succeq M_p(Y,Z)$`

Tags: mixture.

Notes. Mixture identities are identities in law; without Stochastic Equivalence they cannot be substituted as preference identities. Bridges to Sure-Thing explicitly retain Stochastic Equivalence.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 679
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 23



#### L¹ Continuity (random variables) — `l1-continuity`


On variables with real utility levels, if $E|u(X_n)- u(X)| \to 0$ and $X_n \succeq Y$ for every n, then $X \succeq Y$. Only the upper-section clause is imposed, matching the paper. Distance can be infinite between other pairs.

Formal: `$E|u(X_n)- u(X)|\to 0$ and $\forall n X_n \succeq Y \Rightarrow X \succeq Y$`

Tags: continuity.

Notes. Uses the actual coupling of random variables, so does not build in law invariance. With Stochastic Equivalence and the standing availability of all variables this is equivalent to the paper’s extended Wasserstein-1 (infimum-over-couplings) formulation; see writeups/l1-translation.md.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 23



#### Restricted Stochastic Equivalence — `restricted-stochastic-equivalence`


If simple gambles X,Y have the same law, then $X \sim Y$.

Tags: distribution, finite.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.3, p. 675



#### Restricted Totality — `restricted-totality`


Every two simple (finite-valued) gambles are comparable. Outcome comparability is already standing in this topic.

Tags: ordering, finite.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.3, p. 675



#### Rich Outcomes — `rich-outcomes`


Every real number r occurs as a utility level of a sure outcome: for each $r \in \mathbb{R}$ there is an outcome $o_r$ with $u(o_r)=r$, with u defined by the normalized binary-mixture comparisons in the background. This does not assert that every outcome has a finite real level.

Formal: `$\forall r\in \mathbb{R} \exists o\in O_{\mathrm{fin}}: u(o)=r$`

Tags: outcomes.

Notes. Stronger than merely having no upper bound. Kept separate from Archimedean Outcomes at the user’s request. No Rich Outcomes $\Rightarrow$ Archimedean Outcomes edge is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.2, p. 673 (called Unbounded Utility)
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, pp. 22–23



#### Simple Expected Utility — `simple-eu`


The normalized real utility chart u is defined on every outcome, is measurable, and ranks every pair of simple random variables exactly by finite expected utility: $X \succeq Y$ iff $E[u(X)] \ge E[u(Y)]$. Surjectivity of u is not included here.

Formal: `X,Y simple $\Rightarrow (X \succeq Y \Leftrightarrow E[u(X)] \ge E[u(Y)])$`

Tags: expectation, finite.

Notes. The papers sometimes bundle a bijective representation with Simple EUT. Here its surjectivity is split out as Rich Outcomes. This principle does entail Archimedean Outcomes.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 680
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 23



#### Statewise Dominance — `statewise-dominance`


If $X \ge Y$ almost surely in the sure-outcome order, then $X \succeq Y$; if also $P(X>Y)>0$, then $X \succ Y$.

Tags: dominance.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, pp. 678–679



#### Stochastic Dominance — `stochastic-dominance`


If $P(X>o) \ge P(Y>o)$ for every outcome threshold o, then $X \succeq Y$; if one threshold inequality is strict, $X \succ Y$. Thresholds use the sure-outcome order.

Tags: dominance, distribution.

Notes. Includes the weak clause, as in the random-variable statement of the 2024 paper. The 2026 distribution formulation writes only the strict clause because equality of laws has already been identified there.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 678



#### Stochastic Equivalence — `stochastic-equivalence`


If X and Y have the same probability law over outcomes, then $X \sim Y$. The variables remain distinct objects; indifference is an additional axiom.

Formal: `$L(X)=L(Y) \Rightarrow X \sim Y$`

Tags: distribution.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.2, p. 674



#### Sure-Thing — `sure-thing`


For an event E with $0<P(E)<1$, if $X|E \sim Y|E$, then $X \succeq Y$ iff $X|E^{c} \succeq Y|E^{c}$. Here X|E equals X on E and sure 0 elsewhere; it is not a conditional expectation.

Tags: conditioning.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.2, p. 673



#### Totality — `totality`


For all gambles X,Y, either $X \succeq Y$ or $Y \succeq X$.

Tags: ordering.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.2, p. 673



#### Continuity under Vanishing Shifts — `vanishing-shift-continuity`


For real-utility variables X,Y, if $X+\epsilon \succeq Y$ for every $\epsilon >0$, then $X \succeq Y$. The shifts act on utility levels, and all the displayed variables must be available. Only this upper-section closure condition is imposed.

Formal: `$(\forall \epsilon >0, X+\epsilon \succeq Y) \Rightarrow X \succeq Y$`

Tags: continuity, shift.

Notes. This closes comparisons under arbitrarily small constant improvements of the first gamble. It does not assume Shift Invariance, Totality, or closure of lower sections. L1 Continuity implies it directly. The strength of the converse depends on the other decision-theoretic axioms; a restricted-looking continuity condition need not remain weaker once those axioms are imposed.

Sources:

- **GPT-6 formulation 9 Sep** — GPT-6 (Codex), 9 September 2026, formulation in the Logical Maps project following Zachary Goodsell's suggestion to investigate CDF-area comparisons and Shift Transfer under DU, Shift Invariance, and a little continuity.



### Invariance principles

#### Antitonic Sum Invariance — `antitonic-sum-consistency`


If X and Z are antitonic, and Y and Z are antitonic, then $X \succeq Y$ iff $X+Z \succeq Y+Z$. A pair is antitonic when one member is nondecreasing and the other nonincreasing in a common uniform random variable.

Tags: background-risk.

Notes. Numerical scope: real-utility variables for which the indicated sums exist in the outcome chart. These are pointwise utility sums, not randomized mixtures. Stochastic Equivalence remains a separate principle. On laws, use $Q_X(U)+Q_Z(1- U)$. Constant variables count as both comonotonic and antitonic. Atoms are handled by quantiles up to null sets.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.2, p. 18; Theorem 6, p. 19

- **Formulation: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §6.2, p. 18; Theorem 6, p. 19

#### Comonotonic Sum Invariance — `comonotonic-sum-consistency`


If X and Z are comonotonic, and Y and Z are comonotonic, then $X \succeq Y$ iff $X+Z \succeq Y+Z$. A pair is comonotonic when its members admit nondecreasing representations in one common uniform random variable.

Tags: background-risk.

Notes. Numerical scope: real-utility variables for which the indicated sums exist in the outcome chart. These are pointwise utility sums, not randomized mixtures. Stochastic Equivalence remains a separate principle. On laws the sums are represented by $Q_X(U)+Q_Z(U)$ and $Q_Y(U)+Q_Z(U)$, using increasing quantiles. No law-invariance of preferences is built into this node.
Reduction (Claude, Fable 5.1, 23 September 2026): with Stochastic Equivalence this principle says the order on laws is invariant under quantile addition, and then X ≽ Y depends only on Q_X − Q_Y (add Q_{X′} to one pair and Q_X to the other), so the order is an additive cone in the space of differences of nondecreasing functions on (0,1); Mixture Independence is linear in the survival difference instead, and the area is the only functional invariant in both coordinates. A killing lemma and forced comparisons of both-infinite pairs are in the write-up of the conjectured total comonotonic extension.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.2, p. 18; Theorem 7, pp. 19–20

- **Formulation: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §6.2, p. 18; Theorem 7, pp. 19–20

#### Existential Copula Sum Invariance — `existential-copula-sum-consistency`


There exists one copula C such that $\operatorname{SC}(C)$ holds for all eligible X,Y,Z. The copula is chosen once for the preference relation, independently of the triple and its marginal laws. A copula C is a Borel probability measure on $[0,1]^{2}$ with both marginals uniform. Write $H_C(u,v)=C([0,u]\times [0,v])$. A real-utility pair (A,B) admits C when $P(A\le a,B\le b)=H_C(F_A(a),F_B(b))$ for every real a,b. Define $\operatorname{SC}(C)$: for every eligible triple X,Y,Z for which both (X,Z) and (Y,Z) admit this same $C, X \succeq Y$ iff $X+Z \succeq Y+Z$.

Formal: `$\exists C \in \operatorname{Cop}_{2}, \operatorname{SC}(C)$.`

Tags: background-risk, copula.

Notes. Numerical scope: variables in the finite real utility chart for which both pointwise sums exist as gambles. The copula fixes dependence, not the marginal utility distributions. With atoms a pair may admit several copulas; require the displayed compatibility condition, not a uniquely assigned copula. Preferences compare the actual random variables, not their laws or equivalence classes; no indifference of same-law variables is assumed. The dependence condition concerns each pair separately and places no extra condition on the joint law of (X,Y,Z). Proposal: Zachary Goodsell; precise recording: GPT-6 (Codex), 9 September 2026.
Law-level form (Claude, Fable 5.1, 23 September 2026): realize X† = Q_X(U) on the standing uniform U and Z* = Q_Z(W) with (U, W) distributed as C; the pair (X†, Z*) admits C, and X† + Z* has the law of X + Z for every pair (X, Z) admitting C, so under Stochastic Equivalence SC(C) says X ≽ Y iff X† + Z* ≽ Y† + Z* for all laws. Z* is canonical only in law (for the product copula W is independent of U), which is why the recorded bridges from the comonotonic, antitonic and independent principles need Stochastic Equivalence; for the comonotonic copula W = U. The comonotonic and product C-convolutions are associative, giving cone reductions; for a general C the C-convolution need not be, and SC(C) still yields Shift Invariance through a constant summand.

Sources:

- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).
- **Copula Measures and Sklar’s Theorem (definitions)** — Fred Espen Benth, Giulia Di Nunno and Dennis Schroers, Copula Measures and Sklar’s Theorem in Arbitrary Dimensions, arXiv:2012.11530v2, Definition 2.1 and Theorem 2.3; https://arxiv.org/html/2012.11530v2. Reference for copula terminology only, not these preference principles or implication proofs.

- **Background: [Copula measures and Sklar’s theorem in arbitrary dimensions](https://doi.org/10.1111/sjos.12559).** Fred Espen Benth, Giulia Di Nunno and Dennis Schroers (2022). Copula measures and Sklar’s theorem in arbitrary dimensions. Scandinavian Journal of Statistics. — Definition 2.1 and Theorem 2.3 (arXiv:2012.11530v2). Copula terminology only; these preference principles are project formulations.

#### Full Sum Invariance — `full-sum-consistency`


For all X,Y,Z, with arbitrary dependence, $X \succeq Y$ iff $X+Z \succeq Y+Z$.

Tags: background-risk.

Notes. Numerical scope: real-utility variables for which the indicated sums exist in the outcome chart. These are pointwise utility sums, not randomized mixtures. Stochastic Equivalence remains a separate principle.

Sources:

- **Seidenfeld, Schervish & Kadane (2009)** — Seidenfeld, T., Schervish, M., & Kadane, J. (2009). Preference for equivalent random variables: A price for unbounded utilities. Journal of Mathematical Economics, 45, 329–340. §1, p. 330; §3.1, Example 3.1, p. 333. https://doi.org/10.1016/j.jmateco.2008.12.002
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §1, pp. 1–2; §6.1, p. 17

- **Origin: [Preference for equivalent random variables: A price for unbounded utilities](https://doi.org/10.1016/j.jmateco.2008.12.002).** Seidenfeld, T., Schervish, M., & Kadane, J. (2009). Preference for equivalent random variables: A price for unbounded utilities. Journal of Mathematical Economics, 45, 329–340. — §1, p. 330; §3.1, Example 3.1, p. 333. The map expresses the sum-coherence requirement as unrestricted common-addend invariance. SSK formulate coherence through differences of indifferent variables.
- **Formulation: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §1, pp. 1–2; §6.1, p. 17

#### Independent Sum Cancellation — `independent-sum-cancellation`


Whenever Z is independent of $(X,Y), X+Z \succeq Y+Z$ implies $X \succeq Y$.

Tags: background-risk.

Notes. Numerical scope: real-utility variables for which the indicated sums exist in the outcome chart. These are pointwise utility sums, not randomized mixtures. Stochastic Equivalence remains a separate principle. Extracted as an optional axiom, not accepted as a theorem about the CDF-area construction. Convolution can mix positive and negative contributions; the printed proof does not establish cancellation.

Sources:

- **Wilkinson (2025)** — Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. §6.1, Independent Sum Consistency. https://doi.org/10.1111/nous.12530
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; Lemma 1, p. 8 (reverse direction, proof gap)

- **Formulation: [Flummoxing expectations](https://doi.org/10.1111/nous.12530).** Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. — §6.1, Independent Sum Consistency. Reverse direction of the map’s adapted Independent Sum Consistency; the common addend is independent of the compared pair.
- **Formulation: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — Lemma 1, p. 8 (reverse direction, proof gap)

#### Independent Sum Invariance — `independent-sum-consistency`


Whenever Z is independent of the pair $(X,Y), X \succeq Y$ iff $X+Z \succeq Y+Z$.

Tags: background-risk.

Notes. Numerical scope: real-utility variables for which the indicated sums exist in the outcome chart. These are pointwise utility sums, not randomized mixtures. Stochastic Equivalence remains a separate principle. With Stochastic Equivalence and the full real domain this is the manuscript’s Convolution Invariance: compare the two laws before and after convolution by the same probability law. Joint independence supplies a canonical common-noise realization; it does not assume that X and Y are independent.

Sources:

- **Wilkinson (2025)** — Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. §6.1, Independent Sum Consistency. https://doi.org/10.1111/nous.12530
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §1, pp. 1–4; §2, p. 6

- **Origin: [Flummoxing expectations](https://doi.org/10.1111/nous.12530).** Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. — §6.1, Independent Sum Consistency. Wilkinson assumes the three options are mutually independent; the map requires only that the common addend Z be independent of (X,Y).
- **Formulation: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §1, pp. 1–4; §2, p. 6

#### Independent Sum Preservation — `independent-sum-preservation`


Whenever Z is independent of $(X,Y), X \succeq Y$ implies $X+Z \succeq Y+Z$, and $X \succ Y$ implies $X+Z \succ Y+Z$.

Tags: background-risk.

Notes. Numerical scope: real-utility variables for which the indicated sums exist in the outcome chart. These are pointwise utility sums, not randomized mixtures. Stochastic Equivalence remains a separate principle. An explicit separation of the valid forward part of the source’s convolution claim. Weak preservation alone would not ensure preservation of strict preference.

Sources:

- **Wilkinson (2025)** — Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. §6.1, Independent Sum Consistency. https://doi.org/10.1111/nous.12530
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; Lemma 1, pp. 7–8 (forward direction)

- **Formulation: [Flummoxing expectations](https://doi.org/10.1111/nous.12530).** Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. — §6.1, Independent Sum Consistency. Forward direction of the map’s adapted Independent Sum Consistency; the common addend is independent of the compared pair.
- **Formulation: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — Lemma 1, pp. 7–8 (forward direction)

#### Negative Affine Anti-Invariance — `negative-affine-anti-invariance`


For all real $a>0$ and $b, X \succeq Y$ iff $- aY+b \succeq - aX+b$.

Tags: symmetry.

Notes. Arithmetic uses the utility chart, on finite-level variables with the required transformed outcomes available. The source’s full $\mathbb{R}$ setting is supplied by Rich Outcomes and Simple EU in theorem packages.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.2, pp. 686–688
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

- **Formulation: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §4.2, pp. 686–688
- **Formulation: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3, p. 24

#### Positive Affine Invariance — `positive-affine-invariance`


For all real $a>0$ and $b, X \succeq Y$ iff $aX+b \succeq aY+b$.

Tags: symmetry.

Notes. Arithmetic uses the utility chart, on finite-level variables with the required transformed outcomes available. The source’s full $\mathbb{R}$ setting is supplied by Rich Outcomes and Simple EU in theorem packages.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.2, pp. 686–688
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

- **Formulation: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §4.2, pp. 686–688
- **Formulation: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3, p. 24

#### Reflection Anti-Invariance — `reflection-anti-invariance`


$X \succeq Y$ iff $- Y \succeq - X$, using the one fixed normalized origin 0.

Tags: symmetry.

Notes. Arithmetic changes outcomes via their utility levels; it is not a relabeling of the utility function. Applies to finite-level variables when the indicated outcome transformation is available. Full-group implications explicitly assume Rich Outcomes. Reflection reverses the comparison; the displayed same-direction sign on p. 24 of Symmetries is a source typo, as its other definitions and proofs confirm.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.2, pp. 686–688
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

- **Formulation: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §4.2, pp. 686–688
- **Formulation: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3, p. 24

#### Scale Invariance — `scale-invariance`


For every real $a>0, X \succeq Y$ iff $aX \succeq aY$.

Tags: symmetry.

Notes. Arithmetic uses the utility chart, on finite-level variables with the required transformed outcomes available. The source’s full $\mathbb{R}$ setting is supplied by Rich Outcomes and Simple EU in theorem packages.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.2, pp. 686–688
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

- **Formulation: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §4.2, pp. 686–688
- **Formulation: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3, p. 24

#### Shift Invariance — `shift-invariance`


For every real $b, X \succeq Y$ iff $X+b \succeq Y+b$.

Tags: symmetry.

Notes. Arithmetic uses the utility chart, on finite-level variables with the required transformed outcomes available. The source’s full $\mathbb{R}$ setting is supplied by Rich Outcomes and Simple EU in theorem packages.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.2, pp. 686–688
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

- **Formulation: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §4.2, pp. 686–688
- **Formulation: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3, p. 24

#### Universal Copula Sum Invariance — `universal-copula-sum-consistency`


For every copula $C, \operatorname{SC}(C)$ holds. A copula C is a Borel probability measure on $[0,1]^{2}$ with both marginals uniform. Write $H_C(u,v)=C([0,u]\times [0,v])$. A real-utility pair (A,B) admits C when $P(A\le a,B\le b)=H_C(F_A(a),F_B(b))$ for every real a,b. Define $\operatorname{SC}(C)$: for every eligible triple X,Y,Z for which both (X,Z) and (Y,Z) admit this same $C, X \succeq Y$ iff $X+Z \succeq Y+Z$.

Formal: `$\forall C \in \operatorname{Cop}_{2}, \operatorname{SC}(C)$.`

Tags: background-risk, copula.

Notes. Numerical scope: variables in the finite real utility chart for which both pointwise sums exist as gambles. The copula fixes dependence, not the marginal utility distributions. With atoms a pair may admit several copulas; require the displayed compatibility condition, not a uniquely assigned copula. Preferences compare the actual random variables, not their laws or equivalence classes; no indifference of same-law variables is assumed. The dependence condition concerns each pair separately and places no extra condition on the joint law of (X,Y,Z). Proposal: Zachary Goodsell; precise recording: GPT-6 (Codex), 9 September 2026.
Law-level form (Claude, Fable 5.1, 23 September 2026): realize X† = Q_X(U) on the standing uniform U and Z* = Q_Z(W) with (U, W) distributed as C; the pair (X†, Z*) admits C, and X† + Z* has the law of X + Z for every pair (X, Z) admitting C, so under Stochastic Equivalence SC(C) says X ≽ Y iff X† + Z* ≽ Y† + Z* for all laws. Z* is canonical only in law (for the product copula W is independent of U), which is why the recorded bridges from the comonotonic, antitonic and independent principles need Stochastic Equivalence; for the comonotonic copula W = U. The comonotonic and product C-convolutions are associative, giving cone reductions; for a general C the C-convolution need not be, and SC(C) still yields Shift Invariance through a constant summand.

Sources:

- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).
- **Copula Measures and Sklar’s Theorem (definitions)** — Fred Espen Benth, Giulia Di Nunno and Dennis Schroers, Copula Measures and Sklar’s Theorem in Arbitrary Dimensions, arXiv:2012.11530v2, Definition 2.1 and Theorem 2.3; https://arxiv.org/html/2012.11530v2. Reference for copula terminology only, not these preference principles or implication proofs.

- **Background: [Copula measures and Sklar’s theorem in arbitrary dimensions](https://doi.org/10.1111/sjos.12559).** Fred Espen Benth, Giulia Di Nunno and Dennis Schroers (2022). Copula measures and Sklar’s theorem in arbitrary dimensions. Scandinavian Journal of Statistics. — Definition 2.1 and Theorem 2.3 (arXiv:2012.11530v2). Copula terminology only; these preference principles are project formulations.

### Extensions of EUT

#### CDF-Area Extension — `cdf-area-extension`


The normalized utility chart is total and measurable. Write $S_X(t)=P(u(X)>t), d=S_X- S_Y, A_{+}=\int \max (d,0)dt$ and $A_{-}=\int \max (- d,0)dt$ over $\mathbb{R}$. Whenever at least one of $A_{+},A_{-}$ is finite, $X \succeq Y$ iff $A_{+}\ge A_{-}$. If both are infinite, this axiom imposes no comparison.

Tags: background-risk.

Notes. This names the requirement to extend the manuscript’s base preorder, preserving its strict comparisons. It is distinct from the exact CDF-area model, which leaves every both-infinite pair incomparable. Survival-CDF endpoint conventions do not change these Lebesgue areas. No subtraction $\infty - \infty$ is used.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §3, pp. 7–8; §4, p. 8 (strictness-preserving extensions)

- **Formulation: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §3, pp. 7–8; §4, p. 8 (strictness-preserving extensions)

#### Expected Utility — `expected-utility`


The normalized chart u is defined on all outcomes and is measurable. Whenever $u(X),u(Y)$ are integrable, $X \succeq Y$ iff $E[u(X)] \ge E[u(Y)]$. Expectations here are finite Lebesgue expectations; this says nothing about two $+\infty$ expectations or conditionally convergent sums.

Tags: expectation.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.1, p. 685
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 23

- **Formulation: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §4.1, p. 685
- **Formulation: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3, p. 23

#### Folded Expectation — `folded-expectation`


Put $h_X(t)=P(u(X)>t)- P(u(X)<- t)$ for $t\ge 0$. If $\int _0^{\infty }|h_X(t)|dt$ and $\int _0^{\infty }|h_Y(t)|dt$ are finite, compare X,Y exactly by $F(X)=\int _0^{\infty }h_X(t)dt$ and $F(Y)$. Boundary atoms do not change these integrals.

Tags: expectation.

Notes. Absolute Lebesgue integrability of the combined tail difference is essential. Mere convergence of an improper integral is a different proposal. Symmetric laws have $F=0$, however heavy their tails.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, pp. 27–29

- **Formulation: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §4, pp. 27–29

#### Relative Expectation — `relative-expectation`


For real-utility variables X,Y on the same probability space, if $E|u(X)- u(Y)|<\infty$, then $X \succeq Y$ iff $E[u(X)- u(Y)] \ge 0$. Their individual expectations may both be undefined.

Tags: expectation, relative.

Notes. This is a same-space random-variable principle. Stochastic Equivalence is retained separately when importing the paper’s arbitrary-coupling formulation about laws.

Sources:

- **Colyvan (2008)** — Colyvan, M. (2008). Relative expectation theory. Journal of Philosophy, 105(1), 37–44. pp. 37–44. https://doi.org/10.5840/jphil200810519
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, p. 26

- **Origin: [Relative expectation theory](https://doi.org/10.5840/jphil200810519).** Colyvan, M. (2008). Relative expectation theory. Journal of Philosophy, 105(1), 37–44. — pp. 37–44. The map uses the same-space, integrable-difference formulation recorded in Symmetries of value.
- **Formulation: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §4, p. 26

#### Simple Relative Expectation — `simple-relative-expectation`


For real-utility variables X,Y on the same probability space, if $u(X)- u(Y)$ takes finitely many values, $X \succeq Y$ iff $E[u(X)- u(Y)] \ge 0$. X and Y themselves need not be simple or integrable.

Tags: expectation, relative, finite.

Sources:

- **Colyvan (2008)** — Colyvan, M. (2008). Relative expectation theory. Journal of Philosophy, 105(1), 37–44. pp. 37–44. https://doi.org/10.5840/jphil200810519
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, p. 26

- **Origin: [Relative expectation theory](https://doi.org/10.5840/jphil200810519).** Colyvan, M. (2008). Relative expectation theory. Journal of Philosophy, 105(1), 37–44. — pp. 37–44. Finite-valued-difference restriction of Relative Expectation; the precise restricted formulation is from Symmetries of value.
- **Formulation: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §4, p. 26

### Calculation methods

#### Uniqueness of Negative Self-Similarity — `negative-self-similarity`


Fix $0<p<1, a>0, b\in \mathbb{R}$ and Z. If $X \sim M_p(- aX+b,Z)$ and $Y \sim M_p(- aY+b,Z)$, then $X \sim Y$. This records the uniqueness-in-value content of Theorem 10.

Tags: mixture, symmetry.

Notes. The paper also supplies a geometric-mixture solution. Its expanded formula has an apparent sign/power typo; the extraction records the unambiguous uniqueness statement.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 10, pp. 30–31

- **Formulation: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 10, pp. 30–31

#### Transfer of a Shift Across a Mixture — `shift-transfer`


For all real $b$ and $0<p<1$, $M_p(X+\frac{b}{p},Y)\sim M_p(X,Y+\frac{b}{1-p})$. Variables and transformed outcomes are in the real utility chart.

Tags: mixture, symmetry.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 3, pp. 25–26

- **Formulation: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 3, pp. 25–26

#### Symmetric Gambles Are Neutral — `symmetric-neutrality`


If $u(X)$ and $- u(X)$ have the same law, then $X \sim 0$.

Tags: evaluation, symmetry.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, p. 27

- **Formulation: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §4, p. 27

### Prospect evaluations

#### Alternating St Petersburg = −1/2 — `alternating-st-petersburg-value`


Every $X$ with
$$P(u(X)=(-2)^n)=2^{-n},\qquad n\ge 1$$
is indifferent to sure utility $-\frac{1}{2}$.

Tags: evaluation.

Notes. A comparison with a sure outcome, not an assertion that the ordinary expected utility exists.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 9, p. 30

- **Formulation: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 9, p. 30

#### Arroyo = ln 2 — `arroyo-value`


Every $X$ with
$$P(u(X)=(-1)^{n+1}(n+1))=\frac{1}{n(n+1)},\qquad n\ge 1$$
is indifferent to sure utility $\ln 2$.

Tags: evaluation.

Notes. A comparison with a sure outcome, not an assertion that the ordinary expected utility exists.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 8, pp. 29–30

- **Formulation: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 8, pp. 29–30

#### Pasadena = ln 2 — `pasadena-value`


Every $X$ with
$$P(u(X)=-\frac{(-2)^n}{n})=2^{-n},\qquad n\ge 1$$
is indifferent to sure utility $\ln 2$.

Tags: evaluation.

Notes. A comparison with a sure outcome, not an assertion that the ordinary expected utility exists.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 11, pp. 32–33

- **Formulation: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 11, pp. 32–33
- **Background: [Vexing expectations](https://doi.org/10.1093/mind/113.450.237).** Nover, H., & Hájek, A. (2004). Vexing expectations. Mind, 113(450), 237–249.. Introduces the Pasadena game. The ln(2) valuation recorded here is attributed to Goodsell’s Symmetries of value, Theorem 11.

## 4. Results

Each result is a Horn clause: the conjunction of its premises entails its conclusion, relative to the framework above. Premises are sufficient; minimality is not claimed.

### 4.1 Proved

#### Antitonic Sum Invariance ∧ Stochastic Equivalence ⇒ Existential Copula Sum Invariance — `antitonic-sum-and-equivalence-imply-existential-copula`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Antitonic Sum Invariance (`antitonic-sum-consistency`)
- Stochastic Equivalence (`stochastic-equivalence`)

Conclusion: Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

Proof.

Choose the antidiagonal copula once. Given any eligible original triple whose pairs admit it, realize a triple (X′,Y′,Z′) with utility coordinates $(Q_X(U), Q_Y(U), Q_Z(1- U))$ on the standing atomless space, where Q denotes increasing marginal quantiles. Each new pair has the same joint law as its original counterpart, and each is antitonic. Thus the new variables have the original marginal laws, and X′$+Z$′ and Y′$+Z$′ have the original sum laws. Apply Antitonic Sum Invariance to the new triple. Stochastic Equivalence and transitivity transfer both sides of its biconditional to the original variables. This proves $\operatorname{SC}(C)$ for the chosen copula.

Notes. Stochastic Equivalence is explicit because this proof passes through a new realization. No stronger implication without that premise is recorded here. Quantile endpoint values affect no law; choose valid outcomes at exceptional points.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original copula sum consistency definitions and connecting proofs recorded in this project, 9 September 2026, implementing Zachary Goodsell’s proposal.
- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).



Record: `topics/unbounded-utility/results/antitonic-sum-and-equivalence-imply-existential-copula.yaml`.

#### Antitonic Sum Invariance ⇒ Shift Invariance — `antitonic-sum-implies-shift`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Antitonic Sum Invariance (`antitonic-sum-consistency`)

Conclusion: Shift Invariance (`shift-invariance`)

Proof.

Choose Z to be the constant utility b. A constant is independent of every pair and is both comonotonic and antitonic with every variable, so the sum biconditional becomes $X \succeq Y$ iff $X+b \succeq Y+b$. Apply this wherever the shifted outcomes exist.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.2, p. 18; definitions on pp. 3–4

- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §6.2, p. 18; definitions on pp. 3–4

Record: `topics/unbounded-utility/results/antitonic-sum-implies-shift.yaml`.

#### Archimedean Gambles ⇒ Archimedean Outcomes — `archimedean-gambles-restricts`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean verified; 2026-09-08.

Premises:

- Archimedean Gambles (`archimedean-gambles`)

Conclusion: Archimedean Outcomes (`archimedean-outcomes`)

Proof.

Sure outcomes are particular gambles. Restrict the triple of quantified gambles to constants.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, p. 22, footnote 3
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/archimedean-gambles-restricts.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — p. 22, footnote 3

Record: `topics/unbounded-utility/results/archimedean-gambles-restricts.yaml`.

#### CDF-Area Extension ⇒ Stochastic Dominance — `cdf-area-implies-dominance`

Proved result; source **Unbounded Utility and Background Risk (unpublished)**; produced by Zachary Goodsell (unpublished manuscript); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; Lean stated; 2026-09-09.

Premises:

- CDF-Area Extension (`cdf-area-extension`)

Conclusion: Stochastic Dominance (`stochastic-dominance`)

Proof.

Under stochastic dominance, $S_X\ge S_Y$ pointwise, so $A_{-}=0$ and $A_{+}\ge 0$. This forces $X \succeq Y$. If some threshold is strictly improved, one-sided continuity makes d positive on an interval, giving $A_{+}>0$, possibly infinite; then $Y \succeq X$ is false. Equality of laws gives two zero areas.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; Lemma 1, p. 8

- **Proof: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — Lemma 1, p. 8

Record: `topics/unbounded-utility/results/cdf-area-implies-dominance.yaml`.

#### CDF-Area Extension ⇒ Expected Utility — `cdf-area-implies-eu`

Proved result; source **Unbounded Utility and Background Risk (unpublished)**; produced by Zachary Goodsell (unpublished manuscript); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; Lean stated; 2026-09-09.

Premises:

- CDF-Area Extension (`cdf-area-extension`)

Conclusion: Expected Utility (`expected-utility`)

Proof.

The axiom supplies a total measurable chart. For integrable $u(X),u(Y)$, both areas are finite, and the survival-function identity gives $A_{+}- A_{-}=E[u(X)]- E[u(Y)]$. Apply the defining biconditional.

Notes. This is a property of every strictness-preserving extension of the base relation, independent of its unproved convolution cancellation claim.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; Lemma 1, pp. 7–8

- **Proof: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — Lemma 1, pp. 7–8

Record: `topics/unbounded-utility/results/cdf-area-implies-eu.yaml`.

#### CDF-Area Extension ⇒ Relative Expectation — `cdf-area-implies-relative`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; Lean stated; 2026-09-09.

Premises:

- CDF-Area Extension (`cdf-area-extension`)

Conclusion: Relative Expectation (`relative-expectation`)

Proof.

For the actual coupling, $\int |S_X- S_Y|dt \le E|u(X)- u(Y)|$. If the latter is finite, Fubini applied to $1_{u(X)>t}- 1_{u(Y)>t}$ gives $\int (S_X- S_Y)dt=E[u(X)- u(Y)]$. Both areas are finite, so the CDF-area comparison is exactly the comparison of this expectation with zero.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §3, pp. 7–8

- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §3, pp. 7–8

Record: `topics/unbounded-utility/results/cdf-area-implies-relative.yaml`.

#### Comonotonic Sum Invariance ∧ Stochastic Equivalence ⇒ Existential Copula Sum Invariance — `comonotonic-sum-and-equivalence-imply-existential-copula`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Stochastic Equivalence (`stochastic-equivalence`)

Conclusion: Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

Proof.

Choose the diagonal copula once. Given any eligible original triple whose pairs admit it, realize a triple (X′,Y′,Z′) with utility coordinates $(Q_X(U), Q_Y(U), Q_Z(U))$ on the standing atomless space, where Q denotes increasing marginal quantiles. Each new pair has the same joint law as its original counterpart, and each is comonotonic. Thus the new variables have the original marginal laws, and X′$+Z$′ and Y′$+Z$′ have the original sum laws. Apply Comonotonic Sum Invariance to the new triple. Stochastic Equivalence and transitivity transfer both sides of its biconditional to the original variables. This proves $\operatorname{SC}(C)$ for the chosen copula.

Notes. Stochastic Equivalence is explicit because this proof passes through a new realization. No stronger implication without that premise is recorded here. Quantile endpoint values affect no law; choose valid outcomes at exceptional points.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original copula sum consistency definitions and connecting proofs recorded in this project, 9 September 2026, implementing Zachary Goodsell’s proposal.
- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).



Record: `topics/unbounded-utility/results/comonotonic-sum-and-equivalence-imply-existential-copula.yaml`.

#### Comonotonic Sum Invariance ⇒ Shift Invariance — `comonotonic-sum-implies-shift`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)

Conclusion: Shift Invariance (`shift-invariance`)

Proof.

Choose Z to be the constant utility b. A constant is independent of every pair and is both comonotonic and antitonic with every variable, so the sum biconditional becomes $X \succeq Y$ iff $X+b \succeq Y+b$. Apply this wherever the shifted outcomes exist.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.2, p. 18; definitions on pp. 3–4

- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §6.2, p. 18; definitions on pp. 3–4

Record: `topics/unbounded-utility/results/comonotonic-sum-implies-shift.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Independent Sum Cancellation ⇒ Independent Sum Preservation — `conjectured-dtu-cancellation-implies-preservation`

Proved result; source **Misc.**; produced by GPT-6 (Codex), conjecture and geometric-noise proof; Zachary Goodsell, resolution proposal and strict-comparison argument; recorded by GPT-6 (Codex), 2026-09-13; checked by nobody; Lean stated; 2026-09-13.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Independent Sum Cancellation (`independent-sum-cancellation`)

Conclusion: Independent Sum Preservation (`independent-sum-preservation`)

Proof.

Totality plus Cancellation preserves strict comparisons by contraposition. Suppose X is indifferent to Y but $X+Z$ strictly exceeds $Y+Z$. Let nu be the law of Z and let rho be the law of a sum of N independent copies of Z, where $P(N=n)=2^{-n-1}$ for $n\ge 0$. This is an admissible real law and $2 \rho - \nu *\rho = \delta _0$. Put $A=M_{2/3}(X,Y+Z)$ and $B=M_{2/3}(Y,X+Z)$. Mixture Independence gives B strictly above A, hence $B+W$ strictly above $A+W$ for independent W of law rho. With $\alpha =\operatorname{law} X, \beta =\operatorname{law} Y$, and $\eta =(\alpha *\nu *\rho +\beta *\nu *\rho )/2$, the renewal identity rewrites $\operatorname{law}(A+W)=\alpha /3+2 \eta /3$ and $\operatorname{law}(B+W)=\beta /3+2 \eta /3$. Mixture Independence and Stochastic Equivalence therefore make the sums indifferent, a contradiction. Ties are preserved, and strict preservation supplies the rest. The write-up checks the law realizations and all finite-mixture substitutions; no continuity, moment assumption or countable mixture independence is used.

Notes. The original seven-premise conjecture is proved without changing its statement; was_conjectured preserves its history. The geometric renewal law closes the earlier indifference gap. The existing proof with L1 Continuity remains valid but its extra premise is unnecessary. Under DTU, Cancellation, Preservation and Independent Sum Invariance are equivalent by this theorem and the existing converse deductions. Arbitrary independent noise is essential to the argument: the geometric auxiliary law generally has infinite support. No full-noise property is thereby established for the finite-shift total extension. Original connecting work under Misc.; no literature-priority claim, independent checker or Lean verification is asserted.

Sources:

- **GPT-6 conjecture 9 Sep; proof 13 Sep** — GPT-6 (Codex), 9 September 2026: original conjecture and partial analysis; 13 September 2026: geometric-noise proof in writeups/conjectured-dtu-cancellation-implies-preservation.md.
- **Goodsell argument 13 Sep** — Zachary Goodsell, project conversation, 13 September 2026: request to resolve Cancellation implies Preservation and the contraposition argument for strict comparisons.
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, unpublished manuscript, 5 June 2026, Lemma 1, pp. 7–8: source for the separated sum principles, not this connecting theorem.

- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — Lemma 1, pp. 7–8: source for the separated sum principles, not this theorem
- **Background: [Flummoxing expectations](https://doi.org/10.1111/nous.12530).** Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. — §6.1. Source of Independent Sum Consistency; see the principle reference for the changed independence condition. The connecting theorem retains its separate attribution.

Record: `topics/unbounded-utility/results/conjectured-dtu-cancellation-implies-preservation.yaml`.

<details><summary>Hand-written write-up</summary>

#### DTU turns cancellation into full independent-sum invariance

**Proved:** DTU + Independent Sum Cancellation implies Independent Sum
Preservation. The geometric-noise argument below closes the indifference
gap without a continuity axiom.

The recorded premises are unchanged: Rich Outcomes, Totality, Stochastic
Equivalence, Simple EU, Stochastic Dominance, Mixture Independence and
Independent Sum Cancellation. Rich Outcomes and the total measurable
normalized chart identify the outcome domain with the real utility
levels, so the auxiliary real-valued laws below are available.

**Source and work accounting.** GPT-6 (Codex) recorded the conjecture and
partial analysis on 9 September 2026. Zachary Goodsell asked for its
resolution and gave the strict-comparison contraposition argument on
13 September. GPT-6 (Codex) supplied the geometric-noise construction and
finite-mixture proof on 13 September. Goodsell's *Unbounded Utility and
Background Risk* (unpublished), Lemma 1, pp. 7–8, supplies the separated
sum principles, not this connecting theorem. The record retains its
original ID and conjecture history. No independent checker, literature
priority or Lean verification is claimed.

##### Strict comparisons are preserved

If $X\succ Y$ but $Y+Z\succeq X+Z$, Cancellation would give
$Y\succeq X$, a contradiction. Totality of the sums therefore gives

$$X\succ Y\quad\Longrightarrow\quad X+Z\succ Y+Z. \tag{1}$$

This works for every independent noise law, including the auxiliary law
constructed below. Thus Preservation could fail only by breaking a tie.
Suppose $X\sim Y$ and, after exchanging their names if necessary,

$$X+Z\succ Y+Z. \tag{2}$$

##### Geometric noise

Let $\nu=\mathcal L(Z)$. Choose an independent geometric count $N$ and
independent copies $Z_1,Z_2,\ldots$ of $Z$, with

$$P(N=n)=2^{-(n+1)}\quad(n=0,1,\ldots),\qquad
W=\sum_{i=1}^{N}Z_i.$$

The empty sum is zero. Since $N$ is finite almost surely, $W$ is a
real-valued gamble; no moment assumption is required. Its probability
law $\rho$ satisfies the exact renewal identity

$$\rho=\tfrac12\delta_0+\tfrac12\nu*\rho,\qquad
2\rho-\nu*\rho=\delta_0. \tag{3}$$

Indeed, conditional on $N\geq1$, the remaining number of summands again
has the law of $N$. Equivalently,
$\rho=\sum_{n\geq0}2^{-(n+1)}\nu^{*n}$. This is an identity of probability
measures, with no limiting inference about preferences.

Stochastic Equivalence allows fresh realizations of the relevant laws,
with $W$ independent of $X,Y,Z$ and the mixture randomizers. The standing
atomless standard space realizes the required countable product of real
laws. We do not need to adjoin independent noise to a previously fixed
variable that already generates the entire sigma-algebra: independent
sums have convolution laws, and the rankings depend only on those laws.

##### Two finite mixtures give a contradiction

Set

$$A=M_{2/3}(X,Y+Z),\qquad B=M_{2/3}(Y,X+Z).$$

Since $X\sim Y$, Mixture Independence makes
$A\sim M_{2/3}(Y,Y+Z)$. By (2), Mixture Independence on the other branch
makes $B\succ M_{2/3}(Y,Y+Z)$; exchanging mixture branches is licensed by
Stochastic Equivalence. Hence $B\succ A$. Applying (1) with $W$ gives

$$B+W\succ A+W. \tag{4}$$

Write $\alpha=\mathcal L(X)$ and $\beta=\mathcal L(Y)$, and let $H$
have the probability law

$$\eta=\tfrac12\alpha*\nu*\rho+\tfrac12\beta*\nu*\rho.$$

Using (3),

$$\begin{aligned}
\mathcal L(A+W)
 &=\tfrac23\alpha*\rho+\tfrac13\beta*\nu*\rho\\
 &=\tfrac13\alpha+\tfrac13\alpha*\nu*\rho
                       +\tfrac13\beta*\nu*\rho\\
 &=\tfrac13\alpha+\tfrac23\eta.
\end{aligned}$$

Similarly,

$$\mathcal L(B+W)=\tfrac13\beta+\tfrac23\eta.$$

Thus $A+W$ and $B+W$ have the laws of $M_{1/3}(X,H)$ and
$M_{1/3}(Y,H)$ respectively. Since $X\sim Y$, Mixture Independence and
Stochastic Equivalence give $A+W\sim B+W$, contradicting (4).

No tie can be broken. Every weak comparison is either strict or an
indifference, so this and (1) prove both clauses of Independent Sum
Preservation.

##### Scope and consequences

All preference substitutions use **binary mixtures**. The construction
requires neither Countable Sure-Thing nor countable mixture independence,
and uses no continuity or integrability assumption.

Together with the recorded
[Totality + Preservation ⇒ Cancellation](total-preservation-implies-independent-cancellation.html)
and the defining combination of both directions, this makes Cancellation,
Preservation and Independent Sum Invariance equivalent under DTU.

The earlier
[proof with L¹ Continuity](continuous-total-cancellation-implies-preservation.html)
remains valid. Its limiting step is unnecessary for the present theorem.

The auxiliary $W$ generally has infinite support even for finite-valued
$Z$. Cancellation must therefore cover arbitrary independent noise.
This argument does not establish full independent-sum invariance for the
[finite-shift total extension](finite-shift-total-extension.html), whose
verified noise properties concern finite-valued summands.

In cone notation, the same calculation is $R(2I-T)=I$, where $T$ and $R$
are convolution by $\nu$ and $\rho$. If an indifferent vector $v$ were
sent to a strictly positive $Tv$, then $2v-Tv$ would be strictly negative.
Strict preservation by $R$ would make $v$ strictly negative, a
contradiction. The finite-mixture proof above proves this directly
without needing a separate cone representation theorem.

</details>

#### Rich Outcomes ∧ Totality ∧ Stochastic Dominance ∧ L¹ Continuity (random variables) ∧ Independent Sum Cancellation ⇒ Independent Sum Preservation — `continuous-total-cancellation-implies-preservation`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex); checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Dominance (`stochastic-dominance`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Independent Sum Cancellation (`independent-sum-cancellation`)

Conclusion: Independent Sum Preservation (`independent-sum-preservation`)

Proof.

First, Totality and Independent Sum Cancellation preserve every strict comparison: if X is strictly preferred to Y but $X+Z$ were not strictly preferred to $Y+Z$, Totality of the sums would give $Y+Z$ weakly preferred to $X+Z$, and cancellation would contradict X strictly preferred to Y. Now suppose X is weakly preferred to Y. For each $n\ge 1, X+1/n$ strictly stochastically dominates X, so $X+1/n$ is strictly preferred to Y. The shifts exist by Rich Outcomes and Z stays independent of the pair $(X+1/n,Y)$. Strict preservation therefore gives $(X+Z)+1/n$ strictly preferred to $Y+Z$. These upper gambles converge to $X+Z$ in the actual L1 distance, which is exactly 1/n, regardless of whether X or Z has a finite expectation. The upper-section clause of L1 Continuity yields $X+Z$ weakly preferred to $Y+Z$. Together with the first step this is weak and strict Independent Sum Preservation.

Notes. Original work: connecting proof by a strict-order argument and a constant-shift L1 limit. This is not claimed as a new model or as a theorem already proved in the cited papers. Only the existing UPPER continuity clause is used. No integrability of X,Y,Z, mixture independence, or stochastic-equivalence substitution is required. Rich Outcomes ensures the arbitrarily small real shifts are available; arithmetic remains restricted to the finite real chart. Under DTU plus L1 Continuity, Cancellation, Preservation and full Independent Sum Invariance are therefore equivalent. Combining this with the existing Levy obstruction rules out Cancellation under DTU plus L1 Continuity and Symmetric Neutrality, without adding a redundant incompatibility record.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), 9 September 2026, original shift-and-continuity argument in writeups/continuous-total-cancellation-implies-preservation.md.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), §3, p. 23: source for the upper-section L1 Continuity axiom only.
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, unpublished manuscript, 5 June 2026, Lemma 1, pp. 7–8: source for the independent-sum principles only.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3, p. 23: source for the upper-section L1 Continuity axiom only
- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — Lemma 1, pp. 7–8: source for the independent-sum principles only
- **Background: [Flummoxing expectations](https://doi.org/10.1111/nous.12530).** Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. — §6.1. Source of Independent Sum Consistency; see the principle reference for the changed independence condition. The proof or conjecture recorded here retains its separate attribution.

Record: `topics/unbounded-utility/results/continuous-total-cancellation-implies-preservation.yaml`.

<details><summary>Hand-written write-up</summary>

#### L¹ continuity turns independent-sum cancellation into preservation

**Proved implication:** Rich Outcomes + Totality + Stochastic Dominance +
$L^{1}$ Continuity + Independent Sum Cancellation implies Independent Sum
Preservation.

The proof concerns numerical gambles in the finite real chart. Rich Outcomes
makes every real translation below available. Additional outcomes outside
that chart are not used.

##### 1. Cancellation already preserves strict comparisons

Suppose $X\succ Y$ and $Z$ is independent of $(X,Y)$. If
$X+Z\not\succ Y+Z$, Totality of the two sums implies
$Y+Z\succeq X+Z$. Cancellation, with the two compared variables exchanged,
would give $Y\succeq X$, contradicting $X\succ Y$. Hence

$$X\succ Y\quad\Longrightarrow\quad X+Z\succ Y+Z.$$

This argument does not establish preservation of indifference. Cancellation
can, as an abstract order property, prevent reversal of a strict order while
allowing a map to break a tie. The next step closes precisely that gap.

##### 2. Constant shifts supply strict approximations

For every real-valued random variable $X$ and every $\delta>0$, the variable
$X+\delta$ strictly stochastically dominates $X$. All weak tail inequalities
follow from $X+\delta>X$ pointwise. To see that at least one is strict,
partition $\mathbb R$ into the intervals
$(k\delta,(k+1)\delta]$, $k\in\mathbb Z$. At least one has positive
$X$-probability, and at its upper endpoint $t$ we have

$$\Pr(X+\delta>t)-\Pr(X>t)
  =\Pr(t-\delta<X\le t)>0.$$

Stochastic Dominance therefore gives $X+\delta\succ X$. For any outcomes
outside the finite chart the weak comparison also follows pointwise from
the outcome order; the displayed strict threshold lies in the chart.

If $X\succeq Y$, transitivity of the preorder gives
$X+\delta\succ Y$: the contrary comparison $Y\succeq X+\delta$ would
contradict $X+\delta\succ X$.

Independence of $Z$ from $(X,Y)$ implies independence from
$(X+\delta,Y)$, since translation is a measurable transformation of the
pair. Applying the first step now yields

$$(X+Z)+\delta\succ Y+Z.$$

##### 3. Only upper-section continuity is needed

Take $\delta_n=1/n$. The actual, pointwise-coupled variables satisfy

$$E\bigl|((X+Z)+\delta_n)-(X+Z)\bigr|=\delta_n\longrightarrow0.$$

The upper-section clause in the project$'s L^{1}$ Continuity principle applies
to $(X+Z)+\delta_n\succeq Y+Z$ and gives
$X+Z\succeq Y+Z$. It does not require $X$, $Y$, $Z$, or their sums to
have finite expectations. Along with step 1, this proves both clauses of
Independent Sum Preservation.

No comparison of same-law copies, Mixture Independence, or lower-section
continuity has been used.

##### Consequences under DTU

Together with the already recorded decomposition, the result makes
**Cancellation, Preservation, and full Independent Sum Invariance
equivalent under DTU + L¹ Continuity**. Thus the existing Lévy obstruction
also rules out Cancellation under DTU $+ L^{1}$ Continuity + Symmetric Neutrality.
These consequences are left to the inference engine, rather than stored as
duplicate arrows.

Without $L^{1}$ Continuity, the argument stops at strict preservation. The map
separately records the conjecture that DTU alone might close that gap.

**Original work: connecting proof using a shift approximation.**
GPT-6 (Codex), 9 September 2026. Goodsell's *Symmetries of value*, §3, p. 23,
supplies the upper-section continuity definition; his *Unbounded Utility
and Background Risk* (unpublished), Lemma 1, pp. 7–8, supplies the sum
principles. Neither paper is being credited with this additional proof.
Direct source: Misc. No independent checker or Lean verification is claimed.

</details>

#### Stochastic Dominance ⇒ Stochastic Equivalence — `dominance-implies-equivalence`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean verified; 2026-09-08.

Premises:

- Stochastic Dominance (`stochastic-dominance`)

Conclusion: Stochastic Equivalence (`stochastic-equivalence`)

Proof.

Equal laws give equal upper-tail probabilities at every outcome threshold. Apply the weak dominance clause in both directions.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 678

- **Proof: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §3.2, p. 678

Record: `topics/unbounded-utility/results/dominance-implies-equivalence.yaml`.

#### Archimedean Outcomes ∧ Stochastic Dominance ⇒ Statewise Dominance — `dominance-implies-statewise`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Archimedean Outcomes (`archimedean-outcomes`)
- Stochastic Dominance (`stochastic-dominance`)

Conclusion: Statewise Dominance (`statewise-dominance`)

Proof.

Use the real outcome chart supplied by Archimedean Outcomes. If $X\ge Y$ almost surely, $\{Y>t\}\subseteq \{X>t\}$ modulo null events. If $P(X>Y)>0$, the countable family of rational cuts contains a cut with $P(Y\le t<X)>0$; approximate by a realized outcome threshold if necessary. The strict tail inequality then gives strict preference.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, pp. 678–679 and footnote 19

- **Proof: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §3.2, pp. 678–679 and footnote 19

Record: `topics/unbounded-utility/results/dominance-implies-statewise.yaml`.

#### Rich Outcomes ∧ Stochastic Dominance ∧ Antitonic Sum Invariance ⇒ False (⊥) — `dominance-refutes-antitonic-sum`

Proved result; source **Unbounded Utility and Background Risk (unpublished)**; produced by Zachary Goodsell (unpublished manuscript); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Stochastic Dominance (`stochastic-dominance`)
- Antitonic Sum Invariance (`antitonic-sum-consistency`)

Conclusion: False (⊥) (`false`)

Proof.

Let P have St Petersburg law and S have the symmetric mixture $\frac{1}{2} P+\frac{1}{2} (- P)$. Write ⊕Anti for the law of the antitonic sum. Since P has $\operatorname{law} \frac{1}{2} \delta _{2}+\frac{1}{2} (2P)$, pairing opposite quantiles gives S⊕Anti $P = \frac{1}{2} (P+2)+\frac{1}{2} P$, which strictly stochastically dominates $P=0$⊕Anti P. Antitonic Sum Invariance would therefore give $S \succ 0$ (both weak directions allow strict cancellation). Applying it again with common summand of law S gives S⊕Anti $S \succ 0$⊕Anti S. Symmetry of the quantiles makes the left $\operatorname{law} \delta _{0}$ and the right law S, so $0 \succ S, a$ contradiction. Dominance supplies Stochastic Equivalence for every law identity used. This does not assume Symmetric Neutrality or Totality.

Notes. Representation update: the former negative conclusion is expressed by adding antitonic-sum-consistency to the premises and concluding False. The mathematical claim, source, and proof are unchanged.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; Theorem 6, p. 19

- **Proof: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — Theorem 6, p. 19

Record: `topics/unbounded-utility/results/dominance-refutes-antitonic-sum.yaml`.

#### Rich Outcomes ∧ Stochastic Dominance ∧ Full Sum Invariance ⇒ False (⊥) — `dominance-refutes-full-sum`

Proved result; source **Preference for Equivalent RVs**; produced by Teddy Seidenfeld, Mark J. Schervish and Joseph B. Kadane (impossibility result); Zachary Goodsell (sum-invariance presentation); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Stochastic Dominance (`stochastic-dominance`)
- Full Sum Invariance (`full-sum-consistency`)

Conclusion: False (⊥) (`false`)

Proof.

Let P,Q each have St Petersburg $\operatorname{law} P(P=2^{n})=2^{-n}, n\ge 1$, coupled antitonically so exactly one equals 2. Dominance supplies Stochastic Equivalence, hence $P\sim Q$. Full Sum Invariance with common summand P would give $2P\sim P+Q$. But $P+Q$ has the law of $2P+2$: for $n\ge 2$ it takes $2^{n}+2$ with probability $2^{1- n}$. This strictly stochastically dominates the law of 2P, contradicting the asserted indifference. Rich Outcomes and standing prospect richness supply the variables and sums.

Notes. The impossibility is due to Seidenfeld, Schervish and Kadane. In their Example 3.1, X1, X2 and W have the St Petersburg law and $X1+X2=2W+2$. The recorded proof uses this construction in common-addend form. Goodsell’s manuscript is a later presentation, not the origin of the result. The premises, proof and verification status are unchanged.

Sources:

- **Seidenfeld, Schervish & Kadane (2009)** — Seidenfeld, T., Schervish, M., & Kadane, J. (2009). Preference for equivalent random variables: A price for unbounded utilities. Journal of Mathematical Economics, 45, 329–340. §3.1, Example 3.1 and Table 1, p. 333; Theorem 1, p. 332. https://doi.org/10.1016/j.jmateco.2008.12.002
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.1, p. 17

- **Proof: [Preference for equivalent random variables: A price for unbounded utilities](https://doi.org/10.1016/j.jmateco.2008.12.002).** Seidenfeld, T., Schervish, M., & Kadane, J. (2009). Preference for equivalent random variables: A price for unbounded utilities. Journal of Mathematical Economics, 45, 329–340. — §3.1, Example 3.1 and Table 1, p. 333; Theorem 1, p. 332. The recorded antitonic St Petersburg pair is SSK’s X1,X2 construction, expressed as a contradiction with common-addend invariance.
- **Formulation: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §6.1, p. 17. Later presentation of the SSK impossibility, used when the map was first transcribed.

Record: `topics/unbounded-utility/results/dominance-refutes-full-sum.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ L¹ Continuity (random variables) ⇒ Expected Utility — `dtu-l1-implies-eu`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Expected Utility (`expected-utility`)

Proof.

Source-stated implication, §3, p. 23: adding $L^{1}$ Continuity to DTU yields Expected Utility. Stochastic Equivalence makes the quotient ordering on laws well-defined; the remaining premises give exactly the source’s DTU, with the surjectivity part of its Simple EU supplied separately by Rich Outcomes. The $L^{1}$ translation write-up establishes that the random-variable continuity axiom implies the source’s metric continuity. Apply the stated theorem and pull its expected-utility comparison back to X,Y. The source does not supply an expanded proof of the underlying implication; this is a theorem application and translation, not a new proof of that theorem.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 23

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3, p. 23

Record: `topics/unbounded-utility/results/dtu-l1-implies-eu.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Archimedean Gambles ⇒ False (⊥) — `dtu-refutes-archimedean-gambles`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Archimedean Gambles (`archimedean-gambles`)

Conclusion: False (⊥) (`false`)

Proof.

Let S have $P(u(S)=2^n)=2^{- n}$. For any real c choose N with $N>c$. The simple truncation $\min (S,2^N)$ has expectation $N+1$ and is stochastically dominated by S. Thus $S\succ c$. In particular $S\succ 1\succ 0$. Every $M_p(S,0), p>0$, is also better than every sure outcome: its simple truncations have arbitrarily large finite expectations. Hence none is indifferent to 1. This violates Archimedean Gambles while preserving Archimedean Outcomes.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Representation update: the former negative conclusion is expressed by adding archimedean-gambles to the premises and concluding False. The mathematical claim, source, and proof are unchanged.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 22

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3, p. 22

Record: `topics/unbounded-utility/results/dtu-refutes-archimedean-gambles.yaml`.

#### Rich Outcomes ∧ Archimedean Outcomes ∧ Stochastic Equivalence ∧ Stochastic Dominance ∧ Mixture Independence ∧ L¹ Continuity (random variables) ⇒ Relative Expectation — `du-l1-implies-relative`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Relative Expectation (`relative-expectation`)

Proof.

The existing finite-lottery representation argument derives Simple EU from Rich Outcomes, Archimedean Outcomes, Stochastic Dominance and Independence. For any bounded utility variable V, upward finite quantizations $Q_n$ satisfy $Q_n\sim E Q_n$ by Simple $\operatorname{EU}, Q_n\ge V$ by dominance, and $E Q_n\ge E V$. Thus $Q_n\ge E V$ and the sure $E Q_n\ge V$. Their two upper-section L1 limits give $V\sim E V$. Now let $D=X-Y$ be integrable with mean $m\ge 0$. On $E_n=\{|X|\le n,|Y|\le n\}$, with $p_n=P(E_n)>0$, quantize X upward within 1/n to a finite-valued $q_n$ and set $c_n=(E[(q_n-Y)1_{E_n}]-m)/p_n$. Define $Z_n=q_n-c_n$ on $E_n$ and $Z_n=Y$ elsewhere. Its changed conditional branch has mean at least that of Y, by $m/p_n$; bounded EU, law invariance and Independence therefore give $Z_n\ge Y$. At $p_n=1$ bounded EU gives this directly. Moreover $E|Z_n-X|\le 2E[|D|1_{E_n^{c}}]+2/n$ tends to zero, so upper L1 gives $X\ge Y$. If $m>0$, replace Y on a sufficiently small positive-probability event where Y is bounded by a strictly better sure outcome. The resulting Y' strictly dominates Y and has $0<E(Y'-Y)<m$. The weak result gives $X\ge Y'$, hence $X>Y$. For $m=0$ apply the weak result in both directions; for $m<0$ interchange the variables. This proves the Relative Expectation biconditional without Totality, Shift Invariance, lower-section continuity or assumed full Expected Utility.

Notes. Original work: moderate connecting proof and premise reduction. A short upward-quantization lemma derives bounded EU; the earlier conditional truncation argument is then adapted with finite quantization, mean correction and a bounded-event proof of strictness. This removes both assumed full Expected Utility and global Totality from the earlier DTU$+L1$ consequence. Finite-valued replacements suffice for the proof; no arbitrary outcome-space translation map is required. Under DU, the existing Relative-to-CDF and Relative-to-Simple-Relative-to-Shift-Transfer results give CDF-Area Extension and Shift Transfer as well. The five DU axioms remain explicit, including Stochastic Equivalence even though dominance implies it. No minimality, literature priority, independent certification or Lean verification is claimed.

Sources:

- **GPT-6 DU continuity proof 9 Sep** — GPT-6 (Codex), Logical Maps, 9 September 2026; user-inspired DU premise audit and connecting proof in writeups/du-l1-implies-relative.md.
- **GPT-6 earlier connecting proofs 9 Sep** — GPT-6 (Codex), Logical Maps, 9 September 2026; prior conditional-truncation proof in writeups/eu-independence-l1-imply-relative.md and finite-lottery proof in writeups/rich-archimedean-dominance-independence-imply-simple-eu.md.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37, DOI 10.1111/nous.12549, §3 p. 23 (upper-section L1 Continuity and the DTU consequence for Expected Utility), pp. 26–27 (Relative Expectation and Corollary 5 in the symmetry setting).
- **Decision Theory Unbound** — Zachary Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695, DOI 10.1111/nous.12473, §3.2 pp. 678–681 and §3.3 pp. 681–682 (finite expected utility and the DU/DTU distinction).

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3 p. 23 (upper-section L1 Continuity and the DTU consequence for Expected Utility), pp. 26–27 (Relative Expectation and Corollary 5 in the symmetry setting)
- **Background: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §3.2 pp. 678–681 and §3.3 pp. 681–682 (finite expected utility and the DU/DTU distinction)

Record: `topics/unbounded-utility/results/du-l1-implies-relative.yaml`.

<details><summary>Hand-written write-up</summary>

#### DU and upper-section L¹ Continuity imply Relative Expectation

**Proved implication:** Rich Outcomes + Archimedean Outcomes + Stochastic
Equivalence + Stochastic Dominance + Mixture Independence $+ L^{1}$ Continuity
imply Relative Expectation. These are **DU + L¹ Continuity**; Totality is
not included.

The argument first derives expected-utility comparisons for bounded gambles.
It then compares bounded conditional pieces of arbitrary gambles and takes
an upper-section limit. Full Expected Utility, lower-section continuity,
Shift Invariance and symmetry are not assumed.

##### Utility coordinates and finite gambles

The existing
[finite-lottery representation proof](rich-archimedean-dominance-independence-imply-simple-eu.html)
derives Simple EU from Rich Outcomes, Archimedean Outcomes, Stochastic
Dominance and Mixture Independence, without Totality. It supplies a total,
measurable normalized utility chart that strictly preserves the outcome
order. Rich Outcomes supplies a sure outcome at every real utility level.

Below, write $X,Y,V$ for utility coordinates and write a real number $c$
for a sure outcome at level $c$. All finite-valued replacements are available:
choose their finitely many sure outcomes and paste them along the stated
measurable events. This suffices for the main proof, so it does not require
an arbitrary translated outcome-valued variable to be measurable.

##### Bounded EU from two upper-section limits

Let $V$ have a bounded law, and put $v=\mathbb E V$. Null exceptional values
can first be replaced using Stochastic Equivalence. Define upward finite
quantizations

\[
Q_n=\frac{\lceil nV\rceil}{n},\qquad v_n=\mathbb E Q_n.
\]

They obey $0\le Q_n-V\le1/n$ almost surely and
$v\le v_n\le v+1/n$. Each $Q_n$ has a finite range. Simple EU gives
$Q_n\sim v_n$, and Stochastic Dominance gives $Q_n\succeq V$.
Comparison of sure outcomes therefore yields

\[
Q_n\succeq v,\qquad v_n\succeq V.
\tag{1}
\]

In the first comparison the left side converges in actual $L^1$ distance to
$V$. In the second, the left side is a sequence of sure outcomes converging
to the sure $v$. Applying the recorded upper-section continuity clause to
each sequence gives

\[
V\succeq v,\qquad v\succeq V.
\]

Consequently

\[
V\sim\mathbb E V
\quad\text{for every bounded-law gamble }V.
\tag{2}
\]

Together with the standing order on sure outcomes, (2) ranks any two
bounded-law gambles exactly by their expectations, including strict
comparisons. Both limits used upper sections; no closure of lower sections
was inferred. This lemma itself does not use Mixture Independence once
Simple EU is available.

**Observation about weaker continuity.** On real-valued gambles, this
bounded lemma already follows from the weaker-looking closure clause

\[
\bigl(\forall\varepsilon>0,\ V+\varepsilon\succeq W\bigr)
\ \Longrightarrow\ V\succeq W.
\tag{3}
\]

For each $\varepsilon>0$, take $n$ with $1/n<\varepsilon$.
Dominance and (1) give
$V+\varepsilon\succeq Q_n\succeq v$ and
$v+\varepsilon\succeq v_n\succeq V$. Applying (3) twice proves
(2). This is an observation about the bounded lemma only: the proof below
still uses the recorded $L^{1}$ Continuity axiom for its conditional limits.
Constructing and comparing a shifted variable here does not assume Shift
Invariance of preferences.

##### Integrable differences with nonnegative mean

Suppose

\[
D=X-Y\in L^1,\qquad m=\mathbb E D\ge0.
\]

There is no assumption that $X$ or $Y$ separately has an expectation. Set

\[
E_n=\{|X|\le n,\ |Y|\le n\},\qquad p_n=\Pr(E_n).
\]

The events increase to the whole sample space, so $p_n\to1$. Discard
initial indices with $p_n=0$. On $E_n$, quantize $X$ upward to

\[
q_n=\frac{\lceil nX\rceil}{n}.
\]

Only finitely many values occur on $E_n$, and
$0\le q_n-X\le1/n$ there. Define

\[
c_n=\frac{\mathbb E[(q_n-Y)\mathbf1_{E_n}]-m}{p_n},
\qquad
Z_n=\begin{cases}
q_n-c_n&\text{on }E_n,\\
Y&\text{off }E_n.
\end{cases}
\tag{4}
\]

The expectation in $c_n$ is finite because both variables in it are bounded
on $E_n$. The new branch $q_n-c_n$ remains finite-valued, with its sure
outcomes supplied by Rich Outcomes. For the expectation notation, extend
$q_n$ arbitrarily by zero off $E_n$; this has no effect on (4).

The two conditional laws on $E_n$ are bounded and satisfy

\[
\mathbb E[Z_n\mid E_n]-\mathbb E[Y\mid E_n]=\frac{m}{p_n}\ge0.
\tag{5}
\]

Realize these conditional laws on the standing atomless space. By bounded
EU they compare in the direction displayed in (5). If $p_n<1$, both full
laws have these as their $E_n$ branches, with the same conditional law of
$Y$ on $E_n^c$ as their other branch. Mixture Independence and Stochastic
Equivalence give

\[
Z_n\succeq Y.
\tag{6}
\]

If $p_n=1$, both full laws are bounded and their means differ by $m$;
bounded EU gives (6) directly. Values on a null complement can be replaced
using Stochastic Equivalence. There is no application of Independence with
a forbidden weight of one.

For convergence, use $\mathbb E D=m$ to obtain

\[
\begin{aligned}
p_n|c_n|
&=\left|\mathbb E[(q_n-Y)\mathbf1_{E_n}]-m\right|\\
&\le \frac{p_n}{n}+\mathbb E[|D|\mathbf1_{E_n^c}].
\end{aligned}
\]

Consequently the actual coupling in (4) satisfies

\[
\begin{aligned}
\mathbb E|Z_n-X|
&\le \frac{p_n}{n}+p_n|c_n|
       +\mathbb E[|D|\mathbf1_{E_n^c}]\\
&\le \frac{2}{n}+2\mathbb E[|D|\mathbf1_{E_n^c}]
\longrightarrow0.
\end{aligned}
\tag{7}
\]

Integrability of $D$ and dominated convergence justify the last limit.
Apply upper-section $L^{1}$ Continuity to (6), with fixed right side $Y$:

\[
X\succeq Y
\quad\text{whenever }X-Y\in L^1
\text{ and }\mathbb E(X-Y)\ge0.
\tag{8}
\]

##### Strictness and the full biconditional

Suppose $m>0$. Choose $K\ge1$ so
$F=\{|Y|\le K\}$ has positive probability. Atomlessness permits a
measurable $G\subseteq F$ with

\[
0<\Pr(G)<\frac{m}{2K+1}.
\]

Replace $Y$ on $G$ by the sure outcome $K+1$, leaving it unchanged
elsewhere; call the result $Y'$. The replacement has an integrable positive
difference and

\[
0<\delta:=\mathbb E(Y'-Y)
\le(2K+1)\Pr(G)<m.
\]

It weakly increases every upper tail and strictly increases the tail at
threshold $K$ by $\Pr(G)$. Stochastic Dominance therefore gives
$Y'\succ Y$. Meanwhile $X-Y'$ is integrable with mean $m-\delta>0$.
The already proved weak result (8) gives $X\succeq Y'$, hence
$X\succ Y$ by transitivity.

If $m=0$, apply (8) to both $(X,Y)$ and $(Y,X)$, obtaining $X\sim Y$.
If $m<0$, the positive-mean argument with the variables interchanged gives
$Y\succ X$. These three cases establish precisely

\[
X-Y\in L^1
\quad\Longrightarrow\quad
\bigl(X\succeq Y\iff\mathbb E(X-Y)\ge0\bigr).
\]

This is Relative Expectation. All additional variables in this main proof
use finite-valued replacements on measurable events. No Shift Invariance
or comparison of every arbitrary pair of gambles enters the argument.

##### Consequences and attribution

Combining this theorem with the existing
[Relative-to-CDF proof](relative-dominance-imply-cdf-area.html) gives
**DU + L¹ Continuity ⇒ CDF-Area Extension**. Relative Expectation also
restricts to Simple Relative Expectation, whose
[two-branch calculation](simple-relative-implies-shift-transfer.html)
gives **Shift Transfer**. Neither consequence requires Totality or Shift
Invariance as an additional assumption. Thus the previous DTU consequences
extend to DU.

**Original work: moderate connecting proof and premise reduction.** The
bounded quantization lemma is short. The conditional construction adapts the
earlier [Expected-Utility-based proof](eu-independence-l1-imply-relative.html)
by deriving the bounded comparison it needs and using finite quantizations
with mean corrections. The bounded-event argument supplies strictness
without an invariance axiom or a general outcome-space translation map.
This describes the work performed here, not a claim of literature priority.

Zachary Goodsell supplies the principles, utility framework and the source
results: *Decision theory unbound*, §3.2, pp. 678–681, and §3.3,
pp. 681–682; *Symmetries of value*, §3, p. 23, and pp. 26–27. The present
connecting proof and earlier project proofs are credited to GPT-6 (Codex),
9 September 2026, following the user's request to audit the DU premises.
The original source-attributed theorems and the earlier sufficient-premise
proof remain intact. No independent checker or Lean verification is claimed.

</details>

#### Rich Outcomes ∧ Archimedean Outcomes ∧ Stochastic Equivalence ∧ Stochastic Dominance ∧ Mixture Independence ∧ Continuity under Vanishing Shifts ⇒ Relative Expectation — `du-vanishing-shifts-imply-relative`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

Conclusion: Relative Expectation (`relative-expectation`)

Proof.

The DU premises give Simple EU by the recorded finite-lottery representation. First, any integrable survival difference g that is nonnegative outside a compact interval and has positive integral gives a strict preference: choose a compact finite-step minorant $n\le g$ with positive integral; write $n=q(S_\mu - S_\nu )$ for finite laws with $E[\mu ]>E[\nu ]$. Dominance compares the enlarged mixtures $X+q \nu$ and $Y+q \mu$, finite EU and Independence replace mu by nu strictly, and common-mixture cancellation gives X strictly above Y. Now suppose $D=X- Y$ is integrable with $ED\ge 0$, and set $d=S_X- S_Y$. This d is integrable and of bounded variation. Its local envelope $h(t)=\sup _{|s- t|<2}|d(s)|$ is integrable. Choose a nonnegative weight $r(t)$ tending to infinity in both tails with $K=$integral(rh) finite and positive, and let Z have density rh/K. If d is identically zero, use Stochastic Equivalence instead. For each $0<\epsilon \le 1$, sufficiently far in either tail the increment $S_{Z+\epsilon }(t)- S_Z(t)$ is at least $|d(t)|$. Therefore $A=M_{1/2}(X,Z)$ and $B=M_{1/2}(Y,Z)$ have survival difference $S_{A+\epsilon }- S_B$ nonnegative outside a compact interval, integrable everywhere, and of integral $ED/2+\epsilon >0$. The first step gives $A+\epsilon$ strictly above B. Dominance extends this to larger epsilon. Vanishing-shift continuity yields A weakly above B, and Independence cancels Z to give X weakly above Y. Apply this weak conclusion to X and $Y+ED/2$ when $ED>0$ to obtain strict preference by Dominance. Swap X,Y when $ED<0$, and apply the weak conclusion in both directions when $ED=0$. This is exactly Relative Expectation. Totality, Shift Invariance and lower-section continuity are never assumed.

Notes. Original work: substantial connecting proof with an auxiliary common-mixture law. The main step turns a positive-area comparison into dominance outside a compact interval after every positive shift; finite EU handles the compact remainder, one upper-section continuity step removes the shift, and mixture cancellation removes the auxiliary law. The source papers supply the framework and area method, not this proved implication. Source accounting does not assert literature priority. The auxiliary law can have undefined expectation; only actual differences are integrated. Stochastic Equivalence is listed explicitly for law replacements, although Stochastic Dominance already implies it. The proof also applies directly with Simple EU in place of the representation assumptions. No Totality, prior Shift Invariance, symmetry or lower-section continuity is used. No independent checker or Lean verification is asserted. Combining the result with the recorded area implications and the exact CDF-area model's L1 continuity shows that the exact area preorder is the least DU-plus-vanishing-shift-continuity model on the common real-utility domain, with all its strict comparisons preserved by every such extension; equality of all extensions is not claimed.

Sources:

- **GPT-6 continuity proof 9 Sep** — GPT-6 (Codex), Logical Maps project discussion, 9 September 2026: connecting proof developed in response to the proposed link between DU, weak continuity, CDF-area comparison and Shift Transfer; full common-mixture construction and proof in writeups/du-vanishing-shifts-imply-relative.md.
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026 (unpublished), §3, pp. 7–8: source of the CDF-area comparison method; the new continuity theorem and auxiliary density construction are not attributed to the manuscript.
- **Decision Theory Unbound** — Zachary Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695, §3.2–3.3, pp. 678–682: source framework and finite expected-utility formulation. The representation from the current DU preset uses the separate project proof rich-archimedean-dominance-independence-imply-simple-eu.

- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §3, pp. 7–8: source of the CDF-area comparison method; the new continuity theorem and auxiliary density construction are not attributed to the manuscript
- **Background: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §3.2–3.3, pp. 678–682: source framework and finite expected-utility formulation. The representation from the current DU preset uses the separate project proof rich-archimedean-dominance-independence-imply-simple-eu

Record: `topics/unbounded-utility/results/du-vanishing-shifts-imply-relative.yaml`.

<details><summary>Hand-written write-up</summary>

#### DU and continuity under vanishing shifts imply Relative Expectation

**Proved implication:** Rich Outcomes + Archimedean Outcomes + Stochastic
Equivalence + Stochastic Dominance + Mixture Independence + Continuity under
Vanishing Shifts imply Relative Expectation.

Here the continuity assumption is only

\[
\bigl[\forall\varepsilon>0,\ X+\varepsilon\succeq Y\bigr]
\quad\Longrightarrow\quad X\succeq Y.
\tag{VSC}
\]

The proof uses no Totality, Shift Invariance, symmetry or lower-section
continuity. In particular, it proves a stronger implication than the proposed
route through Shift Invariance and Shift Transfer.

**Source and work accounting.** GPT-6 (Codex), Logical Maps project discussion,
9 September 2026. This is a substantial connecting proof using an auxiliary
common-mixture law. Goodsell's unpublished *Unbounded Utility and Background
Risk*, §3, supplies the area-comparison method; *Decision theory unbound*,
§3.2–3.3, supplies the DU framework and finite expected-utility formulation.
The separate project representation proof derives Simple EU from the
current DU preset. The
continuity theorem and auxiliary density construction below are recorded
under Misc., and are not attributed to either paper. This accounts for work
performed for the project, without asserting literature priority or an
independent checker or Lean certificate.

##### 1. Framework and the integrable-difference identity

The recorded [finite-lottery representation](rich-archimedean-dominance-independence-imply-simple-eu.html)
derives Simple Expected Utility from the displayed DU premises. Work in
the resulting real utility chart, writing its numerical variables as $X,Y$.
Rich Outcomes supplies every real utility level; the standing realization
conventions supply the laws and shifted variables used below.

For any actually coupled pair with $E|X-Y|<\infty$, put

\[
d(t)=S_X(t)-S_Y(t),\qquad S_X(t)=P(X>t).
\]

The pointwise indicator identity and Fubini give

\[
\int_{\mathbb R}|d(t)|\,dt\le E|X-Y|,
\qquad
\int_{\mathbb R}d(t)\,dt=E(X-Y).
\tag{1}
\]

Indeed, for each pair of finite values $x,y$, the integral of
$\mathbf1_{\{x>t\}}-\mathbf1_{\{y>t\}}$ is $x-y$, and its absolute integral
is $|x-y|$. Thus (1) never subtracts two undefined expectations.

A survival difference is right-continuous and has total variation at most 2.
Both its integrability and its bounded variation will be needed.

##### 2. A comparison whose negative part lies in a compact interval

We first establish a finite-mixture lemma using only Simple EU, Stochastic
Dominance and Mixture Independence, with law replacements licensed by
Stochastic Equivalence.

**Lemma.** Suppose the survival difference

\[
g=S_F-S_G
\]

is integrable, nonnegative outside a compact interval, and has
$\int g>0$. Then $F\succ G$.

Choose $R$ large enough that $g\ge0$ outside a smaller interval contained in
$(-R,R)$ and

\[
\int_{-R}^{R}g>0.
\]

On a sufficiently fine finite partition of $[-R,R)$, replace $g$ by its
infimum on each half-open interval, and set the resulting function $n$ to
zero outside $[-R,R)$. This makes $n$ a right-continuous finite-step function
with

\[
n\le g\quad\hbox{everywhere},\qquad \int n>0.
\tag{2}
\]

To justify the last inequality, bounded variation bounds the integral error
of this lower approximation by the partition mesh times the total variation
on the interval. That error tends to zero. At $R$ and outside the partition
the comparison $0\le g$ holds by the choice of $R$.

The signed finite measure given by the negative jumps of $n$ has total mass
zero and survival function $n$. Write its positive and negative parts as
$q\mu$ and $q\nu$, where $q>0$ and $\mu,\nu$ are finitely supported
probability laws. Consequently

\[
n=q(S_\mu-S_\nu),\qquad
E_\mu-E_\nu=\frac1q\int n>0.
\tag{3}
\]

Simple EU gives $\mu\succ\nu$. Set $p=1/(1+q)\in(0,1)$.
By (2)–(3), the survival difference of
$M_p(F,\nu)$ and $M_p(G,\mu)$ is

\[
\frac{g-q(S_\mu-S_\nu)}{1+q}\ge0.
\]

Stochastic Dominance and then Mixture Independence give

\[
M_p(F,\nu)\succeq M_p(G,\mu)\succ M_p(G,\nu).
\]

The strict comparison in the last step follows from $\mu\succ\nu$ by
putting the common $G$ branch first or last as appropriate. Transitivity
and cancellation of the common $\nu$ branch yield $F\succ G$.
This proves the lemma without extending the preference to a total order.

##### 3. One auxiliary law for every positive shift

Now suppose $E|X-Y|<\infty$ and $m=E(X-Y)\ge0$. The difference
$d=S_X-S_Y$ satisfies (1).

If $d$ is identically zero, $X,Y$ have the same law and Stochastic
Equivalence gives their indifference. Hence assume $d\not\equiv0$.

Define its local envelope

\[
h(t)=\sup_{|s-t|<2}|d(s)|.
\tag{4}
\]

Right-continuity permits the same supremum to be taken over rational $s$
in the indicated open interval, so $h$ is measurable. If $|Dd|$ denotes
the finite total-variation measure of $d$, then

\[
h(t)\le |d(t)|+|Dd|((t-2,t+2)).
\]

Tonelli therefore gives

\[
\int h\le \int |d|+4|Dd|(\mathbb R)<\infty.
\tag{5}
\]

The right-continuous nonzero function $d$ makes this integral positive.
Choose numbers $R_n\uparrow\infty$, with $R_n\ge n$, such that

\[
\int_{\{|t|>R_n\}}h(t)\,dt\le2^{-n},
\]

and put

\[
r(t)=1+\sum_{n=1}^{\infty}\mathbf1_{\{|t|>R_n\}},
\qquad
K=\int_{\mathbb R}r(t)h(t)\,dt.
\tag{6}
\]

The sum is finite at every finite $t$, $r(t)\to\infty$ as $|t|\to\infty$,
and

\[
0<K\le\int h+\sum_{n=1}^{\infty}2^{-n}<\infty.
\]

Let $Z$ have probability density

\[
f_Z(t)=\frac{r(t)h(t)}K.
\tag{7}
\]

This is a single fixed law, chosen independently of the positive shift.
It need not have a finite expectation.

Fix $0<\varepsilon\le1$. Sufficiently far in either tail,
$r(u)\ge K/\varepsilon$ for every $u\in[t-\varepsilon,t]$.
For all those $u$, the interval in (4) contains $t$, so
$h(u)\ge|d(t)|$. Consequently

\[
\begin{aligned}
S_{Z+\varepsilon}(t)-S_Z(t)
&=P(t-\varepsilon<Z\le t)\\
&=\int_{t-\varepsilon}^{t}f_Z(u)\,du
\ge |d(t)|.
\end{aligned}
\tag{8}
\]

The compact interval outside which (8) holds can depend on $\varepsilon$.
That is sufficient for the finite-mixture lemma.

##### 4. Shift, compare, close, and cancel

Use the same fixed mixture lift to form

\[
A=M_{1/2}(X,Z),\qquad B=M_{1/2}(Y,Z).
\]

For $0<\varepsilon\le1$, their shifted survival difference is

\[
g_\varepsilon(t)
=S_{A+\varepsilon}(t)-S_B(t)
=\frac12\bigl(S_{X+\varepsilon}(t)-S_Y(t)\bigr)
 +\frac12\bigl(S_{Z+\varepsilon}(t)-S_Z(t)\bigr).
\tag{9}
\]

Since $S_{X+\varepsilon}\ge S_X$, equation (8) makes (9) nonnegative outside
a compact interval:

\[
g_\varepsilon(t)\ge \frac12\bigl(d(t)+|d(t)|\bigr)\ge0.
\]

Under the actual common mixture lift, $A-B$ is $X-Y$ on the first branch
and zero on the second. Thus

\[
E|A-B|=\frac12E|X-Y|,\qquad E(A-B)=\frac m2.
\]

The pair $A+\varepsilon,B$ also has integrable actual difference, so (1)
applies to give

\[
g_\varepsilon\in L^1,\qquad
\int g_\varepsilon=\frac m2+\varepsilon>0.
\tag{10}
\]

The lemma of section 2 now yields $A+\varepsilon\succ B$. For
$\varepsilon>1$, weak Stochastic Dominance gives
$A+\varepsilon\succeq A+1\succ B$, so in fact

\[
\forall\varepsilon>0,\quad A+\varepsilon\succeq B.
\]

Apply the single upper-section clause (VSC):

\[
A\succeq B.
\]

Mixture Independence cancels the common $Z$ branch, giving $X\succeq Y$.
We have proved

\[
E|X-Y|<\infty,\quad E(X-Y)\ge0
\quad\Longrightarrow\quad X\succeq Y.
\tag{11}
\]

##### 5. Strict comparisons and the full biconditional

If $m>0$, apply (11) to $X$ and $Y+m/2$. Their actual difference is
integrable with positive mean $m/2$, so

\[
X\succeq Y+m/2.
\]

Every positive shift of a real-valued variable strictly stochastically
dominates it. For completeness, if $c>0$, some interval $(kc,(k+1)c]$
has positive $Y$-probability, and its upper endpoint supplies a strict
survival comparison for $Y+c$ and $Y$. Thus

\[
X\succeq Y+m/2\succ Y.
\]

If $m<0$, swap the variables to obtain $Y\succ X$, which excludes
$X\succeq Y$. If $m=0$, apply (11) in both directions to get indifference.
Altogether,

\[
\boxed{
E|X-Y|<\infty
\quad\Longrightarrow\quad
\bigl(X\succeq Y\iff E(X-Y)\ge0\bigr).
}
\]

This is Relative Expectation. Both comparisons in the zero-mean case arise
from separate applications of the same upper-section argument.

##### Consequences and scope

Relative Expectation implies Simple Relative Expectation and hence the
recorded Shift Transfer principle. Under DU it is also equivalent to
CDF-Area Extension by the existing quantile-area implications. The theorem
therefore supplies the proposed area and transfer consequences without
assuming Shift Invariance first.

Combined with [Relative Expectation plus vanishing-shift continuity](relative-vanishing-shifts-imply-l1.html),
the theorem also gives $L^{1}$ Continuity under DU. Conversely, $L^{1}$ Continuity
immediately implies (VSC). Thus these two continuity principles are
equivalent under DU, even though (VSC) mentions only constant positive
perturbations of one variable.

There is a precise minimality conclusion. The
[exact CDF-area preorder](cdf-area-preorder.html) itself satisfies DU and
$L^{1}$ Continuity, as established in its continuity section. Every DU + (VSC)
model extends that preorder and preserves its strict comparisons, by the
CDF-Area Extension consequence above. On the common real-utility domain,
the exact CDF-area preorder is therefore the **least** such model under
inclusion of weak preference comparisons; it is also the least DU +
$L^{1}$ Continuity model. This does not assert that all these models coincide:
an extension can supply further comparisons when both CDF areas are infinite.

The proof applies directly to Rich Outcomes + Simple $\operatorname{EU} +$ Stochastic
Dominance + Mixture Independence + (VSC); Stochastic Equivalence follows
from Dominance. The recorded statement uses the more basic DU premises
and its separately proved finite-lottery representation.

No comparison of two undefined individual expectations occurs: the only
unbounded integrations are of actual differences, survival differences,
and the nonnegative envelope defining a probability density. The auxiliary
law is used in a randomized mixture, so no independent-sum principle is
assumed.

</details>

#### Rich Outcomes ∧ Archimedean Outcomes ∧ Stochastic Equivalence ∧ Statewise Dominance ⇒ Stochastic Dominance — `equivalence-and-statewise-imply-dominance`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Statewise Dominance (`statewise-dominance`)

Conclusion: Stochastic Dominance (`stochastic-dominance`)

Proof.

On the full real chart, first-order dominance permits quantile realizations X′,Y′ using the same uniform random variable with X′$\ge Y$′ almost surely. Distinct laws give $P(X$′$>Y$′)$>0$. Statewise Dominance compares these realizations, and Stochastic Equivalence plus transitivity transfers that comparison to X,Y. All realizations exist by standing Prospect Richness.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, footnote 19 (RV/quantile translation)

- **Proof: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §3.2, footnote 19 (RV/quantile translation)

Record: `topics/unbounded-utility/results/equivalence-and-statewise-imply-dominance.yaml`.

#### Rich Outcomes ∧ Expected Utility ∧ Stochastic Equivalence ∧ Mixture Independence ∧ Stochastic Dominance ∧ L¹ Continuity (random variables) ⇒ Relative Expectation — `eu-independence-l1-imply-relative`

Proved result; source **Misc.**; produced by GPT-6 (Codex) (connecting proof by conditional truncation); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Expected Utility (`expected-utility`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Mixture Independence (`independence`)
- Stochastic Dominance (`stochastic-dominance`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Relative Expectation (`relative-expectation`)

Proof.

First take an integrable actual difference $D=X- Y$ with $ED=0$. On $E_n=\{|X|\le n,|Y|\le n\}$, put $p_n=P(E_n)$ and $c_n=E[D 1_{E_n}]/p_n$, starting after $p_n>0$. Set $X_n=X- c_n$ on $E_n$ and $X_n=Y$ elsewhere. The conditional laws of $X- c_n$ and Y on $E_n$ are bounded with equal expectations, so Expected Utility, Stochastic Equivalence and Mixture Independence give $X_n\sim Y$; when $p_n=1$ use Expected Utility directly. Furthermore $E|X_n- X|\le E[|D|1_{E_n^{c}}]+|E[D1_{E_n}]|\to 0$. Upper-section L1 Continuity gives $X\succeq Y$. Interchanging X,Y proves $Y\succeq X$. For arbitrary mean m, apply this zero-mean argument to X and $Y+m$ to obtain $X\sim Y+m$. Stochastic Dominance compares $Y+m$ with Y strictly according to the sign of m, giving exactly Relative Expectation.

Notes. Original work: moderate connecting argument by truncation adaptation. The source supplies the expectation/continuity principles and their implication with full affine symmetry. This proof instead compares bounded conditional pieces and corrects their means before taking upper-section limits. In combination with the existing DTU$+L1$-to-EU record, it removes symmetry from the DTU$+L1$-to-Relative implication. No lower-section continuity, prior Relative Expectation, Shift Transfer or Shift Invariance is assumed. This is work accounting, not a claim of literature priority. Stochastic Equivalence is retained to show the conditional- law replacements explicitly, although it follows from Stochastic Dominance in this topic.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof in Logical Maps, 9 September 2026; writeups/eu-independence-l1-imply-relative.md.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, L1 Continuity and DTU+L1 implying Expected Utility, §3, p. 23; Relative Expectation and Corollary 5 in the full DTU+Sym context, pp. 26–27.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3, p. 23; Relative Expectation and Corollary 5 in the full DTU+Sym context, pp. 26–27

Record: `topics/unbounded-utility/results/eu-independence-l1-imply-relative.yaml`.

<details><summary>Hand-written write-up</summary>

#### Expected Utility, Independence and L¹ Continuity yield Relative Expectation

**Claim.** Rich Outcomes + Expected Utility + Stochastic Equivalence + Mixture
Independence + Stochastic Dominance $+ L^{1}$ Continuity imply Relative Expectation.

In particular, the map's existing DTU $+ L^{1}$ Continuity implication to Expected
Utility shows that **DTU + L¹ Continuity implies Relative Expectation without
affine symmetry**. Only the recorded upper-section continuity clause is used.

Write the variables' finite utility coordinates as $X,Y$. Rich Outcomes and
Expected Utility supply all real coordinates and the total measurable chart.

##### Zero-mean integrable differences

Suppose $D=X-Y$ is integrable and $\mathbb E D=0$. Define

$$E_n=\{|X|\le n,\ |Y|\le n\},\qquad p_n=\Pr(E_n).$$

These measurable events increase to the whole sample space, so $p_n\to1$.
Discard any initial terms with $p_n=0$. Put

$$c_n=\frac{\mathbb E[D\mathbf1_{E_n}]}{p_n},\qquad
X_n=\begin{cases}X-c_n&\text{on }E_n,\\Y&\text{off }E_n.\end{cases} \tag{1}$$

The conditional laws of $X-c_n$ and $Y$ on $E_n$ are bounded and have the
same expectation, since

$$\mathbb E[X-c_n\mid E_n]-\mathbb E[Y\mid E_n]
=\frac{\mathbb E[D\mathbf1_{E_n}]}{p_n}-c_n=0.$$

Realize those conditional laws as variables on the standing atomless space.
Expected Utility makes them indifferent. If $p_n<1$, both $X_n$ and $Y$
have probability-mixture laws with these conditional variables in their
$E_n$ branches and the same conditional law of $Y$ on $E_n^c$ in their other
branches. Mixture Independence and Stochastic Equivalence therefore imply

$$X_n\sim Y. \tag{2}$$

If $p_n=1$, $c_n=\mathbb E D=0$ and both original variables have bounded
laws, hence finite expectations; Expected Utility gives (2) directly. Values
on a null complement cause no integrability problem. This endpoint case
does not apply Mixture Independence with a forbidden weight of one.

The actual coupling in (1) obeys

$$\begin{aligned}
\mathbb E|X_n-X|
&\le \mathbb E[|D|\mathbf1_{E_n^c}]+p_n|c_n|\\
&=\mathbb E[|D|\mathbf1_{E_n^c}]
 +|\mathbb E[D\mathbf1_{E_n}]|\longrightarrow0.
\end{aligned}$$

Dominated convergence and $\mathbb E D=0$ justify the limit. The first weak
comparison in (2), followed by upper-section $L^{1}$ Continuity with fixed $Y$,
gives $X\succeq Y$. Repeat the same construction with $X,Y$ interchanged to
obtain $Y\succeq X$. We have therefore proved

$$\mathbb E|X-Y|<\infty,\quad \mathbb E(X-Y)=0
\quad\Longrightarrow\quad X\sim Y. \tag{3}$$

The second comparison in (3) comes from a second *upper-section* limit. It
does not infer closure of lower sections from the given axiom.

##### General means and strict comparison

For an arbitrary integrable difference, put $m=\mathbb E(X-Y)$. Rich Outcomes
supplies $Y+m$. Since $X-(Y+m)$ has zero mean and is integrable, (3) gives

$$X\sim Y+m. \tag{4}$$

If $m>0$, the translated law $Y+m$ stochastically dominates $Y$: its survival
function is $S_Y(t-m)\ge S_Y(t)$. At least one comparison is strict. Indeed
the intervals $(km,(k+1)m]$, $k\in\mathbb Z$, cover the line, so some such
interval has positive probability and its upper endpoint supplies a strict
tail comparison. Rich Outcomes makes that threshold an available outcome.
Thus Stochastic Dominance gives $Y+m\succ Y$. If $m<0$ the reverse argument
gives $Y\succ Y+m$; if $m=0$ the two variables are identical.

Together with (4) and transitivity these cases prove exactly

$$X\succeq Y\iff\mathbb E(X-Y)\ge0.$$

No Totality, symmetry, Shift Transfer or Shift Invariance is used. The shift
in (4) is constructed as a random variable and compared by (3); it is not a
transport of a preference by an unassumed invariance axiom. Stochastic
Equivalence is written explicitly to license the conditional-law mixture
replacements, even though this topic's Stochastic Dominance implies it.

##### Attribution and scope

**Original work: moderate connecting argument by truncation adaptation.**
Zachary Goodsell supplies the principles and Corollary 5's implication in
the full DTU+Sym context. The present proof uses bounded conditional pieces,
mean corrections and two upper-section limits to remove the symmetry
assumptions in the stated sufficient package. It is credited as a connecting
proof, not as a theorem already attributed to the paper. This describes work
performed for the map, not literature priority.

Combined with the existing source-based DTU $+ L^{1}$ Continuity implication to
Expected Utility, this yields the claimed DTU consequence. It does not claim
the converse: the separate infinitesimal folded-tail model satisfies DTU,
Relative Expectation and even Folded Expectation while violating $L^{1}$ Continuity.

**Sources.** Zachary Goodsell, *Symmetries of value*, §3, p. 23, and pp. 26–27
(Relative Expectation and Corollary 5). Connecting proof: GPT-6 (Codex),
9 September 2026. No independent checker or Lean proof is claimed.

</details>

#### Existential Copula Sum Invariance ⇒ Shift Invariance — `existential-copula-implies-shift`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

Conclusion: Shift Invariance (`shift-invariance`)

Proof.

Choose the single copula C supplied by the existential principle. For Z equal to a constant $b, F_Z(z)$ is either 0 or 1. Every copula satisfies $H_C(u,0)=0$ and $H_C(u,1)=u$, so (X,b) and (Y,b) admit C for every $X,Y. \operatorname{SC}(C)$ therefore gives $X \succeq Y$ iff $X+b \succeq Y+b$ whenever the shifted gambles exist. This uses the actual constant summand and needs no Stochastic Equivalence.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original copula sum consistency definitions and connecting proofs recorded in this project, 9 September 2026, implementing Zachary Goodsell’s proposal.
- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).



Record: `topics/unbounded-utility/results/existential-copula-implies-shift.yaml`.

#### Expected Utility ⇒ Simple Expected Utility — `expected-utility-implies-simple`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean verified; 2026-09-08.

Premises:

- Expected Utility (`expected-utility`)

Conclusion: Simple Expected Utility (`simple-eu`)

Proof.

All simple variables have finite real expected utility. Restrict Expected Utility to them.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.1, p. 685
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/expected-utility-implies-simple.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

- **Background: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §4.1, p. 685

Record: `topics/unbounded-utility/results/expected-utility-implies-simple.yaml`.

#### Rich Outcomes ∧ Folded Expectation ⇒ Arroyo = ln 2 — `folded-evaluates-arroyo`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (folded Arroyo evaluation); GPT-6 (Codex) (explicit unshifted tail calculation and premise audit); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Folded Expectation (`folded-expectation`)

Conclusion: Arroyo = ln 2 (`arroyo-value`)

Proof.

For Arroyo A, the folded tail $h_A(t)$ on $[m+1,m+2), m\ge 1$, is the alternating remainder sum over $n\ge m+1$ of $(-1)^{n+1}/(n(n+1))$, whose absolute value is at most $1/((m+1)(m+2))$. Thus $h_A$ is absolutely integrable. At cutoff $T=N+1$ its integral is the alternating harmonic prefix through N, plus $(N+1)$ times that alternating probability remainder. The remainder has absolute value at most $1/(N+2)$, so the integral tends to $\ln 2$. Sure $\ln 2$ has the same folded expectation and exists by Rich Outcomes. Folded Expectation gives $A\sim \ln 2$.

Notes. Original work: source extraction with a small calculation/premise audit. Goodsell already states the folded value of Arroyo immediately before Theorem 8. This record makes Folded Expectation the explicit sufficient principle; the unshifted calculation avoids invoking Shift Invariance from the larger theorem package. It is not a new evaluation or a claim of literature novelty. No independent checker or Lean certification is asserted.

Sources:

- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37, DOI 10.1111/nous.12549, discussion preceding Theorem 8 and Theorem 8, pp. 29–30: Arroyo has folded expectation ln 2.
- **GPT-6 calculation 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/folded-evaluates-arroyo.md: unshifted absolutely integrable tail calculation exposing the sufficient premises.

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 8 and Theorem 8, pp. 29–30: Arroyo has folded expectation ln 2

Record: `topics/unbounded-utility/results/folded-evaluates-arroyo.yaml`.

<details><summary>Hand-written write-up</summary>

#### Folded Expectation directly evaluates Arroyo

**Source and work accounting.** Zachary Goodsell's *Symmetries of value*,
pp. 29–30, explicitly states that Arroyo has folded expectation \(\ln2\), and
Theorem 8 gives its evaluation. The unshifted tail calculation below was
supplied by GPT-6 (Codex), 9 September 2026, to expose the smaller sufficient
package. It is a source extraction with a small calculation and premise audit,
not a new discovery of Arroyo's value. No independent checker or Lean
certification is asserted.

Assume Rich Outcomes and Folded Expectation. Let

\[
\Pr(A=(-1)^{n+1}(n+1))=\frac1{n(n+1)},\qquad n\ge1,
\]

and write \(h(t)=\Pr(A>t)-\Pr(A<-t)\) for \(t\ge0\).
For \(t\in[m+1,m+2)\), \(m\ge1\), apart from immaterial endpoints,

\[
h(t)=\sum_{n=m+1}^{\infty}\frac{(-1)^{n+1}}{n(n+1)}.
\]

The alternating-series estimate gives

\[
|h(t)|\le\frac1{(m+1)(m+2)}.
\]

On \([0,2)\) the tail difference is bounded by one. Thus

\[
\int_0^\infty |h(t)|\,dt
\le2+\sum_{m=1}^{\infty}\frac1{(m+1)(m+2)}<\infty.
\]

For a symmetric cutoff \(T=N+1\), bounded tail integration gives

\[
\int_0^{N+1}h(t)\,dt
=\sum_{n=1}^{N}\frac{(-1)^{n+1}}n
 +(N+1)\sum_{n=N+1}^{\infty}\frac{(-1)^{n+1}}{n(n+1)}.
\]

The final term has absolute value at most \(1/(N+2)\), while the finite
alternating harmonic sum tends to \(\ln2\). Therefore Arroyo's absolutely
defined folded expectation is \(\ln2\). Sure \(\ln2\), available by Rich
Outcomes, has the same folded expectation. The axiom gives

\[
A\sim\ln2.
\]

This holds for every random variable with the indicated utility law because
the folded-tail condition itself depends only on that law. No separate
Stochastic Equivalence, shift symmetry, continuity or DU package is needed.
The use of the limit above computes an already absolutely integrable folded
tail; it does not silently interpret a conditionally convergent expected
utility as an ordinary Lebesgue expectation.

</details>

#### Archimedean Outcomes ∧ Folded Expectation ⇒ Expected Utility — `folded-implies-eu`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Archimedean Outcomes (`archimedean-outcomes`)
- Folded Expectation (`folded-expectation`)

Conclusion: Expected Utility (`expected-utility`)

Proof.

For an integrable real utility variable, the integral of the absolute folded tail difference is bounded by $E|u(X)|$, and the tail-integral formula gives $F(X)=E[u(X)]$. Archimedean Outcomes makes the chart total. Restrict the Folded Expectation comparison to integrable X,Y.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, p. 27
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/folded-implies-eu.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §4, p. 27

Record: `topics/unbounded-utility/results/folded-implies-eu.yaml`.

#### Rich Outcomes ∧ Folded Expectation ⇒ Symmetric Gambles Are Neutral — `folded-implies-symmetric-neutrality`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Folded Expectation (`folded-expectation`)

Conclusion: Symmetric Gambles Are Neutral (`symmetric-neutrality`)

Proof.

For a symmetric real $\operatorname{law}, h_X(t)=0$ almost everywhere, so $F(X)=0$. The zero constant also has folded value zero; apply Folded Expectation.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, pp. 27–28

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §4, pp. 27–28

Record: `topics/unbounded-utility/results/folded-implies-symmetric-neutrality.yaml`.

#### Rich Outcomes ∧ Mixture Independence ∧ Folded Expectation ⇒ Relative Expectation — `folded-independence-imply-relative`

Proved result; source **Misc.**; produced by GPT-6 (Codex) (connecting proof using Goodsell's folded-expectation principle); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Mixture Independence (`independence`)
- Folded Expectation (`folded-expectation`)

Conclusion: Relative Expectation (`relative-expectation`)

Proof.

For actual-coupling real-utility variables X,Y with E|X−Y| finite, the survival difference $d=S_X- S_Y$ is absolutely integrable and its integral is $E(X- Y)$. Let $A=M_{1/2}(X,- Y)$ and $B=M_{1/2}(Y,- Y)$. Except at atom thresholds, $h_A(t)=(d(t)+d(- t))/2$ and $h_B(t)=0$. Thus A and B have folded expectations $E(X- Y)/2$ and zero. Folded Expectation compares them exactly by that sign. Mixture Independence cancels their common −Y branch, giving $X\succeq Y$ iff $E(X- Y)\ge 0$. Rich Outcomes supplies the reflected finite-chart variable −Y. Neither Totality nor a law replacement in preferences is used.

Notes. Original work: small connecting proof. Goodsell supplies both evaluation principles and the forward route from relative to folded expectation under symmetry. This entry gives the converse route by a common reflected mixture, with an explicit integrability bound and a smaller sufficient premise package. This records work done for the map, not a claim of priority in the literature. No independent checker or Lean verification is asserted.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof in Logical Maps, 9 September 2026; writeups/folded-independence-imply-relative.md.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Relative Expectation and Folded Expectation definitions and Theorem 6, pp. 26–29.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 6, pp. 26–29

Record: `topics/unbounded-utility/results/folded-independence-imply-relative.yaml`.

<details><summary>Hand-written write-up</summary>

#### Folded Expectation and Mixture Independence imply Relative Expectation

**Claim.** Rich Outcomes + Mixture Independence + Folded Expectation imply Relative Expectation.

Write the finite utility coordinates of the given variables as $X,Y$, and suppose
$\mathbb E|X-Y|<\infty$ in their actual coupling. Put

$$S_X(t)=\Pr(X>t),\qquad d(t)=S_X(t)-S_Y(t).$$

The indicator identity for the interval between two real numbers, followed by
Tonelli and Fubini, gives

$$\int_{\mathbb R}|d(t)|\,dt\le\mathbb E|X-Y|<\infty,
\qquad \int_{\mathbb R}d(t)\,dt=\mathbb E(X-Y). \tag{1}$$

Rich Outcomes supplies the reflected variable $-Y$. Form the actual fixed-lift
mixtures

$$A=M_{1/2}(X,-Y),\qquad B=M_{1/2}(Y,-Y).$$

The second mixture has a symmetric law. For positive $t$, put
$h_Z(t)=\Pr(Z>t)-\Pr(Z<-t)$. Probability-mixture linearity gives

$$h_B(t)=0,\qquad h_A(t)=\tfrac12(h_X(t)-h_Y(t))
=\tfrac12(d(t)+d(-t))\quad\text{a.e.} \tag{2}$$

The last equality can fail only when $t$ or $-t$ is an atom threshold of one
of the laws, a countable and hence Lebesgue-null set. Equations (1) and (2)
show that both mixtures are foldable, with

$$\int_0^\infty|h_A(t)|\,dt\le\tfrac12\int_{\mathbb R}|d(t)|\,dt<\infty,
\qquad F(A)=\tfrac12\mathbb E(X-Y),\qquad F(B)=0.$$

Folded Expectation therefore gives

$$A\succeq B\iff\mathbb E(X-Y)\ge0.$$

Mixture Independence, applied to the common $-Y$ branch, gives
$A\succeq B\iff X\succeq Y$. This is exactly Relative Expectation, including
indifference at zero and the failure of the weak comparison for negative mean.

The proof uses identities of mixture laws to compute folded tails, but it does
not replace one random variable with an equal-law variable in a preference.
Folded Expectation itself licenses the two comparisons being used. Thus neither
Stochastic Equivalence nor Totality is an omitted premise. No $L^{1}$ Continuity,
reflection axiom or full affine symmetry is needed.

**Original work: small connecting proof.** The two expectation principles and
the source's forward implication are Zachary Goodsell's. The common-reflected-
mixture proof supplies a converse useful to the map, rather than importing a
claim that the paper already proves that converse. The integrability bound is
essential: conditional improper convergence is insufficient. This accounting
is not a claim of literature novelty.

**Sources.** Zachary Goodsell, *Symmetries of value*, pp. 26–29, especially the
definitions and Theorem 6. Connecting proof and premise audit: GPT-6 (Codex),
9 September 2026. No independent checker or Lean proof is claimed.

</details>

#### Full Sum Invariance ⇒ Antitonic Sum Invariance — `full-sum-implies-antitonic`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; Lean verified; 2026-09-09.

Premises:

- Full Sum Invariance (`full-sum-consistency`)

Conclusion: Antitonic Sum Invariance (`antitonic-sum-consistency`)

Proof.

Restrict the universal quantifier over X,Y,Z to triples satisfying the stated dependence condition. Both directions of the same biconditional remain available.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.1–2, pp. 17–18

- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §6.1–2, pp. 17–18
- **Related: [Preference for equivalent random variables: A price for unbounded utilities](https://doi.org/10.1016/j.jmateco.2008.12.002).** Seidenfeld, T., Schervish, M., & Kadane, J. (2009). Preference for equivalent random variables: A price for unbounded utilities. Journal of Mathematical Economics, 45, 329–340. — §1. Related coherence treatment of unbounded random variables; this is not an attribution of the recorded implication to the paper.

Record: `topics/unbounded-utility/results/full-sum-implies-antitonic.yaml`.

#### Full Sum Invariance ⇒ Comonotonic Sum Invariance — `full-sum-implies-comonotonic`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; Lean verified; 2026-09-09.

Premises:

- Full Sum Invariance (`full-sum-consistency`)

Conclusion: Comonotonic Sum Invariance (`comonotonic-sum-consistency`)

Proof.

Restrict the universal quantifier over X,Y,Z to triples satisfying the stated dependence condition. Both directions of the same biconditional remain available.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.1–2, pp. 17–18

- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §6.1–2, pp. 17–18
- **Related: [Preference for equivalent random variables: A price for unbounded utilities](https://doi.org/10.1016/j.jmateco.2008.12.002).** Seidenfeld, T., Schervish, M., & Kadane, J. (2009). Preference for equivalent random variables: A price for unbounded utilities. Journal of Mathematical Economics, 45, 329–340. — §1. Related coherence treatment of unbounded random variables; this is not an attribution of the recorded implication to the paper.

Record: `topics/unbounded-utility/results/full-sum-implies-comonotonic.yaml`.

#### Full Sum Invariance ⇒ Independent Sum Invariance — `full-sum-implies-independent`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; Lean verified; 2026-09-09.

Premises:

- Full Sum Invariance (`full-sum-consistency`)

Conclusion: Independent Sum Invariance (`independent-sum-consistency`)

Proof.

Restrict the universal quantifier over X,Y,Z to triples satisfying the stated dependence condition. Both directions of the same biconditional remain available.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.1–2, pp. 17–18

- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §6.1–2, pp. 17–18
- **Background: [Flummoxing expectations](https://doi.org/10.1111/nous.12530).** Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. — §6.1. Source of Independent Sum Consistency; see the principle reference for the changed independence condition. The proof or conjecture recorded here retains its separate attribution.
- **Related: [Preference for equivalent random variables: A price for unbounded utilities](https://doi.org/10.1016/j.jmateco.2008.12.002).** Seidenfeld, T., Schervish, M., & Kadane, J. (2009). Preference for equivalent random variables: A price for unbounded utilities. Journal of Mathematical Economics, 45, 329–340. — §1. Related coherence treatment of unbounded random variables; this is not an attribution of the recorded implication to the paper.

Record: `topics/unbounded-utility/results/full-sum-implies-independent.yaml`.

#### Full Sum Invariance ⇒ Universal Copula Sum Invariance — `full-sum-implies-universal-copula`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean verified; 2026-09-09.

Premises:

- Full Sum Invariance (`full-sum-consistency`)

Conclusion: Universal Copula Sum Invariance (`universal-copula-sum-consistency`)

Proof.

Fix any copula C and any eligible triple whose two pairs admit C. Full Sum Invariance applies to this triple regardless of dependence and supplies the required biconditional. Since C was arbitrary, $\operatorname{SC}(C)$ holds for every copula.

Notes. No converse is asserted: Universal Copula Sum Invariance only constrains triples for which the two pairs admit a common copula; Full Sum Invariance constrains all eligible triples.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original copula sum consistency definitions and connecting proofs recorded in this project, 9 September 2026, implementing Zachary Goodsell’s proposal.
- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).

- **Related: [Preference for equivalent random variables: A price for unbounded utilities](https://doi.org/10.1016/j.jmateco.2008.12.002).** Seidenfeld, T., Schervish, M., & Kadane, J. (2009). Preference for equivalent random variables: A price for unbounded utilities. Journal of Mathematical Economics, 45, 329–340. — §1. Related coherence treatment of unbounded random variables; this is not an attribution of the recorded implication to the paper.

Record: `topics/unbounded-utility/results/full-sum-implies-universal-copula.yaml`.

#### Mixture Independence ∧ Transfer of a Shift Across a Mixture ⇒ Shift Invariance — `independence-shift-transfer-imply-shift`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Mixture Independence (`independence`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)

Conclusion: Shift Invariance (`shift-invariance`)

Proof.

Fix eligible $X,Y,X+b,Y+b$. Shift Transfer at $p=1/2$ with transfer parameter b/2 gives $M_{1/2}(X+b,X)\sim M_{1/2}(X,X+b)$ and $M_{1/2}(Y+b,X)\sim M_{1/2}(Y,X+b)$. Mixture Independence with common second argument $X+b$ identifies $X\succeq Y$ with the comparison between the latter two right-hand mixtures. Substitute the displayed indifferences and cancel the common second argument X by Independence. The resulting comparison is $X+b\succeq Y+b$. The equivalences work in both directions and require no exchange of mixture branches.

Notes. Original work: direct consequence. Use the shifted first variable itself as the common gamble, avoiding a Rich Outcomes premise for a new sure outcome b; cancel two half-mixtures. This describes the work needed for this database entry, not a claim of novelty in the literature.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof and premise audit in the Logical Maps project, 9 September 2026; see the accompanying handwritten write-up.



Record: `topics/unbounded-utility/results/independence-shift-transfer-imply-shift.yaml`.

<details><summary>Hand-written write-up</summary>

#### Mixture Independence and Shift Transfer imply Shift Invariance

**Claim.** Mixture Independence + Shift Transfer imply Shift Invariance.

Fix real-utility variables $X,Y$ and $b\in\mathbb R$ such that $X+b$ and $Y+b$ are available. Apply Shift Transfer with mixture weight $1/2$ and transfer parameter $b/2$, first to $(X,X)$ and then to $(Y,X)$:

$$M_{1/2}(X+b,X)\sim M_{1/2}(X,X+b),$$
$$M_{1/2}(Y+b,X)\sim M_{1/2}(Y,X+b).$$

Transitivity of the standing preorder lets an indifferent object replace either side of a weak comparison. Therefore

$$\begin{aligned}
X\succeq Y
&\iff M_{1/2}(X,X+b)\succeq M_{1/2}(Y,X+b)\\
&\iff M_{1/2}(X+b,X)\succeq M_{1/2}(Y+b,X)\\
&\iff X+b\succeq Y+b.
\end{aligned}$$

The first and last equivalences are exactly Mixture Independence, with common second arguments $X+b$ and $X$ respectively.

No branch interchange, independent copy, totality assumption or law identity occurs. Using $X$ as the common gamble also avoids assuming the availability of a new sure outcome at utility $b$: all transformations used were already stipulated to exist in this instance of Shift Invariance.

**Original work: direct consequence.** This is a two-application specialization followed by mixture cancellation. The choice of common gamble is the small domain check needed to avoid unnecessary outcome-richness assumptions. No literature novelty is asserted.

**Attribution.** GPT-6 (Codex), 9 September 2026, original connecting argument for this project. No independent checker or Lean proof is claimed.

</details>

#### Stochastic Equivalence ∧ Mixture Independence ⇒ Sure-Thing — `independence-to-sure-thing`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Stochastic Equivalence (`stochastic-equivalence`)
- Mixture Independence (`independence`)

Conclusion: Sure-Thing (`sure-thing`)

Proof.

Let $p=P(E)$. Realize the conditional laws on E and $E^{c}$ as A,B for X and C,D for Y. Law invariance gives $X\sim M_p(A,B), Y\sim M_p(C,D), X|E\sim M_p(A,0), Y|E\sim M_p(C,0)$. Independence cancels 0 to yield $A\sim C$ from the hypothesis. Replace indifferent mixture components and cancel the common E component: $X\succeq Y$ iff $B\succeq D$. The latter is equivalent to $X|E^{c}\succeq Y|E^{c}$ by independence and law invariance.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 679 and p. 682, footnote 28

- **Proof: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §3.2, p. 679 and p. 682, footnote 28

Record: `topics/unbounded-utility/results/independence-to-sure-thing.yaml`.

#### Independent Sum Invariance ∧ Stochastic Equivalence ⇒ Existential Copula Sum Invariance — `independent-sum-and-equivalence-imply-existential-copula`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Independent Sum Invariance (`independent-sum-consistency`)
- Stochastic Equivalence (`stochastic-equivalence`)

Conclusion: Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

Proof.

Choose the product copula once. For an eligible triple admitting that copula in both pairs, Z is separately independent of X and Y, but need not be independent of (X,Y). On the standing atomless space realize independent uniforms U,V, and utility coordinates X′$=Q_X(U), Y$′$=Q_Y(U), Z$′$=Q_Z(V)$. Now Z′ is independent of (X′,Y′). The marginal laws and both pair laws agree with those of the original triple; consequently so do the two sum laws. Independent Sum Invariance gives the biconditional for the new triple. Stochastic Equivalence and transitivity transfer it to the original comparisons. This establishes $\operatorname{SC}(C)$ for the product copula.

Notes. The Stochastic Equivalence premise licenses copying the variables; pairwise independence alone does not license applying the existing jointly-independent sum principle to the original triple.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original copula sum consistency definitions and connecting proofs recorded in this project, 9 September 2026, implementing Zachary Goodsell’s proposal.
- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).

- **Background: [Flummoxing expectations](https://doi.org/10.1111/nous.12530).** Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. — §6.1. Source of Independent Sum Consistency; see the principle reference for the changed independence condition. The proof or conjecture recorded here retains its separate attribution.

Record: `topics/unbounded-utility/results/independent-sum-and-equivalence-imply-existential-copula.yaml`.

#### Independent Sum Invariance ⇒ Independent Sum Cancellation — `independent-sum-implies-cancellation`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; Lean verified; 2026-09-09.

Premises:

- Independent Sum Invariance (`independent-sum-consistency`)

Conclusion: Independent Sum Cancellation (`independent-sum-cancellation`)

Proof.

Take the reverse direction of the biconditional.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §1–2; Lemma 1, p. 8

- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §1–2; Lemma 1, p. 8
- **Background: [Flummoxing expectations](https://doi.org/10.1111/nous.12530).** Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. — §6.1. Source of Independent Sum Consistency; see the principle reference for the changed independence condition. The proof or conjecture recorded here retains its separate attribution.

Record: `topics/unbounded-utility/results/independent-sum-implies-cancellation.yaml`.

#### Independent Sum Invariance ⇒ Independent Sum Preservation — `independent-sum-implies-preservation`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; Lean verified; 2026-09-09.

Premises:

- Independent Sum Invariance (`independent-sum-consistency`)

Conclusion: Independent Sum Preservation (`independent-sum-preservation`)

Proof.

Take the forward weak implication. If $X \succ Y$ but $Y+Z \succeq X+Z$, the reverse implication with X,Y swapped gives $Y \succeq X, a$ contradiction. Thus strict preference is preserved too.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §1–2; Lemma 1, p. 8

- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §1–2; Lemma 1, p. 8
- **Background: [Flummoxing expectations](https://doi.org/10.1111/nous.12530).** Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. — §6.1. Source of Independent Sum Consistency; see the principle reference for the changed independence condition. The proof or conjecture recorded here retains its separate attribution.

Record: `topics/unbounded-utility/results/independent-sum-implies-preservation.yaml`.

#### Independent Sum Invariance ⇒ Shift Invariance — `independent-sum-implies-shift`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Independent Sum Invariance (`independent-sum-consistency`)

Conclusion: Shift Invariance (`shift-invariance`)

Proof.

Choose Z to be the constant utility b. A constant is independent of every pair and is both comonotonic and antitonic with every variable, so the sum biconditional becomes $X \succeq Y$ iff $X+b \succeq Y+b$. Apply this wherever the shifted outcomes exist.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.2, p. 18; definitions on pp. 3–4

- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §6.2, p. 18; definitions on pp. 3–4
- **Background: [Flummoxing expectations](https://doi.org/10.1111/nous.12530).** Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. — §6.1. Source of Independent Sum Consistency; see the principle reference for the changed independence condition. The proof or conjecture recorded here retains its separate attribution.

Record: `topics/unbounded-utility/results/independent-sum-implies-shift.yaml`.

#### L¹ Continuity (random variables) ⇒ Continuity under Vanishing Shifts — `l1-implies-vanishing-shift-continuity`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean verified; 2026-09-09.

Premises:

- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

Proof.

Suppose all the eligible positive shifts $X+\epsilon$ satisfy $X+\epsilon \succeq Y$. Use the actual coupling $X_n=X+1/n$. Its expected absolute utility difference from X is exactly 1/n, tending to zero. Upper-section L1 Continuity therefore yields $X \succeq Y$. No shift invariance, law replacement, or lower-section continuity is used.

Notes. Original work: immediate axiom restriction. This records the comparison between continuity conditions, not a claim of literature novelty.

Sources:

- **GPT-6 direct deduction 9 Sep** — GPT-6 (Codex), 9 September 2026, direct restriction of the recorded upper-section L1 Continuity axiom to constant-shift sequences in Logical Maps.



Record: `topics/unbounded-utility/results/l1-implies-vanishing-shift-continuity.yaml`.

#### Rich Outcomes ∧ Stochastic Dominance ∧ Mixture Independence ∧ Symmetric Gambles Are Neutral ∧ Independent Sum Preservation ⇒ False (⊥) — `levy-refutes-neutral-independent-preservation`

Proved result; source **Misc.**; produced by Zachary Goodsell (stable-law obstruction proposal); GPT-6 (Codex) (specified witness and proof completion); recorded by GPT-6 (Codex); checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Independent Sum Preservation (`independent-sum-preservation`)

Conclusion: False (⊥) (`false`)

Proof.

Let L be positive with density $\exp (-1/(4t))/(2 \sqrt (\pi ) t^{3/2}), t>0$. Its Laplace transform is $\exp (-\sqrt (s))$, so independent copies $L1+L2$ have the law of 4L; its survival is $\operatorname{erf}(1/(2 \sqrt (t)))$. Let epsilon be an independent fair sign, $W=\epsilon L1$, and $D=L2-L1$. Both W and D have symmetric laws, hence are indifferent to zero. Independent Sum Preservation applied in both directions to $W\sim 0$ gives $W+L2\sim L2$. The law of $W+L2$ is the equal mixture of 4L and D. Mixture Independence, $D\sim 0$, and Stochastic Equivalence (entailed by Dominance) therefore give $L\sim M_{1/2}(4L,0)$. For $t>0$ the latter mixture has survival $\operatorname{erf}(1/\sqrt (t))/2$, strictly less than $\operatorname{erf}(1/(2 \sqrt (t)))$ by strict concavity of erf on the positive half-line. At negative thresholds both survivals equal one, and at zero they are one and one half. Thus L strictly stochastically dominates that mixture, contradicting their indifference. The write-up supplies the transform calculation, all law replacements, and the exact scope of the reduced premises.

Notes. Original work: proof adaptation and completion of Goodsell's proposed stable-law obstruction. Goodsell supplied the symmetry-plus-independent- background-risk mechanism; GPT-6 supplied this exact single-index law, the intermediate symmetric difference, the erf dominance proof, and the weaker sufficient premise package. No priority or literature-novelty claim is made. Only weak preservation in both directions is used; the existing Independent Sum Preservation principle is stronger. Totality, Simple EU, independent-sum cancellation, and reflection anti-invariance are not needed. This proves the earlier symmetric-DTU incompatibility candidate as a consequence without rewriting its original conjectural proof or attribution. The executable check is a numerical diagnostic, not the proof or a Lean certificate.

Sources:

- **Goodsell stable-law proposal 9 Sep** — Zachary Goodsell, project conversation, 9 September 2026: proposal that neutral symmetric stable-law mixtures yield an obstruction after adding a common independent stable variable.
- **GPT-6 proof completion 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/levy-refutes-neutral-independent-preservation.md: explicit positive index-1/2 Levy witness, mixture reduction, strict tail comparison, and premise reduction.
- **NIST DLMF 7.7.8** — NIST Digital Library of Mathematical Functions, equation 7.7.8, https://dlmf.nist.gov/7.7.E8: Gaussian integral used to check the Laplace transform; mathematical identity only, not a source for this decision-theoretic argument.

- **Background: [Flummoxing expectations](https://doi.org/10.1111/nous.12530).** Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. — §6.1. Source of Independent Sum Consistency; see the principle reference for the changed independence condition. The proof or conjecture recorded here retains its separate attribution.

Record: `topics/unbounded-utility/results/levy-refutes-neutral-independent-preservation.yaml`.

<details><summary>Hand-written write-up</summary>

#### A Lévy obstruction to neutral symmetric gambles and independent sums

**Proved implication:** Rich Outcomes + Stochastic Dominance + Mixture
Independence + Symmetric Gambles Are Neutral + Independent Sum Preservation
implies **False**.

**Original work: proof adaptation and completion.** Zachary Goodsell proposed
the stable-law obstruction: neutral symmetric gambles can cease to be
indifferent after adding independent background risk. GPT-6 (Codex),
9 September 2026, supplied the exact positive index-$1/2$ law below, the
intermediate symmetric difference, the complete dominance comparison, and
the reduced sufficient premises. This completes that proposed mechanism;
it does not claim a new construction independent of Goodsell's suggestion,
or priority over the literature. The direct source for this completion is
**Misc.**, with the proposal and analytic reference credited separately.
No independent checker or Lean verification is claimed.

##### 1. The positive stable variable

Use the finite utility chart supplied by Rich Outcomes and let $L$ have density

$$
f(t)=\frac{1}{2\sqrt{\pi}}t^{-3/2}e^{-1/(4t)},\qquad t>0.
$$

Its survival function is

$$
S_L(t)=
\begin{cases}
1,&t\leq0,\\
\operatorname{erf}\!\left(\dfrac{1}{2\sqrt t}\right),&t>0,
\end{cases}
\qquad
\operatorname{erf}(x)=\frac{2}{\sqrt\pi}\int_0^x e^{-u^2}\,du.
$$

Substitution $u=1/(2\sqrt t)$ gives normalization and this survival formula.
The same substitution gives, for $s>0$,

$$
E[e^{-sL}]
=\frac{2}{\sqrt\pi}\int_0^\infty
 e^{-u^2-s/(4u^2)}\,du
=e^{-\sqrt s}.
$$

For completeness, write $I(a)=\int_0^\infty e^{-u^2-a^2/u^2}\,du$.
For $a>0$, differentiation under the integral and substitution $v=a/u$
give $I'(a)=-2I(a)$. Dominated convergence gives $I(0)=\sqrt\pi/2$,
so $I(a)=(\sqrt\pi/2)e^{-2a}$. The integral identity is also recorded in
[NIST DLMF, equation 7.7.8](https://dlmf.nist.gov/7.7.E8).

Consequently independent copies $L_1,L_2$ satisfy

$$L_1+L_2\overset d=4L,$$

because both sides have Laplace transform $e^{-2\sqrt s}$, and Laplace
transforms determine probability laws on $[0,\infty)$. Thus the stability
index is explicitly $1/2$; no ambiguous scale convention is needed.

##### 2. What the preference principles force

Realize $L_1,L_2$ and a fair sign $\varepsilon\in\{-1,1\}$ independently
on the standing atomless probability space. Set

$$W=\varepsilon L_1,\qquad D=L_2-L_1.$$

The laws of $W$ and $D$ are symmetric about zero: for $D$, exchange the two
independent identically distributed inputs. Symmetric Gambles Are Neutral
therefore gives $W\sim0$ and $D\sim0$.

The variable $L_2$ is independent of $(W,0)$. Applying the weak part of
Independent Sum Preservation to each direction of $W\sim0$ yields

$$W+L_2\sim L_2.$$

Conditioning on the independent fair sign shows

$$
W+L_2\overset d=M_{1/2}(L_1+L_2,D)
\overset d=M_{1/2}(4L,D).
$$

These are identities of laws, not identities of the fixed random-variable
mixture lift. Stochastic Dominance entails Stochastic Equivalence by applying
its weak clause in both directions when all tails agree, so these law
replacements are licensed. Mixture Independence applied to $D\sim0$ gives

$$M_{1/2}(4L,D)\sim M_{1/2}(4L,0).$$

To use the displayed form of Mixture Independence, first place $D$ and $0$
in the first mixture branch, with common second branch $4L$, and then exchange
the equal-weight branches by Stochastic Equivalence. Finally $L_2\sim L$
by that same principle. Transitivity now forces

$$\boxed{L\sim M_{1/2}(4L,0).}$$

##### 3. Strict stochastic dominance contradicts that indifference

Put $B=M_{1/2}(4L,0)$. For $t>0$, setting $x=1/(2\sqrt t)>0$ gives

$$S_L(t)=\operatorname{erf}(x),\qquad
S_B(t)=\tfrac12\operatorname{erf}(2x).$$

The function $\operatorname{erf}$ vanishes at zero and is strictly concave
on the positive half-line, because

$$\operatorname{erf}''(x)=-\frac{4x}{\sqrt\pi}e^{-x^2}<0\quad(x>0).$$

Hence $\operatorname{erf}(x)>\tfrac12\operatorname{erf}(2x)$ for every
$x>0$. At $t<0$ both survival functions are one; at $t=0$, they are
respectively one and one half. Thus $L$ weakly dominates $B$ at every
threshold and strictly dominates at some threshold. Stochastic Dominance
requires $L\succ B$, contradicting $L\sim B$.

All variables used take finite utility levels. The ordered chart embeds all
real levels by Rich Outcomes. If there are additional outcomes outside the
chart, their thresholds cut the realized real levels into upper rays; the
same real-threshold inequalities and their one-sided limits prove dominance
at those thresholds as well. No claim about utility arithmetic outside the
chart is used.

##### Consequences and limits

The result rules out Independent Sum Preservation under DU plus Symmetric
Gambles Are Neutral, and therefore rules out Independent Sum Invariance
under that package. It settles the
[earlier symmetric-DTU incompatibility candidate](symmetric-dtu-refutes-independent-sum-candidate.html)
through a new proof record, preserving the candidate's original attribution.

The proof needs no Totality, Simple Expected Utility, reflection principle,
or independent-sum cancellation. Only weak forward sum preservation is used
to preserve an indifference; the current preservation node also requires
strict preservation, so it supplies more than is needed.

The check `checks/levy_obstruction.py` verifies the chosen transform and tail
formulas numerically at finitely many points. The analytic argument above,
not those samples, establishes the universal dominance statement.

</details>

#### Rich Outcomes ∧ Negative Affine Anti-Invariance ⇒ Positive Affine Invariance — `negative-affine-implies-positive-affine`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Positive Affine Invariance (`positive-affine-invariance`)

Proof.

Compose x↦−x with x↦−ax$+b$. Both reverse the ordering, so their composition x↦ax$+b$ preserves it. Rich Outcomes supplies all intermediate outcome levels.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3, p. 24

Record: `topics/unbounded-utility/results/negative-affine-implies-positive-affine.yaml`.

#### Negative Affine Anti-Invariance ⇒ Reflection Anti-Invariance — `negative-affine-implies-reflection`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean verified; 2026-09-08.

Premises:

- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Reflection Anti-Invariance (`reflection-anti-invariance`)

Proof.

Set $a=1,b=0$. The order is reversed.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24 (corrected sign)

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3, p. 24 (corrected sign)

Record: `topics/unbounded-utility/results/negative-affine-implies-reflection.yaml`.

#### Rich Outcomes ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Uniqueness of Negative Self-Similarity ⇒ Alternating St Petersburg = −1/2 — `negative-self-similarity-evaluates-alternating`

Proved result; source **Misc.**; produced by Zachary Goodsell (source argument); GPT-6 (Codex) (adaptation and premise audit); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)

Conclusion: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)

Proof.

Let A have $P(u(A)=(- 2)^n)=2^{- n}, n\ge 1$. Splitting off the first atom gives $L(A)=L(M_{1/2}(- 2A,- 2))$; hence $A\sim M_{1/2}(- 2A,- 2)$ by Stochastic Equivalence. The sure gamble $c=- 1/2$ is another fixed point in value: $M_{1/2}(- 2c,- 2)=M_{1/2}(1,- 2)$ has simple expectation −1/2, so Simple EU gives $c\sim M_{1/2}(- 2c,- 2)$. Negative Self-Similarity at $p=1/2,a=2,b=0,Z=- 2$ now gives $A\sim c$. Rich Outcomes supplies all outcomes used. No Totality, Mixture Independence or affine invariance is required once the uniqueness principle itself is assumed.

Notes. Original work: proof adaptation. Recognize the alternating St Petersburg law and the sure value −1/2 as two solutions of the same negative self-similarity equation, and apply the already extracted uniqueness principle. This describes the work needed for this database entry, not a claim of novelty in the literature.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), proof adaptation and premise audit in the Logical Maps project, 9 September 2026; see the accompanying handwritten write-up.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorems 9–10, pp. 30–31. The cited argument is adapted with the explicitly listed sufficient premises; the reduced-premise claim is the present project contribution.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorems 9–10, pp. 30–31. The cited argument is adapted with the explicitly listed sufficient premises; the reduced-premise claim is the present project contribution

Record: `topics/unbounded-utility/results/negative-self-similarity-evaluates-alternating.yaml`.

<details><summary>Hand-written write-up</summary>

#### Negative Self-Similarity evaluates Alternating St Petersburg

**Claim.** Rich Outcomes + Stochastic Equivalence + Simple $\operatorname{EU} +$ Uniqueness of Negative Self-Similarity imply Alternating St Petersburg $=-1/2$.

Let $A$ be any gamble with

$$\mathbb P\bigl(u(A)=(-2)^n\bigr)=2^{-n},\qquad n\geq1.$$

Use numerical utility notation. Multiplication by $-2$ moves the $n$th atom to the $(n+1)$st value. Consequently

$$\mathcal L(A)=\mathcal L\bigl(M_{1/2}(-2A,-2)\bigr).$$

Indeed, the sure branch gives the first atom $-2$ probability $1/2$, and the transformed branch gives each value $(-2)^m$, $m\geq2$, probability $\frac12\,2^{-(m-1)}=2^{-m}$. Stochastic Equivalence therefore yields

$$A\sim M_{1/2}(-2A,-2). \tag{1}$$

Let $c$ be sure utility $-1/2$. Its corresponding mixture is

$$M_{1/2}(-2c,-2)=M_{1/2}(1,-2),$$

which is simple and has expected utility $-1/2$. Simple EU gives

$$c\sim M_{1/2}(-2c,-2). \tag{2}$$

Equations (1) and (2) are two instances of the same fixed-point equation with $p=1/2$, $a=2$, $b=0$ and $Z$ sure $-2$. Uniqueness of Negative Self-Similarity therefore implies $A\sim c$, which is the desired evaluation.

Rich Outcomes ensures the availability of the sure values and transformed variables. The proof uses no finite expectation for $A$, and it does not need Totality, Mixture Independence, Stochastic Dominance or affine invariance as additional assumptions.

**Original work: proof adaptation.** The new connection factors the source's alternating-prospect evaluation through its separately recorded uniqueness principle. The only calculation is the displayed one-step distributional recursion and the simple fixed point. No literature novelty is asserted.

**Attribution.** The evaluation and uniqueness principles are from Zachary Goodsell, *Symmetries of value*, Theorems 9–10, pp. 30–31. Their reduced-premise connection was recorded by GPT-6 (Codex), 9 September 2026. No independent checker or Lean proof is claimed.

</details>

#### Rich Outcomes ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Mixture Independence ∧ Symmetric Gambles Are Neutral ∧ Shift Invariance ⇒ Transfer of a Shift Across a Mixture — `neutrality-shift-imply-shift-transfer`

Proved result; source **Misc.**; produced by Zachary Goodsell (source argument); GPT-6 (Codex) (premise reduction and explicit cancellation proof); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Mixture Independence (`independence`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Shift Invariance (`shift-invariance`)

Conclusion: Transfer of a Shift Across a Mixture (`shift-transfer`)

Proof.

Symmetric Neutrality and Shift Invariance imply $M_{1/2}(X+c,-X)\sim c/2$: center its two branches by subtracting c/2 to obtain a symmetric law. Put $L=M_p(X+b/p,Y)$ and $R=M_p(X,Y+b/(1-p))$. Regroup the law of $M_{1/2}(L,-R)$ into weights p and 1-p of the two centered pairs. They have sure values b/(2p) and -b/(2(1-p)); Simple EU and Independence therefore make their mixture neutral. The law of $M_{1/2}(R,-R)$ is also symmetric and neutral. Cancelling the common -R branch by Mixture Independence yields $L\sim R$. Stochastic Equivalence licenses every regrouping and fixed-lift replacement.

Notes. Original work: small proof adaptation and premise reduction. The paired-law construction is Goodsell's Theorem 3. The present proof isolates symmetric neutrality and shifts as its symmetry inputs and spells out cancellation; neither Scale Invariance nor Totality is needed. This assesses the work performed for the map, not priority in the literature. No independent checker or Lean certification is asserted.

Sources:

- **GPT-6 premise audit 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/neutrality-shift-imply-shift-transfer.md: reduced-premise proof for the Logical Maps DU investigation.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37, DOI 10.1111/nous.12549, Theorem 3, pp. 25–26: paired-reflection and centering argument.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 3, pp. 25–26: paired-reflection and centering argument

Record: `topics/unbounded-utility/results/neutrality-shift-imply-shift-transfer.yaml`.

<details><summary>Hand-written write-up</summary>

#### Symmetric neutrality and shifts suffice for transfer across mixtures

**Source and work accounting.** The paired-reflection argument is Zachary
Goodsell's *Symmetries of value*, Theorem 3, pp. 25–26. The contribution here is
a small premise reduction and an explicit cancellation proof, recorded by GPT-6
(Codex), 9 September 2026. No independent checker or Lean certification is asserted.

Assume Rich Outcomes, Stochastic Equivalence, Simple EU, Mixture Independence,
Symmetric Neutrality and Shift Invariance. Totality and Scale Invariance are
not used. Work in the normalized real utility chart.

For a gamble $X$ and real $c$, the law of

\[
M_{1/2}(X+c/2,-X-c/2)
\]

is symmetric. Neutrality makes this gamble indifferent to zero. Shift both
outcomes by $c/2$. Shift Invariance, followed by Stochastic Equivalence to
identify the resulting fixed-lift realization, gives

\[
M_{1/2}(X+c,-X)\sim c/2. \tag{1}
\]

Fix $0<p<1$ and $b\in\mathbb R$, and put

\[
L=M_p(X+b/p,Y),\qquad R=M_p(X,Y+b/(1-p)).
\]

The law of $M_{1/2}(L,-R)$ can be regrouped as

\[
M_p\left(
 M_{1/2}(X+b/p,-X),
 M_{1/2}(Y,-Y-b/(1-p))
\right).
\]

By (1), the two inner mixtures are indifferent to $b/(2p)$ and

\[
-\frac{b}{2(1-p)},
\]

respectively. Mixture Independence propagates these indifferences; Simple EU
makes their outer mixture indifferent to zero, since its expectation is

\[
p\frac{b}{2p}+(1-p)\frac{-b}{2(1-p)}=0.
\]

Consequently $M_{1/2}(L,-R)\sim0$. Symmetric Neutrality also gives

\[
M_{1/2}(R,-R)\sim0.
\]

Transitivity of indifference and Mixture Independence cancel the common

\[
-R
\]

branch and yield $L\sim R$, which is Shift Transfer. Every regrouping above
is an identity of laws and uses Stochastic Equivalence before being used as
a preference identity. Rich Outcomes supplies the finite constants and all
the displayed translations.

Under DU this gives a useful sufficient route to Simple Relative Expectation:
Symmetric Neutrality plus Shift Invariance suffice. The source theorem's full
negative-affine package already supplies them, but its scale component is not
needed for this conclusion. This is an account of work performed for the map,
not a claim of priority in the literature.

</details>

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Mixture Independence ∧ Symmetric Gambles Are Neutral ⇒ Reflection Anti-Invariance — `neutrality-totality-independence-imply-reflection`

Proved result; source **Unbounded Utility and Background Risk (unpublished)**; produced by Zachary Goodsell (unpublished manuscript); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Mixture Independence (`independence`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)

Conclusion: Reflection Anti-Invariance (`reflection-anti-invariance`)

Proof.

Suppose $X \succeq Y$ but not $- Y \succeq - X$. Totality gives $- X \succ - Y$. Mixture Independence (including its strict consequence), transitivity, and Stochastic Equivalence to interchange mixture branches give $M_{\frac{1}{2} }(X,- X) \succ M_{\frac{1}{2} }(Y,- Y)$. Each mixture has a symmetric law, so Symmetric Neutrality makes both indifferent to 0, a contradiction. Therefore $- Y \succeq - X$. Applying the same implication to −Y,−X proves the converse. Rich Outcomes supplies the reflected variables.

Notes. The draft calls Symmetric Neutrality “Reflection Symmetry”. This argument does not use the failed extension lemma.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; p. 12 n. 1 (continuing on p. 13)

- **Proof: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — p. 12 n. 1 (continuing on p. 13)

Record: `topics/unbounded-utility/results/neutrality-totality-independence-imply-reflection.yaml`.

#### Rich Outcomes ∧ Archimedean Outcomes ∧ Totality ∧ Stochastic Dominance ∧ Sure-Thing ⇒ Simple Expected Utility — `original-dtu-implies-simple-eu`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Totality (`totality`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)

Conclusion: Simple Expected Utility (`simple-eu`)

Proof.

Goodsell §3.2 gives the finite-lottery representation consequence of the original DTU axioms. Stochastic Dominance includes law invariance; Sure-Thing becomes Independence on laws. Restrict to finite gambles and use the outcome mixture calibrations to obtain the normalized vNM utility representation. Prospect Richness, Preordering and comparable outcomes are standing here.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, pp. 679–681 (representation result)

- **Proof: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §3.2, pp. 679–681 (representation result)

Record: `topics/unbounded-utility/results/original-dtu-implies-simple-eu.yaml`.

#### Positive Affine Invariance ⇒ Scale Invariance — `positive-affine-implies-scale`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean verified; 2026-09-08.

Premises:

- Positive Affine Invariance (`positive-affine-invariance`)

Conclusion: Scale Invariance (`scale-invariance`)

Proof.

Set $b=0$.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/positive-affine-implies-scale.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3, p. 24

Record: `topics/unbounded-utility/results/positive-affine-implies-scale.yaml`.

#### Positive Affine Invariance ⇒ Shift Invariance — `positive-affine-implies-shift`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean verified; 2026-09-08.

Premises:

- Positive Affine Invariance (`positive-affine-invariance`)

Conclusion: Shift Invariance (`shift-invariance`)

Proof.

Set $a=1$.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/positive-affine-implies-shift.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3, p. 24

Record: `topics/unbounded-utility/results/positive-affine-implies-shift.yaml`.

#### Rich Outcomes ∧ Positive Affine Invariance ∧ Reflection Anti-Invariance ⇒ Negative Affine Anti-Invariance — `positive-reflection-imply-negative`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)

Conclusion: Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Proof.

Apply reflection to reverse the comparison, then the positive transformation x↦ax$+b$ to preserve that reversed comparison.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3, p. 24

Record: `topics/unbounded-utility/results/positive-reflection-imply-negative.yaml`.

#### Independent Sum Preservation ∧ Independent Sum Cancellation ⇒ Independent Sum Invariance — `preservation-cancellation-imply-independent-sum`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; Lean verified; 2026-09-09.

Premises:

- Independent Sum Preservation (`independent-sum-preservation`)
- Independent Sum Cancellation (`independent-sum-cancellation`)

Conclusion: Independent Sum Invariance (`independent-sum-consistency`)

Proof.

Weak preservation gives the forward implication and cancellation the reverse. Together these are precisely Independent Sum Invariance.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; Lemma 1, p. 8

- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — Lemma 1, p. 8
- **Background: [Flummoxing expectations](https://doi.org/10.1111/nous.12530).** Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. — §6.1. Source of Independent Sum Consistency; see the principle reference for the changed independence condition. The proof or conjecture recorded here retains its separate attribution.

Record: `topics/unbounded-utility/results/preservation-cancellation-imply-independent-sum.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Mixture Independence ∧ Reflection Anti-Invariance ⇒ Symmetric Gambles Are Neutral — `reflection-implies-symmetric-neutrality`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Mixture Independence (`independence`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)

Conclusion: Symmetric Gambles Are Neutral (`symmetric-neutrality`)

Proof.

Let $H=M_{1/2}(X,- X)$. Its reflected law equals its own law, so $H\sim - H$. If $H\succ 0$, reflection gives $- H\prec 0$, contradiction; likewise if $H\prec 0$. Totality gives $H\sim 0$. If X itself has symmetric law, Stochastic Equivalence gives $- X\sim X$ and $H\sim X$, since the mixture then has X’s law. Thus $X\sim 0$.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, pp. 25, 27

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §4, pp. 25, 27

Record: `topics/unbounded-utility/results/reflection-implies-symmetric-neutrality.yaml`.

#### Rich Outcomes ∧ Archimedean Outcomes ∧ Stochastic Dominance ∧ Relative Expectation ⇒ CDF-Area Extension — `relative-dominance-imply-cdf-area`

Proved result; source **Misc.**; produced by GPT-6 (Codex), connecting argument using the recorded quantile-area method; recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Stochastic Dominance (`stochastic-dominance`)
- Relative Expectation (`relative-expectation`)

Conclusion: CDF-Area Extension (`cdf-area-extension`)

Proof.

Archimedean Outcomes supplies a total chart, measurable by the background convention; Rich Outcomes supplies all intermediate utility levels. Dominance entails Stochastic Equivalence. Quantile couple A,B with the marginal laws of X,Y. Nested threshold events and Tonelli give $E[(A- B)_{+}]=A_{+}$ and $E[(A- B)_{-}]=A_{-}$, the two survival-difference areas. If both are finite, Relative Expectation compares A,B exactly by $A_{+}- A_{-}$, and equivalence transfers the result to X,Y. If $A_{+}=\infty$ and $A_{-}<\infty$, put $D=A- B$ and $Z_N=B+\min (D_{+},N)- D_{-}$. Then $Z_N\le A, E|Z_N- B|<\infty$, and $E[Z_N- B]$ tends to $+\infty$. For some N, Relative Expectation gives $Z_N\succ B$; weak Dominance gives $A\succeq Z_N$, hence $A\succ B$. Swap the variables for the other one-infinite case. These exhaust the cases required by CDF-Area Extension.

Notes. Original work: connecting argument and proof adaptation. Reuses the recorded quantile-area/Tonelli identity and supplies the truncated-positive-difference step for the one-infinite-area case. The converse is not attributed as a theorem of the unpublished manuscript. Under DU this establishes CDF-Area Extension iff Relative Expectation. No Totality, Mixture Independence, $L^{1}$ Continuity or affine invariance is needed as an additional premise. This describes work for the map, not a claim of literature novelty.

Sources:

- **GPT-6 connecting proof 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/relative-dominance-imply-cdf-area.md: quantile-coupling converse to the existing area-to-relative implication, with one-sided truncation for a single infinite area.
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026 (unpublished), §3, pp. 7–8: source of the CDF-area comparison. The existing project writeups/cdf-area-preorder.md and results/cdf-area-implies-relative.yaml contain related quantile-area and integrable-difference calculations.

- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §3, pp. 7–8: source of the CDF-area comparison. The existing project writeups/cdf-area-preorder.md and results/cdf-area-implies-relative.yaml contain related quantile-area and integrable-difference calculations

Record: `topics/unbounded-utility/results/relative-dominance-imply-cdf-area.yaml`.

<details><summary>Hand-written write-up</summary>

#### Relative Expectation and Dominance recover CDF-area comparisons

**Proved implication:** Rich Outcomes + Archimedean Outcomes + Stochastic
Dominance + Relative Expectation imply CDF-Area Extension.

**Original work: connecting argument and proof adaptation.** GPT-6 (Codex),
9 September 2026, combines the existing quantile-area identity with a
one-sided truncation of the utility difference. Goodsell's unpublished
*Unbounded Utility and Background Risk*, §3, supplies the area rule;
this converse is a project connecting proof, not attributed as a theorem
from that manuscript. No independent checker, Lean verification or
literature-novelty claim is made.

##### Framework and the quantile identity

Archimedean Outcomes makes the utility chart total; its measurability is a
standing chart convention. Rich Outcomes supplies every finite real level
used below. Write numerical utility variables as \(X,Y\), and put

\[
d(t)=S_X(t)-S_Y(t),\qquad A_\pm=\int_{\mathbb R}d_\pm(t)\,dt.
\]

Dominance implies Stochastic Equivalence, so preferences can be transferred
to new realizations once their marginal laws have been checked. Let \(U\)
be uniform on the standing sample space and set
\(A=Q_X(U), B=Q_Y(U)\) using increasing quantiles. These have the original
marginal laws. Assign finite valid outcomes at the null quantile endpoints.

For each threshold, the upper-level events of these two nondecreasing
functions of \(U\) are nested. Thus

\[
P(A>t,B\le t)=(S_X(t)-S_Y(t))_+.
\]

Integrating the elementary identity
\((a-b)_+=\int\mathbf1_{\{b\le t<a\}}\,dt\) and applying Tonelli gives

\[
E[(A-B)_+]=A_+,\qquad E[(A-B)_-]=A_-.
\tag{1}
\]

These equalities allow infinite values and do not subtract two infinities.

##### Both areas finite

If \(A_+,A_-<\infty\), equation (1) shows that the actual difference
\(A-B\) is integrable, with mean \(A_+-A_-\). Relative Expectation gives
\(A\succeq B\iff A_+\ge A_-\). Stochastic Equivalence transfers both
directions to \(X,Y\), including indifference when the areas are equal.

##### Exactly one infinite area

Suppose \(A_+=\infty\) and \(A_-<\infty\). Put \(D=A-B\), and for a
positive integer \(N\) define

\[
Z_N=B+\min(D_+,N)-D_-.
\]

This is a measurable finite-valued-at-each-state utility variable, so the
full real chart realizes it as a gamble. It need not be a *simple* gamble.
Pointwise, \(Z_N\le A\), and

\[
E|Z_N-B|\le N+A_-<\infty,\qquad
E[Z_N-B]=E[\min(D_+,N)]-A_-\longrightarrow+\infty.
\]

Choose \(N\) with positive mean. Relative Expectation gives
\(Z_N\succ B\), while pointwise domination gives stochastic domination,
hence \(A\succeq Z_N\). In a preorder, a weak comparison followed by a
strict comparison is strict, so \(A\succ B\). Transfer to \(X,Y\) by
Stochastic Equivalence. The case \(A_+<\infty,A_-=\infty\) follows by
exchanging the variables and gives \(Y\succ X\).

These are all cases constrained by CDF-Area Extension. When both areas are
infinite, neither that principle nor this proof demands a comparison.

##### Consequence under DU

DU supplies the outcome and dominance premises. Combined with the already
recorded implication from CDF-Area Extension to Relative Expectation,
this establishes their equivalence under DU. No continuity, mixture
independence, totality or affine symmetry is used in this proof.

</details>

#### Archimedean Outcomes ∧ Relative Expectation ⇒ Expected Utility — `relative-implies-eu`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Archimedean Outcomes (`archimedean-outcomes`)
- Relative Expectation (`relative-expectation`)

Conclusion: Expected Utility (`expected-utility`)

Proof.

Archimedean Outcomes makes the real chart total. If $u(X),u(Y)$ are integrable, so is their difference, and $E[u(X)- u(Y)]=E[u(X)]- E[u(Y)]$. Apply Relative Expectation.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, pp. 26–27
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/relative-implies-eu.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §4, pp. 26–27

Record: `topics/unbounded-utility/results/relative-implies-eu.yaml`.

#### Relative Expectation ⇒ Simple Relative Expectation — `relative-implies-simple-relative`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean verified; 2026-09-08.

Premises:

- Relative Expectation (`relative-expectation`)

Conclusion: Simple Relative Expectation (`simple-relative-expectation`)

Proof.

A finite-valued difference is integrable. Restrict Relative Expectation to such pairs.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, p. 26
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/relative-implies-simple-relative.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §4, p. 26

Record: `topics/unbounded-utility/results/relative-implies-simple-relative.yaml`.

#### Rich Outcomes ∧ Stochastic Equivalence ∧ Relative Expectation ∧ Symmetric Gambles Are Neutral ∧ Shift Invariance ⇒ Folded Expectation — `relative-neutrality-shift-imply-folded`

Proved result; source **Misc.**; produced by Zachary Goodsell (source argument); GPT-6 (Codex) (adaptation and premise audit); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Relative Expectation (`relative-expectation`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Shift Invariance (`shift-invariance`)

Conclusion: Folded Expectation (`folded-expectation`)

Proof.

For a foldable real-utility X, couple a copy A of X and a copy B of −X comonotonically as $A=Q_X(U), B=- Q_X(1- U)$. The survival-function difference is $h_X(t)$ for $t>0$ and $h_X(- t)$ for $t<0$, except at countably many atom thresholds. Thus $E|A- B|=2\int _0^{\infty }|h_X|$ and $E(A- B)=2F(X)$. The midpoint $Z=(A+B)/2$ has a symmetric law, while A−Z is integrable with mean $F(X)$. Relative Expectation gives $A\sim Z+F(X)$; Symmetric Neutrality and Shift Invariance give $Z+F(X)\sim F(X)$. Stochastic Equivalence gives $X\sim A$. Therefore each foldable X is indifferent to its folded expectation, and the standing sure-outcome order compares any two such variables exactly by these real numbers.

Notes. Original work: proof adaptation. Expand the quantile symmetrization behind Goodsell’s folded-expectation argument and retain only Relative Expectation, neutrality, shift invariance and the explicit domain/law assumptions; full affine symmetry and Totality are unnecessary. This describes the work needed for this database entry, not a claim of novelty in the literature.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), proof adaptation and premise audit in the Logical Maps project, 9 September 2026; see the accompanying handwritten write-up.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 6, pp. 27–29. The cited argument is adapted with the explicitly listed sufficient premises; the reduced-premise claim is the present project contribution.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 6, pp. 27–29. The cited argument is adapted with the explicitly listed sufficient premises; the reduced-premise claim is the present project contribution

Record: `topics/unbounded-utility/results/relative-neutrality-shift-imply-folded.yaml`.

<details><summary>Hand-written write-up</summary>

#### Relative Expectation, Neutrality and Shift Invariance imply Folded Expectation

**Claim.** Rich Outcomes + Stochastic Equivalence + Relative Expectation + Symmetric Neutrality + Shift Invariance imply Folded Expectation.

Write the real utility variable of a gamble as $X$. Put

$$h_X(t)=\mathbb P(X>t)-\mathbb P(X<-t),\qquad
F(X)=\int_0^\infty h_X(t)\,dt,$$

and suppose $\int_0^\infty|h_X(t)|\,dt<\infty$. Let $S_X(t)=\mathbb P(X>t)$, and set $d(t)=S_X(t)-S_{-X}(t)$.

For positive $t$, $d(t)=h_X(t)$. For negative $t$, $d(t)=h_X(-t)$ except possibly when $t$ or $-t$ is an atom threshold. There are at most countably many such thresholds, so

$$\int_{\mathbb R}|d(t)|\,dt=2\int_0^\infty|h_X(t)|\,dt<\infty,
\qquad \int_{\mathbb R}d(t)\,dt=2F(X). \tag{1}$$

Let $U$ be uniform and $Q_X$ an increasing quantile for $X$. Define

$$A=Q_X(U),\qquad B=-Q_X(1-U).$$

Arbitrary finite values may be assigned at the null quantile endpoints. These have the laws of $X$ and $-X$, and both are nondecreasing functions of $U$. Their upper-threshold events are therefore nested for every threshold, up to null sets. Tonelli's theorem and the elementary interval-length identity give

$$\begin{aligned}
\mathbb E|A-B|
&=\int_{\mathbb R}\mathbb E\left|\mathbf1_{\{A>t\}}-\mathbf1_{\{B>t\}}\right|\,dt\\
&=\int_{\mathbb R}|S_X(t)-S_{-X}(t)|\,dt<\infty.
\end{aligned}$$

Since this integral is finite, Fubini also gives $\mathbb E(A-B)=\int d=2F(X)$.

Now set

$$Z=\frac{A+B}{2}=\frac{Q_X(U)-Q_X(1-U)}2.$$

Replacing $U$ by $1-U$ negates $Z$ without changing its law. Thus Symmetric Neutrality gives $Z\sim0$. Moreover, $A-Z=(A-B)/2$ is integrable with mean $F(X)$. Relative Expectation applied in both directions gives

$$A\sim Z+F(X),$$

because their actual difference has mean zero. Shift Invariance transports $Z\sim0$ to $Z+F(X)\sim F(X)$, and Stochastic Equivalence gives $X\sim A$. Consequently

$$X\sim F(X).$$

The same argument applies to any other foldable $Y$. The standing linear sure-outcome order then yields $X\succeq Y$ exactly when $F(X)\geq F(Y)$.

Rich Outcomes supplies the midpoint, shifted variables and sure folded values. All are finite-chart variables, even when their individual ordinary expectations are undefined. No conditional improper integral is used: the absolute integrability in (1) is what justifies both Tonelli/Fubini steps. Totality, Mixture Independence and full affine symmetry are absent from the proof.

**Original work: proof adaptation.** The source's folded-expectation argument uses a comparison with a symmetric prospect. The present contribution expands that comparison as an explicit quantile coupling and audits which assumptions it needs. This is a reduced-premise connection for the database, not a literature-novelty claim.

**Attribution.** Source construction: Zachary Goodsell, *Symmetries of value*, Theorem 6, pp. 27–29. Explicit coupling proof and premise audit: GPT-6 (Codex), 9 September 2026. No independent checker or Lean proof is claimed.

</details>

#### Rich Outcomes ∧ Stochastic Equivalence ∧ Mixture Independence ∧ Relative Expectation ∧ Uniqueness of Negative Self-Similarity ⇒ Pasadena = ln 2 — `relative-self-similarity-evaluates-pasadena`

Proved result; source **Misc.**; produced by Zachary Goodsell (Highland Park and Q constructions); GPT-6 (Codex) (negative-self-similarity factorization and explicit couplings); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Mixture Independence (`independence`)
- Relative Expectation (`relative-expectation`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)

Conclusion: Pasadena = ln 2 (`pasadena-value`)

Proof.

For Pasadena P, replace the negative payoff $-4^k/(2k)$ by $-4^k/(2k-1)$ to obtain Highland Park H. The actual pointwise difference P-H is nonnegative and has expectation $\ln 2$. Write H in law as $M_{2/3}(Q,-2Q)$, where Q takes $2^{2k-1}/(2k-1)$ with probability $3/4^k$. Couple Q with S of $\operatorname{law} M_{1/4}(4Q,0)$ by sending its first atom to zero and its kth atom, $k\ge 2$, to four times its (k-1)st value. The difference has absolute expectation 3 and expectation zero, so Relative Expectation gives $Q\sim S$. Substitute this comparison into the Q branch of H and regroup: $H\sim M_{1/2}(-2H,0)$. Zero solves the same fixed-value equation. Negative Self-Similarity yields $H\sim 0$. Relative Expectation gives $P\sim H+\ln 2; a$ half-mixture shift transfer, itself an integrable zero-mean comparison, and Independence give $H+\ln 2\sim \ln 2$. All distributional replacements are licensed by Stochastic Equivalence.

Notes. Original work: moderate proof adaptation. The two distributions and integrable-difference identities come from Goodsell's Theorem 11. The new step factors the proof through the already recorded uniqueness principle: H is a fixed value of $X -> M_{1/2}(-2X,0)$, so one can replace the source's Totality/positive-affine square-root argument by Negative Self-Similarity. No separate Totality, Scale Invariance, Reflection Anti-Invariance, or L1 Continuity is required. Exact couplings and remainder bounds are supplied in the write-up and diagnostic. This is work accounting, not a claim of literature novelty.

Sources:

- **GPT-6 factorization 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/relative-self-similarity-evaluates-pasadena.md: factorization through negative self-similarity and explicit integrable couplings.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37, DOI 10.1111/nous.12549, Theorem 11, pp. 32–33: Pasadena, Highland Park, and Q constructions and relative-expectation identities.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 11, pp. 32–33: Pasadena, Highland Park, and Q constructions and relative-expectation identities

Record: `topics/unbounded-utility/results/relative-self-similarity-evaluates-pasadena.yaml`.

<details><summary>Hand-written write-up</summary>

#### Pasadena from Relative Expectation and Negative Self-Similarity

**Source and work accounting.** Pasadena's modification to Highland Park and
the auxiliary prospect \(Q\) are Zachary Goodsell's constructions in
*Symmetries of value*, Theorem 11, pp. 32–33. The new factorization below uses
the recorded uniqueness principle in place of the source's Totality and
positive-affine argument. GPT-6 (Codex), 9 September 2026, supplied this
moderate proof adaptation, the explicit couplings, and the remainder bounds.
This describes work done for the map, not priority in the literature. No
independent checker or Lean certification is asserted.

Assume Rich Outcomes, Stochastic Equivalence, Mixture Independence, Relative
Expectation and Uniqueness of Negative Self-Similarity. We do not assume
Totality, Scale Invariance, reflection, or $L^{1}$ Continuity. All arithmetic below
is within the real utility chart; Rich Outcomes supplies the required outcomes.

##### 1. Pasadena and Highland Park have an integrable difference

Couple Pasadena \(P\) and Highland Park \(H\) using the same integer
\(N\), where \(\Pr(N=n)=2^{-n}\). For \(k\ge1\), put

\[
\begin{aligned}
P(2k-1)=H(2k-1)&=\frac{2^{2k-1}}{2k-1},\\
P(2k)&=-\frac{4^k}{2k},&H(2k)&=-\frac{4^k}{2k-1}.
\end{aligned}
\]

The difference \(P-H\) is nonnegative. Its expectation and absolute
expectation are both

\[
\sum_{k=1}^{\infty}\frac1{2k(2k-1)}=\ln2. \tag{1}
\]

The equality follows by pairing the alternating harmonic series; the series
in (1) itself is nonnegative and absolutely convergent. Relative Expectation
therefore gives \(P\sim H+\ln2\), since the difference between these two
actually coupled variables is integrable with mean zero.

##### 2. The auxiliary relative-expectation identity

Let \(Q\) take

\[
a_k=\frac{2^{2k-1}}{2k-1}
\quad\text{with probability}\quad\frac3{4^k},\qquad k\ge1.
\]

The positive and negative masses in the preceding definition of \(H\)
give the identity of laws

\[
H\overset d=M_{2/3}(Q,-2Q). \tag{2}
\]

For an explicit coupling of \(Q\) with a variable \(S\), use the same
index \(k\), put \(S=0\) when \(k=1\), and put \(S=4a_{k-1}\)
when \(k\ge2\). Its law is

\[
S\overset d=M_{1/4}(4Q,0).
\]

At \(k=1\) the expectation contribution from \(Q-S\) is \(3/2\).
For \(k\ge2\), the contribution is

\[
\frac3{4^k}(a_k-4a_{k-1})
=-\frac3{(2k-1)(2k-3)}.
\]

Telescoping yields

\[
\sum_{k=2}^{K}\frac3{(2k-1)(2k-3)}
=\frac32\left(1-\frac1{2K-1}\right).
\]

Consequently \(E[Q-S]=0\) and \(E|Q-S|=3\). Relative Expectation
and Stochastic Equivalence give

\[
Q\sim M_{1/4}(4Q,0). \tag{3}
\]

##### 3. Highland Park satisfies a negative fixed-value equation

Substitute (3) into the \(Q\) branch of (2) by Mixture Independence.
Regrouping laws gives

\[
\begin{aligned}
H
&\sim \tfrac16(4Q)+\tfrac12\delta_0+\tfrac13(-2Q)\\
&\overset d=M_{1/2}(-2H,0).
\end{aligned} \tag{4}
\]

In these two lines, scalar coefficients outside parentheses denote
randomized-mixture weights, not pointwise averages of utilities. The last
identity follows directly by pushing the law in (2) through \(x\mapsto-2x\).
No affine transformation has been applied to a preference equality.
Stochastic Equivalence licenses all distributional regrouping.

The sure zero also satisfies

\[
0\sim M_{1/2}(-2\cdot0,0).
\]

Apply Uniqueness of Negative Self-Similarity with
\(p=1/2,a=2,b=0,Z=0\). Equation (4) and the sure-zero equation yield

\[
H\sim0. \tag{5}
\]

This is the central factorization. It avoids extracting a square root of
a positive scaling relation, the point at which the source proof uses
Totality and Positive Affine Invariance.

##### 4. Transfer the finite difference to a sure value

For completeness, the limited shift consequence needed here follows from
the listed assumptions. For any \(X\) and real \(c\), the two variables

\[
M_{1/2}(X+c,0),\qquad M_{1/2}(X,c)
\]

under the fixed mixture lift have difference \(c\) on the first half and
\(-c\) on the second half, apart from irrelevant endpoints. Relative
Expectation makes them indifferent. If \(X\sim0\), Mixture Independence
and Stochastic Equivalence also give

\[
M_{1/2}(X,c)\sim M_{1/2}(0,c)\sim M_{1/2}(c,0).
\]

Cancel the common zero branch to obtain \(X+c\sim c\). Apply this with
\(X=H\), \(c=\ln2\), and (5). Together with the comparison from (1),
it proves

\[
P\sim H+\ln2\sim\ln2.
\]

Any variable with Pasadena's law is indifferent to the constructed \(P\)
by Stochastic Equivalence, so the conclusion has the universal form of the
recorded evaluation principle.

`checks/calculation_factorizations.py` verifies the telescoping coupling
identities with exact fractions and explicit remaining-series bounds. Those
diagnostics supplement this proof; they do not certify the preference axioms.

</details>

#### Rich Outcomes ∧ Relative Expectation ∧ Continuity under Vanishing Shifts ⇒ L¹ Continuity (random variables) — `relative-vanishing-shifts-imply-l1`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Relative Expectation (`relative-expectation`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

Conclusion: L¹ Continuity (random variables) (`l1-continuity`)

Proof.

Suppose $E|u(X_n)- u(X)|$ tends to zero and $X_n \succeq Y$ for every n. Fix $\epsilon >0$. Rich Outcomes supplies $X+\epsilon$ in the real utility chart. For a sufficiently large n, the actual difference $(X+\epsilon )- X_n$ is integrable and has expectation at least $\epsilon - E|u(X_n)- u(X)|>0$. Relative Expectation applied in both directions gives $X+\epsilon \succ X_n$, so transitivity gives $X+\epsilon \succeq Y$. This holds for every $\epsilon >0$. Continuity under Vanishing Shifts yields $X \succeq Y$, exactly the recorded upper-section L1 Continuity clause. Neither transporting a preference by a shift nor closing a lower section is required.

Notes. Original work: short positive-buffer argument. With Rich Outcomes and Relative Expectation, Continuity under Vanishing Shifts and L1 Continuity are equivalent, using the separately recorded reverse implication. The proof concerns actual coupled utility differences and assumes neither Totality nor Stochastic Equivalence nor Shift Invariance. This describes the work performed for the map, not literature priority.

Sources:

- **GPT-6 connecting proof 9 Sep** — GPT-6 (Codex), 9 September 2026, original connecting proof in the Logical Maps investigation of the CDF-area model and weak continuity.



Record: `topics/unbounded-utility/results/relative-vanishing-shifts-imply-l1.yaml`.

#### Rich Outcomes ∧ Archimedean Outcomes ∧ Stochastic Dominance ∧ Mixture Independence ⇒ Simple Expected Utility — `rich-archimedean-dominance-independence-imply-simple-eu`

Proved result; source **Misc.**; produced by GPT-6 (Codex) (finite-lottery proof and premise audit using Goodsell's framework); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)

Conclusion: Simple Expected Utility (`simple-eu`)

Proof.

Stochastic Dominance gives Stochastic Equivalence and strictly orders binary mixtures of fixed distinct sure endpoints by the probability of the better endpoint. Archimedean Outcomes calibrates each outcome against 0 and 1, giving a unique finite chart value u. For any two simple gambles, choose common sure endpoints enclosing their finite supports and 0,1. Every supported outcome is indifferent to a binary mixture of these endpoints. Independence and law invariance replace the finite branches and flatten the resulting compound lotteries. The endpoint probability of an outcome o is $q(0)+(q(1)-q(0))*u(o)$, by the chart's three binary calibration clauses. Thus the two flattened probabilities compare exactly as their finite expected chart utilities. The chart is strictly increasing; Rich Outcomes supplies an outcome $o_r$ at every real level, making each inverse upper ray $\{u>r\}$ the measurable outcome ray $\{o>o_r\}$. The chart is therefore total and measurable, as required by Simple EU. No Totality over arbitrary gambles or gamble continuity is used. See the write-up for endpoint, calibration and finite-mixture details.

Notes. Original work: small proof adaptation and premise audit. The source supplies the finite-lottery representation and DU framework; this entry writes out the argument without global Totality and without presupposing Simple EU or Restricted Totality. It is a new connecting proof, not a change to the existing source-attributed original-dtu-implies-simple-eu record. Rich and Archimedean Outcomes alone are not sufficient: dominance and mixture independence supply essential steps in this proof. The DU and DTU presets can therefore omit Simple EU as an assumed axiom while retaining it as a derived consequence. No minimality, literature priority, independent certification or Lean verification is claimed.

Sources:

- **GPT-6 finite-lottery proof 9 Sep** — GPT-6 (Codex), Logical Maps, 9 September 2026; proof and premise audit in writeups/rich-archimedean-dominance-independence-imply-simple-eu.md, following Zachary Goodsell’s request to derive Simple EU from the more basic DU axioms.
- **Decision Theory Unbound** — Zachary Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695, DOI 10.1111/nous.12473, §3.2 pp. 678–681 and §3.3 pp. 681–682: utility calibration, finite expected utility and the DU/DTU distinction.

- **Background: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §3.2 pp. 678–681 and §3.3 pp. 681–682: utility calibration, finite expected utility and the DU/DTU distinction

Record: `topics/unbounded-utility/results/rich-archimedean-dominance-independence-imply-simple-eu.yaml`.

<details><summary>Hand-written write-up</summary>

#### Simple EU from the more basic DU axioms

**Proved implication:** Rich Outcomes + Archimedean Outcomes + Stochastic
Dominance + Mixture Independence imply Simple Expected Utility.

Totality over arbitrary gambles is not assumed. Nor is Restricted Totality
or Simple EU assumed: comparison of all simple gambles is a conclusion.
Rich Outcomes and Archimedean Outcomes **alone** do not give this result.

**Source and contribution.** Goodsell's *Decision theory unbound*, §3.2,
pp. 678–681, supplies the utility calibration and finite-lottery representation;
§3.3, pp. 681–682, distinguishes DU from DTU. This is a small proof adaptation
and premise audit by GPT-6 (Codex), 9 September 2026, writing out why global
Totality is unnecessary in the mixture formulation. The original
source-attributed representation record is retained. No literature priority,
independent certification or Lean verification is claimed.

##### Binary comparisons and law invariance

Stochastic Dominance includes its weak clause. Applying it in both directions
to equally distributed gambles gives Stochastic Equivalence. We may therefore
use identities in law for the fixed randomized-selection operation $M_p$.

For sure outcomes $a<b$, write

\[
B_{a,b}(p)=M_p(b,a),\qquad 0\le p\le1.
\]

The endpoint cases have the same laws as sure $a$ and sure $b$. If $p>q$,
every upper tail of $B_{a,b}(p)$ is at least that of $B_{a,b}(q)$, with a
strict difference at the outcome threshold $a$. Stochastic Dominance gives

\[
B_{a,b}(p)\succ B_{a,b}(q).
\tag{1}
\]

In particular, these binary gambles are comparable and have distinct values
for distinct probabilities. This follows from dominance, not a Totality axiom.

##### A total, uniquely calibrated chart

Archimedean Outcomes applies separately in the three possible ranges of a
sure outcome $o$:

- For $0<o<1$, it gives $o\sim M_r(1,0)$ for some $0<r<1$.
- For $o>1$, it gives $1\sim M_p(o,0)$ for some $0<p<1$; set $r=1/p>1$.
- For $o<0$, it gives $0\sim M_p(1,o)$ for some $0<p<1$; set
  $r=-p/(1-p)<0$.

Use $u(0)=0$ and $u(1)=1$ at the references. These are precisely the three
clauses defining the normalized chart, so every outcome has a finite chart
value $u(o)$. Equation (1) makes the probability in each calibration unique.
It also places a nontrivial binary mixture strictly between its endpoints,
so a calibration cannot put an outcome in the wrong one of these three ranges.

##### Finite lotteries reduce to common binary endpoints

Fix two simple gambles $X,Y$. Choose $a$ and $b$ as the minimum and maximum
of their finite ranges together with the reference outcomes $0,1$. Then
$a<b$. For every outcome $o$ in this interval, Archimedean Outcomes and (1)
give a unique $q(o)\in[0,1]$ such that

\[
o\sim B_{a,b}(q(o)).
\tag{2}
\]

Here $q(a)=0$ and $q(b)=1$ use the endpoint identities; only interior
outcomes require Archimedean Outcomes. Since sure outcomes have their
standing linear order, (1) and (2) imply that $q$ strictly preserves that
order. In particular, $q(1)>q(0)$.

Mixture Independence preserves indifference in a mixture branch.
Stochastic Equivalence permits interchange of the two branches and
reassociation of compound mixtures, so it also permits substitution in
the other branch. Inductively replace each outcome of a finite lottery
using (2), then flatten its finite compound mixture in law. If $X$ assigns
probabilities $\alpha_i$ to outcomes $o_i$, this yields

\[
X\sim B_{a,b}\!\left(\sum_i\alpha_iq(o_i)\right).
\tag{3}
\]

Discard zero-probability atoms by Stochastic Equivalence. A remaining
one-atom law is already sure; otherwise the inductive substitutions use
only mixture weights strictly between zero and one. No independence
assertion at weights zero or one is needed.

The same substitution and flattening applied to the chart calibrations
gives a common affine expression for all $o$ in the interval. Write
$r=u(o)$:

- If $0\le r\le1$, then
  $q(o)=r q(1)+(1-r)q(0)$.
- If $r>1$, then
  $q(1)=r^{-1}q(o)+(1-r^{-1})q(0)$.
- If $r<0$, put $p=-r/(1-r)$. Then
  $q(0)=p q(1)+(1-p)q(o)$.

In each case, uniqueness in (1) justifies equating the flattened
probabilities. Rearranging gives

\[
q(o)=q(0)+(q(1)-q(0))u(o).
\tag{4}
\]

Equations (1), (3) and (4), and $q(1)-q(0)>0$, now give

\[
X\succeq Y
\quad\Longleftrightarrow\quad
\mathbb E[u(X)]\ge\mathbb E[u(Y)].
\tag{5}
\]

All sums in this step are finite. This proves Restricted Totality as part
of the conclusion, without comparing arbitrary nonsimple gambles.

##### Measurability and the role of Rich Outcomes

Apply the common-endpoint argument to any pair of sure outcomes and $0,1$.
Equation (4) shows that the global chart $u$ strictly preserves the outcome
order. Rich Outcomes supplies, for every $r\in\mathbb R$, an outcome
$o_r$ with $u(o_r)=r$. Therefore

\[
\{o:u(o)>r\}=\{o:o>o_r\}.
\]

These upper rays are measurable by the standing outcome-space convention.
The real upper rays generate the Borel sigma-algebra, so $u$ is measurable.
Together with chart totality and (5), this proves the complete recorded
Simple EU principle, including its measurability requirement.

##### What changes in the map

DU now assumes Rich Outcomes, Archimedean Outcomes, Stochastic Equivalence,
Stochastic Dominance and Mixture Independence. This theorem derives Simple
EU. DTU adds Totality to the same preset. The former Simple-EU-based
formulation is equivalent, using the existing Simple $\operatorname{EU} \Rightarrow$ Archimedean
Outcomes result for the reverse implication.

The additional premises must not be dropped from the theorem record merely
because the DU background usually supplies them. The
[Two-sample minimum: zero extension](finite-two-sample-minimum.md) demonstrates why the
unqualified Rich + Archimedean Outcomes $\Rightarrow$ Simple EU arrow would be false.

</details>

#### Rich Outcomes ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Archimedean Gambles ⇒ False (⊥) — `rich-simple-dominance-refutes-archimedean-gambles`

Proved result; source **Misc.**; produced by Zachary Goodsell (St Petersburg argument); GPT-6 (Codex), explicit reduction of the sufficient premises; recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Archimedean Gambles (`archimedean-gambles`)

Conclusion: False (⊥) (`false`)

Proof.

Let S take utility $2^{n}$ with probability $2^{-n}$ for $n\ge 1$. Rich Outcomes and standing prospect richness supply S, its finite truncations $T_N=\min (S,2$ᴺ), and the required mixtures. For $N\ge 1, E[T_N]=N+1$. By Simple $\operatorname{EU}, T_N$ is indifferent to the sure utility $N+1$. Stochastic Dominance gives $S \succeq T_N$, hence $S \succ c$ for every real c by choosing $N+1>c$. Thus $S \succ 1 \succ 0$. Fix any $p\in (0,1)$ and choose N with $p(N+1)>1$. The mixture $M_p(S,0)$ stochastically dominates the finite-valued mixture $M_p(T_N,0)$, which Simple EU makes indifferent to the sure utility $p(N+1)>1$. Therefore $M_p(S,0) \succ 1$ for every $p\in (0,1)$. Archimedean Gambles would require one such mixture to be indifferent to 1, a contradiction. Only the standing preorder is used to compose these comparisons; no Totality or Mixture Independence is required.

Notes. This is the existing Goodsell argument with its sufficient assumptions made explicit, not a new counterexample. The original source-attributed DTU result is retained unchanged. Stochastic Equivalence follows from this topic’s dominance axiom, but is not separately needed in the displayed proof. Relative to these assumptions, Archimedean Gambles is ruled out; adding it to the background yields False.

Sources:

- **GPT-6 premise audit 9 Sep** — GPT-6 (Codex), project premise audit, 9 September 2026: the St Petersburg proof recorded in dtu-refutes-archimedean-gambles uses only Rich Outcomes, Simple EU, and Stochastic Dominance. This record makes that sufficient subpackage explicit.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 22: St Petersburg obstruction to Archimedean Gambles.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3, p. 22: St Petersburg obstruction to Archimedean Gambles

Record: `topics/unbounded-utility/results/rich-simple-dominance-refutes-archimedean-gambles.yaml`.

#### Rich Outcomes ∧ Simple Expected Utility ∧ Sure-Thing ∧ Countable Sure-Thing ⇒ False (⊥) — `rich-simple-sure-thing-refutes-countable`

Proved result; source **Infinite Prospects**; produced by Jeffrey Sanford Russell and Yoaav Isaacs (Countable Sure-Thing obstruction); Zachary Goodsell (strengthened version recorded here); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Simple Expected Utility (`simple-eu`)
- Sure-Thing (`sure-thing`)
- Countable Sure-Thing (`countable-sure-thing`)

Conclusion: False (⊥) (`false`)

Proof.

Use the strengthened St Petersburg contradiction from §2.3. Simple EU supplies Restricted Totality, Restricted Stochastic Equivalence and finite conditional EU calculations. With independent sequences of fair tosses let A be first-toss St Petersburg, B the same starting at toss 2, and C an independent St Petersburg variable. Conditional on $B=2^n, A$ is a fair mixture of 2 and $2^{n+1}$, so its conditional expected value exceeds B by 1; Countable Sure-Thing would give $A\succ B$. Partition the A,C space by the maximum of their finite stopping times. On each cell they are simple and their restricted laws coincide, so Countable Sure-Thing would give $A\sim C$. Repeat for B,C to get $B\sim C$, contradicting Preordering. Null sets can be assigned a finite outcome without changing the simple-law comparisons.

Notes. Russell and Isaacs supply the Countable Sure-Thing principle and original St Petersburg obstruction. Goodsell, Decision theory unbound, §2.3, pp. 675–676 supplies the strengthened version and proof recorded here. The arrow is attributed to the original result, with the strengthening credited separately. Premises, proof and verification status are unchanged.

Sources:

- **Russell & Isaacs (2021)** — Russell, J. S., & Isaacs, Y. (2021). Infinite prospects. Philosophy and Phenomenological Research, 103(1), 178–198. §2, author’s April 2020 manuscript pp. 6–8; §4, p. 15, footnote 17. https://doi.org/10.1111/phpr.12704
- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.3, pp. 675–676

- **Origin: [Infinite prospects](https://doi.org/10.1111/phpr.12704).** Russell, J. S., & Isaacs, Y. (2021). Infinite prospects. Philosophy and Phenomenological Research, 103(1), 178–198. — §2, author’s April 2020 manuscript pp. 6–8; §4, p. 15, footnote 17. Original St Petersburg obstruction to Countable Sure-Thing with unbounded real utilities. The sufficient premises and proof recorded here follow Goodsell’s strengthened version in Decision theory unbound, §2.3.
- **Proof: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §2.3, pp. 675–676

Record: `topics/unbounded-utility/results/rich-simple-sure-thing-refutes-countable.yaml`.

#### Rich Outcomes ∧ Shift Invariance ∧ Scale Invariance ⇒ Positive Affine Invariance — `shift-scale-imply-positive-affine`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Shift Invariance (`shift-invariance`)
- Scale Invariance (`scale-invariance`)

Conclusion: Positive Affine Invariance (`positive-affine-invariance`)

Proof.

Apply Scale Invariance and then Shift Invariance. Rich Outcomes supplies all intermediate outcome levels.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §§3, 5, pp. 24, 34
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/shift-scale-imply-positive-affine.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §§3, 5, pp. 24, 34

Record: `topics/unbounded-utility/results/shift-scale-imply-positive-affine.yaml`.

#### Rich Outcomes ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Mixture Independence ∧ Transfer of a Shift Across a Mixture ⇒ Simple Relative Expectation — `shift-transfer-implies-simple-relative`

Proved result; source **Misc.**; produced by Zachary Goodsell (source argument); GPT-6 (Codex) (adaptation and premise audit); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Mixture Independence (`independence`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)

Conclusion: Simple Relative Expectation (`simple-relative-expectation`)

Proof.

Write $D=u(X)- u(Y)$, with finitely many values $d_i$ of positive probabilities $p_i$, and let $Y_i$ have the conditional law of Y given $D=d_i$. The law of $M_{1/2}(X,0)$ is the finite mixture with weights $p_i$ of $M_{1/2}(Y_i+d_i,0)$. Shift Transfer gives $M_{1/2}(Y_i+d_i,0)\sim M_{1/2}(Y_i,d_i)$. Mixture Independence propagates these indifferences through the finite mixture; Stochastic Equivalence licenses conditional-law realizations, regrouping and branch exchanges. The resulting law is $M_{1/2}(Y,D)$, so $M_{1/2}(X,0)\sim M_{1/2}(Y,D)$. Two mixture cancellations then give $X\succeq Y$ iff $D\succeq 0$, and Simple EU makes this equivalent to $E[D]\ge 0$. Rich Outcomes supplies the sure $d_i$ and the simple gamble realizing D.

Notes. Original work: proof adaptation. Isolate the actual inputs to Goodsell’s Theorem 4: once Shift Transfer is supplied as a principle, neither Totality, Stochastic Dominance nor full affine symmetry is needed. This describes the work needed for this database entry, not a claim of novelty in the literature.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), proof adaptation and premise audit in the Logical Maps project, 9 September 2026; see the accompanying handwritten write-up.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 4, pp. 26–27. The cited argument is adapted with the explicitly listed sufficient premises; the reduced-premise claim is the present project contribution.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 4, pp. 26–27. The cited argument is adapted with the explicitly listed sufficient premises; the reduced-premise claim is the present project contribution

Record: `topics/unbounded-utility/results/shift-transfer-implies-simple-relative.yaml`.

<details><summary>Hand-written write-up</summary>

#### Shift Transfer recovers Simple Relative Expectation

**Claim.** Rich Outcomes + Stochastic Equivalence + Simple $\operatorname{EU} +$ Mixture Independence + Shift Transfer imply Simple Relative Expectation.

Use numerical utility notation throughout. Suppose $D=X-Y$ has finitely many values. Ignore probability-zero values, and write its remaining values as $d_1,\ldots,d_k$, with probabilities $p_1,\ldots,p_k>0$. Rich Outcomes supplies a sure outcome for each $d_i$ and the simple gamble with utility variable $D$.

For each $i$, choose $Y_i$ with the conditional law of $Y$ given $D=d_i$. Such real-valued laws can be realized on the standing atomless standard probability space. The corresponding conditional law of $X$ is that of $Y_i+d_i$. In particular, by laws,

$$\mathcal L\bigl(M_{1/2}(X,0)\bigr)
=\sum_{i=1}^k p_i\,\mathcal L\bigl(M_{1/2}(Y_i+d_i,0)\bigr).$$

Shift Transfer, with transfer parameter $d_i/2$, gives

$$M_{1/2}(Y_i+d_i,0)\sim M_{1/2}(Y_i,d_i).$$

Mixture Independence propagates indifferences through a finite randomized mixture. To justify replacement in a second branch, first exchange branches using Stochastic Equivalence, apply Independence, and exchange back. Iterating over a binary realization of the finite mixture therefore gives

$$M_{1/2}(X,0)\sim M_{1/2}(Y,D). \tag{1}$$

Here the law of the mixture after all replacements is

$$\sum_i p_i\left(\tfrac12\mathcal L(Y_i)+\tfrac12\delta_{d_i}\right)
=\tfrac12\mathcal L(Y)+\tfrac12\mathcal L(D),$$

which is precisely the law on the right of (1). Stochastic Equivalence licenses both law identities, and so also disposes of the ignored null values.

We can now cancel mixtures:

$$\begin{aligned}
X\succeq Y
&\iff M_{1/2}(X,0)\succeq M_{1/2}(Y,0)\\
&\iff M_{1/2}(Y,D)\succeq M_{1/2}(Y,0)\\
&\iff D\succeq0\\
&\iff\mathbb E D\geq0.
\end{aligned}$$

The first equivalence is Independence. The second uses (1) and the preorder. The third exchanges branches by Stochastic Equivalence and applies Independence with common second argument $Y$. The final equivalence is Simple EU applied to the simple gamble $D$ and sure zero.

No Totality, Stochastic Dominance, reflection or scaling principle is needed. Conditional laws are only a proof construction: every preference replacement of a same-law variable is explicitly licensed by Stochastic Equivalence. Rich Outcomes ensures availability of the newly formed numerical outcomes and does not serve as a hidden total-chart assumption.

**Original work: proof adaptation.** This is Goodsell's finite-shift redistribution argument from Theorem 4, reorganized to identify its actual sufficient premises. The source's use of affine symmetry enters through Shift Transfer, which is now exposed as a separate input. No literature novelty is asserted.

**Attribution.** Original argument: Zachary Goodsell, *Symmetries of value*, Theorem 4, pp. 26–27. Reduced-premise formulation and random-variable audit: GPT-6 (Codex), 9 September 2026. No independent checker or Lean proof is claimed.

</details>

#### Simple Expected Utility ⇒ Archimedean Outcomes — `simple-eu-implies-archimedean-outcomes`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Simple Expected Utility (`simple-eu`)

Conclusion: Archimedean Outcomes (`archimedean-outcomes`)

Proof.

For $a\succ b\succ c$ put $p=(u(b)- u(c))/(u(a)- u(c))$. Then $0<p<1$ and the simple variable $M_p(a,c)$ has expectation $u(b)$, so is indifferent to b.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, p. 22, footnote 3

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — p. 22, footnote 3

Record: `topics/unbounded-utility/results/simple-eu-implies-archimedean-outcomes.yaml`.

#### Simple Expected Utility ⇒ Restricted Stochastic Equivalence — `simple-eu-implies-restricted-equivalence`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean verified; 2026-09-08.

Premises:

- Simple Expected Utility (`simple-eu`)

Conclusion: Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)

Proof.

Equal laws of simple variables give equal finite expectations. Simple EU therefore gives both preference directions.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §§2.3, 3.2

- **Proof: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §§2.3, 3.2

Record: `topics/unbounded-utility/results/simple-eu-implies-restricted-equivalence.yaml`.

#### Simple Expected Utility ⇒ Restricted Totality — `simple-eu-implies-restricted-totality`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean verified; 2026-09-08.

Premises:

- Simple Expected Utility (`simple-eu`)

Conclusion: Restricted Totality (`restricted-totality`)

Proof.

Finite real expectations are comparable, and Simple EU represents the preference in both directions.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, pp. 22–23

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — §3, pp. 22–23

Record: `topics/unbounded-utility/results/simple-eu-implies-restricted-totality.yaml`.

#### Simple Relative Expectation ⇒ Transfer of a Shift Across a Mixture — `simple-relative-implies-shift-transfer`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Simple Relative Expectation (`simple-relative-expectation`)

Conclusion: Transfer of a Shift Across a Mixture (`shift-transfer`)

Proof.

Put $A=M_p(X+b/p,Y)$ and $B=M_p(X,Y+b/(1- p))$, using the same fixed mixture lift. Their actual utility difference is b/p on the first branch, of probability p, and −b/(1−p) on the second branch. It is simple and has mean zero. Simple Relative Expectation in both directions therefore gives $A\sim B$. No law replacement or independence assumption is used.

Notes. Original work: direct consequence. Observe that the two mixtures have a two-valued, zero-mean difference under the actual common lift, and apply Simple Relative Expectation. This describes the work needed for this database entry, not a claim of novelty in the literature.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof and premise audit in the Logical Maps project, 9 September 2026; see the accompanying handwritten write-up.



Record: `topics/unbounded-utility/results/simple-relative-implies-shift-transfer.yaml`.

<details><summary>Hand-written write-up</summary>

#### Simple Relative Expectation implies Shift Transfer

**Claim.** Simple Relative Expectation implies Transfer of a Shift Across a Mixture, without additional preference axioms.

Fix an eligible pair of real-utility variables $X,Y$, a real number $b$, and $0<p<1$. Here and below arithmetic acts on their normalized utility levels. Set

$$A=M_p(X+b/p,Y),\qquad B=M_p(X,Y+b/(1-p)).$$

The fixed mixture lift uses the same branch event and the same rescaled sample in both variables. Consequently

$$u(A)-u(B)=\begin{cases}b/p,&0\leq w<p,\\-b/(1-p),&p\leq w\leq1.\end{cases}$$

Thus the difference is simple and its expectation is

$$p\frac bp-(1-p)\frac b{1-p}=0.$$

Simple Relative Expectation gives both $A\succeq B$ and $B\succeq A$, as required. Any exceptional fixed endpoint convention affects only finitely many null sample points, so it neither destroys finiteness of the difference's range nor changes its mean.

The argument concerns the actual random variables. It does not replace them by equal-law copies, and it uses only the transformed outcomes already required to state Shift Transfer. In particular, neither Stochastic Equivalence nor Rich Outcomes is a hidden premise.

**Original work: direct consequence.** The work is identifying the two-valued difference and checking that the fixed random-variable mixture convention licenses its use. This is a database connection, with no claim of literature novelty.

**Attribution.** Connecting argument: GPT-6 (Codex), 9 September 2026. The principles themselves were extracted from Zachary Goodsell, *Symmetries of value*, Theorems 3–4. No independent checker or Lean proof is claimed.

</details>

#### Rich Outcomes ∧ Simple Relative Expectation ∧ L¹ Continuity (random variables) ⇒ Relative Expectation — `simple-relative-l1-imply-relative`

Proved result; source **Misc.**; produced by Zachary Goodsell (source argument); GPT-6 (Codex) (adaptation and premise audit); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Simple Relative Expectation (`simple-relative-expectation`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Relative Expectation (`relative-expectation`)

Proof.

For real-utility X,Y with $D=u(X)- u(Y)$ integrable, choose simple $q_n\to D$ in L1 and put $d_n=q_n+E[D]- E[q_n]$, so $d_n$ is simple, has mean E[D], and tends to D in L1. Rich Outcomes supplies $X_n$ with utility $u(Y)+d_n$. If $E[D]\ge 0$, Simple Relative Expectation gives $X_n\succeq Y$, and upper-section L1 Continuity gives $X\succeq Y$. To prove the converse when $E[D]<0$, put $c=- E[D]/2>0$. The already proved forward direction gives $Y\succeq X+c$, while Simple Relative Expectation gives $X+c\succ X. \operatorname{Transitivity}$ yields $Y\succ X$, ruling out $X\succeq Y$. No lower-section continuity, totality, law invariance or symmetry is used.

Notes. Original work: proof adaptation. Expand the forward approximation idea of Goodsell’s Corollary 5, correct the approximations to preserve their means, and recover strictness using a positive constant perturbation so that only the recorded upper-section continuity clause is needed. This describes the work needed for this database entry, not a claim of novelty in the literature.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), proof adaptation and premise audit in the Logical Maps project, 9 September 2026; see the accompanying handwritten write-up.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Corollary 5, p. 27. The cited argument is adapted with the explicitly listed sufficient premises; the reduced-premise claim is the present project contribution.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — p. 27. The cited argument is adapted with the explicitly listed sufficient premises; the reduced-premise claim is the present project contribution

Record: `topics/unbounded-utility/results/simple-relative-l1-imply-relative.yaml`.

<details><summary>Hand-written write-up</summary>

#### Simple Relative Expectation and L¹ Continuity imply Relative Expectation

**Claim.** Rich Outcomes + Simple Relative Expectation $+ L^{1}$ Continuity imply Relative Expectation.

All variables in this proof are in the real utility chart; write their utilities as $X,Y$ to simplify notation. Fix $D=X-Y$ with $\mathbb E|D|<\infty$, and write $m=\mathbb E D$. Simple functions are dense in $L^1$, so choose simple $q_n$ with $\mathbb E|q_n-D|\to0$. Define

$$d_n=q_n+m-\mathbb E q_n.$$

These are still simple, satisfy $\mathbb E d_n=m$, and obey

$$\mathbb E|d_n-D|\leq \mathbb E|q_n-D|+|m-\mathbb E q_n|
\leq 2\mathbb E|q_n-D|\longrightarrow0.$$

Rich Outcomes supplies every finite level needed to form the measurable gambles $X_n=Y+d_n$.

First suppose $m\geq0$. Because $X_n-Y=d_n$ is simple with mean $m$, Simple Relative Expectation gives $X_n\succeq Y$ for every $n$. The actual coupling satisfies $\mathbb E|X_n-X|\to0$. The upper-section clause of $L^{1}$ Continuity therefore gives $X\succeq Y$.

This proves the nonnegative-mean direction for every integrable-difference pair. For the converse, suppose $m<0$ and put $c=-m/2>0$. We have

$$\mathbb E[Y-(X+c)]=-m-c=-m/2>0.$$

The direction just proved gives $Y\succeq X+c$. Simple Relative Expectation, applied to the constant difference $c$, gives $X+c\succ X$: its forward weak comparison holds and its reverse weak comparison fails. If $X\succeq Y$, transitivity would give $X\succeq X+c$, a contradiction. Hence $X\not\succeq Y$ whenever $m<0$.

Together these establish exactly $X\succeq Y\iff\mathbb E(X-Y)\geq0$.

The mean correction is essential for obtaining approximants on the required side when $m=0$. The positive perturbation handles strictness without assuming lower-section closure. No Totality, Stochastic Equivalence, Mixture Independence, reflection or affine symmetry is used. Rich Outcomes supplies intermediate real utility levels; it is not silently used to exclude outcomes outside the chart.

**Original work: proof adaptation.** Goodsell's Corollary 5 supplies the approximation idea in the full DTU+Sym context. The present work removes unused assumptions and spells out the mean correction and one-sided-continuity strictness argument. This describes the work for this entry, not literature novelty.

**Attribution.** Source idea: Zachary Goodsell, *Symmetries of value*, Corollary 5, p. 27. Reduced-premise proof: GPT-6 (Codex), 9 September 2026. No independent checker or Lean proof is claimed.

</details>

#### Stochastic Equivalence ⇒ Restricted Stochastic Equivalence — `stochastic-equivalence-restricts`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean verified; 2026-09-08.

Premises:

- Stochastic Equivalence (`stochastic-equivalence`)

Conclusion: Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)

Proof.

Restrict the quantifiers to simple random variables.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.3, p. 675
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/stochastic-equivalence-restricts.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

- **Background: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §2.3, p. 675

Record: `topics/unbounded-utility/results/stochastic-equivalence-restricts.yaml`.

#### Rich Outcomes ∧ Archimedean Outcomes ∧ Totality ∧ Stochastic Dominance ∧ Sure-Thing ⇒ Mixture Independence — `sure-thing-to-independence`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Totality (`totality`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)

Conclusion: Mixture Independence (`independence`)

Proof.

Source reduction, §3.2: in the original DTU framework, Stochastic Dominance yields Stochastic Equivalence. Preferences therefore descend to laws. Every law and its conditional realizations are available by Prospect Richness, and the paper identifies Sure-Thing in this quotient with von Neumann–Morgenstern Independence. Pull this implication back along X↦$L(X)$. The full original DTU assumptions are retained; a weaker converse for arbitrary incomplete orders has not been extracted.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 679

- **Proof: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §3.2, p. 679

Record: `topics/unbounded-utility/results/sure-thing-to-independence.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Symmetric Gambles Are Neutral ∧ Independent Sum Invariance ⇒ False (⊥) — `symmetric-dtu-refutes-independent-sum-candidate`

Proved result; source **Misc.**; produced by Zachary Goodsell (proposed claim and stable-law obstruction); GPT-6 (Codex) (completion via reduced-premise Lévy theorem); recorded by GPT-6 (Codex), 2026-09-09; original proposal retained, now settled by the recorded Lévy proof; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Independent Sum Invariance (`independent-sum-consistency`)

Conclusion: False (⊥) (`false`)

Proof.

Independent Sum Invariance entails Independent Sum Preservation. The other premises include Rich Outcomes, Stochastic Dominance, Mixture Independence and Symmetric Gambles Are Neutral. Apply levy-refutes-neutral-independent-preservation to obtain False. The new proof uses a specified positive index-1/2 Lévy law and an intermediate symmetric difference; it completes Goodsell’s proposed mechanism with fewer assumptions, rather than relying on the withdrawn manuscript proof.

Notes. Settled 9 September 2026 by levy-refutes-neutral-independent-preservation. Original work: direct consequence of that proof completion; no additional mathematical construction is needed for this larger premise package. Goodsell’s proposal and the historical source audit are preserved. The previous open-status wording below records the state before completion.

Historical notes:
Records the user’s proposed incompatibility with a deliberately sufficient package. The user recalls balanced mixtures involving stable indices 1 and 1/2, neutral by symmetry, becoming strictly dominance-ordered after convolution by a common index-1/2 law. Exact laws, skewness, scale, location, mixture weights, and a global strict-dominance proof remain to be specified. The draft explicitly withdraws its symmetry lemma; that proof failure alone is not a proof of this implication. Excluded from proved inference and known-inconsistency warnings.

Representation update: the former negative conclusion is expressed by adding independent-sum-consistency to the premises and concluding False. The mathematical claim, source, and proof are unchanged.

Sources:

- **Goodsell proposal 9 Sep** — Zachary Goodsell, project conversation, 9 September 2026: revised conjecture omitting reflection and recollection of a stable-distribution obstruction
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §4, pp. 10–14 (withdrawn consistency argument)
- **GPT-6 proof completion 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/levy-refutes-neutral-independent-preservation.md: complete reduced-premise proof of Goodsell’s stable-law obstruction.

- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §4, pp. 10–14 (withdrawn consistency argument)
- **Background: [Flummoxing expectations](https://doi.org/10.1111/nous.12530).** Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. — §6.1. Source of Independent Sum Consistency; see the principle reference for the changed independence condition. The proof or conjecture recorded here retains its separate attribution.

Record: `topics/unbounded-utility/results/symmetric-dtu-refutes-independent-sum-candidate.yaml`.

<details><summary>Hand-written write-up</summary>

#### Symmetric DTU versus independent sums — settled

**Proved implication:** DTU + Symmetric Gambles Are Neutral + Independent Sum
Invariance implies **False**.

**Proof.** Independent Sum Invariance supplies Independent Sum Preservation.
Apply the [completed Lévy obstruction](levy-refutes-neutral-independent-preservation.html),
which needs only Rich Outcomes, Stochastic Dominance, Mixture Independence,
Symmetric Neutrality and that preservation property.

**Original work: direct consequence of a proof completion.** Goodsell supplied
the claim and stable-law obstruction proposal; GPT-6 (Codex), 9 September 2026,
supplied the specified witness and reduced-premise proof in the linked record.
This larger-premise consequence needs no further construction. Source: Misc.;
no independent checker or Lean verification is asserted.

Zachary Goodsell thinks Wilkinson’s claimed independent-sum result in
[*Flummoxing expectations*, Theorem A.4](https://doi.org/10.1111/nous.12530)
is mistaken. This record relies on the Lévy proof above.

##### Historical source audit

The audit below is preserved from before the proof completion. Its statements
that the incompatibility was conjectured or lacked a proof describe that earlier
state; they are superseded by the proved result above. The withdrawn manuscript
argument is not reinstated.


**Conjectured implication:** Rich Outcomes + Totality + Stochastic Equivalence
+ Simple $\operatorname{EU} +$ Stochastic Dominance + Mixture Independence + Symmetric
Neutrality + Independent Sum Invariance $\Rightarrow$ False. There is no completed
proof recorded for this implication. The audit below separates it from the
verified portions of the manuscript.

**Source:** Zachary Goodsell, *Unbounded Utility and Background Risk*,
5 June 2026, 21 pages. The draft itself is not included in the public downloads.
**Unpublished; do not cite; erroneous.** The short provenance name in the map
is **Unbounded Utility and Background Risk (unpublished)**. These references identify
which supplied document an entry came from; they do not endorse its claims
or describe it as a published paper. PDF and printed page numbers coincide.

Extraction recorded by GPT-6 (Codex), 9 September 2026, following Goodsell’s
request to preserve the interesting principles and extension construction.
No separate checker or formal verification is claimed.

##### Principle inventory

| Manuscript discussion | Map representation |
| --- | --- |
| Expected Utility, pp. 3–4 | Existing Expected Utility; finite expectations retain the topic’s established scope |
| Totality, p. 4 | Existing Totality; reflexivity and transitivity remain standing |
| Preferences over probability distributions | Existing optional Stochastic Equivalence; translated to random variables |
| Stochastic Dominance, pp. 3–4 | Existing weak-plus-strict Stochastic Dominance |
| Independence / Convexity, pp. 3, 6 | Existing Mixture Independence, with a source terminology alias |
| Reflection Symmetry, pp. 3–4 | Existing Symmetric Neutrality, with an alias; not a second node |
| Reflection Anti-Invariance, pp. 3–4 | Existing Reflection Anti-Invariance |
| Full Sum Invariance, pp. 1–2, 17 | New arbitrary-dependence sum biconditional |
| Independent Sum Invariance / Convolution Invariance, pp. 1–6 | New independent-common-summand biconditional |
| Forward and reverse portions of Lemma 1, p. 8 | Separate Independent Sum Preservation (weak and strict) and Cancellation |
| Relative-area base relation and strict extension, pp. 7–8 | New CDF-Area Extension, plus the exact incomplete model |
| Fixed-copula sum-consistency family, p. 18 | General family documented below; independent, comonotonic and antitonic nodes instantiated |
| Comonotonic Sum Invariance, pp. 18–20 | New node; verified in the explicit area model |
| Antitonic Sum Invariance, pp. 18–19 | New node; incompatibility with dominance recorded |
| Real-valued utility domain throughout | Existing Rich Outcomes and Archimedean Outcomes remain distinct |

Full, Antitonic, and Independent Sum incompatibilities are now recorded as
implications to False, with the relevant sum principle added to the other
premises. There are no separate failure nodes. The independent-sum
incompatibility currently has only a **conjectured** arrow. It must not
trigger a known-inconsistency warning.

For a fixed copula $\kappa$, the general schema compares
$Q_X(U)+Q_Z(V)$ with $Q_Y(U)+Q_Z(V)$ for $(U,V)\sim\kappa$.
A choice of copula specifies an axiom; the schema is not silently promoted to
one axiom universally quantifying over every copula. The three distinguished
instances are the product, comonotonic, and antitonic copulas. All comparisons
in the database remain comparisons of random variables, and law identities
are used in proofs only with Stochastic Equivalence or a premise implying it.

“Coherent Indifference” is mentioned in the introduction as background to an
earlier impossibility result, but not defined in this manuscript. No new
axiom is invented from that mention. Conclosure and extension are construction
operations on relations, not additional primitive properties of an individual
gamble. The model write-up preserves them in their appropriate role.

##### What survives

The full-sum St Petersburg counterexample (§6.1) and antitonic impossibility
(Theorem 6) are recorded with explicit proofs. The latter requires neither
Totality nor Symmetric Neutrality. Full Sum Invariance restricts to the
three dependence-specific principles. Each of those implies Shift Invariance
by taking a constant summand. Independent Sum Invariance splits into forward
preservation and reverse cancellation.

The footnote on pp. 12–13 establishes, under totality, law invariance and
mixture independence, that Symmetric Neutrality implies Reflection
Anti-Invariance. This argument is independent of the failed construction.

The base area preorder is a proved incomplete model. Theorem 7’s comonotonic
argument can be made rigorous using separate positive and negative quantile
areas, avoiding undefined differences of infinities. Its independent-sum
**forward** property follows from Tonelli. See
[the detailed construction](cdf-area-preorder.html).

CDF-Area Extension implies Expected Utility, Relative Expectation, and
Stochastic Dominance. It does **not** automatically transfer the exact
model’s invariance properties to every extension: newly supplied comparisons
must themselves respect any requested invariance axioms.

##### Failed claims and remaining gaps

- **Lemma 3 / Theorem 4, pp. 10–12:** the manuscript explicitly acknowledges
  that the symmetry-extension proof fails. Convolving an odd function with
  an arbitrary probability law need not preserve oddness. Convolution with a
  nonzero point mass already translates the function away from its symmetry
  center. The claimed symmetric consistency model is not entered as proved.
- **Lemma 1, p. 8:** convolved positive and negative parts can overlap. The
  asserted identification with the positive and negative parts of the
  convolved difference is false. This invalidates the given cancellation
  proof; it does not by itself disprove cancellation for the base relation.
- **Equation (16), p. 8:** reflection substitution introduces an incorrect
  minus sign. The area model’s anti-invariance nevertheless has a direct
  corrected proof.
- **Lemma 2, pp. 9–10:** the proposed chain construction shows forward
  transformation closure, not the reverse cancellation clauses its use
  requires. Taking the genuine closure by intersection is possible, but
  the total-extension write-up now spells out Goodsell’s conclosure in
  cone language, including strictness-preservation details that do not
  rely on this lemma’s chain description.
- **Theorem 5, pp. 12–14:** neither the failed symmetric seed nor the
  questionable closure calculation establishes the symmetric total extension.
  A separate [proved total extension without either reflection requirement](conjectured-total-independent-sum-extension.html)
  uses Goodsell’s conclosure and total-extension strategy, with cone-language
  exposition and additional proof details recorded by GPT-6. It establishes
  the previously conjectured package, including Independent Sum Invariance,
  without rehabilitating the original symmetry lemma.
- **Cauchy discussion, pp. 15–16:** the draft’s objections to a particular
  attempted dominance comparison do not establish its own consistency
  theorem. No new consistency or incompatibility arrow is inferred from
  its plots or tail heuristics.

##### User’s recalled stable-law obstruction

Goodsell reports that the main consistency claim is false and recalls
balanced mixtures involving stable parameters 1 and 1/2. By symmetry, the
relevant prospects should both be indifferent to zero; convolution with a
common parameter-1/2 law is recalled to create strict stochastic dominance.
If those specifications work, independent-sum invariance transports the
initial indifference to the convolved pair, contradicting strict dominance.

The recollection does not yet fix whether the parameters refer to stability
indices or another parameter, nor the skewness, scale, location, mixture
weights, and full dominance comparison. The map records the resulting
proposed incompatibility with a sufficient DTU-plus-neutrality package as
**conjectured**, source **Goodsell proposal 9 Sep**. No numerical plot or
partially specified stable law is used as a proof. This leaves the author’s
withdrawal explicit while separating it from a checked mathematical witness.

##### Provenance and scope

New manuscript arguments and its explicit construction use the manuscript’s
own direct source. Original restriction/decomposition proofs use **Misc.**,
with **GPT-6 generated 9 Sep** identifying the contribution. The total-extension model is attributed directly to
**Unbounded Utility and Background Risk (unpublished)**: its CDF-area
construction, conclosure, and extension strategy are Goodsell’s. The
cone-language exposition and additional proof details are separately
credited as **GPT-6 proof details 9 Sep**, not as a new AI construction. The remaining
stable-law conjecture uses **Misc.**, with **Goodsell proposal 9 Sep**.
Source definitions are cited separately, and no published proof was rewritten.

After migrating the failure nodes, the additions are seven principles,
sixteen implications (fifteen proved and
one conjectured), one proved incomplete model, and one proved total
extension model. The graph remains selective; no claim is made to exhaust all true
consequences. No Lean formalization was added.

</details>

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ⇒ Alternating St Petersburg = −1/2 — `symmetry-evaluates-alternating`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)

Proof.

The law identity $A =d M_{1/2}(- 2,- 2A)$ gives indifference by Stochastic Equivalence. If $A\succ - 1/2$ then $- 2A\prec 1$, so Independence and Simple EU imply $A\sim M_{1/2}(- 2,- 2A)\prec M_{1/2}(- 2,1)\sim - 1/2$, contradiction. The opposite strict case is analogous. Totality gives $A\sim - 1/2$.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 9, p. 30

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 9, p. 30

Record: `topics/unbounded-utility/results/symmetry-evaluates-alternating.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ⇒ Uniqueness of Negative Self-Similarity — `symmetry-implies-negative-self-similarity`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean verified; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Uniqueness of Negative Self-Similarity (`negative-self-similarity`)

Proof.

If $X\succ Y$, negative affine anti-invariance makes $- aX+b\prec - aY+b$. Independence with the common Z then reverses the strict comparison between their mixtures. The assumed fixed-point indifferences imply $X\prec Y$, contradiction. Interchange X,Y for the other strict case and use Totality.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 10, pp. 30–31

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 10, pp. 30–31

Record: `topics/unbounded-utility/results/symmetry-implies-negative-self-similarity.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ⇒ Transfer of a Shift Across a Mixture — `symmetry-implies-shift-transfer`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Transfer of a Shift Across a Mixture (`shift-transfer`)

Proof.

This is Theorem 3 transported from laws to random variables using Stochastic Equivalence. Reflection, Totality and Independence first make a half-mixture of V and −V indifferent to 0. Shift invariance then gives $M_{1/2}(V+c,- V)\sim c/2$. Pair the terms on the two sides of the proposed transfer with their negatives; both reduce to the same simple constant mixture. Independence cancels the common terms.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 3, pp. 25–26

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 3, pp. 25–26

Record: `topics/unbounded-utility/results/symmetry-implies-shift-transfer.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ⇒ Simple Relative Expectation — `symmetry-implies-simple-relative`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Simple Relative Expectation (`simple-relative-expectation`)

Proof.

Theorem 4. If $D=u(X)- u(Y)$ has finite range, work with the diluted variables $M_{1/2}(X,0), M_{1/2}(Y,0)$. Partition into the finitely many values of D. Transfer each constant difference to the zero branch by Theorem 3. Finite mixture substitution leaves $M_{1/2}(Y,D)$ in place of $M_{1/2}(X,0)$. Independence and Simple EU reduce the comparison to $E[D]\ge 0$. Law invariance permits each rearrangement of branches.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 4, pp. 26–27

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 4, pp. 26–27

Record: `topics/unbounded-utility/results/symmetry-implies-simple-relative.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ∧ L¹ Continuity (random variables) ⇒ Arroyo = ln 2 — `symmetry-l1-evaluates-arroyo`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Arroyo = ln 2 (`arroyo-value`)

Proof.

Theorem 8 evaluates the folded tail difference of $A+1/2$. Pair its positive and negative tails: the residual weights are $1/[2n(2n- 1)]- 1/[2n(2n+1)]$ at heights $2n+1/2, a$ positive integrable tail whose expectation is $1/2+\ln 2$. Folded Expectation gives $A+1/2\sim 1/2+\ln 2$. Shift Invariance gives $A\sim \ln 2$.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 8, pp. 29–30

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 8, pp. 29–30

Record: `topics/unbounded-utility/results/symmetry-l1-evaluates-arroyo.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ∧ L¹ Continuity (random variables) ⇒ Pasadena = ln 2 — `symmetry-l1-evaluates-pasadena`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Pasadena = ln 2 (`pasadena-value`)

Proof.

Theorem 11. Couple Pasadena P with Highland Park H, retaining each outcome probability and replacing each negative denominator 2n by 2n−1. Then $E[H- P]=- \ln 2$ with integrable difference. The paper writes H as $M_2/3(Q,- 2Q)$. It proves by Relative Expectation that $Q\sim M_1/4(4Q,0)$, then Totality and affine invariance give $Q\sim M_{1/2}(2Q,0)$. Reflection and Independence yield $H\sim 0$; Relative Expectation together with shift transfer then gives $P\sim \ln 2$. These are preference equalities, not ordinary expectations of P or H.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 11, pp. 32–33

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 11, pp. 32–33

Record: `topics/unbounded-utility/results/symmetry-l1-evaluates-pasadena.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ∧ L¹ Continuity (random variables) ⇒ Folded Expectation — `symmetry-l1-implies-folded`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Folded Expectation (`folded-expectation`)

Proof.

Theorem 6 couples the positive and negative utility tails in opposing order. Absolute integrability of the folded tail difference yields an integrable difference of these tail variables, with expectation $F(X)$. Relative Expectation (Corollary 5) and reflection identify X with sure $F(X)$. Apply the same construction to Y and compare the constants. Law invariance transfers the chosen couplings to the original variables.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 6, p. 27 and Figure 7, p. 29

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 6, p. 27 and Figure 7, p. 29

Record: `topics/unbounded-utility/results/symmetry-l1-implies-folded.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ∧ L¹ Continuity (random variables) ⇒ Relative Expectation — `symmetry-l1-implies-relative`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Relative Expectation (`relative-expectation`)

Proof.

Corollary 5. Approximate an integrable difference $u(X)- u(Y)$ in $L^{1}$ by simple differences, apply Theorem 4, and use $L^{1}$ continuity to pass to the limit. This is recorded with the full source context DTU+Sym; the equivalence between its law metric and this topic’s random-variable continuity requires Stochastic Equivalence.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Corollary 5, p. 27

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — p. 27

Record: `topics/unbounded-utility/results/symmetry-l1-implies-relative.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ∧ Relative Expectation ⇒ L¹ Continuity (random variables) — `symmetry-relative-implies-l1`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Relative Expectation (`relative-expectation`)

Conclusion: L¹ Continuity (random variables) (`l1-continuity`)

Proof.

This is the reverse direction of Corollary 5 in its full DTU+Sym context. Pull preferences down to probability laws using Stochastic Equivalence and apply the source equivalence between Relative Expectation Theory and the extended $L^{1}$ metric continuity. Actual-coupling convergence implies convergence in that infimum metric, giving the random-variable clause. The source states this as a corollary without an expanded reverse-direction proof; no claim of an independent proof audit is made.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Corollary 5, p. 27

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — p. 27

Record: `topics/unbounded-utility/results/symmetry-relative-implies-l1.yaml`.

#### Totality ∧ Independent Sum Preservation ⇒ Independent Sum Cancellation — `total-preservation-implies-independent-cancellation`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex); checked by nobody; Lean verified; 2026-09-09.

Premises:

- Totality (`totality`)
- Independent Sum Preservation (`independent-sum-preservation`)

Conclusion: Independent Sum Cancellation (`independent-sum-cancellation`)

Proof.

Suppose Z is independent of (X,Y) and $X+Z$ is weakly preferred to $Y+Z$. If X were not weakly preferred to Y, Totality would give Y strictly preferred to X. The strict clause of Independent Sum Preservation would then give $Y+Z$ strictly preferred to $X+Z$, contradicting the assumed weak comparison. Hence X is weakly preferred to Y.

Notes. Original work: elementary connecting deduction; no model construction or imported theorem proof is needed. Preservation in this project includes STRICT preservation. Under Totality, that extra clause makes preservation equivalent to full Independent Sum Invariance by the already recorded decomposition. Weak preservation alone would not justify this implication. No dominance, mixture independence, stochastic equivalence, continuity, or outcome richness is used.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), 9 September 2026, original strict-order argument in writeups/total-preservation-implies-independent-cancellation.md.
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, unpublished manuscript, 5 June 2026, Lemma 1, pp. 7–8: source for the separated preservation/cancellation principles, not this connecting proof.

- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — Lemma 1, pp. 7–8: source for the separated preservation/cancellation principles, not this connecting proof
- **Background: [Flummoxing expectations](https://doi.org/10.1111/nous.12530).** Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. — §6.1. Source of Independent Sum Consistency; see the principle reference for the changed independence condition. The proof or conjecture recorded here retains its separate attribution.

Record: `topics/unbounded-utility/results/total-preservation-implies-independent-cancellation.yaml`.

<details><summary>Hand-written write-up</summary>

#### Under Totality, strict sum preservation supplies cancellation

**Proved implication:** Totality + Independent Sum Preservation implies
Independent Sum Cancellation.

Let $Z$ be independent of $(X,Y)$, and suppose $X+Z\succeq Y+Z$.
If $X\not\succeq Y$, Totality gives $Y\succ X$. The strict clause of
Independent Sum Preservation then gives $Y+Z\succ X+Z$, which includes
$X+Z\not\succeq Y+Z$. This contradicts the assumption. Therefore
$X\succeq Y$.

Consequently, under DTU, **Independent Sum Preservation is equivalent to
Independent Sum Invariance**: cancellation follows by this argument,
and the existing preservation/cancellation decomposition supplies the
biconditional. In an incomplete preorder, lack of $X\succeq Y$ need not
give $Y\succ X$, so the same reasoning does not apply to the incomplete
CDF-area model.

The current Preservation node demands both weak and strict preservation.
Keeping that strict clause visible is essential to this deduction.

**Original work: elementary connecting deduction.** GPT-6 (Codex),
9 September 2026. The definitions were extracted from Zachary Goodsell,
*Unbounded Utility and Background Risk* (unpublished), Lemma 1, pp. 7–8;
the connecting proof above is recorded under Misc., not attributed to the
manuscript. No independent checker or Lean verification is claimed.

</details>

#### Totality ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ⇒ Uniqueness of Negative Self-Similarity — `totality-independence-negative-affine-imply-self-similarity`

Proved result; source **Misc.**; produced by Zachary Goodsell (source argument); GPT-6 (Codex) (adaptation and premise audit); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean verified; 2026-09-09.

Premises:

- Totality (`totality`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Uniqueness of Negative Self-Similarity (`negative-self-similarity`)

Proof.

Fix p,a,b,Z and write $T(V)=-$aV$+b$ and $F(V)=M_p(T(V),Z)$. Negative Affine Anti-Invariance reverses strict preference under T, while Mixture Independence preserves strict preference between first arguments with the common Z. Hence F reverses strict preference. If $X\sim F(X)$ and $Y\sim F(Y)$ but $X\succ Y$, then $F(Y)\succ F(X)$, so $Y\succ X$ by the two indifferences, a contradiction. The case $Y\succ X$ is symmetric. Totality leaves only $X\sim Y$. The other premises in the original full DTU+Sym package are unused.

Notes. Original work: proof adaptation. Audit Goodsell’s Theorem 10 argument and remove its unused Rich Outcomes, Stochastic Equivalence, Simple EU and Stochastic Dominance premises. This describes the work needed for this database entry, not a claim of novelty in the literature.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), proof adaptation and premise audit in the Logical Maps project, 9 September 2026; see the accompanying handwritten write-up.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 10, pp. 30–31. The cited argument is adapted with the explicitly listed sufficient premises; the reduced-premise claim is the present project contribution.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 10, pp. 30–31. The cited argument is adapted with the explicitly listed sufficient premises; the reduced-premise claim is the present project contribution

Record: `topics/unbounded-utility/results/totality-independence-negative-affine-imply-self-similarity.yaml`.

<details><summary>Hand-written write-up</summary>

#### A smaller sufficient package for Negative Self-Similarity

**Claim.** Totality + Mixture Independence + Negative Affine Anti-Invariance imply Uniqueness of Negative Self-Similarity.

Fix an eligible instance of the principle, with $0<p<1$, $a>0$, $b\in\mathbb R$ and common gamble $Z$. Define, for the variables under consideration,

$$T(V)=-aV+b,\qquad F(V)=M_p(T(V),Z).$$

Negative Affine Anti-Invariance supplies

$$V\succ W\ \Longrightarrow\ T(W)\succ T(V).$$

Indeed, it supplies the weak comparison in this direction, while the opposite weak comparison would imply $W\succeq V$, contradicting strictness. Mixture Independence likewise preserves strictness between first arguments with the same second argument: apply its biconditional to both weak comparison directions. Thus

$$V\succ W\ \Longrightarrow\ F(W)\succ F(V).$$

Suppose now that $X\sim F(X)$ and $Y\sim F(Y)$. If $X\succ Y$, the last implication and the fixed-point indifferences give $Y\succ X$, contradicting the strict part of a preorder. The case $Y\succ X$ is identical. Under Totality, two variables which are not indifferent must be strictly ranked in one of these two directions. Therefore $X\sim Y$.

Only the affine transformations already required by the two fixed-point hypotheses are used. There is no replacement by a same-law variable, no need to construct any additional utility level, and no invocation of expected utility or dominance.

**Original work: proof adaptation.** The mathematical argument is Goodsell's Theorem 10 argument. The new database work is its premise audit: four assumptions from the full source package are unnecessary here. This is not a claim that the uniqueness argument is original to the AI or new in the literature.

**Attribution.** Original uniqueness argument: Zachary Goodsell, *Symmetries of value*, Theorem 10, pp. 30–31. Reduced-premise statement and audit: GPT-6 (Codex), 9 September 2026. No independent checker or Lean proof is claimed.

</details>

#### Totality ⇒ Restricted Totality — `totality-restricts`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean verified; 2026-09-08.

Premises:

- Totality (`totality`)

Conclusion: Restricted Totality (`restricted-totality`)

Proof.

Restrict the quantifiers to simple random variables.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.3, p. 675
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/totality-restricts.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

- **Background: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §2.3, p. 675

Record: `topics/unbounded-utility/results/totality-restricts.yaml`.

#### Universal Copula Sum Invariance ⇒ Antitonic Sum Invariance — `universal-copula-implies-antitonic`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Universal Copula Sum Invariance (`universal-copula-sum-consistency`)

Conclusion: Antitonic Sum Invariance (`antitonic-sum-consistency`)

Proof.

Use the antidiagonal copula, the law of (U,1−U), with $H(u,v)=\max (u+v- 1,0)$. In an antitonic pair one lower-threshold event is an initial uniform interval and the other is a final interval; their intersection has this probability, including for atomic marginals. Both antitonic pairs therefore admit the same copula. $\operatorname{SC}(C)$ applies to the original triple, with no law-invariance premise.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original copula sum consistency definitions and connecting proofs recorded in this project, 9 September 2026, implementing Zachary Goodsell’s proposal.
- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).



Record: `topics/unbounded-utility/results/universal-copula-implies-antitonic.yaml`.

#### Universal Copula Sum Invariance ⇒ Comonotonic Sum Invariance — `universal-copula-implies-comonotonic`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Universal Copula Sum Invariance (`universal-copula-sum-consistency`)

Conclusion: Comonotonic Sum Invariance (`comonotonic-sum-consistency`)

Proof.

Use the diagonal copula, the law of (U,U) for uniform U, with $H(u,v)=\min (u,v)$. For a comonotonic pair, the lower-threshold events are nested up to null sets, so its joint CDF is $\min (F_A(a),F_B(b))$. Thus both comonotonic pairs (X,Z) and (Y,Z) admit this same copula. Applying $\operatorname{SC}(C)$ gives the desired biconditional for the actual X,Y,Z. No replacement of variables in a preference comparison is used.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original copula sum consistency definitions and connecting proofs recorded in this project, 9 September 2026, implementing Zachary Goodsell’s proposal.
- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).



Record: `topics/unbounded-utility/results/universal-copula-implies-comonotonic.yaml`.

#### Universal Copula Sum Invariance ⇒ Existential Copula Sum Invariance — `universal-copula-implies-existential`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean verified; 2026-09-09.

Premises:

- Universal Copula Sum Invariance (`universal-copula-sum-consistency`)

Conclusion: Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

Proof.

The class of bivariate copulas is nonempty: the product of two uniform laws is a copula. Instantiate the universal principle at that copula to obtain one fixed witness for the existential principle.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original copula sum consistency definitions and connecting proofs recorded in this project, 9 September 2026, implementing Zachary Goodsell’s proposal.
- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).



Record: `topics/unbounded-utility/results/universal-copula-implies-existential.yaml`.

#### Universal Copula Sum Invariance ⇒ Independent Sum Invariance — `universal-copula-implies-independent`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Universal Copula Sum Invariance (`universal-copula-sum-consistency`)

Conclusion: Independent Sum Invariance (`independent-sum-consistency`)

Proof.

If Z is independent of (X,Y), it is independent of X and independent of Y. Hence the joint CDFs of (X,Z) and (Y,Z) both factor through the product copula $H(u,v)=$uv. Instantiate Universal Copula Sum Consistency at that copula and apply it to the original triple.

Notes. The converse construction needs care: the product-copula condition gives pairwise independence from Z, which need not be independence from the pair (X,Y).

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original copula sum consistency definitions and connecting proofs recorded in this project, 9 September 2026, implementing Zachary Goodsell’s proposal.
- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).

- **Background: [Flummoxing expectations](https://doi.org/10.1111/nous.12530).** Hayden Wilkinson (2025). Flummoxing expectations. Noûs, 59(3), 700–728. First published online in 2024. — §6.1. Source of Independent Sum Consistency; see the principle reference for the changed independence condition. The proof or conjecture recorded here retains its separate attribution.

Record: `topics/unbounded-utility/results/universal-copula-implies-independent.yaml`.

### 4.2 Conjectures

These are displayed but never used as evidence in any derivation below.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Shift Invariance ⇒ Transfer of a Shift Across a Mixture — `conjectured-dtu-shift-implies-transfer`

Conjecture; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Shift Invariance (`shift-invariance`)

Conclusion: Transfer of a Shift Across a Mixture (`shift-transfer`)

No proof is recorded. This is a conjecture only.

Notes. Original work: conjecture formulation and partial analysis, with a separately recorded countermodel added on 13 September 2026. The candidate asks whether DTU plus Shift Invariance alone implies Shift Transfer, equivalently under DTU Simple Relative Expectation. The recorded neutrality-shift-imply-shift-transfer proof settles the question after adding Symmetric Neutrality. The du-vanishing-shifts-imply-relative proof settles it after adding Continuity under Vanishing Shifts; under DU this is equivalent to L1 Continuity. The independent du-l1-implies-relative proof also supplies the continuity route, without Totality or Shift Invariance. Consequently a separating model would have to fail both neutrality and L1 Continuity. The continuous clipping models already satisfy Relative Expectation; the new lexicographic folded-tail model fails continuity but still satisfies Relative Expectation and neutrality. Neither family supplies the required separation. The new finite-support-compensated-dominance model does separate DU plus Shift Invariance from Shift Transfer, but it violates Totality and therefore does not settle this DTU conjecture. Its explicit transfer and vanishing-shift continuity failures are proved in its write-up. Its finite-shift-total-extension now supplies Totality while strictly ordering the same transfer pair. The new proof checks finite-kernel saturation and preserves the indifferent subspace through the orientation and maximal-extension steps. The original implication, ID, empty proof and conjectured status remain unchanged: the viewer computes refutation from this separate proved model. Stronger backgrounds can still prove the conditional implication, and source filters can remove its refuting evidence. Conjectured records question history, not a claim that the current full evidence leaves it open.

Sources:

- **GPT-6 question 9 Sep** — GPT-6 (Codex), 9 September 2026, follow-up DU investigation; precise unresolved implication and partial analysis in writeups/conjectured-dtu-shift-implies-transfer.md.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37, DOI 10.1111/nous.12549, Theorems 3–4, pp. 25–27: source for Shift Transfer and its derivation with full affine symmetry, not this conjecture.
- **Goodsell/GPT-6 countermodel 13 Sep** — Zachary Goodsell (finite-shift extension proposal) and GPT-6 (Codex) (countermodel and extension proof), Logical Maps, 13 September 2026: the separately recorded model finite-shift-total-extension refutes this implication under its stated premises; see writeups/finite-shift-total-extension.md.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorems 3–4, pp. 25–27: source for Shift Transfer and its derivation with full affine symmetry, not this conjecture

Record: `topics/unbounded-utility/results/conjectured-dtu-shift-implies-transfer.yaml`.

<details><summary>Hand-written write-up</summary>

#### Does DTU plus Shift Invariance imply Shift Transfer?

**Recorded countermodel, 13 September 2026.**
[Stochastic dominance: finite-shift total extension](finite-shift-total-extension.html)
satisfies every premise below and strictly orders a pair that Shift Transfer
requires to be indifferent. It therefore refutes the implication under its
stated premises. The original conjecture ID, statement, and conjectured
status are retained; the Conjectures tab computes its answer from the
separate model. Source filters can remove that evidence, and stronger
backgrounds can prove the conditional implication.

Zachary Goodsell proposed the finite-shift conclosure and separating total
extension. GPT-6 (Codex) supplied the witness and the proof that saturation
and maximal extension preserve its strict comparison. The model's write-up
records the construction, attribution, and checks; no independent checker
or Lean verification is claimed.

The question was formulated by GPT-6 (Codex), 9 September 2026. The principles
and the stronger affine-symmetry derivations are Zachary Goodsell's
*Symmetries of value*, Theorems 3–4, pp. 25–27; the paper is not attributed
this reduced-premise conjecture. The original analysis identified the
remaining gap and checked the model families then available.

With all six DTU axioms assumed, does

\[
X\succeq Y\quad\Longleftrightarrow\quad X+b\succeq Y+b
\quad\text{for every real }b
\]

already force

\[
M_p(X+b/p,Y)\sim M_p(X,Y+b/(1-p))
\quad(0<p<1)?
\]

Under DTU, the recorded implications make the latter equivalent to Simple
Relative Expectation, so the question can equally be read as whether a
common-shift symmetry determines comparisons under every simple pointwise
perturbation.

Two additional hypotheses settle it:

- **Symmetric Neutrality:** the new
  [neutrality-and-shift proof](neutrality-shift-imply-shift-transfer.md)
  centers paired laws, then cancels a common mixture branch. Scale Invariance
  is unnecessary, but the neutral value of the centered laws is essential
  to that proof.
- **Continuity under Vanishing Shifts:** the
  [common-mixture proof](du-vanishing-shifts-imply-relative.html) gives
  Relative Expectation already under DU, without Totality or a prior
  shift-symmetry assumption. This implies Simple Relative Expectation and
  Shift Transfer. Under DU, this continuity condition is equivalent to
  $L^{1}$ Continuity; a separate
  [conditional-approximation proof](du-l1-implies-relative.html) also
  establishes the $L^{1}$ route.

A countermodel must therefore fail **both** Symmetric Neutrality and $L^{1}$
Continuity. The symmetric and asymmetric continuous clipping models already
satisfy Relative Expectation and so cannot separate the question. The
[Folded-tail cone: lexicographic extension](lexicographic-folded-extension.md) does fail
$L^{1}$ Continuity, but retains neutrality and Relative Expectation, so it also
satisfies transfer. The exact clipping records do not establish the required
Shift Invariance and cannot simply be claimed as counterexamples.

The earlier
[Stochastic dominance: finite-support compensation](finite-support-compensated-dominance.html)
model does satisfy DU and Shift Invariance while violating Shift Transfer,
with the explicit pair $M_{1/2}(U+1,0)$ and $M_{1/2}(U,1)$ for uniform
$U$ on $[0,1]$. It also violates Totality, so it settles the version with
DU but does not itself supply a total countermodel. Its failure of continuity
under vanishing shifts is witnessed by $U+\varepsilon\succeq1/2$ for every
$\varepsilon>0$ while $U$ is incomparable with $1/2$.

The [finite-shift total extension](finite-shift-total-extension.html)
supplies the missing Totality while preserving a strict ranking of that
same pair. Finite-kernel saturation leaves the pair incomparable initially;
adjoining one orientation and saturating again preserves the indifferent
subspace exactly. A maximal saturated cone with that fixed subspace is
total, retains every common shift, and keeps the chosen comparison strict.
Thus the refutation is supplied by an actual existence model and an
explicit failed transfer instance.

</details>

#### Countable Sure-Thing ∧ Archimedean Outcomes ⇒ Archimedean Gambles — `countable-sure-thing-outcomes-to-gambles`

Conjecture; source **Misc.**; produced by User suggestion, 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Countable Sure-Thing (`countable-sure-thing`)
- Archimedean Outcomes (`archimedean-outcomes`)

Conclusion: Archimedean Gambles (`archimedean-gambles`)

No proof is recorded. This is a conjecture only.

Notes. Refuted on the standing full measurable domain by the proved lexicographic-nonatomic-mass model, supplied by GPT-6 (Codex) on 13 September 2026. It satisfies both proposed premises, as well as Totality, Stochastic Equivalence, Stochastic Dominance, Mixture Independence and Sure-Thing, while violating both Expected Utility and Archimedean Gambles. Its outcome chart is [0,1], so Rich Outcomes fails; that principle is not a premise of this question. The Russell–Isaacs theorem concerns countably supported lotteries: its domain excludes the nonatomic witness used here. The original ID, premises, authorship and conjectured status are preserved. Refutation is computed from the separate proved model and selected background; under DU or DTU the premises instead conflict with the background. See the handwritten write-up for the witness and source comparison. No independent checking or Lean proof is claimed.

Sources:

- **User suggestion 8 Sep** — User suggestion in this project's conversation, 2026-09-08; proposed implication, not a completed proof.
- **Infinite Prospects (domain comparison)** — Related discrete-lottery theorem, not a theorem of this full-domain arrow: Jeffrey Sanford Russell and Yoaav Isaacs, Infinite Prospects, Philosophy and Phenomenological Research 103 (2021), 178–198, DOI 10.1111/phpr.12704. Author-hosted manuscript, §§4–5 and Appendix A, especially pp. 15, 22, 25: https://www.yoaavisaacs.com/uploads/6/9/2/0/69204575/infinite-prospects-final.pdf
- **GPT-6 countermodel 13 Sep** — GPT-6 (Codex), Logical Maps, 13 September 2026: full-domain refutation in writeups/lexicographic-nonatomic-mass.md and source comparison in writeups/countable-sure-thing-outcomes-to-gambles.md.

- **Background: [Infinite prospects](https://doi.org/10.1111/phpr.12704).** Russell, J. S., & Isaacs, Y. (2021). Infinite prospects. Philosophy and Phenomenological Research, 103(1), 178–198. — §§4–5 and Appendix A, especially pp. 15, 22, 25: https://www.yoaavisaacs.com/uploads/6/9/2/0/69204575/infinite-prospects-final.pdf

Record: `topics/unbounded-utility/results/countable-sure-thing-outcomes-to-gambles.yaml`.

<details><summary>Hand-written write-up</summary>

#### Countable Sure-Thing and Archimedean Outcomes ⇒ Archimedean Gambles?

**Refuted on the full measurable domain.** The original two-premise
proposal is preserved, with refutation supplied by the proved
[Lexicographic expectation: nonatomic mass](lexicographic-nonatomic-mass.html)
model. The model satisfies both stated premises and violates the
conclusion.

Take outcomes $[0,1]$ and rank all measurable gambles lexicographically by

$$V(X)=\bigl(E[X],c(\mathcal L(X))\bigr),$$

where $c$ is the total mass of the nonatomic part of a law. The linked
write-up proves Countable Sure-Thing for every countable measurable
partition, including the strict clause.

For $U$ uniform on $[0,1]$, the model has $1\succ U\succ0$, but
$V(M_p(1,0))=(p,0)$ never equals $V(U)=(1/2,1)$. Nevertheless its sure
outcomes satisfy Archimedean Outcomes.

The model also satisfies Totality, Stochastic Equivalence, Stochastic
Dominance, Mixture Independence and Sure-Thing. It violates Rich Outcomes.
With DU or DTU selected, Countable Sure-Thing instead conflicts with the
background by the recorded St Petersburg obstruction.

**Attribution and conjecture history.** Zachary Goodsell proposed this
arrow on 8 September 2026. GPT-6 (Codex) supplied the countermodel on
13 September, following Goodsell's request for proofs and a source check.
The original implication keeps its ID, premises and conjectured status;
the viewer computes its verdict from proved evidence and the selected
background. No independent checker or Lean proof is claimed.

**Russell–Isaacs source comparison.** *Infinite Prospects*, §§4–5 and
Appendix A, treats countably supported lotteries and complete
preferences. Its passage from acts to lotteries uses conditional-law
dependence. See the author's April 2020 manuscript, pp. 15–16, 22 and
25–26:
[author's manuscript](https://www.yoaavisaacs.com/uploads/6/9/2/0/69204575/infinite-prospects-final.pdf).
In the new model, $c$ vanishes on every countably supported law. Its
restriction to that domain is ordinary bounded EU; the counterexample
uses a nonatomic law. The published theorem therefore does not establish
the full-domain arrow recorded here.

</details>

#### Countable Sure-Thing ∧ Simple Expected Utility ⇒ Expected Utility — `countable-sure-thing-simple-to-full-eu`

Conjecture; source **Misc.**; produced by User suggestion, 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Countable Sure-Thing (`countable-sure-thing`)
- Simple Expected Utility (`simple-eu`)

Conclusion: Expected Utility (`expected-utility`)

No proof is recorded. This is a conjecture only.

Notes. Refuted on the standing full measurable domain by the proved lexicographic-nonatomic-mass model, supplied by GPT-6 (Codex) on 13 September 2026. It satisfies both proposed premises, as well as Totality, Stochastic Equivalence, Stochastic Dominance, Mixture Independence and Sure-Thing, while violating both Expected Utility and Archimedean Gambles. Its outcome chart is [0,1], so Rich Outcomes fails; that principle is not a premise of this question. The Russell–Isaacs theorem concerns countably supported lotteries: its domain excludes the nonatomic witness used here. The original ID, premises, authorship and conjectured status are preserved. Refutation is computed from the separate proved model and selected background; under DU or DTU the premises instead conflict with the background. See the handwritten write-up for the witness and source comparison. No independent checking or Lean proof is claimed.

Sources:

- **User suggestion 8 Sep** — User suggestion in this project's conversation, 2026-09-08; proposed implication, not a completed proof.
- **Decision Theory Unbound** — Related motivation rather than a verified theorem with these exact premises: Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695, DOI 10.1111/nous.12473, §4.1, pp. 685–686.
- **GPT-6 countermodel 13 Sep** — GPT-6 (Codex), Logical Maps, 13 September 2026: full-domain refutation in writeups/lexicographic-nonatomic-mass.md and source comparison in writeups/countable-sure-thing-simple-to-full-eu.md.

- **Background: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — §4.1, pp. 685–686
- **Background: [Infinite prospects](https://doi.org/10.1111/phpr.12704).** Russell, J. S., & Isaacs, Y. (2021). Infinite prospects. Philosophy and Phenomenological Research, 103(1), 178–198. — §2. Source of the Countable Sure-Thing principle; the recorded result or conjecture has its own attribution.

Record: `topics/unbounded-utility/results/countable-sure-thing-simple-to-full-eu.yaml`.

<details><summary>Hand-written write-up</summary>

#### Countable Sure-Thing and Simple EU ⇒ Expected Utility?

**Refuted on the full measurable domain.** The original two-premise
proposal is preserved, with refutation supplied by the proved
[Lexicographic expectation: nonatomic mass](lexicographic-nonatomic-mass.html)
model. The model satisfies both stated premises and violates the
conclusion.

Take outcomes $[0,1]$ and rank all measurable gambles lexicographically by

$$V(X)=\bigl(E[X],c(\mathcal L(X))\bigr),$$

where $c$ is the total mass of the nonatomic part of a law. The linked
write-up proves Countable Sure-Thing for every countable measurable
partition, including the strict clause.

For $U$ uniform on $[0,1]$, the model has $U\succ1/2$ despite equal
finite expected utilities. Every simple law has second coordinate zero,
so Simple EU holds with the unique normalized chart $u(x)=x$.

The model also satisfies Totality, Stochastic Equivalence, Stochastic
Dominance, Mixture Independence and Sure-Thing. It violates Rich Outcomes.
With DU or DTU selected, Countable Sure-Thing instead conflicts with the
background by the recorded St Petersburg obstruction.

**Attribution and conjecture history.** Zachary Goodsell proposed this
arrow on 8 September 2026. GPT-6 (Codex) supplied the countermodel on
13 September, following Goodsell's request for proofs and a source check.
The original implication keeps its ID, premises and conjectured status;
the viewer computes its verdict from proved evidence and the selected
background. No independent checker or Lean proof is claimed.

**Russell–Isaacs source comparison.** *Infinite Prospects*, §§4–5 and
Appendix A, treats countably supported lotteries and complete
preferences. Its passage from acts to lotteries uses conditional-law
dependence. See the author's April 2020 manuscript, pp. 15–16, 22 and
25–26:
[author's manuscript](https://www.yoaavisaacs.com/uploads/6/9/2/0/69204575/infinite-prospects-final.pdf).
In the new model, $c$ vanishes on every countably supported law. Its
restriction to that domain is ordinary bounded EU; the counterexample
uses a nonatomic law. The published theorem therefore does not establish
the full-domain arrow recorded here.

</details>

## 5. Models

A model witnesses consistency, and so refutes every implication from what it satisfies to what it violates. Independence is never recorded directly; the model is the record.

### Signed-measure cone: affine-symmetric extension — `affine-symmetric-extension`

Model; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- L¹ Continuity (random variables) (`l1-continuity`)

Violates:

- Countable Sure-Thing (`countable-sure-thing`)
- Archimedean Gambles (`archimedean-gambles`)

Unknown in this model: Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

Construction.

Goodsell (2026), Theorem 2 constructs a total preference satisfying DTU, both affine symmetry principles, and $L^{1}$ Continuity. Start with the cone of Theorem 12, use Theorem 13 to extend any nontotal cone while preserving convexity, scale and reflection, and apply Zorn’s lemma. Fixed required comparisons preserve finite EU, dominance and prospect shifts; the end of §5 asserts preservation of $L^{1}$ Continuity. Pull the resulting ordering back from laws to all real-valued random variables. The two violations follow from the explicit St Petersburg witnesses in this topic. See the write-up for the scope of this source-based existence certificate.

Notes. This is a nonconstructive existence model, not an implemented comparator. Its existence and $L^{1}$ clause are source-attributed. No numerical test is claimed to verify Zorn’s lemma or the source proof.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 2, p. 24; Theorems 12–13 and end of §5, pp. 35–36

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 2, p. 24; Theorems 12–13 and end of §5, pp. 35–36

Record: `topics/unbounded-utility/models/affine-symmetric-extension.yaml`.

Write-up.

#### Signed-measure cone: affine-symmetric extension

Source: Goodsell, *Symmetries of value*, Theorem 2 (p. 24), with the
construction in Theorems 12–13 and the end of §5 (pp. 35–36).
Human model: Zachary Goodsell. Recorded and translated by GPT-6 (Codex);
no transcription checker asserted.

Theorem 2 asserts the consistency of DTU + Sym $+ L^{1}$ Continuity. The source
constructs the ordering on probability laws via cones in the real vector
space of finite signed measures, then extends a partial ordering to a total
one. Signed measures are auxiliary proof objects, not this topic's gambles.

More specifically, Theorem 12 supplies a cone C that has the required finite
EU, dominance, scale, reflection, and prospect-shift properties, without
Totality. Theorem 13 says that a nontotal convex cone satisfying scale and
reflection has a proper extension preserving those properties and all its
existing weak and strict comparisons. Unions of chains preserve these
properties, so Zorn's lemma supplies a maximal extension. If it were nontotal,
Theorem 13 would extend it again, contradiction. Fixed required comparisons
for finite EU, dominance, and prospect shifts survive extensions. The end of
§5 asserts that the constructed model also has $L^{1}$ Continuity.

Pull the source's resulting preorder on probability laws back along X↦$L(X)$
on the domain of all real-valued random variables. Reflexivity, transitivity,
and Totality pull back immediately, and Stochastic Equivalence holds by
construction. The source's bijective utility representation supplies both
Rich Outcomes and this topic's Simple EU. Randomized-selection laws give
Mixture Independence, and utility transformations give the stated affine
symmetries. The $L^{1}$ translation write-up transfers source continuity to the
random-variable clause. This verifies that the cited existence theorem
applies to precisely the package listed in the model record.

The recorded St Petersburg implications then show that Countable Sure-Thing
and Archimedean Gambles fail in this model, while Archimedean Outcomes holds.
It also witnesses that adding the symmetries and $L^{1}$ is compatible with all the
evaluations extracted from §4.

This certificate is a **source theorem application and domain translation**.
It is not an implementation of the nonconstructive ordering or an independent
audit of the source's cone-extension theorem and continuity argument. No
numerical check can establish those existence claims.

### Clipped expectation: continuous ultrafilter dominance [−t, 2t] — `asymmetric-continuous-ultrafilter`

Model; source **Symmetries of Value**; produced by Zachary Goodsell (construction and source non-implication); GPT-6 (Codex) (explicit specialization and additional property calculations); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Expected Utility (`expected-utility`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Relative Expectation (`relative-expectation`)
- CDF-Area Extension (`cdf-area-extension`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)

Violates:

- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Folded Expectation (`folded-expectation`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)

Unknown in this model: Arroyo = ln 2 (`arroyo-value`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Scale Invariance (`scale-invariance`)

Construction.

Take all real-valued random variables and $q_t(x)=\max (-t,\min (x,2t))$. For a cobounded ultrafilter U on $t>0$, put $X\succeq Y$ iff for every $\epsilon >0$ the set $\{t:E[q_t(X)]\ge E[q_t(Y)]- \epsilon \}$ belongs to U. The continuous quotient preserves DTU, finite $\operatorname{EU}, L^{1}$ Continuity, Relative Expectation, CDF-Area Extension, Shift Invariance, and Transfer of a Shift Across a Mixture. A standard symmetric Cauchy variable has value $\ln (2)/\pi >0$, violating neutral symmetry, reflection and Folded Expectation. It and zero provide distinct fixed values for the negative self-similarity map X↦$M_{1/2}(- 2X,0)$. Paired atoms give Alternating St Petersburg value zero. The accompanying write-up proves every recorded flag.

Executable checks: `topics/unbounded-utility/checks/asymmetric_continuous_ultrafilter.py`, `topics/unbounded-utility/checks/comonotonic_witnesses.py`.

Notes. Original work: source-model specialization and additional verification. The asymmetric construction and the non-implication of reflection even under DTU $+ L^{1}$ Continuity + Relative Expectation are already Goodsell’s: Symmetries of value, Theorem 1 (p. 24), citing Decision theory unbound, Remark 3. They are not new AI results. The 2024 paper supplies the continuous quotient and separate increasing cutoffs; Corollary 3 already permits nonzero values for symmetric gambles. Work recorded here chooses $f(t)=2t$ and $g(t)=t$ and spells out the CDF-area/shift-transfer verification and exact Cauchy, alternating-game and negative-self-similarity witnesses. These added calculations are not a claim of literature novelty. No scale or sum-invariance verdict is asserted without proof. Diagnostic checks do not certify the general axioms or ultrafilter existence.

Revisions:

- **2026-09-23** (Claude (Fable 5.1)) — Comonotonic Sum Invariance shown to fail (write-up section “Failure of Comonotonic Sum Invariance”). Y = C − ln(2)/π is indifferent to sure 0, but with the common comonotonic summand Z = max(C,0) the clipped gap between 0 + Z and Y + Z tends to (2 ln 2)/π, so 0 + Z ≻ Y + Z. Now violates: Comonotonic Sum Invariance.

Sources:

- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 1, p. 24. Already states the failure of affine-symmetry implications under DTU, including with L¹ Continuity and Relative Expectation, and cites Decision theory unbound, Remark 3, for the reflection countermodel.
- **GPT-6 generated 9 Sep** — GPT-6 (Codex), explicit source-model specialization and additional calculations, 9 September 2026; writeups/asymmetric-continuous-ultrafilter.md, in response to Zachary Goodsell's request to investigate consequences and countermodels from DU.
- **Decision Theory Unbound** — Zachary Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, Appendix B, Definition 3, Lemma 6 and proof of Theorem 3, pp. 691–692; Remark 3 and Corollary 3, pp. 692–693. Source of the clipped-expectation ultrafilter, continuous quotient, and asymmetric-cutoff strategy, including the possibility of assigning nonzero values to symmetric gambles.
- **Claude comonotonic failure 23 Sep** — Claude (Fable 5.1), Logical Maps, 23 September 2026: failure of Comonotonic Sum Invariance (half-Cauchy common summand) in writeups/asymmetric-continuous-ultrafilter.md; diagnostic checks/comonotonic_witnesses.py.

- **Proof: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 1, p. 24. Already states the failure of affine-symmetry implications under DTU, including with L¹ Continuity and Relative Expectation, and cites Decision theory unbound, Remark 3, for the reflection countermodel
- **Background: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — Appendix B, Definition 3, Lemma 6 and proof of Theorem 3, pp. 691–692; Remark 3 and Corollary 3, pp. 692–693. Source of the clipped-expectation ultrafilter, continuous quotient, and asymmetric-cutoff strategy, including the possibility of assigning nonzero values to symmetric gambles

Record: `topics/unbounded-utility/models/asymmetric-continuous-ultrafilter.yaml`.

Write-up.

#### Clipped expectation: continuous ultrafilter dominance [−t, 2t]

**Direct source: Symmetries of Value.** Zachary Goodsell’s *Symmetries of
value*, Theorem 1 (p. 24), already states that DTU does not imply the affine
symmetry principles, including when $L^{1}$ Continuity and Relative Expectation
are added. Its reflection countermodel explicitly invokes *Decision theory
unbound*, Remark 3. Thus both the asymmetric construction and this stronger
non-implication belong to Goodsell; they are not new AI results.

The underlying continuous quotient appears in *Decision theory unbound*,
Appendix B, Definition 3, Lemma 6 and proof of Theorem 3 (pp. 691–692).
Remark 3 and Corollary 3 (pp. 692–693) supply separate increasing unbounded
cutoffs and symmetric gambles with arbitrary real values, including nonzero
ones.

**Original work: source-model specialization and additional verification.**
GPT-6 (Codex), 9 September 2026, chose the explicit cutoffs $f(t)=2t, g(t)=t$
and recorded the detailed proofs below. The added work is the displayed
CDF-area and shift-transfer verification, exact Cauchy and alternating-game
values, and negative-self-similarity witness. The $L^{1}/$Relative Expectation
non-implication is already stated in the source; its proof here is an explicit
verification, not a newly discovered separation. No literature-novelty claim,
independent checker or Lean verification is asserted.

##### Construction and the DTU axioms

Take $O=\mathbb R$ with its usual order, Borel structure and identity utility,
and all measurable real random variables on the topic's fixed probability
space. Put

$$q_t(x)=\max(-t,\min(x,2t)),\qquad
v_X(t)=E[q_t(X)],\qquad t>0.$$

Fix an ultrafilter $\mathcal U$ on $(0,\infty)$ containing every tail
$(s,\infty)$. Define

$$X\succeq Y\quad\Longleftrightarrow\quad
\forall\varepsilon>0,\quad
\{t:v_X(t)-v_Y(t)\ge-\varepsilon\}\in\mathcal U.\tag{1}$$

Existence of this ultrafilter uses the usual ultrafilter lemma, as in the
source construction; this is a mathematical existence model, not an
implemented algorithm for arbitrary comparisons.

Reflexivity is immediate. For transitivity, intersect the two large sets
obtained with $\varepsilon/2$. If $X\not\succeq Y$, there is an
$\varepsilon>0$ such that $v_Y-v_X>\varepsilon$ on a large set.
Consequently $Y\succeq X$, proving **Totality**.

Equal laws have equal $v$-functions, so **Stochastic Equivalence** holds.
Constants and all values of each simple gamble eventually lie inside the
clipping window. Their comparisons are therefore exactly their ordinary
expectation comparisons. The normalized chart is the identity: the binary
calibration equations give the usual real values. This proves **Rich
Outcomes** and **Simple Expected Utility**, including all standing chart
conventions.

For the fixed randomized mixture, equality of its law with the mixture law
gives

$$v_{M_p(X,Z)}=p v_X+(1-p)v_Z.$$

Subtracting the corresponding expression with $Y$ and rescaling
$\varepsilon$ by $p>0$ proves the full **Mixture Independence** biconditional.

Write $S_X(s)=\Pr(X>s)$. The elementary clipped-tail identity gives

$$v_X(t)-v_Y(t)=\int_{-t}^{2t}(S_X(s)-S_Y(s))\,ds.\tag{2}$$

If $S_X\ge S_Y$ pointwise, this is nonnegative. If an inequality is strict
at a threshold, right continuity supplies an interval where the difference
is bounded below by a positive constant. All sufficiently large windows
contain that interval, giving a fixed strictly positive gap in (2). Thus
(1) preserves both weak and strict **Stochastic Dominance**. These
verifications establish the entire DTU package.

Two useful consequences of (1) will be used below. Adding a function tending
to zero to $v_X-v_Y$ does not change the comparison, by an
$\varepsilon/2$ argument. If $v_X-v_Y$ tends to a finite number $r$, the
comparison holds exactly when $r\ge0$; when the limit is zero both directions
hold. A limit of $+\infty$ or $-\infty$ yields the corresponding strict
comparison.

##### Expectation, CDF area, and continuity

For integrable $X$, $q_t(X)\to X$ pointwise and $|q_t(X)|\le |X|$.
Dominated convergence gives $v_X(t)\to E[X]$. The preceding limit criterion
proves **Expected Utility**.

Clipping is 1-Lipschitz. Whenever $E|X-Y|<\infty$,

$$q_t(X)-q_t(Y)\longrightarrow X-Y,\qquad
|q_t(X)-q_t(Y)|\le |X-Y|.$$

Hence $v_X-v_Y\to E[X-Y]$, even when the individual expectations do not
exist. The limit criterion proves **Relative Expectation** for the variables'
actual coupling, without replacing that coupling by a more convenient one.

For **CDF-Area Extension**, put $d=S_X-S_Y$ and
$A_\pm=\int_{\mathbb R}d_\pm$. The nested windows $[-t,2t]$ exhaust
$\mathbb R$, so their positive and negative integrals tend monotonically to
$A_+$ and $A_-$. If at least one area is finite, (2) tends to their
well-defined difference in the extended reals. If both are finite and equal,
the limit is zero; if the positive area is larger, including the case of a
single positive infinity, the limit is positive; the reverse cases are
negative. Thus $X\succeq Y$ holds exactly when $A_+\ge A_-$ in every case
specified by the principle. Nothing here specifies the both-infinite pairs.

For **L¹ Continuity**, suppose $\delta_n=E|X_n-X|\to0$ and
$X_n\succeq Y$ for every $n$. The Lipschitz property gives

$$|v_{X_n}(t)-v_X(t)|\le\delta_n\quad\text{for every }t.$$

Fix $\varepsilon>0$, and choose $n$ with $\delta_n<\varepsilon/2$.
On a large set, $v_{X_n}-v_Y\ge-\varepsilon/2$, hence
$v_X-v_Y\ge-\varepsilon$. This is precisely (1) for $X\succeq Y$.
The proof verifies the topic's upper-section clause on the full domain,
including nonintegrable $X$ and $Y$.

##### Shifts

For each fixed real $b$ and arbitrary $X$,

$$q_t(X+b)-q_t(X)\longrightarrow b,\qquad
|q_t(X+b)-q_t(X)|\le |b|.$$

Dominated convergence gives $v_{X+b}-v_X\to b$. Simultaneously shifting
$X,Y$ therefore changes their comparison function by a function tending to
zero. This proves **Shift Invariance**, in both directions.

For $0<p<1$, subtract the values of the two mixtures in **Transfer of a
Shift Across a Mixture**:

$$\begin{aligned}
&v_{M_p(X+b/p,Y)}-v_{M_p(X,Y+b/(1-p))}\\
&\qquad=p(v_{X+b/p}-v_X)
 -(1-p)(v_{Y+b/(1-p)}-v_Y)\longrightarrow b-b=0.
\end{aligned}$$

The mixtures are therefore indifferent. Neither shift conclusion has used
reflection symmetry or finite individual expectations.

##### A symmetric Cauchy has positive value

Let $C_\sigma$ have the symmetric Cauchy density
$\sigma/[\pi(\sigma^2+x^2)]$, where $\sigma>0$. Such a variable is available
on the fixed atomless probability space. Direct integration over the window
and its two clipped tails gives

$$v_{C_\sigma}(t)=
\frac{\sigma}{2\pi}\log\frac{\sigma^2+4t^2}{\sigma^2+t^2}
+\frac{2t}{\pi}\arctan\frac{\sigma}{2t}
-\frac{t}{\pi}\arctan\frac{\sigma}{t}
\longrightarrow \frac{\sigma\log2}{\pi}.\tag{3}$$

Indeed the logarithmic term tends to $\sigma\log2/\pi$, while the last
two terms each tend in magnitude to $\sigma/\pi$ and cancel. Put
$k=\log2/\pi>0$. Equation (3) yields $C_1\sim k\succ0$.

This one comparison proves three failures:

- **Symmetric Gambles Are Neutral** fails: $C_1$ and $-C_1$ have the same
  law but $C_1\not\sim0$.
- **Reflection Anti-Invariance** fails: $C_1\succeq0$, whereas
  $0\not\succeq-C_1$. Its special case $a=1,b=0$ also directly refutes
  **Negative Affine Anti-Invariance**.
- **Folded Expectation** fails: both $C_1$ and zero have identically zero
  combined symmetric tail difference, so that principle would require
  them to be indifferent.

For **Uniqueness of Negative Self-Similarity**, take
$p=1/2$, $a=2$, $b=0$, and $Z=0$. The variables $-2C_1$ and $C_2$ have
the same law. By (3) and mixture linearity,

$$v_{M_{1/2}(-2C_1,0)}\longrightarrow\tfrac12(2k)=k,
\qquad C_1\sim M_{1/2}(-2C_1,0).$$

Zero also satisfies $0\sim M_{1/2}(-2\cdot0,0)$. The two fixed values
are distinct because $C_1\succ0$. This refutes precisely the recorded
uniqueness principle.

##### Alternating St Petersburg is zero

Let $A$ take $(-2)^n$ with probability $2^{-n}$, $n\ge1$. Group consecutive
odd and even indices. Each pair has a negative outcome $-a$ of probability
$2r$ and positive outcome $2a$ of probability $r$, where $a,r>0$.
For every $t>0$,

$$q_t(-a)=-\min(a,t),\qquad q_t(2a)=2\min(a,t),$$

so the pair contributes exactly zero. Clipping makes the expectation
absolutely integrable, which licenses grouping the countably many pairs.
Thus $v_A(t)=0$ for every $t$, and $A\sim0$. In particular
**Alternating St Petersburg = −1/2** fails.

##### Scope of the verification

This model establishes, among other separations, that DTU together with
CDF-Area Extension, Relative Expectation, $L^{1}$ Continuity, and both shift
principles still does not force symmetric neutrality or reflection. No
scale or sum-invariance verdict has been inferred from this construction.
The map can derive further failures from its separately proved
incompatibility records.

`checks/asymmetric_continuous_ultrafilter.py` checks the paired-atom
cancellations with exact rational arithmetic, finite-law clipped-tail and
mixture identities, the Lipschitz bound, and the explicit Cauchy limits.
Those checks are sanity checks of concrete calculations; the universal
properties and ultrafilter comparisons are proved analytically above.

##### Failure of Comonotonic Sum Invariance

**Addition: Claude (Fable 5.1), 23 September 2026.** A property of the
recorded model; not a claim of the source papers.

Realize a standard Cauchy variable as $C=Q_C(U)=\tan(\pi(U-\tfrac12))$ and
put $X=0$, $Y=C-\ln(2)/\pi$, $Z=C_+=\max(C,0)$; all are nondecreasing in
$U$, so both pairs $(X,Z)$, $(Y,Z)$ are comonotonic. By the Cauchy
calculation above, $\mathbb E[q_t(C)]\to\ln(2)/\pi$, and
$q_t(C-v)-q_t(C)\to-v$ boundedly, so $\mathbb E[q_t(Y)]\to0$ and $X\sim Y$.

**Doubling-defect identity.** For any nonnegative random variable $V$ and
any $F>0$,

$$2\,\mathbb E[\min(V,F)]-\mathbb E[\min(2V,F)]
 =2\int_{F/2}^{F}P(V>x)\,dx,$$

since $\mathbb E[\min(V,F)]=\int_0^F P(V>x)\,dx$ and
$\mathbb E[\min(2V,F)]=2\int_0^{F/2}P(V>x)\,dx$. For $V=C_+=\max(C,0)$ with
$C$ standard Cauchy the right-hand side is
$\frac2\pi\int_{F/2}^{F}\arctan(1/x)\,dx$, which is positive for every $F$
and increases to $\frac{2\ln2}{\pi}$ as $F\to\infty$.

Write $m(F)=\mathbb E[\min(C_+,F)]$ and $C_-=\min(C,0)$. Then
$X+Z=C_+$ and $Y+Z=2C_++C_--\ln(2)/\pi$, and with the window $[-t,2t]$,

$$\mathbb E[q_t(C_+)]=m(2t),\qquad
\mathbb E[q_t(2C_++C_-)]=2m(t)-m(t)=m(t),\qquad
\mathbb E[q_t(C)]=m(2t)-m(t).$$

Hence, using the bounded shift once more,

$$v_{X+Z}(t)-v_{Y+Z}(t)=m(2t)-m(t)+\frac{\ln2}{\pi}+o(1)
 =2\bigl(m(2t)-m(t)\bigr)+o(1)\longrightarrow\frac{2\ln2}{\pi}.$$

With $\varepsilon=(\ln2)/\pi$ the set $\{t:v_{Y+Z}(t)\ge v_{X+Z}(t)-\varepsilon\}$
is bounded, so $X+Z\succ Y+Z$ although $X\sim Y$: Comonotonic Sum Invariance
fails, while both shift principles hold. `checks/comonotonic_witnesses.py`
verifies the closed forms, the neutral constant and the limit.

### CDF-area dominance — `cdf-area-preorder`

Model; source **Unbounded Utility and Background Risk (unpublished)**; produced by Zachary Goodsell (unpublished manuscript); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; Lean stated; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Expected Utility (`expected-utility`)
- Relative Expectation (`relative-expectation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)

Violates:

- Totality (`totality`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Folded Expectation (`folded-expectation`)
- Full Sum Invariance (`full-sum-consistency`)
- Antitonic Sum Invariance (`antitonic-sum-consistency`)

Unknown in this model: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`)

Construction.

Use real outcomes with their identity utility. For $d=S_X- S_Y$, define $X \succeq R Y$ iff $\int d_{-}<\infty$ and $\int d_{+}\ge \int d_{-}$. This is the manuscript’s explicit base preorder, satisfying DU but not DTU because Totality fails. Its elementary properties, comonotonic sum consistency, and forward independent-sum preservation are established in the accompanying write-up, with the quantile-area argument made valid for infinite areas. The draft’s proof does not establish reverse independent-sum cancellation, so full Independent Sum Invariance is not asserted. Symmetric Cauchy versus zero has both areas infinite, witnessing incompleteness and failure of Symmetric Neutrality and Folded Expectation. The St Petersburg arguments supply the two sum-consistency violations.

Executable checks: `topics/unbounded-utility/checks/background_risk.py`.

Notes. This is the concrete base construction, not the draft’s withdrawn total symmetric extension. Strict comparisons are part of the construction. No claim that convolution cancellation is false is inferred from a gap in its proof. The L1 Continuity flag is established by the separately attributed elementary closure proof in the write-up; it is not attributed to a theorem stated in the manuscript.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §3, pp. 7–8; Theorems 6–7, pp. 19–20
- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proofs recorded 9 September 2026 in this project; explicit quantile-area/Tonelli details, Cauchy witnesses, and the L1 closure proof in writeups/cdf-area-preorder.md

- **Proof: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §3, pp. 7–8; Theorems 6–7, pp. 19–20

Record: `topics/unbounded-utility/models/cdf-area-preorder.yaml`.

Write-up.

#### CDF-area dominance

This is a model of **DU**, but not **DTU**, because Totality fails.

It is also the **least DU preorder with L¹ Continuity**, equivalently with
Continuity under Vanishing Shifts. The continuity verification below and
the new [DU continuity theorem](du-vanishing-shifts-imply-relative.html)
establish this: every such ordering preserves all of this model's weak
and strict comparisons. Extensions can add comparisons for pairs with
both signed areas infinite.

**Source:** Zachary Goodsell, *Unbounded Utility and Background Risk*, 5 June
2026, §3 (pp. 7–8) and Theorem 7 (pp. 19–20). The supplied manuscript is
**unpublished, marked “do not cite”, and erroneous**. This local provenance
record does not endorse its withdrawn consistency theorem. The construction
is Goodsell’s; the explicit area, Tonelli, and counterexample details below
were recorded by GPT-6 (Codex), 9 September 2026. No separate checker or Lean
verification is claimed.

##### Construction

Take all real-valued random variables, with real outcomes and identity utility.
Let $S_X(t)=\Pr(X>t)$ and put

$$d=S_X-S_Y,\qquad A_+=\int_{\mathbb R}d_+(t)\,dt,
\qquad A_-=\int_{\mathbb R}d_-(t)\,dt.$$

Define

$$X\succeq_R Y\quad\Longleftrightarrow\quad
A_-<\infty\ \text{and}\ A_+\ge A_-.$$

Thus both finite equal areas give indifference; one infinite area gives a
strict comparison in the appropriate direction; two infinite areas give
incomparability. Never evaluate $\infty-\infty$. The draft uses survival CDFs
with a different endpoint convention, which has no effect on the integrals.

##### Preorder, expectation, and symmetry

Reflexivity is immediate. For transitivity write
$d_{XZ}=d_{XY}+d_{YZ}$. If the two component comparisons hold, their negative
parts are integrable. So is the negative part of their sum, since
$(a+b)_-\le a_-+b_-$. Signed integration is additive when negative parts are
integrable, including a possible positive infinity. Both component integrals
are nonnegative, so the sum comparison holds.

The relation depends only on laws. For integrable $X,Y$, both areas are finite
and $A_+-A_-=E[X]-E[Y]$. This verifies Expected Utility, hence the identity
chart, Simple EU, and Archimedean Outcomes; Rich Outcomes is explicit in the
model. More generally, if $E|X-Y|<\infty$ in the actual coupling, then

$$\int|S_X-S_Y|\le E|X-Y|,\qquad
\int(S_X-S_Y)=E[X-Y],$$

by the indicator formula and Fubini. This verifies Relative Expectation even
when the individual expectations are undefined.

Stochastic dominance gives $d\ge0$. Strict dominance gives a positive area:
strict inequality at a threshold persists on an interval by one-sided
continuity. Hence the relation preserves both weak and strict dominance.

Mixing both gambles with a common third law multiplies $d$ by the positive
mixture weight. It multiplies both areas by that weight, proving the full
Mixture Independence biconditional, including cases with infinite areas.

For $a>0$, replacing $X,Y$ by $aX+b,aY+b$ multiplies both areas by $a$.
Thus Positive Affine Invariance holds. Reflection and reversal give
$d_{-Y,-X}(t)=d_{X,Y}(-t)$ almost everywhere, leaving each area unchanged.
Thus Reflection Anti-Invariance holds as well. The minus sign in the draft’s
equation (16) is a substitution error; Lebesgue integration under $t\mapsto-t$
does not negate the integral.

##### Comonotonic Sum Invariance

Let $Q_X,Q_Y$ be increasing quantiles. Tonelli applied to the regions between
the two graphs gives the *separate*, nonnegative area identities

$$A_+=\int_0^1(Q_X(u)-Q_Y(u))_+\,du,\qquad
A_-=\int_0^1(Q_Y(u)-Q_X(u))_+\,du.$$

These identities include infinite areas. For example, the first counts the
region where $Q_Y(u)\le t<Q_X(u)$, either by horizontal or vertical sections.
Monotonicity makes the length of its section at $t$ equal to
$(S_X(t)-S_Y(t))_+$, up to irrelevant endpoint conventions.

A comonotonic sum has quantile $Q_X+Q_Z$ almost everywhere. Adding $Q_Z$ to
both quantiles leaves their difference, and therefore **both** areas,
unchanged. This proves the biconditional on the entire domain. It supplies
the missing infinite-area justification in the manuscript’s informal
“rotate the CDF” argument in Theorem 7.

##### Independent sums: the forward result

For an independent common summand with law $\xi$, the new survival difference
is $h=d*\xi$. Suppose $X\succeq_R Y$, so $g=d_-$ is integrable. Set $f=d_+$.
Then $h=f*\xi-g*\xi$ and

$$h_-\le g*\xi,\qquad \int(g*\xi)=\int g<\infty.$$

Tonelli gives $\int(f*\xi)=\int f$, possibly infinite. Since the negative
term is integrable, the signed integral of $h$ equals the original signed
integral of $d$, with the same finite or positive-infinite value. Therefore
weak **and strict** comparisons are preserved.

This does **not** establish the reverse implication. The printed proof
identifies $f*\xi,g*\xi$ with $h_+,h_-$, which is unjustified: the two
convolutions can overlap and cancel. For a simple example, let $X$ be equally
likely $-1$ or $1$, let $Y=0$, and let $\xi$ be equally likely $0$ or $1$.
Originally both areas are $1/2$; after convolution both are $1/4$. Tonelli
still preserves the integrals of the separately convolved $f$ and $g$.
This demonstrates the false identification; it is **not** a counterexample
to convolution invariance itself. Independent Sum Cancellation, and hence
full Independent Sum Invariance, remain unasserted for this exact model.
A [total extension satisfying Independent Sum Invariance](conjectured-total-independent-sum-extension.html)
is now proved separately: saturating the area cone first supplies
cancellation while preserving its strict comparisons, after which an
invariant maximal-cone argument supplies totality.

##### L¹ Continuity

**Additional proof: GPT-6 (Codex), 9 September 2026.** The exact area preorder
satisfies the recorded upper-section $L^{1}$ Continuity axiom. This is an elementary
closure argument for Goodsell's construction, not a claim that the manuscript
states or proves this additional property.

Suppose $X_n\succeq_R Y$ for every $n$ and
$\delta_n=E|X_n-X|\to0$. Write

$$d=S_X-S_Y,\qquad d_n=S_{X_n}-S_Y=d+e_n,
\qquad e_n=S_{X_n}-S_X.$$

For all sufficiently large $n$, $\delta_n$ is finite. The pointwise indicator
identity and Tonelli give

$$\int_{\mathbb R}|e_n(t)|\,dt
\le E\int_{\mathbb R}
 |\mathbf1_{\{X_n>t\}}-\mathbf1_{\{X>t\}}|\,dt
=E|X_n-X|=\delta_n. \tag{1}$$

The assumed comparison gives $\int(d_n)_-<\infty$ and a nonnegative
signed integral of $d_n$. Choose one sufficiently large index. Since

$$d_-\le(d_n)_-+|e_n|,$$

we obtain $\int d_-<\infty$. If $\int d_+=\infty$, the area rule already
gives $X\succeq_RY$. Otherwise $d$ is integrable. Equation (1) then makes
every sufficiently late $d_n$ integrable too, and

$$\int d=\int d_n-\int e_n\ge-\|e_n\|_1\ge-\delta_n.$$

Taking $n\to\infty$ gives $\int d\ge0$, again proving $X\succeq_RY$.
No subtraction of infinite areas occurs: the case of infinite positive area
was settled separately after negative-area integrability was established.

The same argument applies when $Y_n\to Y$ in $L^{1}$ with $X$ fixed, and even
when both arguments converge in $L^{1}$, since the change in survival difference
has $L^{1}$ norm at most $E|X_n-X|+E|Y_n-Y|$. Only the upper-section property is
recorded as a principle in this model. No Totality or symmetry assumption is
used in this closure proof. Original work consists of this short verification;
the CDF-area construction remains attributed to Goodsell.

##### Verified failures

For a standard symmetric Cauchy variable $C$, comparison with zero has two
infinite areas: on each side the absolute area is the corresponding infinite
first tail moment. Thus $C$ and $0$ are incomparable. This witnesses failure
of Totality and Symmetric Neutrality (the draft’s “Reflection Symmetry”).
Folded Expectation also fails: the symmetric tail difference is identically
zero, so that principle would demand $C\sim0$.

Full and Antitonic Sum Invariance fail by the recorded St Petersburg
arguments, which require only Rich Outcomes and Stochastic Dominance.
See [the full-sum witness](dominance-refutes-full-sum.html) and
[the antitonic witness](dominance-refutes-antitonic-sum.html).

The executable check `checks/background_risk.py` tests finite-law area and
quantile identities, mixture behavior, the convolution-overlap example, and
exact St Petersburg tail identities. It is a sanity check, not a numerical
proof about all distributions or any transfinite extension.

See also the [source inventory and failed-claim audit](symmetric-dtu-refutes-independent-sum-candidate.html).

### CDF-area conclosure — `cdf-conclosure-preorder`

Model; source **Unbounded Utility and Background Risk (unpublished)**; produced by Zachary Goodsell (CDF-area construction and conclosure); GPT-6 (Codex) (construction-stage extraction and property audit); recorded by GPT-6 (Codex); checked by nobody; Lean stated; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Expected Utility (`expected-utility`)
- Simple Expected Utility (`simple-eu`)
- Relative Expectation (`relative-expectation`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)

Violates:

- Totality (`totality`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)

Unknown in this model: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

Construction.

Use all real outcomes with identity utility. In the vector space of survival differences, let $C=\{v$: integral$(v_-)$ is finite and integral$(v_+)$ is at least integral$(v_-)\}$ be Goodsell's CDF-area cone. Define $\operatorname{Sat}(C)=\{v: T_\xi v$ belongs to C for some probability law xi}, where $T_\xi$ is convolution by xi, and set $X \ge  Y$ iff $S_X-S_Y$ belongs to $\operatorname{Sat}(C)$. This is Goodsell's conclosure, stopped before the total-extension step. The previously recorded commutation and strict-preservation argument makes it a cone extending the area comparisons strictly and invariant in both directions under every independent convolution. Reflection of the survival difference conjugates xi to its reflected law; positive affine changes conjugate xi to its positively scaled law. The area cone is invariant under these changes, so the conclosure inherits reflection anti-invariance and positive affine invariance. It fails Symmetric Neutrality by the completed Levy obstruction. Since a comparable symmetric gamble in any law-invariant reflection-anti-invariant preorder must be indifferent to zero, this model must also fail Totality. It is consequently a model of DU, but not DTU: Totality is the additional DTU axiom.

Executable checks: `topics/unbounded-utility/checks/levy_obstruction.py`.

Notes. Original work: construction-stage extraction and model adaptation/property audit. The CDF-area seed and conclosure construction are Goodsell's, and the stage already appears in the recorded total-extension proof. GPT-6 now records this intermediate model separately, proves the inherited affine/reflection symmetries by kernel conjugation, and establishes its incompleteness using the completed Goodsell stable-law proposal. No new independent invention of conclosure or claim of literature novelty is made. The construction quantifies over all probability kernels; it is not a computable comparison algorithm. No comonotonic sum property is asserted: conclosure does not automatically inherit the exact area's comonotonic invariance. No independent checker or Lean verification is claimed.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026 (unpublished), sections 3-4, pages 7-14: CDF-area construction and conclosure. Supplied manuscript marked do not cite and erroneous in its symmetric total-extension claim.
- **GPT-6 conclosure proof details 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/conjectured-total-independent-sum-extension.md, sections 1-3: previously recorded cone-language description and strictness-preservation proof for Goodsell conclosure.
- **GPT-6 model property audit 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/cdf-conclosure-preorder.md: extraction of the intermediate model, conjugation proofs for its inherited symmetries, and incompleteness from the completed Goodsell Levy obstruction.

- **Proof: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — sections 3-4, pages 7-14: CDF-area construction and conclosure. Supplied manuscript marked do not cite and erroneous in its symmetric total-extension claim

Record: `topics/unbounded-utility/models/cdf-conclosure-preorder.yaml`.

Write-up.

#### CDF-area conclosure

This model satisfies **DU**, together with
CDF-Area Extension, Independent Sum Invariance, Positive Affine Invariance,
and Reflection Anti-Invariance. It fails Totality and Symmetric Gambles Are
Neutral. Since DTU is DU plus Totality, this is a DU model but not a DTU
model. Thus reflection anti-invariance remains compatible with independent
sums when completeness is dropped.

**Original work: construction-stage extraction and model adaptation/property
audit.** The CDF-area seed and conclosure construction belong to Zachary
Goodsell, *Unbounded Utility and Background Risk* **(unpublished)**,
5 June 2026, sections 3–4, pp. 7–14. The supplied manuscript is marked
“do not cite” and erroneous in its symmetric total-extension claim; this
record does not reinstate that claim. This intermediate stage already appears
in the [recorded total-extension proof](conjectured-total-independent-sum-extension.html).
GPT-6 (Codex), 9 September 2026, supplied the separate model record,
the conjugation checks for its affine/reflection symmetries, and the deduction
of incompleteness from the completed Goodsell stable-law obstruction.
Conclosure is not presented as an independently invented AI construction,
and no literature-novelty claim is made. No independent checker or Lean
verification is claimed.

##### Construction and area preservation

Use real outcomes and identity utility. Let $V$ be the vector space of
survival functions of finite signed Borel measures of total mass zero,
identified almost everywhere. Each $S_X-S_Y$ belongs to $V$. Define

$$C=\left\{v\in V:\int v_-<\infty,\quad
                     \int v_+\geq\int v_-\right\},$$

and, for probability laws $\xi$,

$$T_\xi v(t)=\int v(t-z)\,d\xi(z),\qquad
 D=\operatorname{Sat}(C)=\{v:\exists\xi,\ T_\xi v\in C\}.$$

Then set $X\succeq_DY$ precisely when $S_X-S_Y\in D$. This is Goodsell's
conclosure of the area relation before taking any maximal total extension.

Here are the closure details, also recorded in sections 1–3 of the
[total-extension construction](conjectured-total-independent-sum-extension.html).

1. $C$ is a cone, and forward convolution preserves all of its weak and
   strict comparisons. Indeed $(T_\xi v)_-\leq T_\xi(v_-)$; Tonelli
   preserves the integrals of the separately convolved positive and negative
   parts. When the negative part is integrable, the signed integral is
   preserved, including a possible positive-infinite value.
2. If $T_\xi v,T_\eta w\in C$, then
   $T_{\xi*\eta}(v+w)=T_\eta T_\xi v+T_\xi T_\eta w\in C$.
   Together with positive scalar closure, this makes $D$ a cone containing
   $C$; hence it induces a reflexive transitive relation.
3. For every $\rho$, $v\in D$ iff $T_\rho v\in D$. In the forward
   direction, convolve an existing witness by $\rho$ and use commutation.
   In the reverse direction, compose $\rho$ with a witnessing convolution.
4. If $v\in C\setminus(-C)$ but $-v\in D$, some $\xi$ would give
   $-T_\xi v\in C$. Forward strict preservation simultaneously gives
   $T_\xi v\in C\setminus(-C)$, a contradiction. Thus $D$ preserves
   every strict area comparison, as well as every weak one.

Consequently the model satisfies CDF-Area Extension. Expected Utility,
Simple EU, Relative Expectation, and Stochastic Dominance follow by the
recorded area arguments. Its sure-outcome chart is the identity, so Rich
Outcomes and Archimedean Outcomes hold. Preferences depend only on laws,
so Stochastic Equivalence holds.

Mixtures with a common law multiply the survival difference by $p>0$.
Cone membership is equivalent under positive scalar multiplication, proving
Mixture Independence. Independent common summands apply $T_\xi$ to the
survival difference. Property 3 proves Independent Sum Invariance, including
cancellation and hence both weak and strict forward preservation.

##### The inherited outcome symmetries

For reflection and reversal of the compared pair, the new survival difference
is $Rv(t)=v(-t)$ almost everywhere. Both areas of $v$ are unchanged under
$R$, so $RC=C$. If $\check\xi$ is the reflected law, then

$$R T_\xi = T_{\check\xi}R.$$

Reflecting a witness for $v\in D$ therefore supplies a witness for $Rv\in D$.
Applying reflection twice gives the converse. As $Rv$ is the survival
difference for $-Y$ versus $-X$ when $v=S_X-S_Y$, this is exactly
Reflection Anti-Invariance:

$$X\succeq_DY\quad\Longleftrightarrow\quad -Y\succeq_D-X.$$

For $a>0$ and $b\in\mathbb R$, put $A_{a,b}v(t)=v((t-b)/a)$.
The two areas are each multiplied by $a$, so $A_{a,b}C=C$. If $a\xi$
denotes the pushforward of $\xi$ by $z\mapsto az$, then

$$A_{a,b}T_\xi=T_{a\xi}A_{a,b}.$$

Thus a witness for $v\in D$ supplies one for $A_{a,b}v\in D$.
Using the inverse affine transformation proves the converse, establishing
Positive Affine Invariance. The kernel is scaled by $a$; it is not also
translated by $b$, since $b$ already translates the compared gambles.

##### Why the model is incomplete

The [completed Lévy obstruction](levy-refutes-neutral-independent-preservation.html)
shows that Rich Outcomes, Stochastic Dominance, Mixture Independence, and
Independent Sum Preservation cannot coexist with Symmetric Gambles Are
Neutral. The model has all four antecedent properties, so it fails the
neutrality principle.

The obstruction gives concrete candidate witnesses: for independent positive
Lévy variables $L_1,L_2$ and an independent fair sign $\varepsilon$, at
least one of

$$W=\varepsilon L_1\qquad\text{and}\qquad D_0=L_2-L_1$$

is not indifferent to zero in this model. Both have symmetric laws. We do
not claim to determine which candidate the existential convolution test
leaves undecided.

For any symmetric-law variable $X$, Stochastic Equivalence gives $X\sim-X$.
If $X\succeq_D0$, reflection gives $0\succeq_D-X$, hence $0\succeq_DX$.
If $0\succeq_DX$, the reversed argument gives $X\succeq_D0$. Thus a
symmetric variable comparable with zero must be indifferent to zero.
The nonneutral candidate above is therefore **incomparable** with zero,
proving failure of Totality. This also explains why the symmetry inherited
by this incomplete model does not contradict the new impossibility result.

The construction quantifies over arbitrary probability laws, so this is an
existence model rather than an executable ranking algorithm. Its listed
check, `checks/levy_obstruction.py`, only verifies finite numerical
diagnostics for the analytic witness used to establish these failures.
Comonotonic Sum Invariance and other unproved properties are left open;
they are not inherited automatically merely because they hold in the
unsaturated area preorder.

### CDF-area: total comonotonic extension — `conjectured-total-comonotonic-area-extension`

Conjectured model; source **Misc.**; produced by Zachary Goodsell (area construction and broader comonotonic consistency question); GPT-6 (Codex) (precise total CDF-area extension candidate); recorded by GPT-6 (Codex); checked by nobody; Lean stated; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)

Violates:


Unknown in this model: nothing; every principle is settled.

Construction.

Proposed existence claim, not a completed construction: a total preorder on all real-valued random variables that strictly extends Goodsell's CDF-area preorder and satisfies both Mixture Independence and Comonotonic Sum Invariance. Real outcomes and the inherited area comparisons supply Rich Outcomes, Simple Expected Utility and Stochastic Dominance; require Stochastic Equivalence explicitly. The incomplete exact CDF-area preorder already satisfies all these properties except Totality. Seek a total extension preserving both the mixture comparisons and the comonotonic-sum biconditionals. The existing total independent-sum extension does not establish this: convolution is linear on survival differences, whereas comonotonic addition is translation of increasing quantiles, and its compatibility with the extension step remains unproved. No symmetry, independent-sum, continuity or negative verdict is asserted for this candidate.

Executable checks: `topics/unbounded-utility/checks/comonotonic_witnesses.py`.

Notes. Original work: precise candidate formulation and comparison of two extension problems. The base area construction, its comonotonic property, and the broader unresolved consistency question are credited to Goodsell. The manuscript's Theorem 7 supplies only the incomplete area model, not this proposed total CDF-area extension. No new completed model is claimed. To settle positively, give a total extension and verify that adjoining comparisons preserves every old strict area comparison, full Mixture Independence, and comonotonic preservation and cancellation. To settle negatively, derive an incompatibility from the displayed package. A generic order extension is insufficient, and the total convolution model is not evidence that comonotonic invariance survives. No claim is made that the question is open in the literature.
Progress (Claude, Fable 5.1, 23 September 2026; write-up section “A necessary condition: forced comparisons of both-infinite pairs”): a killing lemma shows that under Stochastic Equivalence, Stochastic Dominance, Mixture Independence and comonotonic preservation alone, X ≽ Y fails whenever comonotonic shears of the survival difference combine with positive weights into a nonpositive nonzero profile; an explicit both-infinite pair is killed, so the extension must rank it Y ≻ X where the area is silent. Prefix positivity, a positive lowest block, or divergent prefix sums certify that a pair is not killed; for prefix-oscillating block regions the sign of the lowest block is forced. An accounting heuristic suggests that no pair is killed in both orientations, so the lemma alone will not refute the package. Every clipped-expectation model in this topic violates Comonotonic Sum Invariance (half-Cauchy common summand), so the extension cannot come from clipped areas, and probability-trimmed quantile means are comonotonic invariant but not mixture-linear. Candidate: the area when defined, else a functional of the level-ordered block surplus, completed by Zorn's lemma over cones closed under both additive structures with the killing lemma as the pointedness test; regions with no lowest block are where a refutation would have to be sought. Tier set to silver by Zachary Goodsell, 23 September 2026.

Revisions:

- **2026-09-23** (Claude (Fable 5.1)) — Necessary condition added (write-up section “A necessary condition: forced comparisons of both-infinite pairs”): under Stochastic Equivalence, Stochastic Dominance, Mixture Independence and the preservation half of Comonotonic Sum Invariance, a pair whose survival difference d admits comonotonic shears d^{Z_i} and weights with d + Σ q_i d^{Z_i} ≤ 0, ≠ 0, cannot satisfy X ≽ Y. An explicit both-infinite pair with two step-function shears is exhibited, so the sought total extension must rank it Y ≻ X although CDF-Area Extension is silent on it. The conjecture itself is unchanged.
- **2026-09-23** (Zachary Goodsell (tier); Claude (Fable 5.1) (notes and write-up)) — Tier raised to silver by Zachary Goodsell. The write-up section on forced comparisons was expanded with the coordinate reduction, three certificates that a pair is not killed, worked block regions (a prefix-oscillating region that is killed, one that is not, and doubly infinite variants), an accounting heuristic suggesting that no pair is killed in both orientations, a duality caveat, and candidate constructions; the notes summarize them. No status change.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, unpublished manuscript, 5 June 2026, §3, pp. 7–8, and discussion before Theorem 7 and Theorem 7, pp. 19–20: CDF-area construction, its comonotonic invariance, and the broader unresolved consistency question.
- **GPT-6 conjecture 9 Sep** — GPT-6 (Codex), 9 September 2026, proposed total-extension package and obstacle analysis in writeups/conjectured-total-comonotonic-area-extension.md.
- **Claude killing lemma 23 Sep** — Claude (Fable 5.1), Logical Maps, 23 September 2026: killing lemma and an explicit forced comparison, section “A necessary condition: forced comparisons of both-infinite pairs” of the write-up; diagnostic checks/comonotonic_witnesses.py.

- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §3, pp. 7–8, and discussion before Theorem 7 and Theorem 7, pp. 19–20: CDF-area construction, its comonotonic invariance, and the broader unresolved consistency question

Record: `topics/unbounded-utility/models/conjectured-total-comonotonic-area-extension.yaml`.

Write-up.

#### CDF-area: total comonotonic extension

**Conjectured model, not constructed:** a preorder satisfying DTU,
CDF-Area Extension, and Comonotonic Sum Invariance.

The precise proposed package is Rich Outcomes, Totality, Stochastic
Equivalence, Simple Expected Utility, Stochastic Dominance, Mixture
Independence, CDF-Area Extension, and Comonotonic Sum Invariance. The proposed
outcome space is $\mathbb R$ with identity utility. No reflection, neutral
symmetry, independent-sum, or continuity requirement is imposed.

##### The starting model is already known

Goodsell's exact CDF-area preorder declares $X\succeq_RY$ when

$$\int(S_X-S_Y)_-<\infty,
\qquad \int(S_X-S_Y)_+\ge\int(S_X-S_Y)_-.$$

It satisfies DU and the proposed additional principles, but fails the
Totality axiom needed for DTU. In particular,
comonotonic invariance follows from the separate area identities

$$\int(S_X-S_Y)_\pm
  =\int_0^1(Q_X-Q_Y)_\pm,$$

and from adding the same increasing quantile $Q_Z$ to $Q_X,Q_Y$.
Both identities allow infinite areas. See the
[existing construction and verification](cdf-area-preorder.html).

The need for totality is real: pairs with both signed areas infinite remain
incomparable in this exact model, including a standard symmetric Cauchy
variable versus zero.

The discussion immediately before Theorem 7, p. 19, already identifies a
broader comonotonic consistency question as unsettled in the manuscript.
Theorem 7's partial answer uses the incomplete area relation. The present
entry specifies a total CDF-area extension as the target; it does not
attribute a proof or proposal of that exact package to the source.

##### Why the existing total-extension proof does not answer this

The [total independent-sum extension](conjectured-total-independent-sum-extension.html)
uses linear convolution operators on differences of survival functions.
Positive sums of those operators are positive multiples of another
convolution operator. That property makes its orientation and saturation
argument work.

Comonotonic addition is instead translation in quantile coordinates:

$$(Q_X,Q_Y)\longmapsto(Q_X+Q_Z,Q_Y+Q_Z).$$

Its preservation for the seed area relation does not show preservation for
newly adjoined comparisons. Meanwhile Mixture Independence is conveniently
linear in survival coordinates and is not generally linear in quantiles.
Thus simply repeating the convolution proof with a different word for its
operators does not prove this candidate.

##### What would settle the entry

A positive solution must complete the order while preserving every weak
and strict area comparison, full Mixture Independence, and both directions
of the comonotonic-sum comparison. A negative solution must give an explicit
incompatibility from the displayed package. Requiring only an arbitrary
total extension would not answer the question.

This candidate asks for a model of the comonotonic instance specifically.
The existing total independent-sum model already supplies a model of
Existential Copula Sum Invariance using the product copula, so the weaker
existential-copula consistency question is not being reopened here.

**Original work: precise candidate formulation and obstacle analysis.**
Goodsell's *Unbounded Utility and Background Risk* (unpublished), §3,
pp. 7–8, and the discussion before Theorem 7 and Theorem 7, pp. 19–20,
supply the area construction, comonotonic claim, and broader consistency
question. GPT-6 (Codex), 9 September 2026, formulated this precise
total-extension entry and recorded the gap. The candidate's direct source
is Misc.; the underlying construction remains attributed to Goodsell.
No new completed construction, literature novelty, independent check,
or Lean verification is claimed.

##### A necessary condition: forced comparisons of both-infinite pairs

**Addition: Claude (Fable 5.1), 23 September 2026.** The conjecture is
unchanged; this section records constraints that any solution must meet,
the ideas tried, and the directions that remain. Statements are labelled
*proved*, *verified numerically* or *heuristic*. `checks/comonotonic_witnesses.py`
verifies the explicit example below.

###### Coordinates

Under Stochastic Equivalence, Comonotonic Sum Invariance is the statement
that the order on laws is invariant under quantile addition: with
$X^\dagger=Q_X(U)$ for the standing uniform $U$ and $Z^\dagger=Q_Z(U)$,
$X\succeq Y$ iff $X^\dagger+Z^\dagger\succeq Y^\dagger+Z^\dagger$ for every $Z$.
*Proved (structural reduction):* with this invariance and transitivity,
$X\succeq Y$ depends only on $h=Q_X-Q_Y$; if $Q_X-Q_Y=Q_{X'}-Q_{Y'}$, add
$Q_{X'}$ to the first pair and $Q_X$ to the second, and the two right-hand
sides coincide. So the order is an additive cone $K$ in the vector space
$H$ of differences of nondecreasing functions on $(0,1)$, the *width*
function of the region between the two quantile graphs. In these
coordinates: dominance says $h\ge0$ gives $h\in K$, strictly when $h\ne0$;
Simple EU fixes $K$ on step functions by the sign of $\int h$; under
Totality $K$ is closed under positive rational scaling. Mixture Independence
is linear in the other coordinate, the survival difference $d=S_X-S_Y$
(mixing both sides with $Z$ replaces $d$ by $pd$), and under DU the order
also depends only on $d$. The two coordinate systems are related by the
nonlinear inverse-function map, and the area is the only functional
invariant in both: $\int_0^1 h_\pm\,du=\int_{\mathbb R}d_\pm\,dt$. A
comonotonic shear moves the slice of the region at level $u$ horizontally
by $Q_Z(u)$, nondecreasing in $u$, so it preserves the order of slices and
can only widen gaps between blocks; a mixture is $d\mapsto pd$ and
preserves the sign structure in $t$ exactly. The sign of the lowest slice of
the region is invariant under both operations.

###### The killing lemma (proved)

Write $d=S_X-S_Y$ and, for a nondecreasing $Q_Z$ on $(0,1)$,
$d^{Z}=S_{X^\dagger+Z^\dagger}-S_{Y^\dagger+Z^\dagger}$.

**Lemma.** Assume Stochastic Equivalence, Stochastic Dominance, Mixture
Independence, and only the preservation half of Comonotonic Sum Invariance
($X\succeq Y\Rightarrow X+Z\succeq Y+Z$ for comonotonic pairs). If there are
nondecreasing $Q_{Z_1},\dots,Q_{Z_m}$ and weights $q_i>0$ with

$$d+\sum_i q_i\,d^{Z_i}\le0\ \text{everywhere and}\ \ne0,$$

then $X\succeq Y$ is false. Under Totality, $Y\succ X$.

*Proof.* Suppose $X\succeq Y$. Stochastic Equivalence gives
$X^\dagger\succeq Y^\dagger$, and preservation gives
$X^\dagger+Z_i^\dagger\succeq Y^\dagger+Z_i^\dagger$ for each $i$. Let
$W_X$ be the randomized mixture of $X^\dagger$ and the $X^\dagger+Z_i^\dagger$
with weights proportional to $(1,q_1,\dots,q_m)$, built from binary
mixtures, and $W_Y$ likewise. Replacing one component at a time, Mixture
Independence (with Stochastic Equivalence to swap the two arguments of a
binary mixture, which does not change the law) and transitivity give
$W_X\succeq W_Y$. But $S_{W_X}-S_{W_Y}$ is a positive multiple of
$d+\sum_i q_i d^{Z_i}$, which is $\le0$ and nonzero, so $W_Y$ strictly
stochastically dominates $W_X$ and $W_Y\succ W_X$. Contradiction. $\square$

A pair to which the lemma applies is called *killed*. Killing refutes one
orientation in every model of DU with comonotonic preservation; "not
killed" is not a consistency claim.

###### An explicit killed pair with both areas infinite (verified numerically)

Let $c=1/3$. Partition $(0,1)$ into consecutive level intervals: $N_0$ of
length $c$, then for $k\ge1$ the pairs $P_k$, $N_k$, each of length
$c\,2^{-k}$ (total $3c=1$). Choose positions $a_j$ increasing along this
order with gaps growing geometrically (the check uses $100\cdot4^{j}$
between consecutive blocks) and widths $w=2/c$ on $N_0$ and $w=2^k/c$ on
$P_k$ and $N_k$. On a level interval labelled $P$ set $Q_Y=a_j$,
$Q_X=a_j+w$; on one labelled $N$ set $Q_X=a_j$, $Q_Y=a_j+w$. Both quantile
functions are nondecreasing step functions, and

$$d=+c2^{-k}\ \text{on the $t$-range of }P_k,\qquad
d=-c2^{-k}\ \text{on that of }N_k,\qquad d=-c\ \text{on that of }N_0,$$

and $0$ elsewhere. Every block has area $1$ except $N_0$ (area $2$), so
$\int d_+=\int d_-=\infty$: CDF-Area Extension imposes nothing on $(X,Y)$.

Take two step functions $Q_{Z_1},Q_{Z_2}$ constant on the same level
intervals: on $N_0$, $P_k$, $N_k$ the shift of $Q_{Z_1}$ moves $N_0$ onto
$P_1$, moves $P_k$ onto $N_k$, and moves $N_k$ onto the left half of
$P_{k+1}$; $Q_{Z_2}$ is the same except that $N_0$ moves to the empty space
just right of $P_1$ and $N_k$ moves onto the right half of $P_{k+1}$. Because
the gaps grow, both shift sequences are nondecreasing in level, so
$Q_{Z_1},Q_{Z_2}$ are nondecreasing and the sheared blocks stay disjoint.
The sheared profile $d^{Z_i}$ is the profile of the moved blocks with their
heights. Adding up,

$$d+\tfrac12\bigl(d^{Z_1}+d^{Z_2}\bigr)=
\begin{cases}-c&\text{on the range of }N_0,\\ -c/2&\text{where }Q_{Z_2}\text{ puts }N_0,\\ 0&\text{elsewhere:}\end{cases}$$

on $N_k$ the two moved copies of $P_k$ contribute $2\cdot\tfrac12 c2^{-k}$
against $-c2^{-k}$, and on each half of $P_{k+1}$ one moved copy of $N_k$
contributes $-\tfrac12 c2^{-k}=-c2^{-(k+1)}$ against $+c2^{-(k+1)}$. By the
lemma, no model of DU with comonotonic preservation has $X\succeq Y$, and
the total extension sought here must rank $Y\succ X$.

###### Certificates that a pair is not killed (proved)

Call a region *top-infinite* when its positions are bounded below and its
infinite areas sit at levels $u\to1$, so that the prefix integrals
$B(v)=\int_0^v h\,du$ are finite for $v<1$.

1. *Prefix positivity.* If $B(v)\ge0$ for every $v<1$, the pair is not
   killed. For $\psi=1_{(-\infty,T]}$, $\int_{-\infty}^{T}d^{Z}\,dt=
   \int_0^1 h(u)\,\varphi_Z(u)\,du$ where $\varphi_Z(u)\in[0,1]$ is the
   fraction of the sheared slice at level $u$ lying left of $T$. Both
   endpoints of a slice are nondecreasing in $u$ and $(T-a)/(b-a)$ decreases
   in $a$ and in $b$, so $\varphi_Z$ is nonincreasing, and it vanishes near
   $u=1$ for finite $T$. The second mean value theorem gives
   $\int_{-\infty}^{T}d^{Z}\ge0$ for every $Z$ and $T$, whereas a killing
   sum is negative on some interval and so has a negative integral up to a
   large $T$. The mirrored pair $(Y,X)$ of the example above (prefix sums
   $2,1,2,1,\dots$) is therefore not killed; the lemma forces one
   orientation of that pair and leaves the other open.
2. *Lowest block positive.* If the region has a first block and it is
   positive (more generally $h\ge0$, $h\not\equiv0$ on an initial level
   interval, with a first block), the pair is not killed: the leftmost
   positive block among the original and all sheared copies can only be
   covered by a negative block that is preceded, within its own copy, by
   negative blocks alone, and every copy begins with a positive block.
3. *Divergent prefix sums.* If $B(v)\to+\infty$, then $\psi\equiv1$ is a
   certificate: $\int d^{Z}=+\infty$ for every $Z$, since the sheared blocks
   keep their level order.

###### Worked block regions (verified numerically for the first two)

All blocks below have area $1$ unless bracketed; $P$ is positive, $N$
negative; regions are top-infinite unless stated.

- $R=(N_0[2],P_1,N_1,P_2,\dots)$: killed (above). $-R$: not killed (1).
- $R_2=(N_0,P_1[2],N_1[2],P_2[2],\dots)$, prefix sums $-1,+1,-1,+1,\dots$:
  killed with four copies of weight $\tfrac12$. The four copies of $N_0$
  cover $P_1$ (four slots); copies $A$ and $C$ put $P_k$ on the original
  $N_{k+1}$ ("roots"), copies $B$ and $D$ park $P_k$ on empty spots that
  $A$'s and $C$'s $N_{k+1}$ absorb, and $B$'s and $D$'s $N_{k+1}$ cover
  $P_{k+2}$. The sum vanishes except on the original $N_0$. $-R_2$ is not
  killed by (2). So for prefix-oscillating regions with a first block the
  sign of the lowest block decides, and the lemma forces it: the lowest
  block positive gives $X\succ Y$ under Totality.
- $R_3=(N_0,\text{ then positives only})$: not killed by (3); $-R_3$ not
  killed by (2). Neither orientation is forced by the lemma (the area rule
  would say $X\succ Y$).
- Doubly infinite alternating region $R_\infty$ (blocks accumulating at both
  ends, positions unbounded on both sides): the alternating shears give a
  sum that is identically $0$ in both orientations, so neither is killed.
  $R_\infty$ with one extra negative block at index $0$ is killed (the
  surplus block is left over). $R_\infty$ with one extra positive block: the
  same scheme balances to $0$ and the extra positive copies find no
  absorber; *heuristically* not killed.

###### An accounting heuristic and what it suggests (heuristic)

Per index, with all blocks of area $1$ and copies of total weight $W$,
the sheared negative blocks (weight $W$) must cover the original positive
block (weight $1$) and absorb the copies' positive blocks (weight $W$),
minus what the original negative block absorbs (weight $1$): $W=1+W-1$,
tight at every index. Blocks moved to a different index cost a factor
$2^{|\delta|}$ in width or height, so index drift cannot pay a deficit.
A region therefore appears killable exactly when it carries a "negative
surplus" that this tight steady state can spend (the initial $N_0$ in $R$
and $R_2$, the extra negative block in $R_\infty$), and the surplus looks
like a well-defined invariant with a sign. If so, no pair is killed in both
orientations and the lemma alone cannot refute DTU + Comonotonic Sum
Invariance. This is a heuristic; a proof would need to define the surplus
for general regions and show it is invariant under both operations.

A duality caveat: single-functional certificates $\psi\ge0$ (with a limit
at $-\infty$ and integrable at $+\infty$) exist only for prefix-nonnegative
regions, because a killer can hide blocks at $+\infty$, where the local
average of $\psi$ tends to $0$, and pin a negative prefix at $-\infty$. But
hiding at $+\infty$ is a limit rather than a finite kill, so the cone of
killing sums is not closed and Farkas-type duality does not transfer:
$R_2$ shows that regions with a negative prefix can be killed, while the
extra-positive $R_\infty$ suggests some are not.

###### What a solution must look like

Every both-infinite pair must be oriented, and the lemma already forces the
orientation of many of them, including all shears, mixtures and width-sums
of $R$ and $R_2$. The forced verdicts agree with "the lowest block decides"
for top-infinite regions with a first block, and with the mirror rule
(highest block decides) for bottom-infinite ones. Areas cannot see these
pairs; Banach limits of clipped areas fail, since every clipped-expectation
model in this topic violates Comonotonic Sum Invariance (see the write-ups
of those models, same date); probability-trimmed means
$\int_\varepsilon^{1-\varepsilon}Q$ are comonotonic invariant but not
mixture-linear. A candidate is a lexicographic rule: the area when it is
defined, else a functional of the conditionally summed block areas in
level order (invariant under shears, which preserve level order, and under
mixtures, which preserve the $t$-order of blocks), completed by Zorn's
lemma over cones closed under both additive structures with the killing
lemma as the pointedness test. Regions with no first block (an oscillating
lowest part with bounded positions) are where neither certificate applies
and where a double kill, hence a refutation, would have to be sought.

The same lemma is the tool for the copula questions about prospect
evaluations: under DU with the comonotonic copula, Alternating St Petersburg
$=-\tfrac12$ is the orientation of the both-infinite region of
$(A^\dagger,-\tfrac12)$, so the first test is whether that region, or its
mirror, is killed.

### CDF-area conclosure: total extension — `conjectured-total-independent-sum-extension`

Model; source **Unbounded Utility and Background Risk (unpublished)**; produced by Zachary Goodsell — CDF-area construction, conclosure, and total-extension strategy; recorded by GPT-6 (Codex), 2026-09-09 — cone-language exposition and additional proof details for strictness preservation and total extension; checked by nobody; Lean stated; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- CDF-Area Extension (`cdf-area-extension`)
- Expected Utility (`expected-utility`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Relative Expectation (`relative-expectation`)

Violates:

- Full Sum Invariance (`full-sum-consistency`)
- Antitonic Sum Invariance (`antitonic-sum-consistency`)
- Countable Sure-Thing (`countable-sure-thing`)
- Archimedean Gambles (`archimedean-gambles`)

Unknown in this model: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Scale Invariance (`scale-invariance`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

Construction.

Use real outcomes with identity utility. In the vector space of survival functions of finite signed measures of mass zero, let C be the CDF-area cone. Its weak and strict comparisons are preserved by forward convolution. Take Goodsell’s conclosure of C, expressed in cone language by declaring v positive whenever some convolution $T\xi v$ belongs to C; commutation ensures cone closure and full convolution cancellation, and forward strict preservation prevents collapse of old strict comparisons. A convolution-invariant cone D can be extended to orient any incomparable v: first adjoin all $d+$aT$\xi v$, then saturate. Convex mixtures of convolution kernels show that this intermediate cone has the same indifferent part as D and preserves strictness under forward convolution. Zorn’s lemma yields a total invariant cone extending C strictly. Pull its order back to random variables through survival differences. This proves Totality, CDF-Area Extension, Mixture Independence and Independent Sum Invariance; expectation and dominance follow from the area rule. The accompanying write-up proves every closure and orientation step. Known violations follow from the recorded St Petersburg/DU impossibility arguments.

Notes. The construction, conclosure operation, and total-extension strategy are attributed to Zachary Goodsell and his unpublished manuscript. GPT-6 supplied the cone-language exposition and additional proof details in the write-up; these are not attributed verbatim to the manuscript, and no independently originated AI construction is claimed. Upgraded from conjectured after those details were recorded; the stable ID is retained. Neither reflection requirement is assumed or listed as violated. The raw area cone’s cancellation remains unasserted: conclosure can enlarge it. This is nonconstructive existence using Zorn’s lemma. No independent checker or Lean verification is claimed.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026 (unpublished), §§3–4, pp. 7–14: CDF-area construction, conclosure, and total-extension strategy. Supplied manuscript marked “do not cite” and erroneous in its symmetry-extension claim.
- **GPT-6 proof details 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/conjectured-total-independent-sum-extension.md: cone-language exposition of Goodsell’s conclosure and additional details establishing strictness preservation and the total-extension step; not an independently originated construction.
- **Goodsell clarification 9 Sep** — Zachary Goodsell, project conversation, 9 September 2026: extension without reflection and clarification that the saturation construction is conclosure.

- **Proof: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §§3–4, pp. 7–14: CDF-area construction, conclosure, and total-extension strategy. Supplied manuscript marked “do not cite” and erroneous in its symmetry-extension claim

Record: `topics/unbounded-utility/models/conjectured-total-independent-sum-extension.yaml`.

Write-up.

#### CDF-area conclosure: total extension

**Status: proved by the argument below.** This is a nonconstructive existence
model, using Zorn’s lemma. The mathematical proposal and base construction
come from Zachary Goodsell, *Unbounded Utility and Background Risk*
**(unpublished)**, 5 June 2026, §§3–4, pp. 7–14, and Goodsell’s project
requests of 9 September 2026. The supplied manuscript is marked “do not cite”
and erroneous in its symmetry-extension claim.

**Attribution:** the CDF-area construction, conclosure operation, and
strategy of extending the ordering to totality are Zachary Goodsell’s. The
model’s direct source is *Unbounded Utility and Background Risk (unpublished)*.
GPT-6 (Codex), 9 September 2026, supplied the cone-language exposition and
additional details for strictness preservation and the extension step below.
“Convolution saturation” here is an explicit description of Goodsell’s
conclosure, not a separately originated construction. These additional proof
details are not claimed to appear verbatim in the manuscript. The erroneous
symmetry-extension argument is not used.

No independent checker or Lean verification is claimed. The stable record ID
retains its original `conjectured-` prefix; the status and displayed name have
been updated.

##### Existence claim

There exists a total preorder on all real-valued random variables that:

- extends the CDF-area preorder, preserving every weak and strict comparison;
- satisfies Stochastic Equivalence, Expected Utility, Relative Expectation,
  and Stochastic Dominance;
- satisfies Mixture Independence and Independent Sum Invariance, including
  cancellation of an arbitrary independent common summand.

Real outcomes with identity utility supply Rich Outcomes, Archimedean
Outcomes, and the normalized chart. Neither Symmetric Neutrality nor
Reflection Anti-Invariance is required by this construction. Their failure
is not inferred merely from their omission.

##### 1. Linear space and convolution operators

Let $V$ be the real vector space of survival functions of finite signed Borel
measures on $\mathbb R$ of total mass zero, identified almost everywhere.
In particular $S_X-S_Y\in V$ for all real-valued random variables. Every
nonzero signed measure of total mass zero is a positive scalar multiple of a
difference of probability measures, by its Jordan decomposition.

For each probability law $\xi$, write

$$T_\xi v(t)=\int v(t-z)\,d\xi(z).$$

These linear operators map $V$ into $V$. They commute,
$T_\xi T_\eta=T_{\xi*\eta}$, include the identity $T_{\delta_0}$, and obey

$$aT_\xi+bT_\eta=(a+b)T_{(a\xi+b\eta)/(a+b)}\quad(a,b\ge0,\ a+b>0).$$

This last identity says that a positive combination of convolution operators
is a positive scalar times another convolution operator. It is essential to
the orientation argument. No reflection operator is included.

For an additive cone $A\subseteq V$, closed under multiplication by
nonnegative real scalars, write

$$L_A=A\cap(-A),\qquad A^{\mathrm{str}}=A\setminus(-A).$$

These are its indifferent and strictly positive parts. An extension preserves
strict comparisons when it does not acquire the negative of an old strictly
positive vector.

##### 2. The area cone preserves strictness under forward convolution

Define

$$C=\{v\in V:\ \int v_-<\infty,\quad \int v_+\ge\int v_-\}.$$

This is an additive cone: negative parts satisfy
$(v+w)_-\le v_-+w_-$, and integration is additive for signed functions with
integrable negative part, allowing a positive-infinite result. Its lineality
space is $L_C=\{v\in L^1:\int v=0\}$.

For every $\xi$, both $T_\xi C\subseteq C$ and
$T_\xi C^{\mathrm{str}}\subseteq C^{\mathrm{str}}$. Indeed, if $v\in C$,
then $(T_\xi v)_-\le T_\xi(v_-)$ has finite integral. Tonelli preserves the
integrals of the separately convolved positive and negative terms. Since the
negative term is integrable, the signed integral of $T_\xi v$ equals that of
$v$, whether finite or positive infinite. A positive integral stays positive;
a zero integral stays zero. See also the
[base-model proof](cdf-area-preorder.html).

This establishes only forward preservation for $C$. We do not assume that
$T_\xi v\in C$ implies $v\in C$.

##### 3. Conclosure supplies cancellation safely

For any cone $A$ preserved forward, weakly and strictly, by every $T_\xi$,
express its conclosure (convolution saturation) by

$$\operatorname{Sat}(A)=\{v:\text{for some probability law }\xi,
\ T_\xi v\in A\}.$$

This is a cone containing $A$. If $T_\xi v\in A$ and $T_\eta w\in A$,
then

$$T_{\xi*\eta}(v+w)=T_\eta(T_\xi v)+T_\xi(T_\eta w)\in A,$$

which proves closure under addition; scalar closure is immediate. Moreover,
for every probability law $\rho$,

$$v\in\operatorname{Sat}(A)\quad\Longleftrightarrow\quad
T_\rho v\in\operatorname{Sat}(A).$$

For the forward direction convolve an existing witness by $\rho$. For the
reverse direction compose $\rho$ with the witness for $T_\rho v$.

This is the **least** fully convolution-invariant cone containing $A$:
if $D$ is any such cone and $T_\xi v\in A$, then $T_\xi v\in D$, so
cancellation in $D$ forces $v\in D$. Thus $\operatorname{Sat}(A)\subseteq D$.
Mixture closure is already encoded by the cone structure. This identifies
the operation with Goodsell’s conclosure in these coordinates.

Crucially, saturation preserves every strict comparison of $A$. If
$v\in A^{\mathrm{str}}$ but $-v\in\operatorname{Sat}(A)$, some $\xi$
would give $-T_\xi v\in A$. Forward strict preservation gives
$T_\xi v\in A^{\mathrm{str}}$, a contradiction.

Thus $D_0=\operatorname{Sat}(C)$ extends the area cone without losing
strictness and satisfies full convolution cancellation. The resulting
membership equivalence also makes every convolution preserve its strict
comparisons: apply it to both $v$ and $-v$.

##### 4. Orienting an incomparable vector

Let $D$ be any cone satisfying
$v\in D\iff T_\xi v\in D$ for every $\xi$. Suppose that neither $v$ nor
$-v$ belongs to $D$. Then no $T_\xi v$ belongs to $D$ or $-D$ either.

Adjoin $v$ and all its forward transforms by setting

$$K=\{d+aT_\xi v:\ d\in D,\ a\ge0,\ \xi\text{ a probability law}\}.$$

The positive-combination identity from §1 proves that $K$ is a cone;
commutation and forward invariance of $D$ prove forward invariance of $K$.

**No old strict comparison collapses.** In fact $K\cap(-K)=L_D$. To see
this, if $k=d_1+aT_\xi v$ and $-k=d_2+bT_\eta v$, then

$$0=d_1+d_2+(a+b)T_\theta v$$

for a probability law $\theta$ when $a+b>0$. This would imply
$-T_\theta v\in D$, hence $-v\in D$, contrary to incomparability.
Consequently $a=b=0$ and $k\in L_D$. The reverse inclusion is immediate.

**Forward convolution preserves strictness in $K$.** Suppose
$x=d+aT_\xi v\in K$ and $T_\rho x\in L_D$. If $a>0$, then

$$-aT_{\rho*\xi}v=T_\rho d-T_\rho x\in D,$$

which again implies $-v\in D$, impossible. If $a=0$, the two memberships
$T_\rho d\in D$ and $-T_\rho d\in D$, together with cancellation in $D$,
imply $d\in L_D$. Thus a strictly positive element of $K$ cannot become
indifferent after convolution, since the indifferent part of $K$ is exactly
$L_D$.

We can therefore apply §3 to $K$. The cone
$D'=\operatorname{Sat}(K)$ is fully convolution invariant, contains $D$ and
$v$, and preserves all strict comparisons of $D$. It is a proper extension
of $D$. This establishes the orientation step for the genuine closure,
rather than for a chain description that omits cancellation.

##### 5. Maximal extension and totality

Consider the set of cones $D$ containing $D_0$, fully convolution invariant,
and satisfying

$$D\cap(-C^{\mathrm{str}})=\varnothing.$$

It is nonempty by §3. The union of any increasing chain is again such a cone:
closure and convolution membership equivalence involve only finitely many
memberships, and none of its members can contain a forbidden vector. Zorn’s
lemma therefore supplies a maximal member $D_*$.

If some $v$ belonged to neither $D_*$ nor $-D_*$, §4 would give a proper
extension preserving all its strict comparisons, hence still avoiding
$-C^{\mathrm{str}}$. That contradicts maximality. Therefore

$$D_*\cup(-D_*)=V.$$

Define preferences on the original random variables by

$$X\succeq_*Y\quad\Longleftrightarrow\quad S_X-S_Y\in D_*.$$

Cone closure gives reflexivity and transitivity; the displayed coverage gives
totality. Membership depends only on laws, so Stochastic Equivalence holds.
Containment of $C$ and avoidance of $-C^{\mathrm{str}}$ preserve every weak
and strict area comparison, exactly as required by CDF-Area Extension.

Mixing both laws with a common law multiplies their survival difference by
$p>0$. Cone membership is equivalent under positive scalar multiplication,
proving Mixture Independence in both directions. Adding a common independent
summand applies $T_\xi$ to that difference. The defining invariance of $D_*$
proves Independent Sum Invariance in both directions.

Expected Utility, Relative Expectation, and Stochastic Dominance follow from
CDF-Area Extension by the recorded implications. All required comparisons
of sure outcomes and finite gambles therefore agree with the identity chart.

##### Scope and known failures

This proves the previously proposed existence package, including convolution
invariance, without either reflection requirement. It does not establish
convolution cancellation for the **exact incomplete area preorder** itself:
its saturation can add comparisons. Nor does it show that arbitrary total
extensions inherit any invariance automatically.

Full Sum Invariance and Antitonic Sum Invariance fail by the recorded
Rich-Outcomes-plus-Dominance witnesses. Countable Sure-Thing and Archimedean
Gambles fail by the existing DU consequences. These explain the model’s
`violates` entries. No further symmetry or comonotonic-sum properties are
asserted for the chosen maximal cone.

The author’s withdrawn **symmetric** consistency claim remains withdrawn.
The separate [stable-law incompatibility candidate and source audit](symmetric-dtu-refutes-independent-sum-candidate.html)
still lack an exact verified stable-law witness; that is not needed for this
positive existence construction.

### Clipped expectation: eventual dominance — `eventual-clipped-expectation`

Model; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); Claude (Fable 5.1) (failure of Shift Invariance, 15 September 2026; explicit failure of Comonotonic Sum Invariance, 23 September 2026); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Sure-Thing (`sure-thing`)
- Scale Invariance (`scale-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)

Violates:

- Totality (`totality`)
- Expected Utility (`expected-utility`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Countable Sure-Thing (`countable-sure-thing`)
- Archimedean Gambles (`archimedean-gambles`)
- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Shift Invariance (`shift-invariance`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)

Unknown in this model: Arroyo = ln 2 (`arroyo-value`), Independent Sum Cancellation (`independent-sum-cancellation`), Pasadena = ln 2 (`pasadena-value`)

Construction.

Take all real-valued random variables and let $c_t(x)=\max (- t,\min (x,t))$. Define $X\succeq Y$ iff $\exists s\forall t>s E[c_t(X)]\ge E[c_t(Y)]$. The full construction, verification, and explicit witnesses are in the accompanying write-up. This is the incomplete DU model from Decision theory unbound, Theorem 2; it fails the additional Totality axiom of DTU. It witnesses consistency of the unbounded framework and failure of full EU despite finite EU.

Executable checks: `topics/unbounded-utility/checks/countermodels.py`, `topics/unbounded-utility/checks/comonotonic_witnesses.py`.

Notes. Clipping sends tails to ±t; it is not deletion of tail mass. Shift Invariance fails by the Laplace witness in the write-up (Claude, Fable 5.1, 15 September 2026); this failure is an addition to the source model, not a claim of the paper. Positive Affine Invariance fails with it.

Revisions:

- **2026-09-23** (Claude (Fable 5.1)) — Explicit Comonotonic Sum Invariance failure added (write-up section “Failure of Comonotonic Sum Invariance”); the flag was previously derived from the shift failure. A standard Cauchy C is indifferent to sure 0, but with the common comonotonic summand Z = max(C,0) the gap v_{0+Z}(t) − v_{C+Z}(t) = 2∫_{t/2}^{t} P(C>x)dx is positive for every t, so 0 + Z ≻ C + Z. Now violates: Comonotonic Sum Invariance.
- **2026-09-15** (Claude (Fable 5.1)) — Shift Invariance shown to fail (write-up section “Failure of Shift Invariance”). A symmetric Laplace gamble X is indifferent to sure 0, but for b>0 the shifted pair is strictly ordered, X+b ≺ b, because the shifted clipping window cuts more upper than lower tail. Positive Affine Invariance fails with it. Now violates: Shift Invariance, Positive Affine Invariance.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, Theorem 2, pp. 683–685; Theorems 7 and 9, p. 693
- **Claude shift failure 15 Sep** — Claude (Fable 5.1), Logical Maps, 15 September 2026: explicit failure of Shift Invariance (symmetric Laplace witness) in writeups/eventual-clipped-expectation.md.
- **Claude comonotonic failure 23 Sep** — Claude (Fable 5.1), Logical Maps, 23 September 2026: failure of Comonotonic Sum Invariance (half-Cauchy common summand) in writeups/eventual-clipped-expectation.md; diagnostic checks/comonotonic_witnesses.py.

- **Proof: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — Theorem 2, pp. 683–685; Theorems 7 and 9, p. 693

Record: `topics/unbounded-utility/models/eventual-clipped-expectation.yaml`.

Write-up.

#### Clipped expectation: eventual dominance

Source: Goodsell, *Decision theory unbound*, Theorem 2, pp. 683–685;
Theorems 7 and 9, p. 693. Human model: Zachary Goodsell.
Recorded and translated by GPT-6 (Codex); no transcription checker asserted.

Take $O=\mathbb{R}$, all measurable random variables, and

$$c_t(x)=\max(-t,\min(x,t)),\qquad v_X(t)=\mathbb E[c_t(X)].$$

Define $X\succeq Y$ iff there is s such that $v_X(t)\ge v_Y(t)$ for every $t>s$.

Reflexivity is immediate; transitivity follows by taking the larger of the
two thresholds. Equal-law variables have identical v-functions. Constants
have $v_x(t)=x$ for all sufficiently large t. Hence Rich Outcomes holds,
and finite mixtures of constants have their usual expected utilities.
In particular Simple EU and Archimedean Outcomes hold.

For a randomized mixture, $v_M(t)=p v_X(t)+(1-p)v_Z(t)$. Since $p>0$, comparison
with a common Z cancels, proving Independence. The recorded implication using
Stochastic Equivalence gives Sure-Thing.

For first-order dominance, use the tail-integral identity for clipped
expectations. The difference $v_X(t)-v_Y(t)$ is the integral of the difference
of the upper-tail functions on [-t,t]. It is nonnegative. If one tail
inequality is strict, right continuity supplies an interval with positive
integral; all sufficiently large truncations therefore have a positive gap.
The preference is strictly better. This proves the weak and strict dominance
clauses, and the topic's Statewise Dominance consequence follows. Thus this
is a DU model. It is not a DTU model, since Totality fails as shown below.

Reflection gives $v_{-X}(t)=-v_X(t)$. Positive rescaling gives
$v_{aX}(t)=a v_X(t/a)$; eventual comparisons are unchanged by this
reparametrization. Thus reflection and scale invariance hold. No Shift
Invariance flag is needed or claimed here.

If X has symmetric law, every clipped expectation is zero by the oddness of
$c_t$. Thus $X\sim 0$ in this model, verifying Symmetric Gambles Are Neutral even
though Totality fails.

##### Failure of Totality

Let A take $(-2)^n$ with probability $2^{-n}, n\ge 1$. At $t=2^k$,

$$v_A(2^k)=\sum_{n=1}^k(-1)^n+
              2^k\sum_{n>k}(-1)^n2^{-n}
          =\begin{cases}-2/3&k\text{ odd},\\-1/3&k\text{ even}.\end{cases}$$

Consequently neither $A\succeq -1/2$ nor $-1/2\succeq A$ holds: each comparison fails at
arbitrarily large truncation levels. This is an explicit incomparability,
not a conclusion drawn from failing to find a comparison.
It also directly violates the node Alternating St Petersburg $= - 1/2$.

##### Failure of Expected Utility and L¹ Continuity

Let N take n with probability $2^{-n}, n\ge 1$. Then $E[N]=2$ but, for integer $k\ge 1$,

$$v_N(k)=\mathbb E[\min(N,k)]=2-2^{1-k}<2.$$

The same strict bound holds at every finite truncation level above 2.
Thus $2\succ N$ and EU is false. For the continuity witness, put

$$N_k=\min(N,k)+2^{1-k}.$$

Each $N_k$ is simple and has expectation 2, so $N_k\sim 2$. Yet
$E|N_k-N|\le 2\cdot 2^{1-k}\to 0$ and N is not at least as good as 2. This violates
exactly the recorded upper-section $L^{1}$ Continuity clause.

##### Failure of the two gamble-level principles

The recorded Countable Sure-Thing counterargument uses only Rich Outcomes,
Simple EU, and Sure-Thing, all verified above. It therefore applies to this
model. For Archimedean Gambles, S with $P(S=2^n)=2^{-n}$ is better than every
constant: its truncations at $2^k$ have expectation $k+1$. For $p>0$,
$M_p(S,0)$ likewise has unbounded truncated expectations. Hence $S\succ 1\succ 0$
but no such mixture is indifferent to 1.

`checks/countermodels.py` verifies representative exact witness calculations.
The universal statements above are analytic proofs, not conclusions from
finite sampling.

##### Failure of Shift Invariance

**Addition: Claude (Fable 5.1), 15 September 2026.** This is a property of
the recorded model, not a claim made in the source paper.

Let X have a symmetric Laplace law, or any symmetric integrable law with
unbounded support. Oddness of $c_t$ gives $v_X(t)=0=v_0(t)$, so $X\sim 0$. For $b>0$,

$$v_{X+b}(t)-v_b(t)
 =\mathbb E\bigl[\max(-t-b,\min(X,t-b))\bigr]
 =-\mathbb E[(X-(t-b))_+]+\mathbb E[(-X-(t+b))_+]
 =-\bigl(\mathbb E[(X-(t-b))_+]-\mathbb E[(X-(t+b))_+]\bigr),$$

using the symmetry of X for the last step. Unbounded support makes
$E[(X-s)_+]$ strictly decreasing in s, so the bracket is positive for every t
and $X+b\prec b$ for all sufficiently large t, indeed for all t. Since $X\sim 0$ but
$X+b\prec 0+b$, Shift Invariance fails; consequently Positive Affine Invariance
fails, and by the recorded implications so do Transfer of a Shift Across a
Mixture and Simple Relative Expectation. Expected Utility already fails in
this model; the same pair, being integrable with equal means, is a second
witness.

##### Failure of Comonotonic Sum Invariance

**Addition: Claude (Fable 5.1), 23 September 2026.** The flag was already
derived from the shift failure above; this is an explicit witness, not a
claim made in the source paper.

Realize a standard Cauchy variable as $C=Q_C(U)=\tan(\pi(U-\tfrac12))$ and
put $X=0$, $Y=C$, $Z=C_+=\max(C,0)$, all nondecreasing in $U$, so both pairs
$(X,Z)$, $(Y,Z)$ are comonotonic. Oddness of $c_t$ gives $v_C(t)=0=v_0(t)$
for every $t$, hence $X\sim Y$.

**Doubling-defect identity.** For any nonnegative random variable $V$ and
any $F>0$,

$$2\,\mathbb E[\min(V,F)]-\mathbb E[\min(2V,F)]
 =2\int_{F/2}^{F}P(V>x)\,dx,$$

since $\mathbb E[\min(V,F)]=\int_0^F P(V>x)\,dx$ and
$\mathbb E[\min(2V,F)]=2\int_0^{F/2}P(V>x)\,dx$. For $V=C_+=\max(C,0)$ with
$C$ standard Cauchy the right-hand side is
$\frac2\pi\int_{F/2}^{F}\arctan(1/x)\,dx$, which is positive for every $F$
and increases to $\frac{2\ln2}{\pi}$ as $F\to\infty$.

With $X+Z=C_+$, $Y+Z=2C_++C_-$ ($C_-=\min(C,0)$) and
$\mathbb E[\max(C_-,-t)]=-\mathbb E[\min(C_+,t)]$,

$$v_{X+Z}(t)-v_{Y+Z}(t)=2\int_{t/2}^{t}P(C>x)\,dx>0\qquad(t>0),$$

so $X+Z\succeq Y+Z$ holds for all $t$ and $Y+Z\succeq X+Z$ fails for all $t$:
$X+Z\succ Y+Z$ while $X\sim Y$. `checks/comonotonic_witnesses.py` verifies
the calculation.

### Stochastic dominance: finite-shift total extension — `finite-shift-total-extension`

Model; source **Misc.**; produced by Zachary Goodsell (finite-shift conclosure and separating total-extension proposal); GPT-6 (Codex) (canonical-cone adaptation, witness, and extension proof); recorded by GPT-6 (Codex), 2026-09-13; checked by nobody; Lean stated; 2026-09-13.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Shift Invariance (`shift-invariance`)

Violates:

- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Relative Expectation (`relative-expectation`)
- Expected Utility (`expected-utility`)
- CDF-Area Extension (`cdf-area-extension`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)

Unknown in this model: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Scale Invariance (`scale-invariance`)

Construction.

Use real outcomes with identity utility and all real-valued gambles. In the vector space of survival profiles of finite signed measures of mass zero, let $C=P+N$, where P consists of nonnegative profiles and N of compact finite-step profiles of integral zero. Take conclosure using only finitely supported probability kernels: v belongs to D0 iff $T_\mu v$ belongs to C for some such kernel. This preserves all weak and strict comparisons of C and supplies finite-kernel cancellation. For U uniform on [0,1], put $A=M_{1/2}(U+1,0), B=M_{1/2}(U,1)$, and $v=S_A-S_B$. Every finite average of shifts of v is compact, has integral zero, and has nonzero slope just after its smallest shifted left endpoint. Thus neither sign belongs to D0. Adjoin v and all its finite shift averages, then saturate. The indifferent subspace stays exactly that of D0, preserving v as strictly positive. The same orientation lemma and a chain-union argument give a maximal total saturated cone with that fixed indifferent subspace. Its induced preference satisfies DTU and every common real shift, but A strictly exceeds B, contrary to Shift Transfer. The same pair has a simple coupled difference of mean zero and bounded equal means, refuting Simple Relative Expectation, Relative Expectation, Expected Utility and CDF-Area Extension. Positive shifts of B approach B while exceeding A, refuting the two continuity principles. Neutrality and reflection fail by their recorded implications to transfer under the satisfied assumptions. The write-up proves all cone, saturation, strictness and total-extension steps.

Executable checks: `topics/unbounded-utility/checks/finite_shift_extension.py`.

Notes. Original work: model adaptation and separation following Goodsell's proposal. The conclosure method and total-extension strategy are Goodsell's; the canonical seed, bounded witness, finite-kernel argument and explicit preservation of the indifferent subspace are credited to GPT-6 (Codex). Misc. is the direct source of this new separating model; the manuscript supplies a method, not the new result. This is nonconstructive existence using Zorn's lemma. It also preserves addition of independent finite-valued summands; no claim is made for arbitrary independent summands or for positive affine invariance. The separate conjectured-dtu-shift-implies-transfer record keeps its statement and conjectured status, with refutation computed from this model. Exact checks support the bounded witness; they do not implement the total order or certify the universal extension proof. No independent checker, literature-priority claim or Lean verification is asserted.

Sources:

- **Goodsell proposal 13 Sep** — Zachary Goodsell, project conversation, 13 September 2026: proposal to extend the canonical DU model by a conclosure-like construction preserving shifts and violating Shift Transfer.
- **GPT-6 extension proof 13 Sep** — GPT-6 (Codex), Logical Maps, 13 September 2026: finite-kernel witness and fixed-indifference total-extension proof in writeups/finite-shift-total-extension.md, adapting the canonical DU cone and bounded witness recorded on 9 September 2026 in writeups/finite-support-compensated-dominance.md.
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026 (unpublished), sections 3–4, pp. 7–14: conclosure and total-extension strategy, as previously recorded in writeups/conjectured-total-independent-sum-extension.md. The manuscript is marked do not cite and erroneous in its symmetric-extension claim; that claim is not used.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37, DOI 10.1111/nous.12549, Theorems 3–4, pp. 25–27: Shift Transfer and Simple Relative Expectation, not this countermodel.

- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — sections 3–4, pp. 7–14: conclosure and total-extension method. The new finite-shift separating extension is proved separately; the withdrawn symmetric-extension claim is not used.
- **Formulation: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorems 3–4, pp. 25–27: Shift Transfer and Simple Relative Expectation

Record: `topics/unbounded-utility/models/finite-shift-total-extension.yaml`.

Write-up.

#### Stochastic dominance: finite-shift total extension

There is a model of **DTU and Shift Invariance** in which **Shift Transfer
fails**. For $U$ uniform on $[0,1]$, the model makes

$$A=M_{1/2}(U+1,0)\succ B=M_{1/2}(U,1).$$

Shift Transfer requires indifference, with $p=1/2$ and transfer parameter
$b=1/2$. Both gambles are bounded and have expectation $3/4$.

**Source and work accounting.** Zachary Goodsell proposed the finite-shift
conclosure and separating total extension in the project conversation of
13 September 2026. Conclosure and the total-extension strategy are
Goodsell's methods, already recorded in the
[CDF-area total-extension write-up](conjectured-total-independent-sum-extension.html)
from *Unbounded Utility and Background Risk* (unpublished), 5 June 2026,
sections 3–4, pp. 7–14. That manuscript is marked “do not cite” and erroneous
in its symmetric-extension claim; the withdrawn claim is not used here.
GPT-6 (Codex) supplied the canonical-cone adaptation, finite-kernel witness,
and extension proof below, using its
[finite-support-compensation model and witness](finite-support-compensated-dominance.html)
of 9 September 2026. The new separating result is recorded under Misc.,
not attributed to the manuscript. No literature priority, independent
checker, or Lean proof is claimed.

##### The canonical DU cone

Take all measurable real-valued random variables on the standing atomless
standard probability space, with real outcomes and identity utility. Let
$V$ be the real vector space of survival profiles of finite signed Borel
measures of total mass zero, identified almost everywhere. In particular,

$$d_{X,Y}(t)=S_X(t)-S_Y(t)=F_Y(t)-F_X(t)\in V.$$

Define

$$P=\{v\in V:v\geq0\text{ almost everywhere}\},$$

$$N=\{n\in V:n\text{ is compactly supported and finite-step},\ \int n=0\},
\qquad C=P+N.$$

Here “finite-step” means only finitely many steps. For any cone $H$, write
$L_H=H\cap(-H)$ for its indifferent subspace and
$H^{\mathrm{str}}=H\setminus(-H)$ for its strictly positive part.

The cone $C$ has

$$L_C=N. \tag{1}$$

Indeed, if $p+n=-(q+m)$ with $p,q\in P$ and $n,m\in N$, then
$p+q=-(n+m)$ is nonnegative with integral zero. Hence $p=q=0$ almost
everywhere. Conversely, $N$ is a subspace contained in $C$. The same
argument gives the useful criterion

$$v\in L^1,\quad\int v=0
\quad\Longrightarrow\quad(v\in C\iff v\in N). \tag{2}$$

The ordering $X\succeq_CY$ iff $d_{X,Y}\in C$ satisfies DU. Cone addition
gives transitivity, and law dependence gives Stochastic Equivalence.
Mixing both laws with a common law multiplies their difference by $p>0$,
so positive scalar cancellation proves Mixture Independence in both
directions. Nonnegative profiles are in $P$; a nonzero one cannot lie in
$N$, so strict Stochastic Dominance remains strict. A strict threshold
inequality gives a nonzero profile almost everywhere by right continuity.

For finite-valued $X,Y$, the profile $d$ is compact finite-step, with
$m=\int d=E[X]-E[Y]$. Writing $h=\mathbf1_{[0,1)}$ gives
$d=mh+(d-mh)$, where $d-mh\in N$. Thus $m\geq0$ implies $d\in C$.
Conversely, if $d=p+n\in C$, then $p=d-n$ is integrable and
$m=\int p\geq0$. This proves Simple EU, including strictness for unequal
means. Sure outcomes consequently have the ordinary real order and
identity chart. All real outcomes are available, and for $a>b>c$ the
mixture of $a,c$ with weight $(b-c)/(a-c)$ on $a$ is indifferent to $b$.
Thus Rich Outcomes and Archimedean Outcomes hold.

The earlier finite-support-compensation write-up also proves that this is
the least DU preorder on real utility laws. The extension below needs
only the directly verified properties above.

##### Finite-shift conclosure

Let $\mathcal F$ be the probability laws with finite support. For
$\mu=\sum_{i=1}^k a_i\delta_{b_i}$, with $a_i>0$ and $\sum_i a_i=1$, set

$$T_\mu v(t)=\sum_{i=1}^k a_i v(t-b_i).$$

These operators map $V$ to $V$, commute, include the identity, and satisfy
$T_\mu T_\nu=T_{\mu*\nu}$. Also, for $a,b\geq0$ with $a+b>0$,

$$aT_\mu+bT_\nu=(a+b)T_{(a\mu+b\nu)/(a+b)}. \tag{3}$$

Every kernel on the right still has finite support. Point masses supply
all real shifts and their inverses. No countable averaging or topological
closure is used.

Every $T_\mu$ preserves $C$ weakly and strictly: it maps $P$ to $P$ and
$N$ to $N$. If $p\in P$ is nonzero, then $T_\mu p$ is nonnegative and
nonzero. Thus $T_\mu(p+n)$ cannot be in $N$, since that would put the
nonzero nonnegative profile $T_\mu p$ in $N$.

For any forward-invariant cone $H$, define

$$\operatorname{Sat}_f(H)=\{v\in V:\exists\mu\in\mathcal F,\ T_\mu v\in H\}.$$

It is a cone. If $T_\mu v,T_\nu w\in H$, then

$$T_{\mu*\nu}(v+w)=T_\nu(T_\mu v)+T_\mu(T_\nu w)\in H.$$

Positive scalar closure is immediate. For every $\rho\in\mathcal F$,

$$v\in\operatorname{Sat}_f(H)
\quad\Longleftrightarrow\quad
T_\rho v\in\operatorname{Sat}_f(H). \tag{4}$$

For the forward implication, commute $T_\rho$ past a witnessing operator
and use forward invariance of $H$. For the reverse implication, compose
$\rho$ with the witnessing kernel. Call a cone satisfying (4)
**saturated**.

If the operators also preserve strictness in $H$, saturation preserves
every strict comparison of $H$. For $v\in H^{\mathrm{str}}$, membership
of $-v$ in the saturation would give $-T_\mu v\in H$, contradicting
$T_\mu v\in H^{\mathrm{str}}$.

Therefore $D_0=\operatorname{Sat}_f(C)$ is saturated and preserves all weak
and strict comparisons of $C$. Its indifferent subspace may be larger
than $N$; the proof does not identify the two.

##### A transfer pair that stays incomparable

For the displayed $A,B$, direct calculation gives

$$v(t)=S_A(t)-S_B(t)=
\begin{cases}
(t-1)/2,&0<t<1,\\
(2-t)/2,&1<t<2,\\
0,&\text{otherwise},
\end{cases} \tag{5}$$

almost everywhere. Its positive and negative integrals are each $1/4$.

For every $\mu\in\mathcal F$, $T_\mu v$ is compactly supported and has
integral zero. It is not finite-step. Merge repeated atoms and let $b_0$
be the smallest atom of $\mu$, with weight $a_0>0$. Choose $\delta>0$
smaller than $1$ and smaller than the gap to the next atom, if there is
one. On $(b_0,b_0+\delta)$, only the translate at $b_0$ contributes:

$$T_\mu v(t)=\frac{a_0}{2}(t-b_0-1).$$

Its slope is $a_0/2>0$ on a nonempty interval, so it cannot agree almost
everywhere with a finite-step function. Criterion (2) consequently excludes
both $T_\mu v$ and $-T_\mu v$ from $C$. Thus

$$v\notin D_0,\qquad -v\notin D_0. \tag{6}$$

The finiteness of the kernel is used in the existence of the smallest atom
and the positive gap.

##### Orienting a comparison without adding indifferences

Let $D$ be any saturated cone and suppose $w\notin D\cup(-D)$. Adjoin
$w$ and all its finite shift averages:

$$K=\{d+aT_\mu w:d\in D,\ a\geq0,\ \mu\in\mathcal F\}.$$

Identity (3) makes $K$ a cone. Commutation and forward invariance of $D$
make it forward invariant. We will prove

$$L_K=L_D,\qquad L_{\operatorname{Sat}_f(K)}=L_D. \tag{7}$$

First suppose $k=d_1+aT_\mu w$ and $-k=d_2+bT_\nu w$ belong to $K$.
If $a+b>0$, adding gives

$$0=d_1+d_2+(a+b)T_\theta w$$

for a finite probability law $\theta$, by (3). Hence $-T_\theta w\in D$;
saturation would force $-w\in D$, a contradiction. Thus $a=b=0$, and
$k\in L_D$. The reverse inclusion follows from $D\subseteq K$.

Now suppose $x,-x\in\operatorname{Sat}_f(K)$. Choose witnesses with
$T_\mu x\in K$ and $-T_\nu x\in K$. Forward invariance and commutation
give both $T_{\mu*\nu}x$ and its negative in $K$. By the first equality
in (7), $T_{\mu*\nu}x\in L_D$. Applying saturation of $D$ to both signs
gives $x\in L_D$. The reverse inclusion is again immediate.

Consequently $D'=\operatorname{Sat}_f(K)$ is saturated, extends $D$, and
has exactly the same indifferent subspace. Every old strictly positive
element stays strict: acquiring its negative would put it in $L_{D'}=L_D$.
Also $w\in D'$ and $w\notin L_D$, so $w$ is strictly positive in $D'$.
This proves strictness after saturation, not merely before it.

Apply this lemma to $D_0$ and the profile $v$ from (5). Write $D_1$ for
the resulting saturated cone and $L=L_{D_0}=L_{D_1}$. Then $v$ is strict
in $D_1$ and all original strict comparisons of $C$ remain strict.

##### Total extension

Consider the family of saturated cones $E$ containing $D_1$ and satisfying
$E\cap(-E)=L$, ordered by inclusion. It is nonempty, since it contains
$D_1$. The union of any nonempty chain is a saturated cone: each cone
operation involves finitely many memberships, and each direction of (4)
holds in the chain member containing the relevant vector. Its indifferent
subspace is exactly $L$. Indeed, if both $x$ and $-x$ enter the union,
they occur together in one chain member, so $x\in L$. The empty chain
has upper bound $D_1$.

Zorn's lemma therefore supplies a maximal member $E_*$. If some
$w\notin E_*\cup(-E_*)$, the orientation lemma would supply a strictly
larger saturated cone with the same indifferent subspace $L$, still
containing $D_1$. This contradicts maximality. Hence

$$E_*\cup(-E_*)=V.$$

Define preferences on the original random variables by

$$X\succeq_*Y\quad\Longleftrightarrow\quad S_X-S_Y\in E_*.$$

The cone gives reflexivity and transitivity, and the displayed coverage
gives Totality. Law dependence and positive scalar cancellation give
Stochastic Equivalence and the full Mixture Independence biconditional.
The extension preserves every weak and strict comparison of $C$, so
Stochastic Dominance, Simple EU, Rich Outcomes, and Archimedean Outcomes
remain valid. These are DTU.

For every real $b$, equation (4) applied to $\delta_b$ gives

$$X\succeq_*Y\quad\Longleftrightarrow\quad X+b\succeq_*Y+b,$$

which is Shift Invariance. The fixed indifferent subspace protects the
strict comparison $v\in D_1\setminus L$, so $A\succ_*B$. Shift Transfer
therefore fails. Starting the orientation lemma with $-v$ instead gives
another such model with $B\succ_*A$.

This is a total preorder on gambles; distinct same-law variables remain
indifferent. Equivalence classes, rather than individual random variables,
carry the associated total order.

##### Other verified properties and failures

Equation (4) also gives invariance under addition of an independent
finite-valued summand. This is already forced by the target axioms: Shift
Invariance transfers a weak or strict comparison to every shifted pair,
and finite mixture replacement combines the comparisons. Totality supplies
the converse by ruling out the reverse strict comparison. No claim of
Independent Sum Invariance for arbitrary summands follows from this argument.

Use the same fair coin and $U$ to couple $A,B$. On its first branch,
$A=U+1$ and $B=U$; on the other, $A=0$ and $B=1$. Thus $A-B$ takes
just $1,-1$ with equal probabilities. Its mean is zero, while $A\succ_*B$.
This refutes **Simple Relative Expectation** and **Relative Expectation**.
The bounded equal-mean pair also refutes **Expected Utility**; its equal
finite signed areas refute **CDF-Area Extension**. Simple EU is unaffected,
since these mixture laws are not finite-valued.

For every $\varepsilon>0$, the profile
$d=S_{B+\varepsilon}-S_A$ is compactly supported, piecewise affine, and
has integral $\varepsilon$. Choose a compact finite-step lower
approximation $q\leq d$ with integral $m>0$; a sufficiently fine partition
including the finitely many breakpoints supplies one. With
$n=q-m\mathbf1_{[0,1)}$, we have $n\in N$ and $d-n\geq0$. Thus
$B+\varepsilon\succeq_*A$ for every positive $\varepsilon$, but
$B\not\succeq_*A$. This refutes **Continuity under Vanishing Shifts**.
Taking $B_n=B+1/n$ gives $E|B_n-B|=1/n$, directly refuting the recorded
upper-section **L¹ Continuity** as well.

**Symmetric Neutrality** fails: together with the verified assumptions it
would imply Shift Transfer by the recorded
[neutrality-and-shift argument](neutrality-shift-imply-shift-transfer.html).
**Reflection Anti-Invariance** also fails, since with Totality and law
invariance it makes every symmetric gamble neutral, contradicting that
failure. These are deductions from proved implications, not from the
omission of symmetry conditions in the construction. Positive affine
invariance is left unasserted.

The construction is nonconstructive and covers all real laws, including
those without defined expectations. The accompanying exact-rational check
verifies the witness, its areas, simple coupling, finite-kernel examples,
and positive-shift margins. It does not compute the maximal ordering or
prove the universal extension lemma. The latter is the analytic argument
above; no independent checker or Lean verification is claimed.

### Stochastic dominance: finite-support compensation — `finite-support-compensated-dominance`

Model; source **Misc.**; produced by GPT-6 (Codex) (construction and original axiom audit); Claude (Fable 5.1) (seven further verified failures, 15 September 2026); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Shift Invariance (`shift-invariance`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)

Violates:

- Totality (`totality`)
- Expected Utility (`expected-utility`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Relative Expectation (`relative-expectation`)
- CDF-Area Extension (`cdf-area-extension`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Pasadena = ln 2 (`pasadena-value`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

Unknown in this model: Independent Sum Cancellation (`independent-sum-cancellation`)

Construction.

Use real outcomes with identity utility and all measurable real random variables. In the vector space V of survival profiles of finite signed measures with total mass zero, modulo almost-everywhere equality, let P be the cone of nonnegative profiles and N the subspace of compactly supported finite-step profiles with integral zero. Define $X\ge Y$ iff $S_X-S_Y$ belongs to $P+N$. This orders gambles by stochastic dominance after allowing a finite-support zero-mean compensation. The cone is preserved by common translations, positive affine changes and reflected comparison reversal. Its indifferent part is exactly N. Finite gambles are compared by their ordinary expectations, giving Simple EU and the identity chart, while strict stochastic dominance remains strict. A finite-mixture cancellation argument shows that this is the least DU preorder on real utility laws: every DU preorder preserves all its weak and strict comparisons. For U uniform on [0,1], U and sure 1/2 are incomparable despite their equal finite means. Nevertheless $U+\epsilon \ge 1/2$ for every $\epsilon >0$: sufficiently fine lower finite quantizations have mean at least 1/2. Thus Continuity under Vanishing Shifts and L1 Continuity fail. Shift Transfer also fails explicitly: $M_{1/2}(U+1,0)$ and $M_{1/2}(U,1)$ have equal means but a non-step survival difference, so are incomparable. Coupling their branches with the same fair coin gives a simple difference taking values $+1$ and -1, also refuting Simple Relative Expectation.

Executable checks: `topics/unbounded-utility/checks/shift_continuity.py`.

Notes. Original work: substantive elementary cone construction with direct axiom checks, a least-DU characterization, and explicit separating examples, motivated by the user's question. The construction and new proofs are credited to GPT-6, not to a paper merely because the paper also uses cones or supplies principle definitions. This describes work performed in the project and makes no literature-priority claim. DU holds, but DTU fails because Totality fails. Therefore this model settles the failure of DU plus Shift Invariance to imply Shift Transfer; this incomplete seed does not itself settle the DTU conjecture. Its separately recorded finite-shift-total-extension, added on 13 September 2026, supplies that separation while retaining every weak and strict comparison of this seed. All comparisons refer to the full standing domain, and all listed failures have exact witnesses in the write-up. No independent checker or Lean verification is asserted; no numerical computation is used as a proof of a universal axiom.

Revisions:

- **2026-09-15** (Claude (Fable 5.1)) — Seven further failures verified for the recorded construction, in the write-up section “Further verified failures”; the model, its construction and its earlier flags are unchanged. Now violates: Alternating St Petersburg = −1/2, Arroyo = ln 2, Pasadena = ln 2, Uniqueness of Negative Self-Similarity, Comonotonic Sum Invariance, Independent Sum Preservation, Existential Copula Sum Invariance.

Sources:

- **GPT-6 cone construction 9 Sep** — GPT-6 (Codex), Logical Maps, 9 September 2026: original finite-support compensation cone construction and exact analytic witnesses in writeups/finite-support-compensated-dominance.md.
- **Goodsell research prompt 9 Sep** — Zachary Goodsell, project conversation, 9 September 2026: prompt to investigate the role of CDF-area dominance, DU, Shift Invariance and continuity in deriving Shift Transfer.
- **Claude further failures 15 Sep** — Claude (Fable 5.1), Logical Maps, 15 September 2026: seven further explicit failures (the three named prospect evaluations, uniqueness of negative self-similarity, comonotonic, independent and every-copula sum invariance) in the section “Further verified failures” of writeups/finite-support-compensated-dominance.md, in response to Zachary Goodsell's request for a complete package picture.



Record: `topics/unbounded-utility/models/finite-support-compensated-dominance.yaml`.

Write-up.

#### Stochastic dominance: finite-support compensation

This is a model of **DU and Shift Invariance** in which **Shift Transfer
fails**. It also preserves Positive Affine Invariance and Reflection
Anti-Invariance. Totality and the continuity principles fail. Thus the
construction separates the question for DU from the stronger question
for DTU, which includes Totality.

**Source and work accounting.** GPT-6 (Codex), 9 September 2026, constructed
this ordering and supplied the proofs below in response to Zachary Goodsell's
question about CDF-area dominance, shifts and continuity. This is an original
construction recorded under Misc.; the use of cones alone does not make a
paper the source of this proof. The work is an elementary cone construction
with a full axiom audit and explicit separating examples. No claim of
literature priority, independent checking or Lean verification is made.

##### The ordering

Take all measurable real-valued random variables on the standing atomless
space. The outcome order and normalized utility chart will both be the
ordinary identity on the real line, as verified below.

For a finite signed Borel measure $\sigma$ of total mass zero, write

$$S_\sigma(t)=\sigma((t,\infty)).$$

Let $V$ be the real vector space of these profiles, with functions identified
when they agree Lebesgue-almost everywhere. In particular,
$S_X-S_Y=S_{\mathcal L(X)-\mathcal L(Y)}$ belongs to $V$ for every pair of
gambles. Define

$$P=\{v\in V:v\ge0\ \text{almost everywhere}\},$$

$$N=\left\{n\in V:n\text{ is a compactly supported finite-step function},
                       \ \int_{\mathbb R}n=0\right\},
\qquad C=P+N.$$

Here a finite-step function has only finitely many steps. Such compact
profiles correspond to finitely supported signed measures of mass zero;
their integrals are the signed measures' first moments. Endpoints of the
steps do not affect the equivalence class or integrals. Thus $N$ allows
exactly finite-support zero-mean compensations, including real scalar
multiples of them.

Set

$$X\succeq_C Y\quad\Longleftrightarrow\quad S_X-S_Y\in C. \tag{1}$$

The set $P$ is an additive cone and $N$ is a linear subspace. Consequently
$C$ contains zero, is closed under addition, and satisfies
$v\in C\Longleftrightarrow av\in C$ for every $a>0$. Equation (1) is
therefore reflexive and transitive. It depends only on laws, proving
Stochastic Equivalence.

##### Indifference and zero-integral profiles

The indifferent part of this cone is exactly

$$C\cap(-C)=N. \tag{2}$$

For if $v=p+n$ and $-v=q+m$, with $p,q\in P$ and $n,m\in N$, then

$$p+q=-(n+m)\ge0.$$

The right side is integrable with integral zero. Nonnegativity therefore
forces $p=q=0$ almost everywhere, so $v=n\in N$. The converse follows
because $N$ is a subspace contained in $C$.

A useful stronger observation for the examples is

$$v\in L^1,\quad \int v=0
\quad\Longrightarrow\quad
\bigl(v\in C\Longleftrightarrow v\in N\bigr). \tag{3}$$

Indeed, if $v=p+n$, then $p=v-n$ is integrable, nonnegative, and has integral
zero; hence $p=0$. Applying the same observation to $-v$ shows that an
integrable zero-integral profile outside $N$ is incomparable with zero
in the cone ordering, rather than merely non-indifferent.

##### Finite expected utility and the DU axioms

Let $X,Y$ have finite support and put $d=S_X-S_Y$. This is a compact finite-step
profile with

$$m=\int d=E[X]-E[Y].$$

Let $h=S_1-S_0=\mathbf1_{[0,1)}$ almost everywhere. If $m\ge0$, then

$$d=mh+(d-mh),\qquad mh\in P,\quad d-mh\in N,$$

so $X\succeq_CY$. Conversely, if $d=p+n\in C$, then $p=d-n$ is compactly
supported and integrable. Thus $m=\int p\ge0$. This proves **Simple
Expected Utility**, in both directions.

In particular, sure outcomes have their ordinary real ordering and every
binary calibration equation gives the identity utility chart. All real
outcomes are available, so **Rich Outcomes** holds. For $a>b>c$, the binary
mixture with probability $(b-c)/(a-c)$ of $a$ and the remaining probability
of $c$ has expectation $b$ and is indifferent to $b$. Thus **Archimedean
Outcomes** holds.

For **Stochastic Dominance**, a dominating pair has $d\ge0$, so $d\in P$.
If dominance is strict at a threshold, right continuity gives an interval
where $d>0$, so $d$ is not zero almost everywhere. The reverse comparison
would imply $-d=p+n$ and hence $d+p=-n$. The same nonnegative-integral-zero
argument used in (2) forces $d=0$, a contradiction. Thus strict dominance
remains strict.

Randomized selection with a common law gives

$$S_{M_p(X,Z)}-S_{M_p(Y,Z)}=p(S_X-S_Y),\qquad 0<p<1.$$

Positive scalar cancellation for $C$ proves the full **Mixture Independence**
biconditional. These facts verify every assumption in the current DU preset,
without assuming Totality.

##### The least DU preorder

On the common domain of real utility laws, **every DU preorder preserves all
the weak and strict comparisons of (1)**. Thus this model is a least ordering
for DU itself, before any continuity requirement is added. Simple EU is
available in any DU preorder by the separately recorded
[derivation from the primitive DU assumptions](rich-archimedean-dominance-independence-imply-simple-eu.html).

To prove the claim, suppose $S_X-S_Y=p+n\in C$. A nonzero $p\in P$
is the profile of a nonzero finite signed measure of mass zero. Its positive
and negative Jordan parts have the same finite mass $s>0$. Normalize them
to probability laws $\mu_H,\mu_K$. Then

$$p=s(S_H-S_K),\qquad H\succ K$$

in every DU preorder by strict Stochastic Dominance. Nonnegativity of
the profile almost everywhere gives dominance at every threshold by
right continuity. Nonzero $p$ gives strictness. If $p=0$, put $s=0$
and omit this pair of laws instead.

Likewise, a nonzero $n\in N$ is the profile of a finitely supported signed
measure of mass zero and first moment zero. Normalize its Jordan parts,
of common mass $t>0$, to finite laws $\mu_F,\mu_G$. Then

$$n=t(S_F-S_G),\qquad E[F]=E[G],\qquad F\sim G$$

in every DU preorder by Simple EU. If $n=0$, put $t=0$ and omit these
laws. Equality of survival profiles almost everywhere determines their
signed measures, so the decomposition gives the exact measure identity

$$\mu_X+s\mu_K+t\mu_G=\mu_Y+s\mu_H+t\mu_F. \tag{5}$$

Divide by $w=1+s+t$ to obtain probability laws. Stochastic Equivalence
identifies the two normalized mixtures in (5). Replacing $F$ with the
indifferent $G$, and replacing $H$ with the weakly worse $K$, gives

$$\frac{\mu_X+s\mu_K+t\mu_G}{w}
\succeq
\frac{\mu_Y+s\mu_K+t\mu_G}{w}. \tag{6}$$

These are finite mixtures; Mixture Independence and Stochastic Equivalence
license every branch replacement. When $s>0$, the replacement of $H$ by
$K$ is strict, so (6) is strict too. Terms of zero weight were omitted;
no use of the Independence axiom at a mixture weight of zero is needed.

If $s+t>0$, the common mixture law is
$\lambda=(s\mu_K+t\mu_G)/(s+t)$, and the weight of $X$ or $Y$ in (6)
is $1/w\in(0,1)$. Cancel this common branch by Mixture Independence to
obtain $X\succeq Y$, strictly when $s>0$. If $s=t=0$, (5) just says
$\mu_X=\mu_Y$, so Stochastic Equivalence gives indifference directly.

Every strict comparison of (1) has $p\ne0$: otherwise its profile lies
in $N$ and (2) gives indifference. Thus the argument preserves every
strict comparison as well as every weak one. Since (1) itself satisfies
DU, the least-ordering claim follows. This characterization is part of
the original proof recorded here; it is not attributed to a source theorem.

##### Common shifts and other affine transformations

For $a>0$ and real $b$, the survival difference of $aX+b$ and $aY+b$ is

$$d_{a,b}(t)=d((t-b)/a).$$

This invertible transformation preserves $P$. It takes a compact finite-step
function to another one and multiplies its integral by $a$, so it also
preserves $N$ in both directions. It therefore preserves membership in $C$,
proving **Positive Affine Invariance**, including **Shift Invariance**.

Reflection together with comparison reversal sends the profile to
$d(-t)$ almost everywhere: endpoint differences at atoms affect only a
countable null set. This map also preserves $P$, $N$, and $C$ in both
directions, proving **Reflection Anti-Invariance**. These are transformations
of the fixed identity utility chart.

##### Incompleteness and failure of full expected utility

Let $U$ be uniform on $[0,1]$ and compare it with the sure outcome $1/2$.
Their survival difference is, almost everywhere,

$$d(t)=\begin{cases}
-t,&0<t<1/2,\\
1-t,&1/2<t<1,\\
0,&\text{otherwise}.
\end{cases}$$

This profile is integrable with integral zero, but is not a finite-step
function, so (3) gives

$$U\not\succeq_C1/2,\qquad 1/2\not\succeq_CU. \tag{4}$$

Thus **Totality** fails. Both gambles have finite expectation $1/2$, so
**Expected Utility** and **Relative Expectation** fail. The two signed areas
are finite and equal, so **CDF-Area Extension** fails too.

By Shift Invariance, $U-1/2$ is likewise incomparable with zero. Its law is
symmetric, giving an explicit failure of **Symmetric Gambles Are Neutral**.
Reflection Anti-Invariance does not force neutrality in this incomplete
ordering.

##### A direct Shift Transfer counterexample

Take $p=1/2$, transfer parameter $b=1/2$, $X=U$, and $Y=0$. The two gambles
required to be indifferent by Shift Transfer are

$$A=M_{1/2}(U+1,0),\qquad B=M_{1/2}(U,1).$$

Their common expectation is $3/4$. Their survival difference is

$$S_A(t)-S_B(t)=\begin{cases}
(t-1)/2,&0<t<1,\\
(2-t)/2,&1<t<2,\\
0,&\text{otherwise},
\end{cases}$$

almost everywhere. Its negative and positive integrals are each $1/4$.
It is not a finite-step function, so (3) shows that $A$ and $B$ are
**incomparable**. In particular **Shift Transfer fails**, although common
Shift Invariance holds.

The same example directly refutes **Simple Relative Expectation**. Realize
$U$ and an independent fair coin on the standing space, and use that same
coin to define both gambles: on its first branch set $A=U+1$, $B=U$; on
its second branch set $A=0$, $B=1$. Then the actual difference $A-B$
takes only the values $+1$ and $-1$, with equal probabilities. Its mean is
zero, while the law-based ordering still leaves $A,B$ incomparable.

##### Continuity under Vanishing Shifts and L¹ Continuity fail

For every $\varepsilon>0$, choose a positive integer $n$ with
$1/(2n)\le\varepsilon$, and define the simple gamble

$$Q_n=\frac{\lfloor nU\rfloor}{n}+\varepsilon.$$

It satisfies $Q_n\le U+\varepsilon$ pointwise and

$$E[Q_n]=\frac12-\frac1{2n}+\varepsilon\ge\frac12.$$

The probability-zero endpoint $U=1$ does not change this expectation or
finite support. Stochastic Dominance and the already verified Simple EU give

$$U+\varepsilon\succeq_C Q_n\succeq_C1/2
\qquad\text{for every }\varepsilon>0.$$

But (4) says $U\not\succeq_C1/2$. This is exactly a failure of
**Continuity under Vanishing Shifts**. Taking $X_k=U+1/k$ also gives
$E|X_k-U|=1/k\to0$ and $X_k\succeq_C1/2$ for every $k$, while the limit
comparison fails. Thus the recorded upper-section **L¹ Continuity** fails.

The countermodel establishes that DU plus Shift Invariance alone is
insufficient for Shift Transfer. This seed fails Totality. Its separately
recorded [finite-shift total extension](finite-shift-total-extension.html),
added on 13 September 2026, preserves a strict ranking of the transfer pair
and supplies the separation with **DTU** as antecedent. The original seed
and its properties remain unchanged. Its examples also identify the
continuity condition that it lacks.

##### Further verified failures

**Addition: Claude (Fable 5.1), 15 September 2026**, at Zachary Goodsell's
request for a complete picture of the DU + Sym package. The construction and
everything above are unchanged. Criterion (3) is used throughout: an
integrable zero-integral profile is comparable with zero only when it is a
finite-step function, and any element of $C$ is nonnegative outside a
compact set.

**The three prospect evaluations fail.** The alternating St Petersburg,
Pasadena and Arroyo prospects each take arbitrarily large positive and
negative utility values with positive probability. Let $X$ be one of them
and $c$ its prescribed sure value. For $t\ge c$ the profile $S_X-S_c$
equals $S_X(t)\ge0$, and for $t<c$ it equals $S_X(t)-1=-\Pr(X\le t)<0$
on an unbounded set of $t$. So neither $S_X-S_c$ nor its negative is
nonnegative outside a compact set, and neither lies in $C$: $X$ and $c$
are incomparable. Alternating St Petersburg $=-1/2$, Pasadena $=\ln2$ and
Arroyo $=\ln2$ all demand indifference, so all three fail.

**Uniqueness of Negative Self-Similarity fails.** Let $A$ be the
alternating St Petersburg gamble. Its law satisfies
$A\overset d=M_{1/2}(-2A,-2)$, so the two profiles coincide and
$A\sim_C M_{1/2}(-2A,-2)$. The sure outcome $-1/2$ satisfies
$-1/2\sim_C M_{1/2}(1,-2)=M_{1/2}(-2\cdot(-1/2),-2)$ by Simple EU. Both
solve the same self-similarity indifference with $p=1/2$, $a=2$, $b=0$,
$Z=-2$, but $A$ and $-1/2$ are incomparable by the previous paragraph.

**Comonotonic Sum Invariance fails.** Let $X=2\cdot\mathbf1\{U>1/2\}$,
$Y=1$ and $Z=U$. All three are nondecreasing functions of $U$, so both
pairs are comonotonic. $X\sim_CY$ by Simple EU. The sum $X+Z$ is uniform
on $[0,1/2)\cup(5/2,3]$ and $Y+Z$ is uniform on $[1,2]$; both have mean
$3/2$. Their survival difference is $-t$ on $(0,1/2)$, $-1/2$ on
$(1/2,1)$, $t-3/2$ on $(1,2)$, $1/2$ on $(2,5/2)$ and $3-t$ on $(5/2,3)$:
integrable, integral zero, not finite-step. By (3), $X+Z$ and $Y+Z$ are
incomparable, so the biconditional fails.

**Independent Sum Preservation fails.** Take the same $X,Y$ and an
independent uniform $Z$. Then $X+Z$ has the law of $M_{1/2}(U,U+2)$ and
$Y+Z$ that of $1+U$. The survival difference is again piecewise linear with
sloped pieces and integral zero, so the sums are incomparable although
$X\sim_CY$. Weak preservation of indifference fails, hence Independent Sum
Invariance fails as well.

**Existential Copula Sum Invariance fails.** Fix any copula $\mathcal C$
and realize $(U,W)$ with law $\mathcal C$. Put $X=2\cdot\mathbf1\{U>1/2\}$,
$Z=W$ and $Y=1$. Since $X$ is a nondecreasing function of $U$, the pair
$(X,Z)$ admits $\mathcal C$; a constant $Y$ admits every copula. For
$t\in[1,2)$ we have $S_{X+Z}(t)=\Pr(U>1/2)=1/2$ while $S_{1+W}(t)=2-t$, so
the survival difference is sloped on that interval, has integral zero and is
not finite-step. Thus $X+Z$ and $Y+Z$ are incomparable while $X\sim_CY$, and
$\mathrm{SC}(\mathcal C)$ fails. As $\mathcal C$ was arbitrary, no copula
satisfies sum invariance in this model.

These are direct calculations in the recorded model; no independent checker
or Lean verification is claimed.

### Two-sample minimum: zero extension — `finite-two-sample-minimum`

Model; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Totality (`totality`)
- Restricted Totality (`restricted-totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)

Violates:

- Simple Expected Utility (`simple-eu`)
- Mixture Independence (`independence`)
- Stochastic Dominance (`stochastic-dominance`)
- Statewise Dominance (`statewise-dominance`)

Unknown in this model: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

Construction.

Take all measurable real-valued random variables. When the law of X has finite support, put $V(X)=E[\min (X1,X2)]$ for independent copies X1,X2; for every other law put $V(X)=0$. Rank all gambles by their finite real scores V. This is a total law-invariant preorder with sure score $V(x)=x$. The raw outcome coordinate x differs from the normalized utility chart: the outcome at chart level r is $x=r^{2}$ for $r\ge 0$ and $x=- r^{2}/(1- 2r)$ for $r<0$. This is a continuous increasing bijection of the real line, satisfying all three binary calibration clauses. Thus the chart is total, measurable and onto, and Archimedean Outcomes holds: a binary mixture of $a>c$ has score $c+(a- c)p^{2}$, which reaches any intermediate b at $p=\sqrt ((b- c)/(a- c))$. Nevertheless the fair raw-outcome gamble {1,4} has score 7/4, below sure 9/4, although both have expected chart utility 3/2. The write-up also gives exact mixture-independence and dominance failures.

Executable checks: `topics/unbounded-utility/checks/finite_two_sample_minimum.py`.

Notes. Original work: elementary countermodel construction, calibration audit and explicit finite witnesses. This records the work performed for the project, without asserting literature novelty. Finite support refers to the probability law, so changes on null sets do not change the assigned score. The value-zero clause for all other laws makes the construction a total preorder on the full standing domain; its dominance failures are explicit. The example shows that Rich Outcomes and Archimedean Outcomes alone do not entail Simple EU, even after adding Totality and Stochastic Equivalence. Additional DU premises such as Mixture Independence remain essential to the separate representation argument. Other principle verdicts are left to recorded implications or future analysis. No independent checker or Lean verification is asserted.

Sources:

- **GPT-6 counterexample 9 Sep** — GPT-6 (Codex), Logical Maps project discussion, 9 September 2026: counterexample developed in response to the proposed Rich Outcomes plus Archimedean Outcomes implication to Simple Expected Utility; full construction and proofs in writeups/finite-two-sample-minimum.md.



Record: `topics/unbounded-utility/models/finite-two-sample-minimum.yaml`.

Write-up.

#### Two-sample minimum: zero extension

This model satisfies **Rich Outcomes, Archimedean Outcomes, Totality and
Stochastic Equivalence**, while violating Simple Expected Utility and Mixture
Independence. The distinction between the **raw outcome coordinate** and the
**normalized utility chart** is essential to the construction.

**Source and work accounting.** GPT-6 (Codex), Logical Maps project discussion,
9 September 2026. This is an elementary countermodel construction with an
explicit calibration audit and finite witnesses, recorded under Misc. The
work accounting concerns this project and makes no claim of literature
novelty. No independent checker or Lean verification is asserted.

##### The preference on the full domain

Take outcomes to be the real line with its usual Borel structure and order,
and take all measurable real-valued random variables on the standing atomless
probability space. Reference outcomes are the raw numbers 0 and 1.

For a finitely supported law

\[
\mu=\sum_{i=1}^n p_i\delta_{x_i},
\]

put

\[
V(\mu)=\sum_{i,j=1}^n p_i p_j\min(x_i,x_j).
\tag{1}
\]

This is the expected minimum of two independent draws from that law. For
every law that does **not** have finite support, put $V(\mu)=0$. Define

\[
X\succeq Y\quad\Longleftrightarrow\quad
V(\mathcal L(X))\ge V(\mathcal L(Y)).
\tag{2}
\]

Every score is a finite real number. Consequently (2) is reflexive,
transitive and total. It depends only on laws, proving Stochastic Equivalence.
It also proves Restricted Totality and Restricted Stochastic Equivalence.
Finite support is a property of the law: a variable with infinitely many
exceptional values on a null set receives the same score as its almost-sure
finite-valued representative.

A sure raw outcome $x$ has score $x$, so the sure preference order agrees
exactly with the ordinary order on the outcome space, as the framework requires.

##### Binary mixtures and Archimedean Outcomes

For raw outcomes $a>c$, a mixture with probability $p$ of $a$ has minimum

\[
\min(X_1,X_2)=a
\]

only when both independent draws give $a$, an event of probability $p^2$.
Thus

\[
V(M_p(a,c))=c+(a-c)p^2.
\tag{3}
\]

For any $a>b>c$, choose

\[
p=\sqrt{\frac{b-c}{a-c}}\in(0,1).
\]

Equation (3) gives $M_p(a,c)\sim b$, proving Archimedean Outcomes.

##### The actual normalized chart

The framework defines a chart level $r$ by binary comparisons with reference
outcomes 0 and 1. It does not identify that level with an arbitrary numerical
label on outcomes. In this model the raw outcome at chart level $r$ is

\[
f(r)=
\begin{cases}
r^2,&r\ge0,\\
-\dfrac{r^2}{1-2r},&r<0.
\end{cases}
\tag{4}
\]

All three branches of the chart definition can be checked directly:

- For $0\le r\le1$, equation (3) gives $V(M_r(1,0))=r^2=f(r)$.
- For $r>1$, it gives $V(M_{1/r}(f(r),0))=f(r)/r^2=1$.
- For $r<0$, put $p=-r/(1-r)\in(0,1)$. Then
  $V(M_p(1,f(r)))=f(r)+(1-f(r))p^2=0$.

These equations also determine the raw outcome uniquely. The first branch
requires a raw outcome between 0 and 1, the second one strictly above 1,
and the last one strictly below 0: a nontrivial binary-mixture score is
strictly between the scores of its distinct endpoints. Solving in the
respective ranges gives exactly (4).

The function $f$ is a continuous strictly increasing bijection of the real
line. On the negative half-line,

\[
f'(r)=\frac{2r(r-1)}{(1-2r)^2}>0;
\]

its limits at the ends of the real line are $-\infty$ and $+\infty$,
and its two formulas meet at zero. The normalized utility chart is therefore
the continuous inverse

\[
u(x)=f^{-1}(x)=
\begin{cases}
\sqrt{x},&x\ge0,\\
x-\sqrt{x^2-x},&x<0.
\end{cases}
\tag{5}
\]

The chart is single-valued, defined on every outcome, measurable and onto
the real line. In particular, **Rich Outcomes holds with precisely the
framework's calibration-based meaning**, including every negative level.

##### Simple Expected Utility fails

Let $X=M_{1/2}(4,1)$, with 4 and 1 still denoting raw outcomes, and let

\[
Y=\text{sure }9/4.
\]

Their normalized chart utilities satisfy

\[
E[u(X)]=\frac12\cdot2+\frac12\cdot1=\frac32
=u(9/4)=E[u(Y)].
\]

But their scores are

\[
V(X)=1+(4-1)\left(\frac12\right)^2=\frac74,
\qquad V(Y)=\frac94.
\]

Thus $Y\succ X$, contradicting the indifference required by Simple Expected
Utility. Another normalized chart cannot repair this discrepancy, because
the calibration computation established that (5) is the unique chart.

##### Mixture Independence fails

Put $L=M_{1/2}(4,0)$. Equation (3) gives $V(L)=1$, so $L\sim1$.
The law of $M_{1/2}(L,1)$ gives raw outcomes 0, 1 and 4 probabilities

\[
\frac14,\quad\frac12,\quad\frac14.
\]

For two independent draws from this law, the minimum is at least 1 with
probability $9/16$, and is 4 with probability $1/16$. Hence

\[
V(M_{1/2}(L,1))=\frac9{16}+3\frac1{16}=\frac34<1
=V(M_{1/2}(1,1)).
\]

The true comparison $L\succeq1$ becomes false after mixing both sides
equally with sure 1, violating Mixture Independence.

##### The explicit dominance failures

Let $U(\omega)=2+\omega$ on $[0,1]$ with Lebesgue measure. Its law is
uniform on $[2,3]$, so the second clause of the construction assigns

\[
V(U)=0<1=V(\text{sure }1).
\]

Nevertheless $U>1$ at every state. This disproves Statewise Dominance.
It also disproves Stochastic Dominance: the survival probability for $U$
is at least that of sure 1 at every threshold, and is strictly greater at
threshold 1. The preference ranks sure 1 strictly above $U$.

The model therefore witnesses that even Rich Outcomes, Archimedean Outcomes,
Totality and Stochastic Equivalence together do not imply Simple EU.
The separate DU representation argument must use its additional premises.

The accompanying exact-arithmetic diagnostic checks the displayed finite
scores and representative calibrations in all three chart ranges. The
analytic arguments above establish the universal claims.

### Clipped expectation: continuous ultrafilter dominance [−4ⁿ, 4ⁿ] — `geometric-continuous-ultrafilter`

Model; source **Misc.**; produced by Zachary Goodsell (continuous clipping construction); GPT-6 (Codex) (geometric-cutoff specialization and additional verifications); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- CDF-Area Extension (`cdf-area-extension`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Folded Expectation (`folded-expectation`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Shift Invariance (`shift-invariance`)

Violates:

- Scale Invariance (`scale-invariance`)
- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)

Unknown in this model: Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Pasadena = ln 2 (`pasadena-value`)

Construction.

Use real outcomes with identity utility, choose a free ultrafilter U on positive integers, and put $v_X(n)=E[\max (- 4^n,\min (X,4^n))]$. Define $X \succeq Y$ iff for every $\epsilon >0, \{n:v_X(n)\ge v_Y(n)- \epsilon \}$ belongs to U. This specializes Goodsell’s continuous clipped-expectation construction to geometric cutoffs. The write-up proves DTU, CDF-Area Extension, $L^{1}$ Continuity and Folded Expectation directly, with reflection and shift. For alternating St Petersburg $A, v_A(n)=- 1/3$ and $v_{2A}(n)=- 4/3$ for every $n\ge 1$, so $A \succ - 1/2$ while $2A \prec - 1$. This verifies failure of Scale Invariance and the recorded alternating evaluation without relying on the printed scale witness. A and sure −1/2 both satisfy the same negative self-similarity equation, but have different values, so that uniqueness principle also fails.

Executable checks: `topics/unbounded-utility/checks/geometric_clipping.py`, `topics/unbounded-utility/checks/comonotonic_witnesses.py`.

Notes. Original work: model adaptation and direct verification. Reuses Goodsell’s continuous ultrafilter ordering; the preference construction is not claimed as original. New work here chooses cutoffs $4^n$ to fix an exact alternating-game value, gives an explicit scaling reversal and nonunique self-similarity witness, and proves additional area/continuity/folded flags. This describes work performed in this project, not a claim of novelty in the literature. A free ultrafilter is nonconstructive; the numerical check verifies the finite formulas and estimates, not ultrafilter existence or all quantified axioms.

Revisions:

- **2026-09-23** (Claude (Fable 5.1)) — Comonotonic Sum Invariance shown to fail (write-up section “Failure of Comonotonic Sum Invariance”). A standard Cauchy C is indifferent to sure 0, but with the common comonotonic summand Z = max(C,0) the clipped gap at cutoff 4ⁿ is 2∫_{4ⁿ/2}^{4ⁿ} P(C>x)dx → (2 ln 2)/π, so 0 + Z ≻ C + Z. Now violates: Comonotonic Sum Invariance.

Sources:

- **Decision Theory Unbound** — Zachary Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, Appendix B, Definition 3, Lemma 6 and proof of Theorem 3, pp. 691–692; Theorems 7–10, pp. 693–695: underlying continuous clipping construction and original scale-failure strategy.
- **GPT-6 model adaptation 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/geometric-continuous-ultrafilter.md: geometric-cutoff specialization, explicit alternating-St-Petersburg witness, and additional CDF-area/L¹/folded-expectation verifications.
- **Claude comonotonic failure 23 Sep** — Claude (Fable 5.1), Logical Maps, 23 September 2026: failure of Comonotonic Sum Invariance (half-Cauchy common summand) in writeups/geometric-continuous-ultrafilter.md; diagnostic checks/comonotonic_witnesses.py.

- **Background: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — Appendix B, Definition 3, Lemma 6 and proof of Theorem 3, pp. 691–692; Theorems 7–10, pp. 693–695: underlying continuous clipping construction and original scale-failure strategy

Record: `topics/unbounded-utility/models/geometric-continuous-ultrafilter.yaml`.

Write-up.

#### Clipped expectation: continuous ultrafilter dominance [−4ⁿ, 4ⁿ]

Source: **Misc.** Construction by Zachary Goodsell; specialization and the additional
proofs below by GPT-6 (Codex), 9 September 2026. No independent checker or Lean
verification is asserted.

**Original work: model adaptation and direct verification.** We reuse the continuous
ultrafilter construction from *Decision theory unbound*, Appendix B, Definition 3,
Lemma 6 and Theorem 3. Choosing geometric cutoffs supplies an explicit alternating-game
evaluation and scaling reversal. The CDF-area, $L^{1}$ and folded-expectation verifications
below establish extra properties of this construction. This is an account of work
done for the map, not a claim that these observations are new in the literature.

##### Construction and DTU

Outcomes are real utilities; all measurable random variables on the standing sample
space are available. Choose a free ultrafilter \(\mathcal U\) on the positive integers.
Put \(t_n=4^n\), \(c_t(x)=\max(-t,\min(x,t))\), and

\[
v_X(n)=E[c_{t_n}(X)],\qquad
X\succeq Y\iff
\forall\varepsilon>0\quad
\{n:v_X(n)-v_Y(n)\ge-\varepsilon\}\in\mathcal U.
\]

Changing a comparison sequence by a sequence tending to zero leaves this relation
unchanged. A positive lower bound on an ultrafilter-large set gives strict preference.
If a difference converges to a finite number, its comparison is exactly the sign of
that number, including indifference at zero.

Reflexivity is immediate. For transitivity, intersect the two sets corresponding
to tolerance \(\varepsilon/2\). If \(X\not\succeq Y\), ultrafilter dichotomy gives
an \(\varepsilon>0\) and an ultrafilter-large set where
\(v_Y-v_X>\varepsilon\). Thus \(Y\succ X\), establishing totality.
These statements use addition and positive scalar multiplication of comparison
sequences; no multiplication of arbitrary unbounded quotient classes is needed.

Equal laws have identical clipped expectations. For bounded, hence simple, variables
clipping eventually disappears; their comparisons are ordinary expectations. In
particular the normalized chart is the identity and every real utility is realized.
Randomized mixtures satisfy
\(v_{M_p(X,Z)}=p v_X+(1-p)v_Z\), so cancelling the common term and rescaling
\(\varepsilon\) proves both directions of Mixture Independence.

For survival functions \(S_X\), bounded layer integration gives

\[
v_X(n)-v_Y(n)=\int_{-t_n}^{t_n}(S_X(s)-S_Y(s))\,ds.
\]

Stochastic dominance makes the integrand nonnegative. If it is strictly positive
at one threshold, right-continuity gives a positive integral over some bounded
interval. Every sufficiently large cutoff therefore has a fixed positive gap.
This proves strict as well as weak Stochastic Dominance, and finishes DTU.

##### Additional expectation and continuity properties

Write \(d=S_X-S_Y\) and \(A_\pm=\int d_\pm\). If at least one of these areas is
finite, monotone convergence of the positive and negative parts over
\([-t_n,t_n]\) shows that the clipped difference tends to the well-defined extended
difference \(A_+-A_-\). The preceding sign criterion proves **CDF-Area Extension**,
including the equality case and both possible infinite signs. Consequently the
recorded CDF-area implications give Relative Expectation and Expected Utility.

For **L¹ Continuity**, clipping is 1-Lipschitz, so for every cutoff

\[
|v_{X_k}(n)-v_X(n)|\le E|X_k-X|.
\]

If this last quantity tends to zero and every \(X_k\succeq Y\), fix
\(\varepsilon>0\) and choose one \(k\) with error below \(\varepsilon/2\).
On the ultrafilter-large set where \(v_{X_k}-v_Y\ge-\varepsilon/2\), we have
\(v_X-v_Y\ge-\varepsilon\). This is exactly the required upper-section closure.
It also applies when other distances in the domain are infinite.

For **Folded Expectation**, put
\(h_X(s)=P(X>s)-P(X<-s)\). Layer integration gives
\(v_X(n)=\int_0^{t_n}h_X(s)\,ds\); boundary atoms change no integral.
If \(h_X,h_Y\) are absolutely integrable, these converge to their folded
expectations. Their finite difference is therefore compared by its sign.

Reflection negates every clipped expectation, proving **Reflection Anti-Invariance**.
For a real constant \(b\),
\(c_t(X+b)-c_t(X)\to b\) pointwise with absolute value at most \(|b|\).
Dominated convergence shows that shifting both compared variables changes the
clipped difference by a sequence tending to zero. This proves **Shift Invariance**.
No individual integrability of the variables is required.

##### Explicit failures of scale, alternating evaluation and uniqueness

Let \(A\) have \(P(A=(-2)^j)=2^{-j}\), \(j\ge1\). For
\(2^k\le t\le2^{k+1}\), summing the finite prefix and the geometric tail gives

\[
E[c_t(A)]
=\sum_{j=1}^k(-1)^j+
  \frac{(-1)^{k+1}t}{3\,2^k}.
\]

At \(t_n=4^n\), this equals \(-1/3\), whereas
\(E[c_{t_n}(2A)]=2E[c_{t_n/2}(A)]=-4/3\). Hence

\[
A\sim-1/3\succ-1/2,
\qquad 2A\sim-4/3\prec-1.
\]

This is a concrete scaling reversal in every free-ultrafilter choice used here.
It also directly violates the recorded Alternating St Petersburg Value principle.

The law of \(A\) is the half-mixture of \(-2A\) and sure \(-2\): the sure
branch supplies the first atom and the other branch supplies all subsequent atoms.
Stochastic Equivalence gives
\(A\sim M_{1/2}(-2A,-2)\). The sure gamble \(q=-1/2\) satisfies the same
fixed-value equation by Simple EU, since
\(\frac12(-2q)+\frac12(-2)=q\). Nevertheless \(A\not\sim q\).
With \(p=1/2,a=2,b=0,Z=-2\), these are two witnesses refuting **Uniqueness of
Negative Self-Similarity**.

##### Scope and validation

The model satisfies DTU together with CDF-Area Extension, $L^{1}$ Continuity, Folded
Expectation, reflection and shift, yet fails scale and the two calculation/evaluation
principles just exhibited. Further exclusions are derived by the map's implication
records, not asserted without evidence. The free ultrafilter remains nonconstructive.

`checks/geometric_clipping.py` checks the geometric-tail calculation against a
separate finite-sum calculation with a rigorous residual bound, the scaling reversal,
and the finite Lipschitz estimate. Those checks are diagnostics; the quantified
claims rely on the proofs above.

##### References

- Zachary Goodsell, *Decision theory unbound*, Noûs 58 (2024), 669–695,
  DOI 10.1111/nous.12473, Appendix B, pp. 691–695. Original construction and
  scale-failure strategy; the explicit witness above is a separate verification.
- GPT-6 (Codex), project research on 9 September 2026: this specialization,
  additional property proofs and explicit witnesses.

##### Failure of Comonotonic Sum Invariance

**Addition: Claude (Fable 5.1), 23 September 2026.** A property of the
recorded model; not a claim of the source paper.

Realize a standard Cauchy variable as \(C=Q_C(U)=\tan(\pi(U-\tfrac12))\) and
put \(X=0\), \(Y=C\), \(Z=C_+=\max(C,0)\), all nondecreasing in \(U\), so both
pairs are comonotonic. The clipping \(\max(-4^n,\min(x,4^n))\) is odd and
\(C\) is symmetric, so \(v_C(n)=0=v_0(n)\) and \(X\sim Y\).

**Doubling-defect identity.** For any nonnegative random variable $V$ and
any $F>0$,

\[2\,\mathbb E[\min(V,F)]-\mathbb E[\min(2V,F)]
 =2\int_{F/2}^{F}P(V>x)\,dx,\]

since $\mathbb E[\min(V,F)]=\int_0^F P(V>x)\,dx$ and
$\mathbb E[\min(2V,F)]=2\int_0^{F/2}P(V>x)\,dx$. For $V=C_+=\max(C,0)$ with
$C$ standard Cauchy the right-hand side is
$\frac2\pi\int_{F/2}^{F}\arctan(1/x)\,dx$, which is positive for every $F$
and increases to $\frac{2\ln2}{\pi}$ as $F\to\infty$.

With \(X+Z=C_+\), \(Y+Z=2C_++C_-\), \(C_-=\min(C,0)\), and
\(\mathbb E[\max(C_-,-4^n)]=-\mathbb E[\min(C_+,4^n)]\),

\[
v_{X+Z}(n)-v_{Y+Z}(n)=2\int_{4^n/2}^{4^n}P(C>x)\,dx\longrightarrow\frac{2\ln2}{\pi}>0.
\]

With \(\varepsilon=(\ln2)/\pi\), the set \(\{n:v_{Y+Z}(n)\ge v_{X+Z}(n)-\varepsilon\}\)
is finite, hence outside the free ultrafilter, while \(v_{X+Z}\ge v_{Y+Z}\)
for every \(n\). So \(X+Z\succ Y+Z\) although \(X\sim Y\): Comonotonic Sum
Invariance fails, even though Shift Invariance, CDF-Area Extension, \(L^1\)
Continuity and Folded Expectation hold. `checks/comonotonic_witnesses.py`
verifies the calculation.

### Folded-tail cone: lexicographic extension — `lexicographic-folded-extension`

Model; source **Misc.**; produced by GPT-6 (Codex) (folded-tail quotient and infinitesimal separation), adapting Zachary Goodsell's area-cone and total-extension methods; recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- CDF-Area Extension (`cdf-area-extension`)
- Relative Expectation (`relative-expectation`)
- Folded Expectation (`folded-expectation`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Shift Invariance (`shift-invariance`)

Violates:

- L¹ Continuity (random variables) (`l1-continuity`)
- Scale Invariance (`scale-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)

Unknown in this model: Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Pasadena = ln 2 (`pasadena-value`)

Construction.

Take all real-valued random variables. In the vector space spanned by their folded-tail profiles $h_X(t)=P(X>t)- P(X<- t), t>0$, quotient out every integrable profile of integral zero. The base positive cone consists of profiles with integrable negative part and nonnegative finite or positive-infinite integral. Put $e=[h_1], q=- 1/2$, and $f=[h_A- h_q]$ for the alternating St Petersburg gamble A. Both sign areas of $h_A- h_q$ are infinite, so this cone meets span(e,f) only in the nonnegative e ray. Add the lexicographic cone $a e+b f>0$ iff $a>0$ or $a=0,b>0$, then extend the resulting pointed cone to a total pointed cone by Zorn's lemma. Define $X\succeq Y$ by membership of $[h_X- h_Y]$. The write-up verifies every satisfied axiom. In particular $q\prec A\prec q+\epsilon$ for every $\epsilon >0$. Hence constants $q+1/n$ converge in $L^{1}$ to q and all exceed A, while q does not weakly exceed A; the recorded upper-section $L^{1}$ Continuity fails. The distributional recursion of A gives a scaling reversal and nonunique negative self-similarity. The total extension is an existence construction, not an algorithm.

Executable checks: `topics/unbounded-utility/checks/lexicographic_folded_extension.py`.

Notes. Original work: substantial model adaptation and separation. Goodsell supplies the area-order idea, folded-tail evaluations, alternating-game recursion and use of total cone extensions. Work here passes to folded profiles modulo zero-integral L1 profiles, inserts an infinitesimal lexicographic comparison, proves that the two cones remain compatible, and gives an explicit upper-section continuity counterexample. This establishes DTU + Folded Expectation (even with Relative Expectation, reflection, shift and CDF-Area Extension) does not imply L1 Continuity. It does not contradict the source equivalence under full affine symmetry: Scale Invariance fails in this model. This is work accounting, not a claim of literature priority. The executable diagnostic checks exact dyadic tails and finite lexicographic witnesses; it does not execute the nonconstructive extension or certify the quantified axioms.

Sources:

- **GPT-6 model adaptation 9 Sep** — GPT-6 (Codex), original model adaptation and separation in Logical Maps, 9 September 2026; writeups/lexicographic-folded-extension.md.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Folded Expectation and its tail representation, pp. 27–29; alternating St Petersburg and negative self-similarity, pp. 29–31; cone-extension framework, §5, pp. 33–37.
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §3, pp. 7–8, the base area preorder. Its withdrawn symmetric-extension theorem is not used.

- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — pp. 27–29; alternating St Petersburg and negative self-similarity, pp. 29–31; cone-extension framework, §5, pp. 33–37
- **Background: Unbounded Utility and Background Risk.** Zachary Goodsell (5 June 2026). Unbounded Utility and Background Risk. Unpublished working manuscript. — §3, pp. 7–8, the base area preorder. Its withdrawn symmetric-extension theorem is not used

Record: `topics/unbounded-utility/models/lexicographic-folded-extension.yaml`.

Write-up.

#### Folded-tail cone: lexicographic extension

**Result.** There exists a model of DTU + Folded Expectation + Relative Expectation
+ CDF-Area Extension + Reflection Anti-Invariance + Shift Invariance which fails
$L^{1}$ Continuity. Scale Invariance, the alternating St Petersburg evaluation and
Uniqueness of Negative Self-Similarity fail too.

The construction assigns the alternating gamble a value *infinitesimally above*
$-1/2$: it is strictly better than $-1/2$ but strictly worse than $-1/2+\varepsilon$
for every real $\varepsilon>0$. The word "infinitesimal" describes comparisons
in an ordered vector space; no hyperreal field is assumed.

##### 1. Folded profiles and the base cone

Use all real-valued random variables on the standing sample space, with identity
utility. For each $X$ define its folded-tail profile on $(0,\infty)$ by

$$h_X(t)=\Pr(X>t)-\Pr(X<-t).$$

Let $W$ be the real vector space spanned by these profiles, identifying functions
that agree Lebesgue-almost everywhere. Define the linear subspace

$$N=\left\{g\in W\cap L^1(0,\infty):\int_0^\infty g(t)\,dt=0\right\},
\qquad V=W/N.$$

This quotient is part of the model's construction, not a change to the topic's
standing random-variable objects. Preferences will still be defined on every
actual random variable.

In $W$ put

$$C=\left\{g:\int g_-<\infty,\quad \int g_+\ge\int g_-\right\}.$$

Here either sign area may initially be infinite; membership requires a finite
negative area. Thus the signed integral is well-defined and nonnegative, with
$+\infty$ allowed. Addition and nonnegative scalar multiplication make $C$ a
convex cone. The inequality $(g+k)_-\le g_-+k_-$ and additivity of the
one-sided signed integral prove addition closure. Moreover

$$C\cap(-C)=N,\qquad C+N=C.$$

Indeed membership in both signs makes both areas finite and equal; adding an
integrable zero-integral profile preserves integrability of the negative part
and the integral. Consequently the image $K=C/N$ is a **pointed** convex cone
in $V$: $K\cap(-K)=\{0\}$.

Write $e=[h_1]$. Since $h_1=\mathbf1_{(0,1)}$ a.e., its integral is one and
$e\ne0$. Every integrable profile $g$ has

$$[g]=\left(\int g\right)e. \tag{1}$$

This identity will enforce both ordinary and folded expected-value comparisons
in every pointed cone extending $K$.

##### 2. An oscillating profile and a compatible lexicographic plane

Let $A$ be the alternating St Petersburg gamble

$$\Pr(A=(-2)^j)=2^{-j},\qquad j\ge1,$$

and let $q=-1/2$ be a sure outcome. Define $f=[h_A-h_q]$.
For every integer $k\ge1$ and every $t\in(2^k,2^{k+1})$, direct summation of
the geometric tail gives

$$h_A(t)=\sum_{j=k+1}^\infty(-1)^j2^{-j}
=\frac{(-1)^{k+1}}{3\,2^k}. \tag{2}$$

As $h_q(t)=0$ for $t>1/2$, each interval $(2^k,2^{k+1})$ contributes exactly
$1/3$ to the absolute area of $h_A-h_q$, with sign alternating between
positive and negative intervals. Thus **both sign areas are infinite**.
Adding any integrable function cannot change that fact, for either nonzero
scalar multiple of this profile.

It follows that $e,f$ are linearly independent in $V$, and that

$$K\cap\operatorname{span}\{e,f\}=\{a e:a\ge0\}. \tag{3}$$

To check (3), a representative of $ae+bf$ is
$a h_1+b(h_A-h_q)+n$ with $n\in N$. If $b\ne0$, both sign areas remain
infinite, so it is not in $C$. If $b=0$, the profile is integrable with integral
$a$, so membership is equivalent to $a\ge0$.

On this plane define the lexicographic cone

$$D=\{ae+bf:a>0\}\;\cup\;\{bf:b\ge0\}.$$

This is a pointed convex cone, and

$$0<_D f<_D\varepsilon e\qquad\text{for every }\varepsilon>0. \tag{4}$$

The sum $K+D$ is also pointed. If $k_1+d_1=-(k_2+d_2)$ with $k_i\in K$
and $d_i\in D$, then

$$k_1+k_2=-(d_1+d_2)\in K\cap\operatorname{span}\{e,f\}.$$

By (3) the left side is $ae$ for $a\ge0$, while $-ae\in D$ forces $a=0$.
Pointedness of the two original cones now gives $k_1=k_2=d_1=d_2=0$.
Thus adjoining (4) does not collapse any strictly positive comparison in $K$.

##### 3. Total extension

Partially order by inclusion the pointed convex cones containing $K+D$.
The union of a chain is still pointed and convex: each forbidden pair or
finite closure operation would already occur in one member of the chain.
Zorn's lemma therefore gives a maximal such cone $T$.

It is total: $T\cup(-T)=V$. Otherwise choose $v$ with neither $v$ nor $-v$
in $T$. Then $T+\mathbb R_{\ge0}v$ remains pointed. Indeed a vector and its
negative in this new cone would give

$$0=t_1+t_2+(a+b)v,\qquad t_1,t_2\in T,\quad a,b\ge0.$$

If $a+b>0$, this puts $-v$ in $T$, a contradiction; if $a+b=0$, pointedness
of $T$ forces both terms to be zero. This would properly enlarge $T$, also
a contradiction. Every nonzero element of $K+D$ stays strictly positive
because a pointed extension cannot also contain its negative.

Define preferences by

$$X\succeq Y\quad\Longleftrightarrow\quad[h_X-h_Y]\in T. \tag{5}$$

The total cone is an existence construction; no comparison algorithm for
arbitrary profiles is claimed.

##### 4. Verification of the satisfied principles

**Preordering, Totality and Stochastic Equivalence.** Cone addition gives
transitivity, zero gives reflexivity, and totality of $T$ compares every pair.
Equal laws give identical profiles, so they are indifferent.

**Rich Outcomes and Simple EU.** All reals are outcomes. Simple variables have
integrable folded profiles whose integrals are their ordinary expectations.
Equation (1) compares them exactly by those expectations, including sure
outcomes and all calibrating binary lotteries. Hence the normalized utility
chart is the identity, and every real utility level is realized.

**Mixture Independence.** Probability-mixture linearity gives

$$h_{M_p(X,Z)}-h_{M_p(Y,Z)}=p(h_X-h_Y).$$

For $p>0$, cone membership is unchanged by this multiplication in either
direction, proving the full biconditional.

**Weak and strict Stochastic Dominance.** Put $d=S_X-S_Y$. Except at atom
thresholds,

$$h_X(t)-h_Y(t)=d(t)+d(-t)\qquad(t>0). \tag{6}$$

If $d\ge0$, the profile in (6) is nonnegative and belongs to $C$. If dominance
is strict at some threshold, right-continuity of survival functions supplies
a bounded interval of positive area. Thus (6) has strictly positive finite
or infinite integral. Its class is a nonzero member of $K$, so the comparison
is strict in $T$ too.

**CDF-Area Extension.** Suppose first that $\int_{\mathbb R}d_-<\infty$.
By (6),

$$\int_0^\infty(h_X-h_Y)_-
\le\int_{\mathbb R}d_-<\infty.$$

Change of variables in the well-defined one-sided integral gives

$$\int_0^\infty(h_X-h_Y)=\int_{\mathbb R}d,$$

including $+\infty$. If the latter is positive the class is strictly positive
in $K$; if zero it vanishes in $V$; if negative it is strictly negative.
When only $\int d_+$ is finite, apply the same reasoning to $-d$. These
are exactly all comparisons required by CDF-Area Extension, with strictness
and equality preserved. Both-infinite pairs remain unrestricted by that axiom.

**Relative Expectation.** If the actual difference $X-Y$ is integrable,
the indicator and Fubini formulas give $d\in L^1(\mathbb R)$ and
$\int d=\mathbb E(X-Y)$. Equations (1) and (6) therefore give exactly the
required sign comparison.

**Folded Expectation.** If $h_X,h_Y$ are both integrable, equation (1) gives
$[h_X-h_Y]=(F(X)-F(Y))e$. Definition (5) compares them exactly by their
folded expectations.

**Reflection Anti-Invariance.** The exact identity $h_{-X}=-h_X$ gives
$h_{-Y}-h_{-X}=h_X-h_Y$. Thus reversing and reflecting a comparison leaves
its class unchanged.

**Shift Invariance.** For every real $b$, the pointwise difference
$(X+b)-X=b$ is integrable. The Relative Expectation computation above gives

$$[h_{X+b}-h_X]=be.$$

Consequently shifting both compared variables leaves their difference class
unchanged. This argument requires no individual integrability of $X$ or $Y$.

##### 5. Explicit failures

By (1), $[h_q]=qe$, and by definition $[h_A]=qe+f$. Equations (4) and (5)
therefore give

$$q\prec A\prec q+\varepsilon\qquad(\varepsilon>0). \tag{7}$$

For **failure of the recorded upper-section L¹ Continuity**, take
$X_n=q+1/n$, $X=q$, and $Y=A$. Their actual-coupling distances satisfy
$\mathbb E|X_n-X|=1/n\to0$, and every $X_n\succeq Y$, but $X\not\succeq Y$.
No lower-section continuity is assumed or needed for this witness.

For the **scaling reversal**, use the law identity

$$A\overset d=M_{1/2}(-2A,-2).$$

It gives $[h_A]=-[h_{2A}]/2-e$, hence

$$[h_{2A}]=-e-2f.$$

Thus $A\succ-1/2$, while $2A\prec-1$. Scale Invariance fails at scale two.
The first of these inequalities also directly refutes the specified alternating
St Petersburg value.

For **failure of Uniqueness of Negative Self-Similarity**, both $A$ and sure
$q=-1/2$ satisfy $X\sim M_{1/2}(-2X,-2)$. For $A$ this follows from the
law recursion and Stochastic Equivalence; for $q$ it is Simple EU. Yet (7)
says $A\not\sim q$.

##### Attribution, original work and limits

**Original work: substantial model adaptation and separation.** Zachary
Goodsell supplies the base area-preorder idea, the folded-tail evaluation
principle, the alternating-gamble recursion and the use of total cone
extensions. The present model changes the ordered space to folded profiles
modulo all zero-integral $L^{1}$ profiles, adds the compatible infinitesimal plane,
and proves the explicit continuity separation. Its direct source is **Misc.**,
with GPT-6 (Codex) credited for that adaptation. This is an account of work
performed for the map, not a claim of literature priority.

The construction does **not** contradict *Symmetries of value*, Corollary 5:
that result assumes full affine symmetry, including Scale Invariance, which
fails here. The source's unpublished erroneous symmetric-extension theorem
is not invoked. The extension step in §3 is proved directly and imposes no
additional convolution or scaling invariance.

The diagnostic `checks/lexicographic_folded_extension.py` checks the exact
dyadic tail formula, the repeated positive/negative area contributions,
lexicographic witness inequalities and the distributional recursion. It does
not simulate Zorn's lemma or certify arbitrary infinite-dimensional claims.
No independent checker or Lean proof is claimed.

**References.** Zachary Goodsell, *Symmetries of value*, pp. 27–31 and §5,
pp. 33–37; *Unbounded Utility and Background Risk*, unpublished manuscript,
§3, pp. 7–8 (the base area preorder only). Model adaptation and proofs:
GPT-6 (Codex), 9 September 2026.

### Lexicographic expectation: nonatomic mass — `lexicographic-nonatomic-mass`

Model; source **Misc.**; produced by GPT-6 (Codex), countermodel and proof in response to Zachary Goodsell's proposed implications; recorded by GPT-6 (Codex), 2026-09-13; checked by nobody; Lean stated; 2026-09-13.

Satisfies:

- Archimedean Outcomes (`archimedean-outcomes`)
- Totality (`totality`)
- Restricted Totality (`restricted-totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Statewise Dominance (`statewise-dominance`)
- Mixture Independence (`independence`)
- Sure-Thing (`sure-thing`)
- Countable Sure-Thing (`countable-sure-thing`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Shift Invariance (`shift-invariance`)
- Scale Invariance (`scale-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Pasadena = ln 2 (`pasadena-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

Violates:

- Rich Outcomes (`rich-outcomes`)
- Expected Utility (`expected-utility`)
- Archimedean Gambles (`archimedean-gambles`)
- Relative Expectation (`relative-expectation`)
- CDF-Area Extension (`cdf-area-extension`)
- Folded Expectation (`folded-expectation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Preservation (`independent-sum-preservation`)
- Full Sum Invariance (`full-sum-consistency`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Antitonic Sum Invariance (`antitonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Universal Copula Sum Invariance (`universal-copula-sum-consistency`)

Unknown in this model: nothing; every principle is settled.

Construction.

Take outcomes [0,1] and all measurable outcome-valued gambles. Rank X lexicographically by $(E[X], c(\operatorname{law} X))$, where $c(\mu )$ is the total mass of the nonatomic part of mu. For any countable sum of finite positive measures, the atom set of the sum is the union of their atom sets, so c is countably additive. Adding an atom at 0 changes neither coordinate. Thus the vector of a gamble is the absolutely convergent sum of its masked vectors over any countable measurable partition. Summing lexicographically nonnegative differences proves Countable Sure-Thing, including strictness. Finite additivity gives Sure-Thing and Mixture Independence. Law dependence gives Stochastic Equivalence and Totality; strict stochastic dominance raises the mean. Every simple law has $c=0$, proving Simple EU with the unique normalized chart $u(x)=x$ and Archimedean Outcomes. Rich Outcomes fails because the chart is bounded. A uniform U on [0,1] has vector (1/2,1), whereas sure 1/2 has (1/2,0), refuting Expected Utility. Also 1 is strictly above U, which is strictly above 0, but every $M_p(1,0)$ has vector (p,0), so Archimedean Gambles fails. The write-up proves the countable partition identity for arbitrary partitions and verifies every listed property. Nonatomic mass is unchanged by injective affine maps and by finite-valued coupled differences, giving positive affine invariance, transfer and Simple Relative Expectation. Negative self-similarity fixes both coordinates uniquely. Negative affine anti-invariance fails under $x -> 1-x; L1$ Continuity fails at sure 1/2 using decreasing sure improvements. The uniform-versus-sure comparison refutes the remaining expectation rules. For every copula C realize (U,W) with law C and put $X=U/4, Y=1/8, Z=W/4$. Then X strictly exceeds Y, but both sums have mean 1/4 and $c(Y+Z)=1\ge c(X+Z)$. The pairs (X,Z) and (Y,Z) both admit C, so no copula satisfies sum invariance. Independent, comonotonic and antitonic specializations give explicit failures of all the other sum axioms, including strict independent-sum preservation. Reflection about zero, symmetric neutrality, the three named unbounded-gamble evaluations and the all-positive-shifts continuity antecedent have only trivial or empty scope on this bounded chart. All 39 principles are assigned.

Executable checks: `topics/unbounded-utility/checks/countable_sure_thing.py`.

Notes. Original countermodel to both two-premise questions on the standing full measurable domain. Their stable IDs and conjectured statuses remain; the engine computes refutation from this proved model when it matches the selected background. The model also satisfies Totality and Stochastic Equivalence, so merely adding those assumptions does not repair either arrow. On countably supported lotteries its second coordinate vanishes, leaving ordinary bounded EU. This distinguishes the full-domain questions from the Russell–Isaacs discrete-lottery theorem. Neither question assumes Rich Outcomes; the model violates that principle and is not a DU or DTU model. Exact checks support the witness and evidence integration, not the universal measure-theoretic proof. The completed classification records 23 satisfactions and 16 violations. The write-up distinguishes substantive satisfactions from trivial or empty scope on [0,1], especially Vanishing Shift Continuity, whose antecedent requires every positive shift to be available. The underlying principles and their quantifiers are unchanged. No independent checker or Lean verification is claimed.

Sources:

- **Goodsell proposals 8 and 13 Sep** — Zachary Goodsell, project conversations, 8 and 13 September 2026: proposed Countable Sure-Thing implications and request to check the Russell–Isaacs source.
- **GPT-6 countermodel 13 Sep** — GPT-6 (Codex), Logical Maps, 13 September 2026: lexicographic nonatomic-mass countermodel and full measurable-domain proofs in writeups/lexicographic-nonatomic-mass.md.
- **Infinite Prospects (domain comparison)** — Russell, J. S., & Isaacs, Y. (2021). Infinite prospects. Philosophy and Phenomenological Research, 103(1), 178–198. DOI 10.1111/phpr.12704. Author manuscript §§4–5, pp. 15–16 and 22, Appendix A, pp. 25–26: discrete-lottery framework and related representation theorem, not this countermodel.
- **GPT-6 full classification 13 Sep** — GPT-6 (Codex), Logical Maps, 13 September 2026, following Zachary Goodsell's request to classify the remaining principles: all-principle audit and explicit sum witnesses in writeups/lexicographic-nonatomic-mass.md.

- **Related: [Infinite prospects](https://doi.org/10.1111/phpr.12704).** Russell, J. S., & Isaacs, Y. (2021). Infinite prospects. Philosophy and Phenomenological Research, 103(1), 178–198. — §§4–5, author manuscript pp. 15–16 and 22; Appendix A, pp. 25–26. Published theorem for countably supported lotteries. The new countermodel uses nonatomic laws, outside that domain.

Record: `topics/unbounded-utility/models/lexicographic-nonatomic-mass.yaml`.

Write-up.

#### Lexicographic expectation: nonatomic mass

On the full measurable domain, **Countable Sure-Thing and Simple EU do
not imply Expected Utility**, and **Countable Sure-Thing and Archimedean
Outcomes do not imply Archimedean Gambles**. One model refutes both
implications, even with Totality, Stochastic Equivalence, Stochastic
Dominance, Mixture Independence and Sure-Thing.

**Source and work accounting.** Zachary Goodsell proposed the two
implications on 8 September 2026 and requested proofs and a
Russell–Isaacs source check on 13 September. GPT-6 (Codex) supplied the
countermodel and proofs below on 13 September 2026. The source comparison
at the end distinguishes this new countermodel from Russell and Isaacs's
published discrete-lottery theorem. No independent checker, literature
priority or Lean verification is claimed.

##### Construction

Take outcomes $O=[0,1]$, with the usual order, Borel structure and reference
outcomes $0,1$. All measurable $O$-valued random variables on the standing
atomless standard probability space are available.

For any finite positive Borel measure $\mu$ on $O$, put

$$D_\mu=\{x:\mu(\{x\})>0\},\qquad c(\mu)=\mu(O\setminus D_\mu).$$

Thus $D_\mu$ is countable and $c(\mu)$ is the total mass of the nonatomic
part, including any singular continuous part. For a gamble $X$, define

$$V(X)=\bigl(E[X],\,c(\mathcal L(X))\bigr),\qquad
X\succeq Y\ \Longleftrightarrow\ V(X)\geq_{\mathrm{lex}}V(Y).$$

The first coordinate decides unless the means agree; in that case, the
larger nonatomic mass is preferred. Both coordinates lie in $[0,1]$.
Lexicographic order is a total order on these vectors, so its pullback is
a reflexive, transitive, total preference on all gambles.

##### Countable additivity of the two coordinates

Suppose $\mu=\sum_n\mu_n$ is a finite positive measure. Then

$$D_\mu=\bigcup_nD_{\mu_n},\qquad c(\mu)=\sum_n c(\mu_n). \tag{1}$$

The first identity follows by evaluating singletons. For each $n$,
$D_\mu\setminus D_{\mu_n}$ is countable and has $\mu_n$-measure zero.
Consequently $\mu_n(O\setminus D_\mu)=c(\mu_n)$; summing gives (1).
Also $c(a\mu)=a c(\mu)$ for $a\geq0$. Thus $c$ is additive under arbitrary
countable positive mixtures, not only mixtures with disjoint supports.

Let $(E_n)$ be any countable measurable partition and write
$\mu_n(B)=P(E_n\cap\{X\in B\})$. Its sum is $\mathcal L(X)$, while

$$\mathcal L(X|E_n)=\mu_n+(1-P(E_n))\delta_0.$$

Adding an atom at zero changes neither the first moment nor the
nonatomic mass. Therefore

$$V(X)=\sum_n V(X|E_n). \tag{2}$$

Each coordinate of this series is nonnegative and summable. In particular,
the corresponding difference series for any $X,Y$ is absolutely
convergent. The argument permits arbitrary partitions depending on $X,Y$.

##### Countable Sure-Thing and Sure-Thing

Suppose $X|E_n\succeq Y|E_n$ for every $n$. Write
$V(X|E_n)-V(Y|E_n)=(a_n,b_n)$. Lexicographic nonnegativity means
$a_n\geq0$, and $b_n\geq0$ whenever $a_n=0$.

If some $a_n>0$, then $\sum_n a_n>0$, giving $X\succ Y$ by (2).
Otherwise every $a_n=0$, every $b_n\geq0$, and (2) gives $X\succeq Y$.
If one local comparison is strict in this second case, some $b_n>0$,
so the global comparison is strict. This proves both clauses of
Countable Sure-Thing exactly as formulated using masked acts in the map.

For a two-cell partition, (2) gives
$V(X)=V(X|E)+V(X|E^c)$. If $X|E\sim Y|E$, their vectors agree, so
subtracting those equal vectors proves the biconditional in Sure-Thing.

##### Simple EU, dominance and mixtures

Every simple law has nonatomic mass zero. Thus simple gambles are
compared exactly by their ordinary means. Sure outcomes have vector
$(x,0)$, and a Bernoulli gamble $M_p(1,0)$ has vector $(p,0)$.
The normalized utility chart is uniquely $u(x)=x$: its middle branch
forces $p=x$; its outer branches cannot calibrate an outcome in $[0,1]$
at a level outside $[0,1]$. The chart is measurable and order-preserving,
and satisfies the standing regularity contract. This proves Simple EU,
Restricted Totality and Restricted Stochastic Equivalence. Rich Outcomes
fails, since level $2$ is absent.

For $a>b>c$ in $[0,1]$, take $p=(b-c)/(a-c)$. Both the sure outcome
$b$ and $M_p(a,c)$ have vector $(b,0)$, proving Archimedean Outcomes.

Dependence only on the law proves Stochastic Equivalence. By (1), for
$0<p<1$,

$$V(M_p(X,Z))=pV(X)+(1-p)V(Z).$$

The difference between two mixtures with a common branch is therefore
$p(V(X)-V(Y))$. Positive multiplication preserves and reflects
lexicographic order, proving Mixture Independence.

Finally, weak stochastic dominance on $[0,1]$ gives $E[X]\geq E[Y]$
by the bounded tail-integral formula. If a tail inequality is strict at
one threshold, right continuity makes the mean inequality strict.
If no tail inequality is strict, the laws agree, so both coordinates
agree. Hence Stochastic Dominance, including its strict clause, holds.
It also yields Statewise Dominance.

##### The two counterexamples

Let $U$ be uniform on $[0,1]$. Then

$$V(U)=(1/2,1),\qquad V(1/2)=(1/2,0).$$

Thus $U\succ1/2$ despite equal finite expectations. The unique normalized
chart is the identity, so choosing another chart cannot restore Expected
Utility. This refutes
[Countable Sure-Thing + Simple EU ⇒ Expected Utility](countable-sure-thing-simple-to-full-eu.html).

Also $1\succ U\succ0$. For every $p\in(0,1)$,

$$V(M_p(1,0))=(p,0)\ne(1/2,1)=V(U).$$

No such mixture is indifferent to $U$. This refutes
[Countable Sure-Thing + Archimedean Outcomes ⇒ Archimedean Gambles](countable-sure-thing-outcomes-to-gambles.html).

The bounded outcome space is permitted because neither proposed arrow
assumes Rich Outcomes. This is not a model of DU, which does require Rich
Outcomes. Under DU or DTU, the recorded St Petersburg obstruction makes
Countable Sure-Thing incompatible with the background; that is distinct
from a countermodel to either implication with empty background.

##### Affine maps, transfer and simple differences

Write $c_X=c(\mathcal L(X))$. Any injective affine map preserves atoms
and their masses, so, whenever the transformed gamble stays in $[0,1]$,

$$V(aX+b)=(aE[X]+b,c_X)\qquad(a\ne0).$$

For $a>0$, this preserves and reflects lexicographic comparisons.
Thus **Positive Affine Invariance, Shift Invariance and Scale Invariance**
hold. **Shift Transfer** also holds: both of its mixtures have vector

$$\bigl(pE[X]+(1-p)E[Y]+b,\;pc_X+(1-p)c_Y\bigr).$$

For **Simple Relative Expectation**, suppose $X-Y$ has finite range.
Partition the space by its values $d$. On each cell, the subprobability
laws of $X$ and $Y$ are translates by $d$, so their nonatomic masses
agree. Summing over these cells using (1) gives $c_X=c_Y$.
Consequently $X\succeq Y$ iff $E[X-Y]\geq0$, as required.

**Negative Affine Anti-Invariance fails.** Take $X=U$, $Y=1/2$ and
the eligible map $x\mapsto1-x$. Both before and after transformation,
the uniform law strictly exceeds the sure half. In particular,
$X\succeq Y$ but $1-Y\not\succeq1-X$.

##### Expectation rules and continuity

The same equal-mean pair $U\succ1/2$ refutes **Relative Expectation**,
**CDF-Area Extension** and **Folded Expectation**. Everything is bounded:
the relative difference is integrable; both CDF areas are finite and
equal; and the folded values are their ordinary means, both $1/2$.
In each case the axiom would require indifference.

**L¹ Continuity fails.** Let $X_n$ be sure $1/2+1/(n+3)$, let $X$ be
sure $1/2$, and put $Y=U$. Then

$$X_n\succ Y\quad\text{for all }n,\qquad
E|X_n-X|=\frac1{n+3}\longrightarrow0,$$

but $X\not\succeq Y$. Every gamble in this example is available.

##### Uniqueness of negative self-similarity

Suppose $X\sim M_p(-aX+b,Z)$, with the transformed gamble available.
Equality of the two coordinates gives

$$E[X]=\frac{pb+(1-p)E[Z]}{1+pa},\qquad c_X=c_Z.$$

Here $a>0$ and $0<p<1$, so both divisions used to solve the equations
are valid. The same equations fix $V(Y)$ whenever
$Y\sim M_p(-aY+b,Z)$. Thus $X\sim Y$, proving
**Uniqueness of Negative Self-Similarity**. Existence of a solution is
not part of this principle.

##### Sum principles

Let $U$ be uniform on $[0,1]$, and put $X=U/4$ and $Y=1/8$.
Then $X\succ Y$, since their vectors are $(1/8,1)$ and $(1/8,0)$.
The following choices of $Z$ give explicit failures. Every sum has
mean $1/4$ and lies in $[0,1/2]$.

| Dependence | Common summand $Z$ | $c_{X+Z}$ | $c_{Y+Z}$ | Comparison of sums |
| --- | --- | --- | --- | --- |
| Independent | $W/4$, with $W$ uniform and independent of $U$ | $1$ | $1$ | $X+Z\sim Y+Z$ |
| Comonotonic | $U/4$ | $1$ | $1$ | $X+Z\sim Y+Z$ |
| Antitonic | $(1-U)/4$ | $0$ | $1$ | $Y+Z\succ X+Z$ |

For the independent row, the sum of the two independent uniforms has
no atoms: condition on either summand to see that the probability of
each singleton is zero. The other nonatomic sums in the table are
nonconstant affine functions of a uniform variable. In the last row,
$X+Z$ is sure $1/4$.

The independent row violates the strict clause of **Independent Sum
Preservation**. It also violates **Independent Sum Cancellation**:
$Y+Z\succeq X+Z$ but $Y\not\succeq X$. Hence **Independent Sum
Invariance** fails. The other rows refute **Comonotonic** and
**Antitonic Sum Invariance**; a constant is eligible for either
dependence condition. These examples also refute **Full Sum Invariance**.

##### No fixed copula works

In fact **Existential Copula Sum Invariance fails**, as does its
**Universal** counterpart. The same parameters work for every copula.

Fix any copula $C$ and realize $(U,W)$ with joint law $C$ on the standing
sample space. Take

$$X=U/4,\qquad Y=1/8,\qquad Z=W/4.$$

The pair $(X,Z)$ admits $C$ by positive rescaling. The pair $(Y,Z)$
also admits $C$: the CDF of the constant $Y$ is either zero or one,
and every copula satisfies $H_C(0,v)=0$ and $H_C(1,v)=v$.

As before $X\succ Y$, and both sums have mean $1/4$. But $Y+Z$ is
uniform on $[1/8,3/8]$, so

$$c_{Y+Z}=1\geq c_{X+Z}.$$

Therefore $Y+Z\succeq X+Z$ while $Y\not\succeq X$, contradicting
$\mathrm{SC}(C)$. This uses the comparison in the reversed order
$(Y,X)$, which the universal quantifier permits. Since $C$ was arbitrary,
no copula satisfies $\mathrm{SC}(C)$. No assumption about atoms of
$X+Z$, and no choice of parameters depending on $C$, is needed.

##### Principles with trivial or empty scope here

The outcome chart is $[0,1]$. Numerical axioms concern only their stated
eligible gambles and transformations. This matters for the following
satisfactions.

- **Reflection Anti-Invariance** holds because $X$ and $-X$ can both
  take values in $[0,1]$ only if $X=0$. Every eligible comparison is
  between zero gambles. This does not imply negative affine
  anti-invariance: reflection about $1/2$ is available and fails as shown
  above, whereas the recorded reflection principle fixes the origin $0$.
- **Symmetric Gambles Are Neutral** holds because a nonnegative law
  symmetric about zero is concentrated at zero. Stochastic Equivalence
  then gives indifference to sure zero.
- **Alternating St Petersburg = −1/2**, **Pasadena = ln 2** and
  **Arroyo = ln 2** hold vacuously. Their prescribed distributions put
  positive mass outside $[0,1]$: already their first values are $-2$,
  $2$ and $2$, respectively. None is an available gamble. The first
  axiom's target outcome $-1/2$ is absent as well.
- **Continuity under Vanishing Shifts**, as currently defined in the
  map, holds vacuously. Its antecedent requires an available
  $X+\varepsilon\succeq Y$ for **every** $\varepsilon>0$.
  Taking $\varepsilon=2$ makes availability impossible. Requiring
  comparisons only for sufficiently small available shifts would be
  a different axiom and would fail here, as the $L^{1}$ example shows.
  The recorded principle and its quantifiers have not been changed.

Together with the earlier sections, this assigns every one of the map's
39 principles: **23 satisfied and 16 violated**, with none left unknown.
The full classification was supplied by GPT-6 (Codex) on 13 September
2026 following Goodsell's request to check the remaining relations.
The exact examples supplement the written proofs; no independent checker
or Lean proof is claimed.


##### Relation to Russell and Isaacs

Russell and Isaacs, *Infinite Prospects* (2021), pass to discrete
lotteries in §4 and state their Equivalence Theorem in §5. Appendix A
defines lotteries as probability mass functions and preferences as total
preorders. The bridge from acts to lotteries uses conditional-law
dependence; see the author's April 2020 manuscript, pp. 15–16 and
footnotes 18–20, p. 22 and footnote 29, and Appendix A, pp. 25–26:
[author's manuscript](https://www.yoaavisaacs.com/uploads/6/9/2/0/69204575/infinite-prospects-final.pdf).

In this model, $c(\mathcal L(X))=0$ for **every countably supported**
lottery. Its restriction to that domain is ordinary bounded expected
utility and satisfies Archimedean Gambles. Only nonatomic laws introduce
the extra coordinate. Thus the countermodel does not contradict the
published discrete-lottery theorem; that theorem does not establish
these two arrows on the map's larger domain.

### Clipped expectation: continuous ultrafilter dominance [−4ⁿ, 4²ⁿ] — `polynomial-asymmetric-continuous-ultrafilter`

Model; source **Misc.**; produced by Zachary Goodsell (asymmetric continuous clipping construction); GPT-6 (Codex) (cutoff specialization and evaluation calculations); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; Lean stated; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- CDF-Area Extension (`cdf-area-extension`)
- Relative Expectation (`relative-expectation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)

Violates:

- Pasadena = ln 2 (`pasadena-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)

Unknown in this model: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Positive Affine Invariance (`positive-affine-invariance`), Scale Invariance (`scale-invariance`)

Construction.

Let $q_n(x)=\max (-4^n,\min (x,4^{2n}))$ and choose a free ultrafilter U on the positive integers. Define $X\ge Y$ iff for every $\epsilon >0$ the set $\{n:E[q_n(X)]-E[q_n(Y)]\ge -\epsilon \}$ belongs to U. This is Goodsell's continuous asymmetric clipping construction with unequal polynomial growth of the two cutoffs. Its linear clipped expectations, increasing cutoff intervals, and uniform Lipschitz bound give DTU, CDF-Area Extension, Relative Expectation, L1 Continuity, and the shift properties. Pasadena's clipped expectations converge to $(3/2) \ln 2$; hence $P\sim (3/2) \ln 2$, strictly above the recorded value $\ln 2$. Arroyo's clipped expectations equal $(n+1) \ln 2+o(1)$ and diverge to positive infinity, so Arroyo is strictly above every sure outcome. A symmetric Cauchy variable also has clipped expectations tending to positive infinity, refuting Symmetric Neutrality. These are quantified asymptotic conclusions, not finite-cutoff approximations used as values.

Executable checks: `topics/unbounded-utility/checks/calculation_factorizations.py`, `topics/unbounded-utility/checks/comonotonic_witnesses.py`.

Notes. Original work: model specialization with moderate evaluation calculations. The asymmetric clipping method and its strong expectation/continuity compatibility with failure of reflection are already Goodsell's. This entry selects upper cutoff equal to the square of the lower cutoff and computes its different Pasadena value and unbounded Arroyo value. The general construction is not a new AI invention. No independent checker or Lean certification is asserted. The free ultrafilter remains nonconstructive; the diagnostic checks finite formulas and convergence estimates rather than ultrafilter existence.

Revisions:

- **2026-09-23** (Claude (Fable 5.1)) — Comonotonic Sum Invariance shown to fail (write-up section “Failure of Comonotonic Sum Invariance”). Y = max(C,0) + 2 min(C,0) − (2 ln 2 − 1)/π is indifferent to sure 0, but with the common comonotonic summand Z = max(C,0) the clipped gap between 0 + Z and Y + Z tends to (2 ln 2)/π, so 0 + Z ≻ Y + Z. Now violates: Comonotonic Sum Invariance.

Sources:

- **GPT-6 cutoff calculations 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/polynomial-asymmetric-continuous-ultrafilter.md: cutoff specialization, Pasadena/Arroyo evaluations, and explicit verification of the inherited axioms.
- **Decision Theory Unbound** — Zachary Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695, DOI 10.1111/nous.12473, Appendix B, Definition 3, Lemma 6, Remark 3 and Corollary 3, pp. 691–693: continuous clipped-expectation quotient and separate cutoff functions.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37, DOI 10.1111/nous.12549, Theorem 1, p. 24: asymmetric source model and failure of reflection even with DTU, L1 Continuity and Relative Expectation; pp. 28–33 for the named prospects.
- **Claude comonotonic failure 23 Sep** — Claude (Fable 5.1), Logical Maps, 23 September 2026: failure of Comonotonic Sum Invariance (half-Cauchy common summand) in writeups/polynomial-asymmetric-continuous-ultrafilter.md; diagnostic checks/comonotonic_witnesses.py.

- **Background: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — Appendix B, Definition 3, Lemma 6, Remark 3 and Corollary 3, pp. 691–693: continuous clipped-expectation quotient and separate cutoff functions
- **Background: [Symmetries of value](https://doi.org/10.1111/nous.12549).** Zachary Goodsell (2026). Symmetries of value. Noûs, 60, 16–37. — Theorem 1, p. 24: asymmetric source model and failure of reflection even with DTU, L1 Continuity and Relative Expectation; pp. 28–33 for the named prospects

Record: `topics/unbounded-utility/models/polynomial-asymmetric-continuous-ultrafilter.yaml`.

Write-up.

#### Clipped expectation: continuous ultrafilter dominance [−4ⁿ, 4²ⁿ]

**Source and work accounting.** This uses Zachary Goodsell's asymmetric
continuous clipping construction from *Decision theory unbound*, Appendix B,
Definition 3, Lemma 6, Remark 3 and Corollary 3, pp. 691–693. Its compatibility
with DTU, Relative Expectation and $L^{1}$ Continuity while failing reflection is
already recorded in *Symmetries of value*, Theorem 1, p. 24. The work supplied
by GPT-6 (Codex), 9 September 2026, is the cutoff choice and the explicit
Pasadena/Arroyo evaluations below, with verification of inherited properties.
This is a model specialization, not a new invention of asymmetric clipping
or a claim of priority in the literature. No independent checker or Lean
certification is asserted.

##### 1. The source construction with upper cutoff equal to the square of the lower

Use all real-valued random variables on the standing sample space. Let

\[
L_n=4^n,\quad U_n=4^{2n},\quad
q_n(x)=\max(-L_n,\min(x,U_n)),\quad v_X(n)=E[q_n(X)].
\]

Choose a free ultrafilter \(\mathcal U\) on the positive integers and set

\[
X\succeq Y\quad\Longleftrightarrow\quad
\forall\varepsilon>0\ \{n:v_X(n)-v_Y(n)\ge-\varepsilon\}\in\mathcal U.
\tag{1}
\]

A comparison difference converging to a finite number is ranked by its sign,
with indifference at zero. If \(v_X(n)\to+\infty\), then \(X\) is strictly
better than every sure real outcome; this does not assign a real certainty
equivalent to \(X\).

Reflexivity follows directly from (1). To prove transitivity, intersect the
two ultrafilter-large comparison sets for tolerance \(\varepsilon/2\).
If \(X\not\succeq Y\), some positive tolerance is violated on an
ultrafilter-large set, making \(Y\succ X\). Thus the relation is total.
Changing any comparison sequence by an ordinary sequence tending to zero
does not affect it.

The clipped expectations depend only on laws. Bounded, in particular simple,
variables are eventually unchanged by clipping, so the utility chart is the
identity and simple gambles have ordinary expected utility comparisons.
All real sure outcomes are available. Moreover,

\[
v_{M_p(X,Z)}=p v_X+(1-p)v_Z,
\]

so cancellation and rescaling tolerances prove both directions of Mixture
Independence. These facts establish all DTU clauses except dominance.

For survival functions \(S_X\), bounded layer integration gives

\[
v_X(n)-v_Y(n)=\int_{-L_n}^{U_n}(S_X(t)-S_Y(t))\,dt. \tag{2}
\]

Dominance makes this integrand nonnegative. If it is positive at one threshold,
right-continuity makes its integral positive on some bounded interval. Once
that interval is inside the cutoffs, there is a fixed positive comparison gap.
This establishes weak and strict Stochastic Dominance and completes DTU.

##### 2. The stronger expectation, continuity and shift properties

The intervals in (2) increase to all of \(\mathbb R\). If at least one
of the positive and negative areas of \(S_X-S_Y\) is finite, monotone
convergence of the two nonnegative areas makes the clipped differences tend
to their well-defined extended difference. Equation (1) therefore gives
exactly **CDF-Area Extension**, including strict infinite-area cases and
the zero case.

For any actually coupled \(X,Y\), clipping is 1-Lipschitz and tends
pointwise to the identity. If \(E|X-Y|<\infty\), then

\[
|q_n(X)-q_n(Y)|\le|X-Y|,
\qquad v_X(n)-v_Y(n)\longrightarrow E[X-Y].
\]

Dominated convergence and (1) prove **Relative Expectation** directly.
Likewise, if \(E|X_k-X|\to0\), then for every cutoff

\[
|v_{X_k}(n)-v_X(n)|\le E|X_k-X|.
\]

If every \(X_k\succeq Y\), choose one \(k\) with this error below
\(\varepsilon/2\), and use its ultrafilter-large comparison set with
tolerance \(\varepsilon/2\). This proves \(X\succeq Y\) and hence
the recorded upper-section **L¹ Continuity**.

For any constant \(b\), dominated convergence applied to
\(q_n(X+b)-q_n(X)\) gives limit \(b\), since this difference is bounded
in absolute value by \(|b|\). The two shifts cancel in a comparison,
proving **Shift Invariance**. The fixed-lift variables in **Shift Transfer**
have integrable difference \(b/p\) on a set of probability \(p\) and
\(-b/(1-p)\) on its complement; its mean is zero. Relative Expectation
proves their indifference.

##### 3. Pasadena has value \((3/2)\ln2\)

For Pasadena \(P\), separate its odd and even indices:

\[
\begin{array}{c|c|c}
 &\text{payoff}&\text{probability}\\\hline
\text{positive branch }k&4^k/[2(2k-1)]&2/4^k\\
\text{negative branch }k&-4^k/(2k)&1/4^k
\end{array}
\]

Let \(K_+(n)\) be the largest positive index whose payoff does not exceed
\(U_n\), and \(K_-(n)\) the largest negative index whose magnitude does
not exceed \(L_n\). The defining inequalities show

\[
K_+(n)=2n+O(\log n),\qquad K_-(n)=n+O(\log n).
\tag{3}
\]

For example, take logarithms of
\(4^{K_+}/[2(2K_+-1)]\le4^{2n}<4^{K_++1}/[2(2K_++1)]\);
the corresponding negative-branch inequalities work identically.

Summing the clipped geometric tails exactly yields

\[
v_P(n)=
\sum_{k=1}^{K_+(n)}\frac1{2k-1}
-\sum_{k=1}^{K_-(n)}\frac1{2k}
+\frac{2U_n}{3\,4^{K_+(n)}}
-\frac{L_n}{3\,4^{K_-(n)}}. \tag{4}
\]

The two clipped-tail terms tend to zero: the next positive-payoff inequality
bounds the positive term by \(4/[3(2K_++1)]\), and the next negative-payoff
inequality bounds the negative term's magnitude by \(2/[3(K_-+1)]\).
Writing \(H_j=\sum_{k=1}^j1/k=\log j+\gamma+o(1)\), the finite part
of (4) is

\[
H_{2K_+}-\tfrac12H_{K_+}-\tfrac12H_{K_-}
=\ln2+\tfrac12\log(K_+/K_-)+o(1).
\]

By (3), the ratio tends to two. Thus

\[
v_P(n)\longrightarrow\frac32\ln2,
\qquad P\sim\frac32\ln2\succ\ln2.
\]

This disproves the recorded Pasadena evaluation in this model. The argument
uses convergent clipped expectations, not an ordinary expectation of Pasadena.

##### 4. Arroyo lies strictly above every sure outcome

For Arroyo \(A\), the positive branch indexed by \(k\) has payoff
\(2k\) and probability \(1/[(2k-1)2k]\). The negative branch has payoff
\(-(2k+1)\) and probability \(1/[2k(2k+1)]\).
The last unclipped indices are

\[
J_+=U_n/2,\qquad J_-=L_n/2-1.
\]

Its clipped expectation is exactly

\[
\sum_{k=1}^{J_+}\frac1{2k-1}
-\sum_{k=1}^{J_-}\frac1{2k}
+U_n\sum_{k>J_+}\frac1{(2k-1)2k}
-L_n\sum_{k>J_-}\frac1{2k(2k+1)}. \tag{5}
\]

Each probability-tail summand is asymptotic to \(1/(4k^2)\), and the
corresponding tail sum is asymptotic to \(1/(4J)\), by comparison with
the integral of \(k^{-2}\). Each of the last two magnitudes in (5)
therefore tends to \(1/2\), so their difference tends to zero. The harmonic
prefix has asymptotic value

\[
\ln2+\tfrac12\log(J_+/J_-)+o(1)
=\ln2+\tfrac12\log(U_n/L_n)+o(1)
=(n+1)\ln2+o(1).
\]

Consequently \(v_A(n)\to+\infty\). In (1), this yields
\(A\succ c\) for every real sure outcome \(c\), and in particular
\(A\not\sim\ln2\). Although Arroyo's folded expectation is \(\ln2\),
this model does not obey Folded Expectation.

##### 5. A symmetric-neutrality witness

Let \(C\) have the standard symmetric Cauchy law. Symmetry cancels its
clipped tails up to \(L_n\), leaving

\[
v_C(n)=\int_{L_n}^{U_n}\left(\frac12-\frac{\arctan t}{\pi}\right)dt
=\frac1\pi\log(U_n/L_n)+o(1)
=\frac{n\log4}{\pi}+o(1).
\]

The asymptotic follows from the integrand
\(1/(\pi t)+O(t^{-3})\); its integrated error tends to zero. Thus the
symmetric gamble \(C\) is strictly above every sure outcome, and Symmetric
Neutrality fails. This mechanism belongs to Goodsell's general asymmetric
construction; only these chosen cutoff rates and calculations are additions here.

##### Scope and diagnostics

The model satisfies DTU, Relative Expectation, $L^{1}$ Continuity, CDF-Area Extension,
and the shift properties, yet fails both named game evaluations. Its failure
of Negative Self-Similarity follows from the new Pasadena implication; further
exclusions are left to the map's inference engine rather than separately
asserted without evidence. No Scale Invariance or sum-invariance verdict is
claimed here.

`checks/calculation_factorizations.py` verifies the exact Pasadena clipping
formula against direct finite atom sums with bounded remainders, tests the
displayed cutoff asymptotic, and checks finite Arroyo sums. It also verifies
the exact coupling identities in the accompanying Pasadena proof. These are
diagnostics supporting quantified arguments, not simulations of a free
ultrafilter or proofs of all universal axioms.

##### 6. Failure of Comonotonic Sum Invariance

**Addition: Claude (Fable 5.1), 23 September 2026.** A property of the
recorded model; not a claim of the source paper.

Realize a standard Cauchy variable as \(C=Q_C(U)=\tan(\pi(U-\tfrac12))\), let
\(C_+=\max(C,0)\), \(C_-=\min(C,0)\), and put
\(X=0\), \(Y=C_++2C_--v\) with \(v=(2\ln2-1)/\pi\), and \(Z=C_+\). All are
nondecreasing in \(U\), so both pairs are comonotonic. With
\(m(F)=\mathbb E[\min(C_+,F)]=\frac1{2\pi}\ln(1+F^2)+\frac F\pi\arctan(1/F)
=\frac1\pi\ln F+\frac1\pi+o(1)\) and the window \([-4^n,4^{2n}]\),

\[
\mathbb E[q_n(C_++2C_-)]=m(4^{2n})-2m(4^n/2)\longrightarrow
\frac{2\ln2-1}{\pi}=v,
\]

and \(q_n(Y)-q_n(C_++2C_-)\to-v\) boundedly, so \(\mathbb E[q_n(Y)]\to0\) and
\(X\sim Y\).

**Doubling-defect identity.** For any nonnegative random variable $V$ and
any $F>0$,

\[2\,\mathbb E[\min(V,F)]-\mathbb E[\min(2V,F)]
 =2\int_{F/2}^{F}P(V>x)\,dx,\]

since $\mathbb E[\min(V,F)]=\int_0^F P(V>x)\,dx$ and
$\mathbb E[\min(2V,F)]=2\int_0^{F/2}P(V>x)\,dx$. For $V=C_+=\max(C,0)$ with
$C$ standard Cauchy the right-hand side is
$\frac2\pi\int_{F/2}^{F}\arctan(1/x)\,dx$, which is positive for every $F$
and increases to $\frac{2\ln2}{\pi}$ as $F\to\infty$.

Now \(X+Z=C_+\) and \(Y+Z=2C_++2C_--v\), so

\[
v_{X+Z}(n)-v_{Y+Z}(n)
 =m(4^{2n})-2m(4^{2n}/2)+2m(4^n/2)+v+o(1)
 =2\bigl(m(4^{2n})-m(4^{2n}/2)\bigr)+o(1)\longrightarrow\frac{2\ln2}{\pi},
\]

the lower-cutoff terms cancelling against \(v\). With
\(\varepsilon=(\ln2)/\pi\) the set \(\{n:v_{Y+Z}(n)\ge v_{X+Z}(n)-\varepsilon\}\)
is finite, so \(X+Z\succ Y+Z\) although \(X\sim Y\): Comonotonic Sum
Invariance fails, while Shift Invariance and Transfer of a Shift hold.
`checks/comonotonic_witnesses.py` verifies the closed forms, the neutral
constant and the limit.

### Clipped expectation: continuous ultrafilter dominance — `total-continuous-ultrafilter`

Model; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); Claude (Fable 5.1) (failure of Comonotonic Sum Invariance, 23 September 2026); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Expected Utility (`expected-utility`)
- Shift Invariance (`shift-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)

Violates:

- Scale Invariance (`scale-invariance`)
- Countable Sure-Thing (`countable-sure-thing`)
- Archimedean Gambles (`archimedean-gambles`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)

Unknown in this model: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Relative Expectation (`relative-expectation`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

Construction.

Take all real-valued random variables and a cobounded ultrafilter U. Define $X\succeq Y$ iff for every $\epsilon >0, \{t:E[c_t(X)]\ge E[c_t(Y)]- \epsilon \}\in U$. This is the continuous-hyperreal quotient ordering in the proof of Theorem 3. Its EU, shift, reflection, and failed scale claims are given in Appendix B; see the accompanying write-up. Consequently Expected Utility does not imply Positive Affine Invariance, even with DTU.

Executable checks: `topics/unbounded-utility/checks/comonotonic_witnesses.py`.

Notes. No $L^{1}$ Continuity or Relative Expectation flag is inferred merely from the word continuous; these are distinct claims. Scale failure is source-attributed as above.

Revisions:

- **2026-09-23** (Claude (Fable 5.1)) — Comonotonic Sum Invariance shown to fail (write-up section “Failure of Comonotonic Sum Invariance”). A standard Cauchy C is indifferent to sure 0, but with the common comonotonic summand Z = max(C,0), C_+ = 0 + Z is strictly better than C + Z: the clipped gap is 2∫_{t/2}^{t} P(C>x)dx, positive for every t and tending to (2 ln 2)/π. Now violates: Comonotonic Sum Invariance.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, Appendix B, Lemma 6 and proof of Theorem 3, p. 691; Theorems 7, 8 and 10, pp. 693–695
- **Claude comonotonic failure 23 Sep** — Claude (Fable 5.1), Logical Maps, 23 September 2026: failure of Comonotonic Sum Invariance (half-Cauchy common summand) in writeups/total-continuous-ultrafilter.md; diagnostic checks/comonotonic_witnesses.py.

- **Proof: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — Appendix B, Lemma 6 and proof of Theorem 3, p. 691; Theorems 7, 8 and 10, pp. 693–695

Record: `topics/unbounded-utility/models/total-continuous-ultrafilter.yaml`.

Write-up.

#### Clipped expectation: continuous ultrafilter dominance

Source: Goodsell, *Decision theory unbound*, Appendix B, Lemma 6 and proof
of Theorem 3 (p. 691), Theorems 7, 8, and 10 (pp. 693–695).
Human model: Zachary Goodsell. Recorded and translated by GPT-6 (Codex);
no transcription checker asserted.

With U and $v_X$ as in the exact-ultrafilter model, define

$$X\succeq Y\quad\Longleftrightarrow\quad
\text{for every }\varepsilon>0,
\{t:v_X(t)\ge v_Y(t)-\varepsilon\}\in\mathcal U.$$

This quotients out infinitesimal errors in the ultrafilter comparison.
Reflexivity and transitivity follow using $\epsilon /2$ in each premise and intersecting
sets. If X is not at least as good as Y, some positive $\epsilon$ gives a U-large
set where Y exceeds X by $\epsilon$, which implies $Y\succ X$. This proves Totality.
The affine mixture formula for $v_X$ gives Independence after rescaling $\epsilon$.
Equal laws give equality. Constants and simple variables stabilize, giving
Rich Outcomes and Simple EU. A strict stochastic dominance comparison gives
a fixed positive gap for all sufficiently large t, and so remains strict
after taking this quotient. Thus the model satisfies DTU.

For integrable $X, v_X(t)\to E[X]$ by dominated convergence. Hence two integrable
variables are compared exactly by their finite expectations, including
indifference when those expectations agree. This proves EU, the purpose of
the continuous quotient in the source's Theorem 3.

Reflection negates clipped expectation exactly. For any fixed b,

$$c_t(X+b)-c_t(X)\longrightarrow b,\qquad
|c_t(X+b)-c_t(X)|\le |b|.$$

Dominated convergence gives $v_{X+b}(t)-v_X(t)\to b$, even for nonintegrable X.
Simultaneously shifting X and Y therefore changes their truncated comparison
by a function tending to zero, which the quotient ignores. This proves Shift
Invariance. Reflection and shift do **not** establish scale invariance.

The failed scale flag applies the source's Theorem 10 to this continuous
ultrafilter construction. Its witness and proof-audit limitation are described
in the exact-ultrafilter write-up and `extraction.md`. Thus this is a
source-attributed witness that DTU $+ \operatorname{EU} +$ shift + reflection does not entail
positive affine invariance. The two St Petersburg arguments establish failure
of Countable Sure-Thing and Archimedean Gambles here as well.

No $L^{1}$ Continuity or Relative Expectation flag is inferred from the name
"continuous": the quotient construction and the topic's closure axiom are
different mathematical claims.

##### Failure of Comonotonic Sum Invariance

**Addition: Claude (Fable 5.1), 23 September 2026.** This is a property of
the recorded model, not a claim made in the source paper.

Realize a standard Cauchy variable as $C=Q_C(U)=\tan(\pi(U-\tfrac12))$ and
put $X=0$, $Y=C$, $Z=C_+=\max(C,0)$; all are nondecreasing in $U$, so both
pairs $(X,Z)$ and $(Y,Z)$ are comonotonic. Oddness of $c_t$ gives
$v_C(t)=0=v_0(t)$ for every $t$, so $X\sim Y$.

**Doubling-defect identity.** For any nonnegative random variable $V$ and
any $F>0$,

$$2\,\mathbb E[\min(V,F)]-\mathbb E[\min(2V,F)]
 =2\int_{F/2}^{F}P(V>x)\,dx,$$

since $\mathbb E[\min(V,F)]=\int_0^F P(V>x)\,dx$ and
$\mathbb E[\min(2V,F)]=2\int_0^{F/2}P(V>x)\,dx$. For $V=C_+=\max(C,0)$ with
$C$ standard Cauchy the right-hand side is
$\frac2\pi\int_{F/2}^{F}\arctan(1/x)\,dx$, which is positive for every $F$
and increases to $\frac{2\ln2}{\pi}$ as $F\to\infty$.

With $X+Z=C_+$ and $Y+Z=2C_++C_-$, $C_-=\min(C,0)$, symmetry gives
$\mathbb E[\max(C_-,-t)]=-\mathbb E[\min(C_+,t)]$ and therefore

$$v_{X+Z}(t)-v_{Y+Z}(t)=2\int_{t/2}^{t}P(C>x)\,dx
 \longrightarrow\frac{2\ln2}{\pi}>0.$$

Take $\varepsilon=(\ln2)/\pi$. The set $\{t:v_{Y+Z}(t)\ge v_{X+Z}(t)-\varepsilon\}$
is bounded, hence not in the cobounded ultrafilter, while
$v_{X+Z}\ge v_{Y+Z}$ everywhere. Thus $X+Z\succ Y+Z$ although $X\sim Y$:
Comonotonic Sum Invariance fails. Shift Invariance holds in this model, so
this is a genuinely new failure and not a consequence of the recorded
implication from comonotonic invariance to shifts.
`checks/comonotonic_witnesses.py` verifies the closed forms and the limit.

### Clipped expectation: exact ultrafilter dominance — `total-exact-ultrafilter`

Model; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); Claude (Fable 5.1) (failure of Comonotonic Sum Invariance, 23 September 2026); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)

Violates:

- Expected Utility (`expected-utility`)
- Scale Invariance (`scale-invariance`)
- Countable Sure-Thing (`countable-sure-thing`)
- Archimedean Gambles (`archimedean-gambles`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)

Unknown in this model: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`)

Construction.

Take all real-valued random variables. Choose a cobounded ultrafilter U on positive truncation levels; define $X\succeq Y$ iff $\{t:E[c_t(X)]\ge E[c_t(Y)]\}\in U$. This is the exact hyperreal ordering of Theorem 1, not its continuous quotient. The accompanying write-up explains the satisfied axioms and EU counterexample; failure of Scale Invariance is the source’s Theorem 10.

Executable checks: `topics/unbounded-utility/checks/comonotonic_witnesses.py`.

Notes. The scale failure is recorded from the source theorem; its printed analytic witness has apparent typographical issues itemized in extraction.md. This record is a literature extraction, not a separately audited reconstruction of that witness.

Revisions:

- **2026-09-23** (Claude (Fable 5.1)) — Comonotonic Sum Invariance shown to fail (write-up section “Failure of Comonotonic Sum Invariance”). A standard Cauchy C has v_C(t) = 0 = v_0(t) for every t, but with the common comonotonic summand Z = max(C,0) the clipped gap v_{0+Z}(t) − v_{C+Z}(t) = 2∫_{t/2}^{t} P(C>x)dx is positive for every t, so 0 + Z ≻ C + Z on the whole domain of truncation levels. Now violates: Comonotonic Sum Invariance.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, Appendix B, Theorem 1, pp. 690–691; Theorems 3 and 10, pp. 691, 693–695
- **Claude comonotonic failure 23 Sep** — Claude (Fable 5.1), Logical Maps, 23 September 2026: failure of Comonotonic Sum Invariance (half-Cauchy common summand) in writeups/total-exact-ultrafilter.md; diagnostic checks/comonotonic_witnesses.py.

- **Proof: [Decision theory unbound](https://doi.org/10.1111/nous.12473).** Zachary Goodsell (2024). Decision theory unbound. Noûs, 58, 669–695. First published online in 2023. — Appendix B, Theorem 1, pp. 690–691; Theorems 3 and 10, pp. 691, 693–695

Record: `topics/unbounded-utility/models/total-exact-ultrafilter.yaml`.

Write-up.

#### Clipped expectation: exact ultrafilter dominance

Source: Goodsell, *Decision theory unbound*, Appendix B, Theorems 1, 3,
and 10. Human model: Zachary Goodsell.
Recorded and translated by GPT-6 (Codex); no transcription checker asserted.

Take all real-valued random variables. Let U be an ultrafilter on positive
truncation levels containing every tail $(s,\infty )$. Define $v_X(t)=E[c_t(X)]$
as in the eventual-clipping write-up and set

$$X\succeq Y\quad\Longleftrightarrow\quad
\{t:v_X(t)\ge v_Y(t)\}\in\mathcal U.$$

Reflexivity holds because the entire domain is in U; finite intersections
prove transitivity; the ultrafilter dichotomy proves Totality. The ordering
extends eventual weak comparisons and eventual strictly positive gaps.
Thus its law invariance, Simple EU, richness, and stochastic dominance follow
from the calculations for clipped expectations. Common mixture components
cancel pointwise before taking the ultrafilter, giving Independence.
Reflection negates $v_X$ exactly, giving reflection anti-invariance. These
properties give the DTU package in the topic's random-variable language.

The geometric N from the accompanying eventual model has expectation 2, but
$v_N(t)$<2 for every finite t>2. Therefore N is strictly worse than 2 on this
total ordering as well. This establishes failure of EU, exactly as the source's
Theorem 3 notes. The Countable Sure-Thing and Archimedean Gambles violations
follow from the recorded St Petersburg arguments.

**Scale failure is a source theorem application.** Goodsell's Theorem 10
(pp. 693–695) states that every total ordering constructed in this way fails
Scale Invariance. Its argument uses a pair of attainable clipped-expectation
curves whose difference oscillates in log scale, reverses sign on a doubling
of the truncation parameter, and cannot be neutralized simultaneously in both
phases by an ultrafilter. Apply that theorem to the U just chosen. This does
not assert that all total DTU models fail scale: the 2026 paper constructs
models that satisfy it.

The printed analytic witness has the notation/endpoint issues documented in
`extraction.md`. This model record accepts the published theorem for the scale
flag; it does not claim an independently checked correction of that entire
witness. The explicit EU counterexample and elementary satisfied-axiom
calculations above do not depend on those issues.

##### Failure of Comonotonic Sum Invariance

**Addition: Claude (Fable 5.1), 23 September 2026.** This is a property of
the recorded model, not a claim made in the source paper.

Realize a standard Cauchy variable as $C=Q_C(U)=\tan(\pi(U-\tfrac12))$ and
put $X=0$, $Y=C$, $Z=C_+=\max(C,0)$. All three are nondecreasing functions of
$U$, so $(X,Z)$ and $(Y,Z)$ are comonotonic pairs. Oddness of $c_t$ and the
symmetry of $C$ give $v_C(t)=0=v_0(t)$ for every $t$, hence $X\sim Y$.

**Doubling-defect identity.** For any nonnegative random variable $V$ and
any $F>0$,

$$2\,\mathbb E[\min(V,F)]-\mathbb E[\min(2V,F)]
 =2\int_{F/2}^{F}P(V>x)\,dx,$$

since $\mathbb E[\min(V,F)]=\int_0^F P(V>x)\,dx$ and
$\mathbb E[\min(2V,F)]=2\int_0^{F/2}P(V>x)\,dx$. For $V=C_+=\max(C,0)$ with
$C$ standard Cauchy the right-hand side is
$\frac2\pi\int_{F/2}^{F}\arctan(1/x)\,dx$, which is positive for every $F$
and increases to $\frac{2\ln2}{\pi}$ as $F\to\infty$.

Now $X+Z=C_+$ and $Y+Z=2C_+ + C_-$ with $C_-=\min(C,0)$. Since
$c_t(2C_++C_-)=\min(2C_+,t)$ on $\{C\ge0\}$ and $=\max(C_-,-t)$ on
$\{C<0\}$, and $\mathbb E[\max(C_-,-t)]=-\mathbb E[\min(C_+,t)]$ by symmetry,

$$v_{X+Z}(t)-v_{Y+Z}(t)
 =2\,\mathbb E[\min(C_+,t)]-\mathbb E[\min(2C_+,t)]
 =2\int_{t/2}^{t}P(C>x)\,dx>0\qquad\text{for every }t>0.$$

So $\{t:v_{X+Z}(t)\ge v_{Y+Z}(t)\}$ is the whole domain and its reverse is
empty: $X+Z\succ Y+Z$ while $X\sim Y$. Comonotonic Sum Invariance fails.
The gap tends to $(2\ln2)/\pi$. `checks/comonotonic_witnesses.py` verifies
the closed forms, the identity on an exact finite law, and the limit.

## 6. Derived state

Computed from the proved records only, by the closure rules in `README.md`. Conjectures take no part. A missing entry means *not recorded*, not *false*.

### 6.1 Interderivable principles

No two principles are currently interderivable.

### 6.2 Settled single-premise implications (51)

| From | To | Via |
| --- | --- | --- |
| Antitonic Sum Invariance | Shift Invariance | `antitonic-sum-implies-shift` |
| Archimedean Gambles | Archimedean Outcomes | `archimedean-gambles-restricts` |
| CDF-Area Extension | Archimedean Outcomes | `cdf-area-implies-eu`, `expected-utility-implies-simple`, `simple-eu-implies-archimedean-outcomes` |
| CDF-Area Extension | Expected Utility | `cdf-area-implies-eu` |
| CDF-Area Extension | Relative Expectation | `cdf-area-implies-relative` |
| CDF-Area Extension | Restricted Stochastic Equivalence | `cdf-area-implies-eu`, `expected-utility-implies-simple`, `simple-eu-implies-restricted-equivalence` |
| CDF-Area Extension | Restricted Totality | `cdf-area-implies-eu`, `expected-utility-implies-simple`, `simple-eu-implies-restricted-totality` |
| CDF-Area Extension | Transfer of a Shift Across a Mixture | `cdf-area-implies-relative`, `relative-implies-simple-relative`, `simple-relative-implies-shift-transfer` |
| CDF-Area Extension | Simple Expected Utility | `cdf-area-implies-eu`, `expected-utility-implies-simple` |
| CDF-Area Extension | Simple Relative Expectation | `cdf-area-implies-relative`, `relative-implies-simple-relative` |
| CDF-Area Extension | Statewise Dominance | `cdf-area-implies-eu`, `expected-utility-implies-simple`, `simple-eu-implies-archimedean-outcomes`, `cdf-area-implies-dominance`, `dominance-implies-statewise` |
| CDF-Area Extension | Stochastic Dominance | `cdf-area-implies-dominance` |
| CDF-Area Extension | Stochastic Equivalence | `cdf-area-implies-dominance`, `dominance-implies-equivalence` |
| Comonotonic Sum Invariance | Shift Invariance | `comonotonic-sum-implies-shift` |
| Existential Copula Sum Invariance | Shift Invariance | `existential-copula-implies-shift` |
| Expected Utility | Archimedean Outcomes | `expected-utility-implies-simple`, `simple-eu-implies-archimedean-outcomes` |
| Expected Utility | Restricted Stochastic Equivalence | `expected-utility-implies-simple`, `simple-eu-implies-restricted-equivalence` |
| Expected Utility | Restricted Totality | `expected-utility-implies-simple`, `simple-eu-implies-restricted-totality` |
| Expected Utility | Simple Expected Utility | `expected-utility-implies-simple` |
| Full Sum Invariance | Antitonic Sum Invariance | `full-sum-implies-antitonic` |
| Full Sum Invariance | Comonotonic Sum Invariance | `full-sum-implies-comonotonic` |
| Full Sum Invariance | Existential Copula Sum Invariance | `full-sum-implies-universal-copula`, `universal-copula-implies-existential` |
| Full Sum Invariance | Independent Sum Cancellation | `full-sum-implies-independent`, `independent-sum-implies-cancellation` |
| Full Sum Invariance | Independent Sum Invariance | `full-sum-implies-independent` |
| Full Sum Invariance | Independent Sum Preservation | `full-sum-implies-independent`, `independent-sum-implies-preservation` |
| Full Sum Invariance | Shift Invariance | `full-sum-implies-independent`, `independent-sum-implies-shift` |
| Full Sum Invariance | Universal Copula Sum Invariance | `full-sum-implies-universal-copula` |
| Independent Sum Invariance | Independent Sum Cancellation | `independent-sum-implies-cancellation` |
| Independent Sum Invariance | Independent Sum Preservation | `independent-sum-implies-preservation` |
| Independent Sum Invariance | Shift Invariance | `independent-sum-implies-shift` |
| L¹ Continuity (random variables) | Continuity under Vanishing Shifts | `l1-implies-vanishing-shift-continuity` |
| Negative Affine Anti-Invariance | Reflection Anti-Invariance | `negative-affine-implies-reflection` |
| Positive Affine Invariance | Scale Invariance | `positive-affine-implies-scale` |
| Positive Affine Invariance | Shift Invariance | `positive-affine-implies-shift` |
| Relative Expectation | Transfer of a Shift Across a Mixture | `relative-implies-simple-relative`, `simple-relative-implies-shift-transfer` |
| Relative Expectation | Simple Relative Expectation | `relative-implies-simple-relative` |
| Simple Expected Utility | Archimedean Outcomes | `simple-eu-implies-archimedean-outcomes` |
| Simple Expected Utility | Restricted Stochastic Equivalence | `simple-eu-implies-restricted-equivalence` |
| Simple Expected Utility | Restricted Totality | `simple-eu-implies-restricted-totality` |
| Simple Relative Expectation | Transfer of a Shift Across a Mixture | `simple-relative-implies-shift-transfer` |
| Stochastic Dominance | Restricted Stochastic Equivalence | `dominance-implies-equivalence`, `stochastic-equivalence-restricts` |
| Stochastic Dominance | Stochastic Equivalence | `dominance-implies-equivalence` |
| Stochastic Equivalence | Restricted Stochastic Equivalence | `stochastic-equivalence-restricts` |
| Totality | Restricted Totality | `totality-restricts` |
| Universal Copula Sum Invariance | Antitonic Sum Invariance | `universal-copula-implies-antitonic` |
| Universal Copula Sum Invariance | Comonotonic Sum Invariance | `universal-copula-implies-comonotonic` |
| Universal Copula Sum Invariance | Existential Copula Sum Invariance | `universal-copula-implies-existential` |
| Universal Copula Sum Invariance | Independent Sum Cancellation | `universal-copula-implies-independent`, `independent-sum-implies-cancellation` |
| Universal Copula Sum Invariance | Independent Sum Invariance | `universal-copula-implies-independent` |
| Universal Copula Sum Invariance | Independent Sum Preservation | `universal-copula-implies-independent`, `independent-sum-implies-preservation` |
| Universal Copula Sum Invariance | Shift Invariance | `universal-copula-implies-antitonic`, `antitonic-sum-implies-shift` |

### 6.3 Refuted single-premise implications (832)

Read *A ⇏ B*: assuming A alone does not yield B, as the named model shows.

| From | To | Witness model |
| --- | --- | --- |
| Alternating St Petersburg = −1/2 | Antitonic Sum Invariance | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Alternating St Petersburg = −1/2 | Archimedean Gambles | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Alternating St Petersburg = −1/2 | CDF-Area Extension | `lexicographic-nonatomic-mass` |
| Alternating St Petersburg = −1/2 | Comonotonic Sum Invariance | `lexicographic-nonatomic-mass` |
| Alternating St Petersburg = −1/2 | Countable Sure-Thing | `affine-symmetric-extension` |
| Alternating St Petersburg = −1/2 | Existential Copula Sum Invariance | `lexicographic-nonatomic-mass` |
| Alternating St Petersburg = −1/2 | Expected Utility | `lexicographic-nonatomic-mass` |
| Alternating St Petersburg = −1/2 | Folded Expectation | `lexicographic-nonatomic-mass` |
| Alternating St Petersburg = −1/2 | Full Sum Invariance | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Alternating St Petersburg = −1/2 | Independent Sum Cancellation | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Alternating St Petersburg = −1/2 | Independent Sum Invariance | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Alternating St Petersburg = −1/2 | Independent Sum Preservation | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Alternating St Petersburg = −1/2 | L¹ Continuity (random variables) | `lexicographic-nonatomic-mass` |
| Alternating St Petersburg = −1/2 | Negative Affine Anti-Invariance | `lexicographic-nonatomic-mass` |
| Alternating St Petersburg = −1/2 | Relative Expectation | `lexicographic-nonatomic-mass` |
| Alternating St Petersburg = −1/2 | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Alternating St Petersburg = −1/2 | Universal Copula Sum Invariance | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Archimedean Outcomes | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Archimedean Outcomes | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Arroyo = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Archimedean Outcomes | CDF-Area Extension | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Existential Copula Sum Invariance | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Archimedean Outcomes | Expected Utility | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Mixture Independence | `finite-two-sample-minimum` |
| Archimedean Outcomes | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Archimedean Outcomes | Pasadena = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Archimedean Outcomes | Positive Affine Invariance | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Archimedean Outcomes | Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Archimedean Outcomes | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Shift Invariance | `eventual-clipped-expectation` |
| Archimedean Outcomes | Transfer of a Shift Across a Mixture | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Archimedean Outcomes | Simple Expected Utility | `finite-two-sample-minimum` |
| Archimedean Outcomes | Simple Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Archimedean Outcomes | Statewise Dominance | `finite-two-sample-minimum` |
| Archimedean Outcomes | Stochastic Dominance | `finite-two-sample-minimum` |
| Archimedean Outcomes | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Archimedean Outcomes | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Archimedean Outcomes | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Continuity under Vanishing Shifts | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Arroyo = ln 2 | Alternating St Petersburg = −1/2 | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Arroyo = ln 2 | Antitonic Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass` |
| Arroyo = ln 2 | Archimedean Gambles | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass` |
| Arroyo = ln 2 | CDF-Area Extension | `lexicographic-nonatomic-mass` |
| Arroyo = ln 2 | Comonotonic Sum Invariance | `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass` |
| Arroyo = ln 2 | Countable Sure-Thing | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Arroyo = ln 2 | Existential Copula Sum Invariance | `lexicographic-nonatomic-mass` |
| Arroyo = ln 2 | Expected Utility | `lexicographic-nonatomic-mass` |
| Arroyo = ln 2 | Folded Expectation | `lexicographic-nonatomic-mass` |
| Arroyo = ln 2 | Full Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass` |
| Arroyo = ln 2 | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass` |
| Arroyo = ln 2 | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass` |
| Arroyo = ln 2 | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass` |
| Arroyo = ln 2 | L¹ Continuity (random variables) | `lexicographic-folded-extension`, `lexicographic-nonatomic-mass` |
| Arroyo = ln 2 | Negative Affine Anti-Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass` |
| Arroyo = ln 2 | Uniqueness of Negative Self-Similarity | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Arroyo = ln 2 | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Arroyo = ln 2 | Relative Expectation | `lexicographic-nonatomic-mass` |
| Arroyo = ln 2 | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Arroyo = ln 2 | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Arroyo = ln 2 | Universal Copula Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass` |
| Arroyo = ln 2 | Continuity under Vanishing Shifts | `lexicographic-folded-extension` |
| CDF-Area Extension | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| CDF-Area Extension | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| CDF-Area Extension | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| CDF-Area Extension | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| CDF-Area Extension | L¹ Continuity (random variables) | `lexicographic-folded-extension` |
| CDF-Area Extension | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| CDF-Area Extension | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| CDF-Area Extension | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| CDF-Area Extension | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Continuity under Vanishing Shifts | `lexicographic-folded-extension` |
| Comonotonic Sum Invariance | Antitonic Sum Invariance | `cdf-area-preorder` |
| Comonotonic Sum Invariance | Archimedean Gambles | `cdf-area-preorder` |
| Comonotonic Sum Invariance | Countable Sure-Thing | `cdf-area-preorder` |
| Comonotonic Sum Invariance | Folded Expectation | `cdf-area-preorder` |
| Comonotonic Sum Invariance | Full Sum Invariance | `cdf-area-preorder` |
| Comonotonic Sum Invariance | Symmetric Gambles Are Neutral | `cdf-area-preorder` |
| Comonotonic Sum Invariance | Totality | `cdf-area-preorder` |
| Comonotonic Sum Invariance | Universal Copula Sum Invariance | `cdf-area-preorder` |
| Countable Sure-Thing | Antitonic Sum Invariance | `lexicographic-nonatomic-mass` |
| Countable Sure-Thing | Archimedean Gambles | `lexicographic-nonatomic-mass` |
| Countable Sure-Thing | CDF-Area Extension | `lexicographic-nonatomic-mass` |
| Countable Sure-Thing | Comonotonic Sum Invariance | `lexicographic-nonatomic-mass` |
| Countable Sure-Thing | Existential Copula Sum Invariance | `lexicographic-nonatomic-mass` |
| Countable Sure-Thing | Expected Utility | `lexicographic-nonatomic-mass` |
| Countable Sure-Thing | Folded Expectation | `lexicographic-nonatomic-mass` |
| Countable Sure-Thing | Full Sum Invariance | `lexicographic-nonatomic-mass` |
| Countable Sure-Thing | Independent Sum Cancellation | `lexicographic-nonatomic-mass` |
| Countable Sure-Thing | Independent Sum Invariance | `lexicographic-nonatomic-mass` |
| Countable Sure-Thing | Independent Sum Preservation | `lexicographic-nonatomic-mass` |
| Countable Sure-Thing | L¹ Continuity (random variables) | `lexicographic-nonatomic-mass` |
| Countable Sure-Thing | Negative Affine Anti-Invariance | `lexicographic-nonatomic-mass` |
| Countable Sure-Thing | Relative Expectation | `lexicographic-nonatomic-mass` |
| Countable Sure-Thing | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Countable Sure-Thing | Universal Copula Sum Invariance | `lexicographic-nonatomic-mass` |
| Existential Copula Sum Invariance | Antitonic Sum Invariance | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Existential Copula Sum Invariance | Archimedean Gambles | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Existential Copula Sum Invariance | Countable Sure-Thing | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Existential Copula Sum Invariance | Folded Expectation | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Existential Copula Sum Invariance | Full Sum Invariance | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Existential Copula Sum Invariance | Negative Affine Anti-Invariance | `conjectured-total-independent-sum-extension` |
| Existential Copula Sum Invariance | Reflection Anti-Invariance | `conjectured-total-independent-sum-extension` |
| Existential Copula Sum Invariance | Symmetric Gambles Are Neutral | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Existential Copula Sum Invariance | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Existential Copula Sum Invariance | Universal Copula Sum Invariance | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Expected Utility | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Expected Utility | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Expected Utility | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Expected Utility | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Expected Utility | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Expected Utility | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Expected Utility | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Expected Utility | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Expected Utility | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Expected Utility | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Expected Utility | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Expected Utility | L¹ Continuity (random variables) | `lexicographic-folded-extension` |
| Expected Utility | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Expected Utility | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Expected Utility | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Expected Utility | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Expected Utility | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Expected Utility | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Expected Utility | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Expected Utility | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Expected Utility | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Expected Utility | Continuity under Vanishing Shifts | `lexicographic-folded-extension` |
| Folded Expectation | Alternating St Petersburg = −1/2 | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Antitonic Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Archimedean Gambles | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Comonotonic Sum Invariance | `geometric-continuous-ultrafilter` |
| Folded Expectation | Countable Sure-Thing | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Full Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | L¹ Continuity (random variables) | `lexicographic-folded-extension` |
| Folded Expectation | Negative Affine Anti-Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Uniqueness of Negative Self-Similarity | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Universal Copula Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Continuity under Vanishing Shifts | `lexicographic-folded-extension` |
| Mixture Independence | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Mixture Independence | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Arroyo = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Mixture Independence | CDF-Area Extension | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Mixture Independence | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Existential Copula Sum Invariance | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Mixture Independence | Expected Utility | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Mixture Independence | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Mixture Independence | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Mixture Independence | Pasadena = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Mixture Independence | Positive Affine Invariance | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Mixture Independence | Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Mixture Independence | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Mixture Independence | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Shift Invariance | `eventual-clipped-expectation` |
| Mixture Independence | Transfer of a Shift Across a Mixture | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Mixture Independence | Simple Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Mixture Independence | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Mixture Independence | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Mixture Independence | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Continuity under Vanishing Shifts | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Independent Sum Cancellation | Antitonic Sum Invariance | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Cancellation | Archimedean Gambles | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Cancellation | Countable Sure-Thing | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Cancellation | Folded Expectation | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Cancellation | Full Sum Invariance | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Cancellation | Negative Affine Anti-Invariance | `conjectured-total-independent-sum-extension` |
| Independent Sum Cancellation | Reflection Anti-Invariance | `conjectured-total-independent-sum-extension` |
| Independent Sum Cancellation | Symmetric Gambles Are Neutral | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Cancellation | Totality | `cdf-conclosure-preorder` |
| Independent Sum Cancellation | Universal Copula Sum Invariance | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Invariance | Antitonic Sum Invariance | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Invariance | Archimedean Gambles | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Invariance | Countable Sure-Thing | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Invariance | Folded Expectation | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Invariance | Full Sum Invariance | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Invariance | Negative Affine Anti-Invariance | `conjectured-total-independent-sum-extension` |
| Independent Sum Invariance | Reflection Anti-Invariance | `conjectured-total-independent-sum-extension` |
| Independent Sum Invariance | Symmetric Gambles Are Neutral | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Invariance | Totality | `cdf-conclosure-preorder` |
| Independent Sum Invariance | Universal Copula Sum Invariance | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Preservation | Antitonic Sum Invariance | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Preservation | Archimedean Gambles | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Preservation | Countable Sure-Thing | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Preservation | Folded Expectation | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Preservation | Full Sum Invariance | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Preservation | Negative Affine Anti-Invariance | `conjectured-total-independent-sum-extension` |
| Independent Sum Preservation | Reflection Anti-Invariance | `conjectured-total-independent-sum-extension` |
| Independent Sum Preservation | Symmetric Gambles Are Neutral | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Preservation | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Independent Sum Preservation | Universal Copula Sum Invariance | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| L¹ Continuity (random variables) | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Positive Affine Invariance | `geometric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Scale Invariance | `geometric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Totality | `cdf-area-preorder` |
| L¹ Continuity (random variables) | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| Negative Affine Anti-Invariance | Alternating St Petersburg = −1/2 | `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Antitonic Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Archimedean Gambles | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Arroyo = ln 2 | `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | CDF-Area Extension | `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Comonotonic Sum Invariance | `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Countable Sure-Thing | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Existential Copula Sum Invariance | `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Expected Utility | `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Folded Expectation | `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Full Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Independent Sum Cancellation | `affine-symmetric-extension` |
| Negative Affine Anti-Invariance | Independent Sum Invariance | `affine-symmetric-extension`, `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Independent Sum Preservation | `affine-symmetric-extension`, `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | L¹ Continuity (random variables) | `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Uniqueness of Negative Self-Similarity | `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Pasadena = ln 2 | `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Relative Expectation | `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Transfer of a Shift Across a Mixture | `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Simple Relative Expectation | `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Symmetric Gambles Are Neutral | `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Universal Copula Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance` |
| Negative Affine Anti-Invariance | Continuity under Vanishing Shifts | `finite-support-compensated-dominance` |
| Uniqueness of Negative Self-Similarity | Antitonic Sum Invariance | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Uniqueness of Negative Self-Similarity | Archimedean Gambles | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Uniqueness of Negative Self-Similarity | CDF-Area Extension | `lexicographic-nonatomic-mass` |
| Uniqueness of Negative Self-Similarity | Comonotonic Sum Invariance | `lexicographic-nonatomic-mass` |
| Uniqueness of Negative Self-Similarity | Countable Sure-Thing | `affine-symmetric-extension` |
| Uniqueness of Negative Self-Similarity | Existential Copula Sum Invariance | `lexicographic-nonatomic-mass` |
| Uniqueness of Negative Self-Similarity | Expected Utility | `lexicographic-nonatomic-mass` |
| Uniqueness of Negative Self-Similarity | Folded Expectation | `lexicographic-nonatomic-mass` |
| Uniqueness of Negative Self-Similarity | Full Sum Invariance | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Uniqueness of Negative Self-Similarity | Independent Sum Cancellation | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Uniqueness of Negative Self-Similarity | Independent Sum Invariance | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Uniqueness of Negative Self-Similarity | Independent Sum Preservation | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Uniqueness of Negative Self-Similarity | L¹ Continuity (random variables) | `lexicographic-nonatomic-mass` |
| Uniqueness of Negative Self-Similarity | Negative Affine Anti-Invariance | `lexicographic-nonatomic-mass` |
| Uniqueness of Negative Self-Similarity | Relative Expectation | `lexicographic-nonatomic-mass` |
| Uniqueness of Negative Self-Similarity | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Uniqueness of Negative Self-Similarity | Universal Copula Sum Invariance | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Pasadena = ln 2 | Antitonic Sum Invariance | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Pasadena = ln 2 | Archimedean Gambles | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Pasadena = ln 2 | CDF-Area Extension | `lexicographic-nonatomic-mass` |
| Pasadena = ln 2 | Comonotonic Sum Invariance | `lexicographic-nonatomic-mass` |
| Pasadena = ln 2 | Countable Sure-Thing | `affine-symmetric-extension` |
| Pasadena = ln 2 | Existential Copula Sum Invariance | `lexicographic-nonatomic-mass` |
| Pasadena = ln 2 | Expected Utility | `lexicographic-nonatomic-mass` |
| Pasadena = ln 2 | Folded Expectation | `lexicographic-nonatomic-mass` |
| Pasadena = ln 2 | Full Sum Invariance | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Pasadena = ln 2 | Independent Sum Cancellation | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Pasadena = ln 2 | Independent Sum Invariance | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Pasadena = ln 2 | Independent Sum Preservation | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Pasadena = ln 2 | L¹ Continuity (random variables) | `lexicographic-nonatomic-mass` |
| Pasadena = ln 2 | Negative Affine Anti-Invariance | `lexicographic-nonatomic-mass` |
| Pasadena = ln 2 | Relative Expectation | `lexicographic-nonatomic-mass` |
| Pasadena = ln 2 | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Pasadena = ln 2 | Universal Copula Sum Invariance | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Positive Affine Invariance | Alternating St Petersburg = −1/2 | `finite-support-compensated-dominance` |
| Positive Affine Invariance | Antitonic Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Positive Affine Invariance | Archimedean Gambles | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Positive Affine Invariance | Arroyo = ln 2 | `finite-support-compensated-dominance` |
| Positive Affine Invariance | CDF-Area Extension | `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Positive Affine Invariance | Comonotonic Sum Invariance | `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Positive Affine Invariance | Countable Sure-Thing | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance` |
| Positive Affine Invariance | Existential Copula Sum Invariance | `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Positive Affine Invariance | Expected Utility | `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Positive Affine Invariance | Folded Expectation | `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Positive Affine Invariance | Full Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Positive Affine Invariance | Independent Sum Cancellation | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Positive Affine Invariance | Independent Sum Invariance | `affine-symmetric-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Positive Affine Invariance | Independent Sum Preservation | `affine-symmetric-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Positive Affine Invariance | L¹ Continuity (random variables) | `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Positive Affine Invariance | Negative Affine Anti-Invariance | `lexicographic-nonatomic-mass` |
| Positive Affine Invariance | Uniqueness of Negative Self-Similarity | `finite-support-compensated-dominance` |
| Positive Affine Invariance | Pasadena = ln 2 | `finite-support-compensated-dominance` |
| Positive Affine Invariance | Relative Expectation | `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Positive Affine Invariance | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Positive Affine Invariance | Transfer of a Shift Across a Mixture | `finite-support-compensated-dominance` |
| Positive Affine Invariance | Simple Relative Expectation | `finite-support-compensated-dominance` |
| Positive Affine Invariance | Symmetric Gambles Are Neutral | `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance` |
| Positive Affine Invariance | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance` |
| Positive Affine Invariance | Universal Copula Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Positive Affine Invariance | Continuity under Vanishing Shifts | `finite-support-compensated-dominance` |
| Reflection Anti-Invariance | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Reflection Anti-Invariance | Antitonic Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Archimedean Gambles | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Arroyo = ln 2 | `finite-support-compensated-dominance` |
| Reflection Anti-Invariance | CDF-Area Extension | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Comonotonic Sum Invariance | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Countable Sure-Thing | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Existential Copula Sum Invariance | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Reflection Anti-Invariance | Expected Utility | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Folded Expectation | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Full Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Negative Affine Anti-Invariance | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Uniqueness of Negative Self-Similarity | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Reflection Anti-Invariance | Pasadena = ln 2 | `finite-support-compensated-dominance` |
| Reflection Anti-Invariance | Positive Affine Invariance | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Relative Expectation | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Reflection Anti-Invariance | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Shift Invariance | `eventual-clipped-expectation` |
| Reflection Anti-Invariance | Transfer of a Shift Across a Mixture | `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Reflection Anti-Invariance | Simple Relative Expectation | `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Reflection Anti-Invariance | Symmetric Gambles Are Neutral | `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance` |
| Reflection Anti-Invariance | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Reflection Anti-Invariance | Universal Copula Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Continuity under Vanishing Shifts | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Relative Expectation | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Relative Expectation | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Relative Expectation | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Relative Expectation | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Relative Expectation | L¹ Continuity (random variables) | `lexicographic-folded-extension` |
| Relative Expectation | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Relative Expectation | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Relative Expectation | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Relative Expectation | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Continuity under Vanishing Shifts | `lexicographic-folded-extension` |
| Restricted Stochastic Equivalence | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Restricted Stochastic Equivalence | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Arroyo = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Stochastic Equivalence | CDF-Area Extension | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Existential Copula Sum Invariance | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Restricted Stochastic Equivalence | Expected Utility | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Mixture Independence | `finite-two-sample-minimum` |
| Restricted Stochastic Equivalence | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Stochastic Equivalence | Pasadena = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Stochastic Equivalence | Positive Affine Invariance | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Stochastic Equivalence | Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Restricted Stochastic Equivalence | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Shift Invariance | `eventual-clipped-expectation` |
| Restricted Stochastic Equivalence | Transfer of a Shift Across a Mixture | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Restricted Stochastic Equivalence | Simple Expected Utility | `finite-two-sample-minimum` |
| Restricted Stochastic Equivalence | Simple Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Restricted Stochastic Equivalence | Statewise Dominance | `finite-two-sample-minimum` |
| Restricted Stochastic Equivalence | Stochastic Dominance | `finite-two-sample-minimum` |
| Restricted Stochastic Equivalence | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Stochastic Equivalence | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Restricted Stochastic Equivalence | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Continuity under Vanishing Shifts | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Restricted Totality | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Restricted Totality | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Arroyo = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Totality | CDF-Area Extension | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Restricted Totality | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Existential Copula Sum Invariance | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Restricted Totality | Expected Utility | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Restricted Totality | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Mixture Independence | `finite-two-sample-minimum` |
| Restricted Totality | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Restricted Totality | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Totality | Pasadena = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Totality | Positive Affine Invariance | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Totality | Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Restricted Totality | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Restricted Totality | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Shift Invariance | `eventual-clipped-expectation` |
| Restricted Totality | Transfer of a Shift Across a Mixture | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Restricted Totality | Simple Expected Utility | `finite-two-sample-minimum` |
| Restricted Totality | Simple Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Restricted Totality | Statewise Dominance | `finite-two-sample-minimum` |
| Restricted Totality | Stochastic Dominance | `finite-two-sample-minimum` |
| Restricted Totality | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Totality | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Restricted Totality | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Continuity under Vanishing Shifts | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Rich Outcomes | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Rich Outcomes | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Arroyo = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Rich Outcomes | CDF-Area Extension | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Rich Outcomes | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Existential Copula Sum Invariance | `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Rich Outcomes | Expected Utility | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Rich Outcomes | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Mixture Independence | `finite-two-sample-minimum` |
| Rich Outcomes | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Rich Outcomes | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Rich Outcomes | Pasadena = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Rich Outcomes | Positive Affine Invariance | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Rich Outcomes | Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Rich Outcomes | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Shift Invariance | `eventual-clipped-expectation` |
| Rich Outcomes | Transfer of a Shift Across a Mixture | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Rich Outcomes | Simple Expected Utility | `finite-two-sample-minimum` |
| Rich Outcomes | Simple Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Rich Outcomes | Statewise Dominance | `finite-two-sample-minimum` |
| Rich Outcomes | Stochastic Dominance | `finite-two-sample-minimum` |
| Rich Outcomes | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Rich Outcomes | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Rich Outcomes | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Continuity under Vanishing Shifts | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Scale Invariance | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Scale Invariance | Antitonic Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Scale Invariance | Archimedean Gambles | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Scale Invariance | Arroyo = ln 2 | `finite-support-compensated-dominance` |
| Scale Invariance | CDF-Area Extension | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Scale Invariance | Comonotonic Sum Invariance | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Scale Invariance | Countable Sure-Thing | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Scale Invariance | Existential Copula Sum Invariance | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Scale Invariance | Expected Utility | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Scale Invariance | Folded Expectation | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Scale Invariance | Full Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Scale Invariance | Independent Sum Cancellation | `affine-symmetric-extension`, `lexicographic-nonatomic-mass` |
| Scale Invariance | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Scale Invariance | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Scale Invariance | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Scale Invariance | Negative Affine Anti-Invariance | `eventual-clipped-expectation`, `lexicographic-nonatomic-mass` |
| Scale Invariance | Uniqueness of Negative Self-Similarity | `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Scale Invariance | Pasadena = ln 2 | `finite-support-compensated-dominance` |
| Scale Invariance | Positive Affine Invariance | `eventual-clipped-expectation` |
| Scale Invariance | Relative Expectation | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Scale Invariance | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Scale Invariance | Shift Invariance | `eventual-clipped-expectation` |
| Scale Invariance | Transfer of a Shift Across a Mixture | `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Scale Invariance | Simple Relative Expectation | `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Scale Invariance | Symmetric Gambles Are Neutral | `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance` |
| Scale Invariance | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Scale Invariance | Universal Copula Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Scale Invariance | Continuity under Vanishing Shifts | `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Shift Invariance | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Shift Invariance | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Shift Invariance | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Shift Invariance | Arroyo = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Shift Invariance | CDF-Area Extension | `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Shift Invariance | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Shift Invariance | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Shift Invariance | Existential Copula Sum Invariance | `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Shift Invariance | Expected Utility | `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Shift Invariance | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter` |
| Shift Invariance | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Shift Invariance | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter` |
| Shift Invariance | Independent Sum Invariance | `affine-symmetric-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter` |
| Shift Invariance | Independent Sum Preservation | `affine-symmetric-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter` |
| Shift Invariance | L¹ Continuity (random variables) | `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass` |
| Shift Invariance | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Shift Invariance | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Shift Invariance | Pasadena = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Shift Invariance | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Shift Invariance | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Shift Invariance | Relative Expectation | `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Shift Invariance | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Shift Invariance | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Shift Invariance | Transfer of a Shift Across a Mixture | `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Shift Invariance | Simple Relative Expectation | `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Shift Invariance | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Shift Invariance | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `finite-support-compensated-dominance` |
| Shift Invariance | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Shift Invariance | Continuity under Vanishing Shifts | `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension` |
| Transfer of a Shift Across a Mixture | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Transfer of a Shift Across a Mixture | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | CDF-Area Extension | `lexicographic-nonatomic-mass` |
| Transfer of a Shift Across a Mixture | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Existential Copula Sum Invariance | `lexicographic-nonatomic-mass` |
| Transfer of a Shift Across a Mixture | Expected Utility | `lexicographic-nonatomic-mass` |
| Transfer of a Shift Across a Mixture | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | L¹ Continuity (random variables) | `lexicographic-folded-extension`, `lexicographic-nonatomic-mass` |
| Transfer of a Shift Across a Mixture | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Relative Expectation | `lexicographic-nonatomic-mass` |
| Transfer of a Shift Across a Mixture | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Transfer of a Shift Across a Mixture | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Transfer of a Shift Across a Mixture | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Continuity under Vanishing Shifts | `lexicographic-folded-extension` |
| Simple Expected Utility | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Simple Expected Utility | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Arroyo = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Expected Utility | CDF-Area Extension | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Simple Expected Utility | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Existential Copula Sum Invariance | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Simple Expected Utility | Expected Utility | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Simple Expected Utility | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Simple Expected Utility | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Expected Utility | Pasadena = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Expected Utility | Positive Affine Invariance | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Expected Utility | Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Simple Expected Utility | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Simple Expected Utility | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Shift Invariance | `eventual-clipped-expectation` |
| Simple Expected Utility | Transfer of a Shift Across a Mixture | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Simple Expected Utility | Simple Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Simple Expected Utility | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Expected Utility | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Simple Expected Utility | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Continuity under Vanishing Shifts | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Simple Relative Expectation | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Simple Relative Expectation | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Relative Expectation | CDF-Area Extension | `lexicographic-nonatomic-mass` |
| Simple Relative Expectation | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Existential Copula Sum Invariance | `lexicographic-nonatomic-mass` |
| Simple Relative Expectation | Expected Utility | `lexicographic-nonatomic-mass` |
| Simple Relative Expectation | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Relative Expectation | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | L¹ Continuity (random variables) | `lexicographic-folded-extension`, `lexicographic-nonatomic-mass` |
| Simple Relative Expectation | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Relative Expectation | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Relative Expectation | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Relative Expectation | Relative Expectation | `lexicographic-nonatomic-mass` |
| Simple Relative Expectation | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Simple Relative Expectation | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Relative Expectation | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Simple Relative Expectation | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Continuity under Vanishing Shifts | `lexicographic-folded-extension` |
| Statewise Dominance | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Statewise Dominance | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Arroyo = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Statewise Dominance | CDF-Area Extension | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Statewise Dominance | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Existential Copula Sum Invariance | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Statewise Dominance | Expected Utility | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Statewise Dominance | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Statewise Dominance | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Statewise Dominance | Pasadena = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Statewise Dominance | Positive Affine Invariance | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Statewise Dominance | Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Statewise Dominance | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Statewise Dominance | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Shift Invariance | `eventual-clipped-expectation` |
| Statewise Dominance | Transfer of a Shift Across a Mixture | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Statewise Dominance | Simple Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Statewise Dominance | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Statewise Dominance | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Statewise Dominance | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Continuity under Vanishing Shifts | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Stochastic Dominance | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Stochastic Dominance | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Arroyo = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Dominance | CDF-Area Extension | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Stochastic Dominance | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Existential Copula Sum Invariance | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Stochastic Dominance | Expected Utility | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Stochastic Dominance | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Stochastic Dominance | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Dominance | Pasadena = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Dominance | Positive Affine Invariance | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Dominance | Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Stochastic Dominance | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Stochastic Dominance | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Shift Invariance | `eventual-clipped-expectation` |
| Stochastic Dominance | Transfer of a Shift Across a Mixture | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Stochastic Dominance | Simple Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Stochastic Dominance | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Dominance | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Stochastic Dominance | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Continuity under Vanishing Shifts | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Stochastic Equivalence | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Arroyo = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Equivalence | CDF-Area Extension | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Existential Copula Sum Invariance | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Stochastic Equivalence | Expected Utility | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Mixture Independence | `finite-two-sample-minimum` |
| Stochastic Equivalence | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Equivalence | Pasadena = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Equivalence | Positive Affine Invariance | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Equivalence | Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Stochastic Equivalence | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Shift Invariance | `eventual-clipped-expectation` |
| Stochastic Equivalence | Transfer of a Shift Across a Mixture | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Stochastic Equivalence | Simple Expected Utility | `finite-two-sample-minimum` |
| Stochastic Equivalence | Simple Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Stochastic Equivalence | Statewise Dominance | `finite-two-sample-minimum` |
| Stochastic Equivalence | Stochastic Dominance | `finite-two-sample-minimum` |
| Stochastic Equivalence | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Equivalence | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Stochastic Equivalence | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Continuity under Vanishing Shifts | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Sure-Thing | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Sure-Thing | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Arroyo = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Sure-Thing | CDF-Area Extension | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Sure-Thing | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Existential Copula Sum Invariance | `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass` |
| Sure-Thing | Expected Utility | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Sure-Thing | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Sure-Thing | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Sure-Thing | Pasadena = ln 2 | `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Sure-Thing | Positive Affine Invariance | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Sure-Thing | Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Sure-Thing | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Sure-Thing | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Shift Invariance | `eventual-clipped-expectation` |
| Sure-Thing | Transfer of a Shift Across a Mixture | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Sure-Thing | Simple Relative Expectation | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance` |
| Sure-Thing | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `polynomial-asymmetric-continuous-ultrafilter` |
| Sure-Thing | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `finite-support-compensated-dominance` |
| Sure-Thing | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Continuity under Vanishing Shifts | `eventual-clipped-expectation`, `finite-shift-total-extension`, `finite-support-compensated-dominance`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Symmetric Gambles Are Neutral | Antitonic Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Archimedean Gambles | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | CDF-Area Extension | `eventual-clipped-expectation`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Comonotonic Sum Invariance | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Countable Sure-Thing | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Existential Copula Sum Invariance | `eventual-clipped-expectation`, `lexicographic-nonatomic-mass` |
| Symmetric Gambles Are Neutral | Expected Utility | `eventual-clipped-expectation`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Folded Expectation | `eventual-clipped-expectation`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Full Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Negative Affine Anti-Invariance | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Uniqueness of Negative Self-Similarity | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Symmetric Gambles Are Neutral | Positive Affine Invariance | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Relative Expectation | `eventual-clipped-expectation`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Symmetric Gambles Are Neutral | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Shift Invariance | `eventual-clipped-expectation` |
| Symmetric Gambles Are Neutral | Transfer of a Shift Across a Mixture | `eventual-clipped-expectation` |
| Symmetric Gambles Are Neutral | Simple Relative Expectation | `eventual-clipped-expectation` |
| Symmetric Gambles Are Neutral | Totality | `eventual-clipped-expectation` |
| Symmetric Gambles Are Neutral | Universal Copula Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Continuity under Vanishing Shifts | `eventual-clipped-expectation`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Totality | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Totality | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Totality | CDF-Area Extension | `finite-shift-total-extension`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Totality | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Existential Copula Sum Invariance | `lexicographic-nonatomic-mass` |
| Totality | Expected Utility | `finite-shift-total-extension`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Totality | Folded Expectation | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Mixture Independence | `finite-two-sample-minimum` |
| Totality | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | L¹ Continuity (random variables) | `finite-shift-total-extension`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Totality | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Totality | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Totality | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Totality | Relative Expectation | `finite-shift-total-extension`, `finite-two-sample-minimum`, `lexicographic-nonatomic-mass`, `total-exact-ultrafilter` |
| Totality | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Totality | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Transfer of a Shift Across a Mixture | `finite-shift-total-extension` |
| Totality | Simple Expected Utility | `finite-two-sample-minimum` |
| Totality | Simple Relative Expectation | `finite-shift-total-extension` |
| Totality | Statewise Dominance | `finite-two-sample-minimum` |
| Totality | Stochastic Dominance | `finite-two-sample-minimum` |
| Totality | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Totality | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-shift-total-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Continuity under Vanishing Shifts | `finite-shift-total-extension`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Continuity under Vanishing Shifts | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter` |
| Continuity under Vanishing Shifts | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter` |
| Continuity under Vanishing Shifts | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter` |
| Continuity under Vanishing Shifts | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Continuity under Vanishing Shifts | CDF-Area Extension | `lexicographic-nonatomic-mass` |
| Continuity under Vanishing Shifts | Comonotonic Sum Invariance | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter` |
| Continuity under Vanishing Shifts | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| Continuity under Vanishing Shifts | Existential Copula Sum Invariance | `lexicographic-nonatomic-mass` |
| Continuity under Vanishing Shifts | Expected Utility | `lexicographic-nonatomic-mass` |
| Continuity under Vanishing Shifts | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter` |
| Continuity under Vanishing Shifts | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter` |
| Continuity under Vanishing Shifts | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass` |
| Continuity under Vanishing Shifts | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass` |
| Continuity under Vanishing Shifts | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass` |
| Continuity under Vanishing Shifts | L¹ Continuity (random variables) | `lexicographic-nonatomic-mass` |
| Continuity under Vanishing Shifts | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter` |
| Continuity under Vanishing Shifts | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| Continuity under Vanishing Shifts | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Continuity under Vanishing Shifts | Positive Affine Invariance | `geometric-continuous-ultrafilter` |
| Continuity under Vanishing Shifts | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| Continuity under Vanishing Shifts | Relative Expectation | `lexicographic-nonatomic-mass` |
| Continuity under Vanishing Shifts | Rich Outcomes | `lexicographic-nonatomic-mass` |
| Continuity under Vanishing Shifts | Scale Invariance | `geometric-continuous-ultrafilter` |
| Continuity under Vanishing Shifts | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `polynomial-asymmetric-continuous-ultrafilter` |
| Continuity under Vanishing Shifts | Totality | `cdf-area-preorder` |
| Continuity under Vanishing Shifts | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `geometric-continuous-ultrafilter`, `lexicographic-nonatomic-mass`, `polynomial-asymmetric-continuous-ultrafilter` |

### 6.4 Open single-premise pairs (599)

Listed in `OPEN-QUESTIONS.md`.

### Negative implications (0)

Read A ⇒ ¬B: A and B cannot hold together. This does not by itself witness a model of A.

None.

### 6.5 What the recorded premise packages entail

Every multi-premise package used by a proved result, with its full consequence set.

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Symmetric Gambles Are Neutral + Independent Sum Invariance

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `symmetric-neutrality`, `independent-sum-consistency`.

**Inconsistent:** these premises imply False via independent-sum-implies-preservation, levy-refutes-neutral-independent-preservation. No consequences by explosion are listed.

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance + L¹ Continuity (random variables)

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`, `l1-continuity`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Refuted (a model satisfies the package and violates these): nothing
- Open: Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance + Relative Expectation

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`, `relative-expectation`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Refuted (a model satisfies the package and violates these): nothing
- Open: Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Archimedean Gambles

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `archimedean-gambles`.

**Inconsistent:** these premises imply False via dtu-refutes-archimedean-gambles. No consequences by explosion are listed.

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Independent Sum Cancellation

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `independent-sum-cancellation`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Archimedean Outcomes (`archimedean-outcomes`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): nothing
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Expected Utility (`expected-utility`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + L¹ Continuity (random variables)

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `l1-continuity`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Archimedean Outcomes (`archimedean-outcomes`), CDF-Area Extension (`cdf-area-extension`), Expected Utility (`expected-utility`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Folded Expectation (`folded-expectation`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Open: Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Refuted (a model satisfies the package and violates these): nothing
- Open: Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Pasadena = ln 2 (`pasadena-value`), Relative Expectation (`relative-expectation`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

#### Rich Outcomes + Archimedean Outcomes + Stochastic Equivalence + Stochastic Dominance + Mixture Independence + L¹ Continuity (random variables)

Assumes: `rich-outcomes`, `archimedean-outcomes`, `stochastic-equivalence`, `stochastic-dominance`, `independence`, `l1-continuity`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: CDF-Area Extension (`cdf-area-extension`), Expected Utility (`expected-utility`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Folded Expectation (`folded-expectation`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`)
- Open: Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

#### Rich Outcomes + Archimedean Outcomes + Stochastic Equivalence + Stochastic Dominance + Mixture Independence + Continuity under Vanishing Shifts

Assumes: `rich-outcomes`, `archimedean-outcomes`, `stochastic-equivalence`, `stochastic-dominance`, `independence`, `vanishing-shift-continuity`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: CDF-Area Extension (`cdf-area-extension`), Expected Utility (`expected-utility`), L¹ Continuity (random variables) (`l1-continuity`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Folded Expectation (`folded-expectation`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`)
- Open: Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

#### Rich Outcomes + Expected Utility + Stochastic Equivalence + Mixture Independence + Stochastic Dominance + L¹ Continuity (random variables)

Assumes: `rich-outcomes`, `expected-utility`, `stochastic-equivalence`, `independence`, `stochastic-dominance`, `l1-continuity`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Archimedean Outcomes (`archimedean-outcomes`), CDF-Area Extension (`cdf-area-extension`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Folded Expectation (`folded-expectation`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`)
- Open: Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Mixture Independence + Reflection Anti-Invariance

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `independence`, `reflection-anti-invariance`.

- Rules out (entails their negations): Countable Sure-Thing (`countable-sure-thing`)
- Entails: Archimedean Outcomes (`archimedean-outcomes`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: Arroyo = ln 2 (`arroyo-value`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Pasadena = ln 2 (`pasadena-value`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`)

#### Rich Outcomes + Stochastic Equivalence + Simple Expected Utility + Mixture Independence + Symmetric Gambles Are Neutral + Shift Invariance

Assumes: `rich-outcomes`, `stochastic-equivalence`, `simple-eu`, `independence`, `symmetric-neutrality`, `shift-invariance`.

- Rules out (entails their negations): Countable Sure-Thing (`countable-sure-thing`)
- Entails: Archimedean Outcomes (`archimedean-outcomes`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Positive Affine Invariance (`positive-affine-invariance`), Scale Invariance (`scale-invariance`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Pasadena = ln 2 (`pasadena-value`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Totality (`totality`)

#### Rich Outcomes + Archimedean Outcomes + Totality + Stochastic Dominance + Sure-Thing

Assumes: `rich-outcomes`, `archimedean-outcomes`, `totality`, `stochastic-dominance`, `sure-thing`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Mixture Independence (`independence`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`), Statewise Dominance (`statewise-dominance`), Stochastic Equivalence (`stochastic-equivalence`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Shift Invariance (`shift-invariance`)

#### Rich Outcomes + Stochastic Dominance + Mixture Independence + Symmetric Gambles Are Neutral + Independent Sum Preservation

Assumes: `rich-outcomes`, `stochastic-dominance`, `independence`, `symmetric-neutrality`, `independent-sum-preservation`.

**Inconsistent:** these premises imply False via levy-refutes-neutral-independent-preservation. No consequences by explosion are listed.

#### Rich Outcomes + Stochastic Equivalence + Mixture Independence + Relative Expectation + Uniqueness of Negative Self-Similarity

Assumes: `rich-outcomes`, `stochastic-equivalence`, `independence`, `relative-expectation`, `negative-self-similarity`.

- Rules out (entails their negations): nothing further
- Entails: Pasadena = ln 2 (`pasadena-value`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Totality (`restricted-totality`), Scale Invariance (`scale-invariance`), Simple Expected Utility (`simple-eu`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

#### Rich Outcomes + Stochastic Equivalence + Simple Expected Utility + Mixture Independence + Transfer of a Shift Across a Mixture

Assumes: `rich-outcomes`, `stochastic-equivalence`, `simple-eu`, `independence`, `shift-transfer`.

- Rules out (entails their negations): Countable Sure-Thing (`countable-sure-thing`)
- Entails: Archimedean Outcomes (`archimedean-outcomes`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`), Simple Relative Expectation (`simple-relative-expectation`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: CDF-Area Extension (`cdf-area-extension`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Relative Expectation (`relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`)

#### Rich Outcomes + Totality + Stochastic Equivalence + Mixture Independence + Symmetric Gambles Are Neutral

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `independence`, `symmetric-neutrality`.

- Rules out (entails their negations): nothing further
- Entails: Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Pasadena = ln 2 (`pasadena-value`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`)

#### Rich Outcomes + Totality + Stochastic Dominance + L¹ Continuity (random variables) + Independent Sum Cancellation

Assumes: `rich-outcomes`, `totality`, `stochastic-dominance`, `l1-continuity`, `independent-sum-cancellation`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Full Sum Invariance (`full-sum-consistency`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`), Stochastic Equivalence (`stochastic-equivalence`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Refuted (a model satisfies the package and violates these): nothing
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Gambles (`archimedean-gambles`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Mixture Independence (`independence`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)

#### Rich Outcomes + Stochastic Equivalence + Relative Expectation + Symmetric Gambles Are Neutral + Shift Invariance

Assumes: `rich-outcomes`, `stochastic-equivalence`, `relative-expectation`, `symmetric-neutrality`, `shift-invariance`.

- Rules out (entails their negations): nothing further
- Entails: Arroyo = ln 2 (`arroyo-value`), Folded Expectation (`folded-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Positive Affine Invariance (`positive-affine-invariance`), Scale Invariance (`scale-invariance`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), CDF-Area Extension (`cdf-area-extension`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Mixture Independence (`independence`), Pasadena = ln 2 (`pasadena-value`), Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Sure-Thing (`sure-thing`), Totality (`totality`)

#### Rich Outcomes + Simple Expected Utility + Stochastic Dominance + Archimedean Gambles

Assumes: `rich-outcomes`, `simple-eu`, `stochastic-dominance`, `archimedean-gambles`.

**Inconsistent:** these premises imply False via rich-simple-dominance-refutes-archimedean-gambles. No consequences by explosion are listed.

#### Rich Outcomes + Archimedean Outcomes + Stochastic Dominance + Mixture Independence

Assumes: `rich-outcomes`, `archimedean-outcomes`, `stochastic-dominance`, `independence`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`), Statewise Dominance (`statewise-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: nothing

#### Rich Outcomes + Archimedean Outcomes + Stochastic Dominance + Relative Expectation

Assumes: `rich-outcomes`, `archimedean-outcomes`, `stochastic-dominance`, `relative-expectation`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Full Sum Invariance (`full-sum-consistency`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: CDF-Area Extension (`cdf-area-extension`), Expected Utility (`expected-utility`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Equivalence (`stochastic-equivalence`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Mixture Independence (`independence`), Shift Invariance (`shift-invariance`), Sure-Thing (`sure-thing`)

#### Rich Outcomes + Archimedean Outcomes + Stochastic Equivalence + Statewise Dominance

Assumes: `rich-outcomes`, `archimedean-outcomes`, `stochastic-equivalence`, `statewise-dominance`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Full Sum Invariance (`full-sum-consistency`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Stochastic Dominance (`stochastic-dominance`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: Mixture Independence (`independence`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`), Sure-Thing (`sure-thing`)

#### Rich Outcomes + Simple Expected Utility + Sure-Thing + Countable Sure-Thing

Assumes: `rich-outcomes`, `simple-eu`, `sure-thing`, `countable-sure-thing`.

**Inconsistent:** these premises imply False via rich-simple-sure-thing-refutes-countable. No consequences by explosion are listed.

#### Rich Outcomes + Stochastic Equivalence + Simple Expected Utility + Uniqueness of Negative Self-Similarity

Assumes: `rich-outcomes`, `stochastic-equivalence`, `simple-eu`, `negative-self-similarity`.

- Rules out (entails their negations): nothing further
- Entails: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`)
- Refuted (a model satisfies the package and violates these): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Mixture Independence (`independence`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

#### Rich Outcomes + Stochastic Dominance + Antitonic Sum Invariance

Assumes: `rich-outcomes`, `stochastic-dominance`, `antitonic-sum-consistency`.

**Inconsistent:** these premises imply False via dominance-refutes-antitonic-sum. No consequences by explosion are listed.

#### Rich Outcomes + Mixture Independence + Folded Expectation

Assumes: `rich-outcomes`, `independence`, `folded-expectation`.

- Rules out (entails their negations): nothing further
- Entails: Arroyo = ln 2 (`arroyo-value`), Relative Expectation (`relative-expectation`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Positive Affine Invariance (`positive-affine-invariance`), Scale Invariance (`scale-invariance`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), CDF-Area Extension (`cdf-area-extension`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Pasadena = ln 2 (`pasadena-value`), Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`), Totality (`totality`)

#### Rich Outcomes + Stochastic Dominance + Full Sum Invariance

Assumes: `rich-outcomes`, `stochastic-dominance`, `full-sum-consistency`.

**Inconsistent:** these premises imply False via dominance-refutes-full-sum. No consequences by explosion are listed.

#### Totality + Mixture Independence + Negative Affine Anti-Invariance

Assumes: `totality`, `independence`, `negative-affine-anti-invariance`.

- Rules out (entails their negations): nothing further
- Entails: Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Totality (`restricted-totality`)
- Refuted (a model satisfies the package and violates these): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Rich Outcomes (`rich-outcomes`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

#### Rich Outcomes + Simple Relative Expectation + L¹ Continuity (random variables)

Assumes: `rich-outcomes`, `simple-relative-expectation`, `l1-continuity`.

- Rules out (entails their negations): nothing further
- Entails: Relative Expectation (`relative-expectation`), Transfer of a Shift Across a Mixture (`shift-transfer`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), CDF-Area Extension (`cdf-area-extension`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Mixture Independence (`independence`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`), Simple Expected Utility (`simple-eu`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`)

#### Rich Outcomes + Positive Affine Invariance + Reflection Anti-Invariance

Assumes: `rich-outcomes`, `positive-affine-invariance`, `reflection-anti-invariance`.

- Rules out (entails their negations): nothing further
- Entails: Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Relative Expectation (`relative-expectation`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), Mixture Independence (`independence`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`)

#### Rich Outcomes + Relative Expectation + Continuity under Vanishing Shifts

Assumes: `rich-outcomes`, `relative-expectation`, `vanishing-shift-continuity`.

- Rules out (entails their negations): nothing further
- Entails: L¹ Continuity (random variables) (`l1-continuity`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), CDF-Area Extension (`cdf-area-extension`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Mixture Independence (`independence`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`), Simple Expected Utility (`simple-eu`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`)

#### Rich Outcomes + Shift Invariance + Scale Invariance

Assumes: `rich-outcomes`, `shift-invariance`, `scale-invariance`.

- Rules out (entails their negations): nothing further
- Entails: Positive Affine Invariance (`positive-affine-invariance`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Relative Expectation (`relative-expectation`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), Mixture Independence (`independence`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`)

#### Antitonic Sum Invariance + Stochastic Equivalence

Assumes: `antitonic-sum-consistency`, `stochastic-equivalence`.

- Rules out (entails their negations): nothing further
- Entails: Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Shift Invariance (`shift-invariance`)
- Refuted (a model satisfies the package and violates these): nothing
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Gambles (`archimedean-gambles`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Mixture Independence (`independence`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Restricted Totality (`restricted-totality`), Rich Outcomes (`rich-outcomes`), Scale Invariance (`scale-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

#### Archimedean Outcomes + Folded Expectation

Assumes: `archimedean-outcomes`, `folded-expectation`.

- Rules out (entails their negations): nothing further
- Entails: Expected Utility (`expected-utility`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Positive Affine Invariance (`positive-affine-invariance`), Scale Invariance (`scale-invariance`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Mixture Independence (`independence`), Pasadena = ln 2 (`pasadena-value`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Rich Outcomes (`rich-outcomes`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`)

#### Archimedean Outcomes + Relative Expectation

Assumes: `archimedean-outcomes`, `relative-expectation`.

- Rules out (entails their negations): nothing further
- Entails: Expected Utility (`expected-utility`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: CDF-Area Extension (`cdf-area-extension`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Mixture Independence (`independence`), Rich Outcomes (`rich-outcomes`), Shift Invariance (`shift-invariance`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`)

#### Archimedean Outcomes + Stochastic Dominance

Assumes: `archimedean-outcomes`, `stochastic-dominance`.

- Rules out (entails their negations): nothing further
- Entails: Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Statewise Dominance (`statewise-dominance`), Stochastic Equivalence (`stochastic-equivalence`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Rich Outcomes (`rich-outcomes`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: Mixture Independence (`independence`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`), Sure-Thing (`sure-thing`)

#### Comonotonic Sum Invariance + Stochastic Equivalence

Assumes: `comonotonic-sum-consistency`, `stochastic-equivalence`.

- Rules out (entails their negations): nothing further
- Entails: Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Shift Invariance (`shift-invariance`)
- Refuted (a model satisfies the package and violates these): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Expected Utility (`expected-utility`), Mixture Independence (`independence`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Restricted Totality (`restricted-totality`), Rich Outcomes (`rich-outcomes`), Scale Invariance (`scale-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Sure-Thing (`sure-thing`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

#### Rich Outcomes + Folded Expectation

Assumes: `rich-outcomes`, `folded-expectation`.

- Rules out (entails their negations): nothing further
- Entails: Arroyo = ln 2 (`arroyo-value`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Positive Affine Invariance (`positive-affine-invariance`), Scale Invariance (`scale-invariance`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), CDF-Area Extension (`cdf-area-extension`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Mixture Independence (`independence`), Pasadena = ln 2 (`pasadena-value`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`), Totality (`totality`)

#### Mixture Independence + Transfer of a Shift Across a Mixture

Assumes: `independence`, `shift-transfer`.

- Rules out (entails their negations): nothing further
- Entails: Shift Invariance (`shift-invariance`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Rich Outcomes (`rich-outcomes`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`)

#### Stochastic Equivalence + Mixture Independence

Assumes: `stochastic-equivalence`, `independence`.

- Rules out (entails their negations): nothing further
- Entails: Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Rich Outcomes (`rich-outcomes`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`)

#### Independent Sum Preservation + Independent Sum Cancellation

Assumes: `independent-sum-preservation`, `independent-sum-cancellation`.

- Rules out (entails their negations): nothing further
- Entails: Independent Sum Invariance (`independent-sum-consistency`), Shift Invariance (`shift-invariance`)
- Refuted (a model satisfies the package and violates these): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Mixture Independence (`independence`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Rich Outcomes (`rich-outcomes`), Scale Invariance (`scale-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

#### Independent Sum Invariance + Stochastic Equivalence

Assumes: `independent-sum-consistency`, `stochastic-equivalence`.

- Rules out (entails their negations): nothing further
- Entails: Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Preservation (`independent-sum-preservation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Shift Invariance (`shift-invariance`)
- Refuted (a model satisfies the package and violates these): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Expected Utility (`expected-utility`), Mixture Independence (`independence`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Restricted Totality (`restricted-totality`), Rich Outcomes (`rich-outcomes`), Scale Invariance (`scale-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Sure-Thing (`sure-thing`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

#### Totality + Independent Sum Preservation

Assumes: `totality`, `independent-sum-preservation`.

- Rules out (entails their negations): nothing further
- Entails: Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`)
- Refuted (a model satisfies the package and violates these): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Mixture Independence (`independence`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Rich Outcomes (`rich-outcomes`), Scale Invariance (`scale-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

#### Rich Outcomes + Negative Affine Anti-Invariance

Assumes: `rich-outcomes`, `negative-affine-anti-invariance`.

- Rules out (entails their negations): nothing further
- Entails: Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Relative Expectation (`relative-expectation`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`), Continuity under Vanishing Shifts (`vanishing-shift-continuity`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), Mixture Independence (`independence`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`)

## 7. Additional write-ups

Hand-written notes not attached to a single record.

### `falsity-migration`

#### Falsity-constraint migration

Negative conclusions now use an additional premise and `conclusion: false`.
The following retired display nodes are preserved here for reference; their results retain their IDs, proofs and sources.

##### Failure of Full Sum Consistency (`failure-full-sum-consistency`)

Negation of `full-sum-consistency`. Full Sum Consistency does not hold: an admissible triple witnesses failure of its biconditional.

Sources:

- Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.1, p. 17

##### Failure of Antitonic Sum Consistency (`failure-antitonic-sum-consistency`)

Negation of `antitonic-sum-consistency`. Antitonic Sum Consistency does not hold: an admissible triple witnesses failure of its biconditional.

Sources:

- Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; Theorem 6, p. 19

##### Failure of Archimedean Gambles (`failure-archimedean-gambles`)

Negation of `archimedean-gambles`. There exist $X \succ Y \succ Z$ such that no $p \in (0,1)$ satisfies $Y \sim M_p(X,Z)$.

Sources:

- Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 22

##### Failure of Countable Sure-Thing (`failure-countable-sure-thing`)

Negation of `countable-sure-thing`. Countable Sure-Thing is false: there are X,Y and a countable positive-probability partition satisfying its conditional premises but failing its corresponding weak or strict conclusion.

Sources:

- Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §§2.2–2.3, pp. 674–676

##### Failure of Independent Sum Consistency (`failure-independent-sum-consistency`)

Negation of `independent-sum-consistency`. Independent Sum Consistency does not hold: an admissible triple witnesses failure of its biconditional.

Sources:

- Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §4, especially the acknowledged error on p. 12

### `l1-translation`

#### Translating the source's L¹ metric to random variables

In *Symmetries of value*, p. 23, distance between two laws is the infimum of
E|A−B| over all couplings, with infinity allowed. Call this extended metric W.
The node in this topic instead uses $E|X_n- X|$ for the actual variables.

Assume **Stochastic Equivalence**, the full random-variable domain, and the
real chart used in the source theorem packages. If W-continuity holds, then
actual-coupling $L^{1}$ convergence implies W-convergence, so the topic's closure
clause follows immediately.

Conversely, suppose laws $\mu _n$ converge to $\mu$ in W. Pick couplings $(A_n,B_n)$ with
laws $\mu _n,\mu$ and $E|A_n- B_n|\to 0$ (an approximate infimum within 1/n suffices).
On a standard Borel space, disintegrate these couplings over their common
second marginal and realize them with a single B of $\operatorname{law} \mu$ and a sequence of
auxiliary uniform random variables. The resulting $A'_n$ all share the same B
and satisfy $E|A'_n- B|\to 0$. All are realizable on the standing atomless space.
By Stochastic Equivalence, each comparison of $\mu _n$ with a fixed $\operatorname{law} \nu$ holds
for these representatives as well. Apply the topic's continuity clause and
transfer the conclusion back by Stochastic Equivalence.

Without Stochastic Equivalence the transfer between representatives is
unavailable. This is why a metric on laws was not used in the node definition:
its zero-distance constant sequences would already force equal-law variables
to be indifferent by reflexivity and closure.

This verifies a **translation of the continuity assumption**. It does not
independently prove the paper's DTU $\Rightarrow \operatorname{EU}$ extension after adding continuity,
or the reverse direction of its Corollary 5. Those are cited source results.

## 8. Where this came from

The paper catalogue is `topics/unbounded-utility/papers.yaml`; any included source documents are in `topics/unbounded-utility/sources/`. The extraction log, with transcription decisions and deliberately deferred items, is `topics/unbounded-utility/extraction.md`. Read it before trusting any single page reference.
