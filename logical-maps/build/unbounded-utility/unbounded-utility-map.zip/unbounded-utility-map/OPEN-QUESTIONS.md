# Open questions — Unbounded Utility

Recorded conjectures, their current answers, and remaining gaps where a new result or model would contribute to the map.

**"Open" means not settled by the records in this bundle.** It does not mean unsolved in the literature, and it does not mean hard. Many entries below are routine and simply have not been added yet. Check the sources before assuming a question is new.

## 1. Recorded conjectures and their answers

Answers below are recomputed from proved records under the fixed topic background. A conjectured record supplies no evidence for its own answer. Records marked was_conjectured remain in this history after promotion to proved; their proved status, rather than the historical marker, determines whether they supply evidence. Original sources and notes are retained below each answer.

### 1.1 Unresolved (1)

#### CDF-area: total comonotonic extension — `conjectured-total-comonotonic-area-extension`

**Answer: Open.**

Original record notes:

Original work: precise candidate formulation and comparison of two extension problems. The base area construction, its comonotonic property, and the broader unresolved consistency question are credited to Goodsell. The manuscript's Theorem 7 supplies only the incomplete area model, not this proposed total CDF-area extension. No new completed model is claimed. To settle positively, give a total extension and verify that adjoining comparisons preserves every old strict area comparison, full Mixture Independence, and comonotonic preservation and cancellation. To settle negatively, derive an incompatibility from the displayed package. A generic order extension is insufficient, and the total convolution model is not evidence that comonotonic invariance survives. No claim is made that the question is open in the literature.

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, unpublished manuscript, 5 June 2026, §3, pp. 7–8, and discussion before Theorem 7 and Theorem 7, pp. 19–20: CDF-area construction, its comonotonic invariance, and the broader unresolved consistency question.
- **GPT-6 conjecture 9 Sep** — GPT-6 (Codex), 9 September 2026, proposed total-extension package and obstacle analysis in writeups/conjectured-total-comonotonic-area-extension.md.

Record: `topics/unbounded-utility/models/conjectured-total-comonotonic-area-extension.yaml`.

### 1.2 Resolved (6)

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Independent Sum Cancellation ⇒ Independent Sum Preservation — `conjectured-dtu-cancellation-implies-preservation`

**Answer: Proved.**

Supporting result ids: `conjectured-dtu-cancellation-implies-preservation`.

Original record notes:

The original seven-premise conjecture is proved without changing its statement; was_conjectured preserves its history. The geometric renewal law closes the earlier indifference gap. The existing proof with L1 Continuity remains valid but its extra premise is unnecessary. Under DTU, Cancellation, Preservation and Independent Sum Invariance are equivalent by this theorem and the existing converse deductions. Arbitrary independent noise is essential to the argument: the geometric auxiliary law generally has infinite support. No full-noise property is thereby established for the finite-shift total extension. Original connecting work under Misc.; no literature-priority claim, independent checker or Lean verification is asserted.

- **GPT-6 conjecture 9 Sep; proof 13 Sep** — GPT-6 (Codex), 9 September 2026: original conjecture and partial analysis; 13 September 2026: geometric-noise proof in writeups/conjectured-dtu-cancellation-implies-preservation.md.
- **Goodsell argument 13 Sep** — Zachary Goodsell, project conversation, 13 September 2026: request to resolve Cancellation implies Preservation and the contraposition argument for strict comparisons.
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, unpublished manuscript, 5 June 2026, Lemma 1, pp. 7–8: source for the separated sum principles, not this connecting theorem.

Record: `topics/unbounded-utility/results/conjectured-dtu-cancellation-implies-preservation.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Shift Invariance ⇒ Transfer of a Shift Across a Mixture — `conjectured-dtu-shift-implies-transfer`

**Answer: Refuted.**

Model witness ids: `finite-shift-total-extension`.

Original record notes:

Original work: conjecture formulation and partial analysis, with a separately recorded countermodel added on 13 September 2026. The candidate asks whether DTU plus Shift Invariance alone implies Shift Transfer, equivalently under DTU Simple Relative Expectation. The recorded neutrality-shift-imply-shift-transfer proof settles the question after adding Symmetric Neutrality. The du-vanishing-shifts-imply-relative proof settles it after adding Continuity under Vanishing Shifts; under DU this is equivalent to L1 Continuity. The independent du-l1-implies-relative proof also supplies the continuity route, without Totality or Shift Invariance. Consequently a separating model would have to fail both neutrality and L1 Continuity. The continuous clipping models already satisfy Relative Expectation; the new lexicographic folded-tail model fails continuity but still satisfies Relative Expectation and neutrality. Neither family supplies the required separation. The new finite-support-compensated-dominance model does separate DU plus Shift Invariance from Shift Transfer, but it violates Totality and therefore does not settle this DTU conjecture. Its explicit transfer and vanishing-shift continuity failures are proved in its write-up. Its finite-shift-total-extension now supplies Totality while strictly ordering the same transfer pair. The new proof checks finite-kernel saturation and preserves the indifferent subspace through the orientation and maximal-extension steps. The original implication, ID, empty proof and conjectured status remain unchanged: the viewer computes refutation from this separate proved model. Stronger backgrounds can still prove the conditional implication, and source filters can remove its refuting evidence. Conjectured records question history, not a claim that the current full evidence leaves it open.

- **GPT-6 question 9 Sep** — GPT-6 (Codex), 9 September 2026, follow-up DU investigation; precise unresolved implication and partial analysis in writeups/conjectured-dtu-shift-implies-transfer.md.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37, DOI 10.1111/nous.12549, Theorems 3–4, pp. 25–27: source for Shift Transfer and its derivation with full affine symmetry, not this conjecture.
- **Goodsell/GPT-6 countermodel 13 Sep** — Zachary Goodsell (finite-shift extension proposal) and GPT-6 (Codex) (countermodel and extension proof), Logical Maps, 13 September 2026: the separately recorded model finite-shift-total-extension refutes this implication under its stated premises; see writeups/finite-shift-total-extension.md.

Record: `topics/unbounded-utility/results/conjectured-dtu-shift-implies-transfer.yaml`.

#### Countable Sure-Thing ∧ Archimedean Outcomes ⇒ Archimedean Gambles — `countable-sure-thing-outcomes-to-gambles`

**Answer: Refuted.**

Model witness ids: `lexicographic-nonatomic-mass`.

Original record notes:

Refuted on the standing full measurable domain by the proved lexicographic-nonatomic-mass model, supplied by GPT-6 (Codex) on 13 September 2026. It satisfies both proposed premises, as well as Totality, Stochastic Equivalence, Stochastic Dominance, Mixture Independence and Sure-Thing, while violating both Expected Utility and Archimedean Gambles. Its outcome chart is [0,1], so Rich Outcomes fails; that principle is not a premise of this question. The Russell–Isaacs theorem concerns countably supported lotteries: its domain excludes the nonatomic witness used here. The original ID, premises, authorship and conjectured status are preserved. Refutation is computed from the separate proved model and selected background; under DU or DTU the premises instead conflict with the background. See the handwritten write-up for the witness and source comparison. No independent checking or Lean proof is claimed.

- **User suggestion 8 Sep** — User suggestion in this project's conversation, 2026-09-08; proposed implication, not a completed proof.
- **Infinite Prospects (domain comparison)** — Related discrete-lottery theorem, not a theorem of this full-domain arrow: Jeffrey Sanford Russell and Yoaav Isaacs, Infinite Prospects, Philosophy and Phenomenological Research 103 (2021), 178–198, DOI 10.1111/phpr.12704. Author-hosted manuscript, §§4–5 and Appendix A, especially pp. 15, 22, 25: https://www.yoaavisaacs.com/uploads/6/9/2/0/69204575/infinite-prospects-final.pdf
- **GPT-6 countermodel 13 Sep** — GPT-6 (Codex), Logical Maps, 13 September 2026: full-domain refutation in writeups/lexicographic-nonatomic-mass.md and source comparison in writeups/countable-sure-thing-outcomes-to-gambles.md.

Record: `topics/unbounded-utility/results/countable-sure-thing-outcomes-to-gambles.yaml`.

#### Countable Sure-Thing ∧ Simple Expected Utility ⇒ Expected Utility — `countable-sure-thing-simple-to-full-eu`

**Answer: Refuted.**

Model witness ids: `lexicographic-nonatomic-mass`.

Original record notes:

Refuted on the standing full measurable domain by the proved lexicographic-nonatomic-mass model, supplied by GPT-6 (Codex) on 13 September 2026. It satisfies both proposed premises, as well as Totality, Stochastic Equivalence, Stochastic Dominance, Mixture Independence and Sure-Thing, while violating both Expected Utility and Archimedean Gambles. Its outcome chart is [0,1], so Rich Outcomes fails; that principle is not a premise of this question. The Russell–Isaacs theorem concerns countably supported lotteries: its domain excludes the nonatomic witness used here. The original ID, premises, authorship and conjectured status are preserved. Refutation is computed from the separate proved model and selected background; under DU or DTU the premises instead conflict with the background. See the handwritten write-up for the witness and source comparison. No independent checking or Lean proof is claimed.

- **User suggestion 8 Sep** — User suggestion in this project's conversation, 2026-09-08; proposed implication, not a completed proof.
- **Decision Theory Unbound** — Related motivation rather than a verified theorem with these exact premises: Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695, DOI 10.1111/nous.12473, §4.1, pp. 685–686.
- **GPT-6 countermodel 13 Sep** — GPT-6 (Codex), Logical Maps, 13 September 2026: full-domain refutation in writeups/lexicographic-nonatomic-mass.md and source comparison in writeups/countable-sure-thing-simple-to-full-eu.md.

Record: `topics/unbounded-utility/results/countable-sure-thing-simple-to-full-eu.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Symmetric Gambles Are Neutral ∧ Independent Sum Invariance ⇒ False (⊥) — `symmetric-dtu-refutes-independent-sum-candidate`

**Answer: Proved.**

Supporting result ids: `independent-sum-implies-preservation`, `levy-refutes-neutral-independent-preservation`.

Original record notes:

Settled 9 September 2026 by levy-refutes-neutral-independent-preservation. Original work: direct consequence of that proof completion; no additional mathematical construction is needed for this larger premise package. Goodsell’s proposal and the historical source audit are preserved. The previous open-status wording below records the state before completion.

Historical notes:
Records the user’s proposed incompatibility with a deliberately sufficient package. The user recalls balanced mixtures involving stable indices 1 and 1/2, neutral by symmetry, becoming strictly dominance-ordered after convolution by a common index-1/2 law. Exact laws, skewness, scale, location, mixture weights, and a global strict-dominance proof remain to be specified. The draft explicitly withdraws its symmetry lemma; that proof failure alone is not a proof of this implication. Excluded from proved inference and known-inconsistency warnings.

Representation update: the former negative conclusion is expressed by adding independent-sum-consistency to the premises and concluding False. The mathematical claim, source, and proof are unchanged.

- **Goodsell proposal 9 Sep** — Zachary Goodsell, project conversation, 9 September 2026: revised conjecture omitting reflection and recollection of a stable-distribution obstruction
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §4, pp. 10–14 (withdrawn consistency argument)
- **GPT-6 proof completion 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/levy-refutes-neutral-independent-preservation.md: complete reduced-premise proof of Goodsell’s stable-law obstruction.

Record: `topics/unbounded-utility/results/symmetric-dtu-refutes-independent-sum-candidate.yaml`.

#### CDF-area conclosure: total extension — `conjectured-total-independent-sum-extension`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `dominance-refutes-full-sum`, `dominance-refutes-antitonic-sum`, `independence-to-sure-thing`, `rich-simple-sure-thing-refutes-countable`, `dtu-refutes-archimedean-gambles`.

Model witness ids: `conjectured-total-independent-sum-extension`.

Original record notes:

The construction, conclosure operation, and total-extension strategy are attributed to Zachary Goodsell and his unpublished manuscript. GPT-6 supplied the cone-language exposition and additional proof details in the write-up; these are not attributed verbatim to the manuscript, and no independently originated AI construction is claimed. Upgraded from conjectured after those details were recorded; the stable ID is retained. Neither reflection requirement is assumed or listed as violated. The raw area cone’s cancellation remains unasserted: conclosure can enlarge it. This is nonconstructive existence using Zorn’s lemma. No independent checker or Lean verification is claimed.

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026 (unpublished), §§3–4, pp. 7–14: CDF-area construction, conclosure, and total-extension strategy. Supplied manuscript marked “do not cite” and erroneous in its symmetry-extension claim.
- **GPT-6 proof details 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/conjectured-total-independent-sum-extension.md: cone-language exposition of Goodsell’s conclosure and additional details establishing strictness preservation and the total-extension step; not an independently originated construction.
- **Goodsell clarification 9 Sep** — Zachary Goodsell, project conversation, 9 September 2026: extension without reflection and clarification that the saturation construction is conclosure.

Record: `topics/unbounded-utility/models/conjectured-total-independent-sum-extension.yaml`.

### 1.3 Incompatible with background (0)

None.

## 2. Lynchpin conjectures

Answering a lynchpin conjecture settles many other open questions. A question is S ⇒ c for S at most two principle classes (True, with none) and c a class or False, asked only where no smaller premise set already proves or excludes c; S ⇒ False asks whether S is consistent. A question is settled alike by a proof, by an exclusion (S ∧ c ⇒ False) or by a recorded model that holds S and fails c. Each row scores an open question by the number of *other* open questions that stop being open once the answer joins the proved records. Both answers are scored, because proving a strong conjecture settles everything below it while refuting a weak one settles everything above it; a question with two high scores is worth answering either way. A refutation is scored by its least informative countermodel, so an actual model settles at least as much. A model check (model: principle) scores deciding an unknown verdict inside a recorded model, which settles questions exactly as a proof does. Under a background, only models of that background count and the class of its theorems is named after it (True, with no preset). Recompute with `python3 scripts/pmap.py lynchpins unbounded-utility`.

### Under no extra assumptions

39 classes and 15 fitting models; 15308 open questions. 41% of questions with up to two premises settled (10882 of 26190).

| Question | if yes | if no |
|---|---:|---:|
| Antitonic Sum Invariance ⇒ False (⊥) | 3373 | 0 |
| Comonotonic Sum Invariance ∧ Independent Sum Cancellation ⇒ False (⊥) | 2455 | 0 |
| Comonotonic Sum Invariance ∧ Independent Sum Invariance ⇒ False (⊥) | 2401 | 1 |
| Antitonic Sum Invariance ∧ Existential Copula Sum Invariance ⇒ False (⊥) | 2325 | 1 |
| Antitonic Sum Invariance ∧ Independent Sum Cancellation ⇒ False (⊥) | 2226 | 1 |

### Under DU

27 classes and 13 fitting models; 2279 open questions. 35% of questions with up to two premises settled (1245 of 3524).

| Question | if yes | if no |
|---|---:|---:|
| Alternating St Petersburg = −1/2 ∧ Existential Copula Sum Invariance ⇒ False (⊥) | 483 | 0 |
| Alternating St Petersburg = −1/2 ⇒ Folded Expectation | 443 | 0 |
| Existential Copula Sum Invariance ∧ Pasadena = ln 2 ⇒ False (⊥) | 428 | 0 |
| Existential Copula Sum Invariance ⇒ Uniqueness of Negative Self-Similarity | 392 | 0 |
| Arroyo = ln 2 ∧ Existential Copula Sum Invariance ⇒ False (⊥) | 389 | 0 |

### Under DTU

23 classes and 9 fitting models; 1228 open questions. 25% of questions with up to two premises settled (421 of 1649).

| Question | if yes | if no |
|---|---:|---:|
| True (⊤) ⇒ Comonotonic Sum Invariance | 426 | 0 |
| Alternating St Petersburg = −1/2 ∧ Existential Copula Sum Invariance ⇒ False (⊥) | 353 | 0 |
| Scale Invariance ⇒ Folded Expectation | 339 | 0 |
| Existential Copula Sum Invariance ∧ Positive Affine Invariance ⇒ False (⊥) | 334 | 1 |
| Existential Copula Sum Invariance ∧ Scale Invariance ⇒ False (⊥) | 334 | 1 |

## 3. Open questions under each recorded package

The most useful place to work: these are open *given* assumptions the sources already make.

### DTU

Assuming `rich-outcomes`, `archimedean-outcomes`, `totality`, `stochastic-equivalence`, `stochastic-dominance`, `independence`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Shift Invariance (`shift-invariance`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance + L¹ Continuity (random variables)

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`, `l1-continuity`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance + Relative Expectation

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`, `relative-expectation`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Independent Sum Cancellation

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `independent-sum-cancellation`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Expected Utility (`expected-utility`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Relative Expectation (`relative-expectation`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + L¹ Continuity (random variables)

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `l1-continuity`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Pasadena = ln 2 (`pasadena-value`)
- Relative Expectation (`relative-expectation`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Rich Outcomes + Archimedean Outcomes + Stochastic Equivalence + Stochastic Dominance + Mixture Independence + L¹ Continuity (random variables)

Assuming `rich-outcomes`, `archimedean-outcomes`, `stochastic-equivalence`, `stochastic-dominance`, `independence`, `l1-continuity`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

### Rich Outcomes + Archimedean Outcomes + Stochastic Equivalence + Stochastic Dominance + Mixture Independence + Continuity under Vanishing Shifts

Assuming `rich-outcomes`, `archimedean-outcomes`, `stochastic-equivalence`, `stochastic-dominance`, `independence`, `vanishing-shift-continuity`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

### Rich Outcomes + Expected Utility + Stochastic Equivalence + Mixture Independence + Stochastic Dominance + L¹ Continuity (random variables)

Assuming `rich-outcomes`, `expected-utility`, `stochastic-equivalence`, `independence`, `stochastic-dominance`, `l1-continuity`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Mixture Independence + Reflection Anti-Invariance

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `independence`, `reflection-anti-invariance`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Pasadena = ln 2 (`pasadena-value`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)

### Rich Outcomes + Stochastic Equivalence + Simple Expected Utility + Mixture Independence + Symmetric Gambles Are Neutral + Shift Invariance

Assuming `rich-outcomes`, `stochastic-equivalence`, `simple-eu`, `independence`, `symmetric-neutrality`, `shift-invariance`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Totality (`totality`)

### Rich Outcomes + Archimedean Outcomes + Totality + Stochastic Dominance + Sure-Thing

Assuming `rich-outcomes`, `archimedean-outcomes`, `totality`, `stochastic-dominance`, `sure-thing`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Shift Invariance (`shift-invariance`)

### Rich Outcomes + Stochastic Equivalence + Mixture Independence + Relative Expectation + Uniqueness of Negative Self-Similarity

Assuming `rich-outcomes`, `stochastic-equivalence`, `independence`, `relative-expectation`, `negative-self-similarity`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Restricted Totality (`restricted-totality`)
- Scale Invariance (`scale-invariance`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Rich Outcomes + Stochastic Equivalence + Simple Expected Utility + Mixture Independence + Transfer of a Shift Across a Mixture

Assuming `rich-outcomes`, `stochastic-equivalence`, `simple-eu`, `independence`, `shift-transfer`, these remain open:

- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Relative Expectation (`relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)

### Rich Outcomes + Totality + Stochastic Equivalence + Mixture Independence + Symmetric Gambles Are Neutral

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `independence`, `symmetric-neutrality`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Pasadena = ln 2 (`pasadena-value`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)

### Rich Outcomes + Totality + Stochastic Dominance + L¹ Continuity (random variables) + Independent Sum Cancellation

Assuming `rich-outcomes`, `totality`, `stochastic-dominance`, `l1-continuity`, `independent-sum-cancellation`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Gambles (`archimedean-gambles`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Countable Sure-Thing (`countable-sure-thing`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)

### Rich Outcomes + Stochastic Equivalence + Relative Expectation + Symmetric Gambles Are Neutral + Shift Invariance

Assuming `rich-outcomes`, `stochastic-equivalence`, `relative-expectation`, `symmetric-neutrality`, `shift-invariance`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)
- Totality (`totality`)

### Rich Outcomes + Archimedean Outcomes + Stochastic Dominance + Relative Expectation

Assuming `rich-outcomes`, `archimedean-outcomes`, `stochastic-dominance`, `relative-expectation`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Mixture Independence (`independence`)
- Shift Invariance (`shift-invariance`)
- Sure-Thing (`sure-thing`)

### Rich Outcomes + Archimedean Outcomes + Stochastic Equivalence + Statewise Dominance

Assuming `rich-outcomes`, `archimedean-outcomes`, `stochastic-equivalence`, `statewise-dominance`, these remain open:

- Mixture Independence (`independence`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Sure-Thing (`sure-thing`)

### Rich Outcomes + Stochastic Equivalence + Simple Expected Utility + Uniqueness of Negative Self-Similarity

Assuming `rich-outcomes`, `stochastic-equivalence`, `simple-eu`, `negative-self-similarity`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Scale Invariance (`scale-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Rich Outcomes + Mixture Independence + Folded Expectation

Assuming `rich-outcomes`, `independence`, `folded-expectation`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Totality (`totality`)

### Totality + Mixture Independence + Negative Affine Anti-Invariance

Assuming `totality`, `independence`, `negative-affine-anti-invariance`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Rich Outcomes + Simple Relative Expectation + L¹ Continuity (random variables)

Assuming `rich-outcomes`, `simple-relative-expectation`, `l1-continuity`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Shift Invariance (`shift-invariance`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

### Rich Outcomes + Positive Affine Invariance + Reflection Anti-Invariance

Assuming `rich-outcomes`, `positive-affine-invariance`, `reflection-anti-invariance`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- Mixture Independence (`independence`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

### Rich Outcomes + Relative Expectation + Continuity under Vanishing Shifts

Assuming `rich-outcomes`, `relative-expectation`, `vanishing-shift-continuity`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Shift Invariance (`shift-invariance`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

### Rich Outcomes + Shift Invariance + Scale Invariance

Assuming `rich-outcomes`, `shift-invariance`, `scale-invariance`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

### Antitonic Sum Invariance + Stochastic Equivalence

Assuming `antitonic-sum-consistency`, `stochastic-equivalence`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Gambles (`archimedean-gambles`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Countable Sure-Thing (`countable-sure-thing`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- Full Sum Invariance (`full-sum-consistency`)
- Mixture Independence (`independence`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Totality (`restricted-totality`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)
- Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Archimedean Outcomes + Folded Expectation

Assuming `archimedean-outcomes`, `folded-expectation`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Mixture Independence (`independence`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Rich Outcomes (`rich-outcomes`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)

### Archimedean Outcomes + Relative Expectation

Assuming `archimedean-outcomes`, `relative-expectation`, these remain open:

- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Mixture Independence (`independence`)
- Rich Outcomes (`rich-outcomes`)
- Shift Invariance (`shift-invariance`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

### Archimedean Outcomes + Stochastic Dominance

Assuming `archimedean-outcomes`, `stochastic-dominance`, these remain open:

- Mixture Independence (`independence`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Sure-Thing (`sure-thing`)

### Comonotonic Sum Invariance + Stochastic Equivalence

Assuming `comonotonic-sum-consistency`, `stochastic-equivalence`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Totality (`restricted-totality`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Rich Outcomes + Folded Expectation

Assuming `rich-outcomes`, `folded-expectation`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Totality (`totality`)

### Mixture Independence + Transfer of a Shift Across a Mixture

Assuming `independence`, `shift-transfer`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

### Stochastic Equivalence + Mixture Independence

Assuming `stochastic-equivalence`, `independence`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)

### Independent Sum Preservation + Independent Sum Cancellation

Assuming `independent-sum-preservation`, `independent-sum-cancellation`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Independent Sum Invariance + Stochastic Equivalence

Assuming `independent-sum-consistency`, `stochastic-equivalence`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Totality (`restricted-totality`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Totality + Independent Sum Preservation

Assuming `totality`, `independent-sum-preservation`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Rich Outcomes + Negative Affine Anti-Invariance

Assuming `rich-outcomes`, `negative-affine-anti-invariance`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- Mixture Independence (`independence`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

## 4. Unknown verdicts inside each model

For these principles the model has not been checked either way. Deciding one is a self-contained calculation in a construction that is already written down.

### Signed-measure cone: affine-symmetric extension — `affine-symmetric-extension`

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

### Clipped expectation: continuous ultrafilter dominance [−t, 2t] — `asymmetric-continuous-ultrafilter`

- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Scale Invariance (`scale-invariance`)

### CDF-area dominance — `cdf-area-preorder`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)

### CDF-area conclosure — `cdf-conclosure-preorder`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### CDF-area: total comonotonic extension — `conjectured-total-comonotonic-area-extension`

Fully determined; nothing unknown.

### CDF-area conclosure: total extension — `conjectured-total-independent-sum-extension`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Scale Invariance (`scale-invariance`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Clipped expectation: eventual dominance — `eventual-clipped-expectation`

- Arroyo = ln 2 (`arroyo-value`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Pasadena = ln 2 (`pasadena-value`)

### Stochastic dominance: finite-shift total extension — `finite-shift-total-extension`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Scale Invariance (`scale-invariance`)

### Stochastic dominance: finite-support compensation — `finite-support-compensated-dominance`

- Independent Sum Cancellation (`independent-sum-cancellation`)

### Two-sample minimum: zero extension — `finite-two-sample-minimum`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Antitonic Sum Invariance (`antitonic-sum-consistency`)
- Archimedean Gambles (`archimedean-gambles`)
- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Countable Sure-Thing (`countable-sure-thing`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Full Sum Invariance (`full-sum-consistency`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Scale Invariance (`scale-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Clipped expectation: continuous ultrafilter dominance [−4ⁿ, 4ⁿ] — `geometric-continuous-ultrafilter`

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Pasadena = ln 2 (`pasadena-value`)

### Folded-tail cone: lexicographic extension — `lexicographic-folded-extension`

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Pasadena = ln 2 (`pasadena-value`)

### Lexicographic expectation: nonatomic mass — `lexicographic-nonatomic-mass`

Fully determined; nothing unknown.

### Clipped expectation: continuous ultrafilter dominance [−4ⁿ, 4²ⁿ] — `polynomial-asymmetric-continuous-ultrafilter`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Scale Invariance (`scale-invariance`)

### Clipped expectation: continuous ultrafilter dominance — `total-continuous-ultrafilter`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Folded Expectation (`folded-expectation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Relative Expectation (`relative-expectation`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Clipped expectation: exact ultrafilter dominance — `total-exact-ultrafilter`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)

## 5. Open single-premise pairs (604)

*A ⇒ B ?* means neither implication nor incompatibility nor a countermodel is currently recorded. Grouped by antecedent. Most are open only because the obvious model has not been added.

- **Alternating St Petersburg = −1/2** (`alternating-st-petersburg-value`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Continuity under Vanishing Shifts, Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Antitonic Sum Invariance** (`antitonic-sum-consistency`) ⇒ Alternating St Petersburg = −1/2, Archimedean Gambles, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Continuity under Vanishing Shifts, Countable Sure-Thing, Existential Copula Sum Invariance, Expected Utility, Folded Expectation, Full Sum Invariance, Independent Sum Cancellation, Independent Sum Invariance, Independent Sum Preservation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity, Universal Copula Sum Invariance
- **Archimedean Gambles** (`archimedean-gambles`) ⇒ Alternating St Petersburg = −1/2, Antitonic Sum Invariance, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Continuity under Vanishing Shifts, Countable Sure-Thing, Existential Copula Sum Invariance, Expected Utility, Folded Expectation, Full Sum Invariance, Independent Sum Cancellation, Independent Sum Invariance, Independent Sum Preservation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity, Universal Copula Sum Invariance
- **Archimedean Outcomes** (`archimedean-outcomes`) ⇒ Restricted Stochastic Equivalence, Restricted Totality, Stochastic Equivalence, Sure-Thing
- **Arroyo = ln 2** (`arroyo-value`) ⇒ Archimedean Outcomes, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture
- **CDF-Area Extension** (`cdf-area-extension`) ⇒ Comonotonic Sum Invariance, Existential Copula Sum Invariance, Mixture Independence, Rich Outcomes, Shift Invariance, Sure-Thing
- **Comonotonic Sum Invariance** (`comonotonic-sum-consistency`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Continuity under Vanishing Shifts, Existential Copula Sum Invariance, Expected Utility, Independent Sum Cancellation, Independent Sum Invariance, Independent Sum Preservation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Continuity under Vanishing Shifts** (`vanishing-shift-continuity`) ⇒ Archimedean Outcomes, Mixture Independence, Restricted Stochastic Equivalence, Restricted Totality, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Countable Sure-Thing** (`countable-sure-thing`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, Continuity under Vanishing Shifts, Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Existential Copula Sum Invariance** (`existential-copula-sum-consistency`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Continuity under Vanishing Shifts, Expected Utility, Independent Sum Cancellation, Independent Sum Invariance, Independent Sum Preservation, L¹ Continuity (random variables), Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Expected Utility** (`expected-utility`) ⇒ CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Mixture Independence, Relative Expectation, Rich Outcomes, Shift Invariance, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Folded Expectation** (`folded-expectation`) ⇒ Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture
- **Full Sum Invariance** (`full-sum-consistency`) ⇒ Alternating St Petersburg = −1/2, Archimedean Gambles, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Continuity under Vanishing Shifts, Countable Sure-Thing, Expected Utility, Folded Expectation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Independent Sum Cancellation** (`independent-sum-cancellation`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Continuity under Vanishing Shifts, Existential Copula Sum Invariance, Expected Utility, Independent Sum Invariance, Independent Sum Preservation, L¹ Continuity (random variables), Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Independent Sum Invariance** (`independent-sum-consistency`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Continuity under Vanishing Shifts, Existential Copula Sum Invariance, Expected Utility, L¹ Continuity (random variables), Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Independent Sum Preservation** (`independent-sum-preservation`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Continuity under Vanishing Shifts, Existential Copula Sum Invariance, Expected Utility, Independent Sum Cancellation, Independent Sum Invariance, L¹ Continuity (random variables), Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **L¹ Continuity (random variables)** (`l1-continuity`) ⇒ Archimedean Outcomes, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, Mixture Independence, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Mixture Independence** (`independence`) ⇒ Archimedean Outcomes, Restricted Stochastic Equivalence, Restricted Totality, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Negative Affine Anti-Invariance** (`negative-affine-anti-invariance`) ⇒ Archimedean Outcomes, Mixture Independence, Positive Affine Invariance, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Pasadena = ln 2** (`pasadena-value`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, Continuity under Vanishing Shifts, Mixture Independence, Positive Affine Invariance, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Positive Affine Invariance** (`positive-affine-invariance`) ⇒ Archimedean Outcomes, Mixture Independence, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Reflection Anti-Invariance** (`reflection-anti-invariance`) ⇒ Archimedean Outcomes, Mixture Independence, Restricted Stochastic Equivalence, Restricted Totality, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Relative Expectation** (`relative-expectation`) ⇒ Archimedean Outcomes, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, Mixture Independence, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Restricted Stochastic Equivalence** (`restricted-stochastic-equivalence`) ⇒ Archimedean Outcomes, Restricted Totality, Stochastic Equivalence, Sure-Thing
- **Restricted Totality** (`restricted-totality`) ⇒ Archimedean Outcomes, Restricted Stochastic Equivalence, Stochastic Equivalence, Sure-Thing
- **Rich Outcomes** (`rich-outcomes`) ⇒ Archimedean Outcomes, Restricted Stochastic Equivalence, Restricted Totality, Stochastic Equivalence, Sure-Thing
- **Scale Invariance** (`scale-invariance`) ⇒ Archimedean Outcomes, Mixture Independence, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Shift Invariance** (`shift-invariance`) ⇒ Archimedean Outcomes, Mixture Independence, Restricted Stochastic Equivalence, Restricted Totality, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Simple Expected Utility** (`simple-eu`) ⇒ Mixture Independence, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Simple Relative Expectation** (`simple-relative-expectation`) ⇒ Archimedean Outcomes, Mixture Independence, Restricted Stochastic Equivalence, Restricted Totality, Shift Invariance, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Statewise Dominance** (`statewise-dominance`) ⇒ Archimedean Outcomes, Mixture Independence, Restricted Stochastic Equivalence, Restricted Totality, Simple Expected Utility, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Stochastic Dominance** (`stochastic-dominance`) ⇒ Archimedean Outcomes, Mixture Independence, Restricted Totality, Simple Expected Utility, Statewise Dominance, Sure-Thing
- **Stochastic Equivalence** (`stochastic-equivalence`) ⇒ Archimedean Outcomes, Restricted Totality, Sure-Thing
- **Sure-Thing** (`sure-thing`) ⇒ Archimedean Outcomes, Mixture Independence, Restricted Stochastic Equivalence, Restricted Totality, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence
- **Symmetric Gambles Are Neutral** (`symmetric-neutrality`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Totality** (`totality`) ⇒ Archimedean Outcomes, Restricted Stochastic Equivalence, Shift Invariance, Stochastic Equivalence, Sure-Thing
- **Transfer of a Shift Across a Mixture** (`shift-transfer`) ⇒ Archimedean Outcomes, Mixture Independence, Restricted Stochastic Equivalence, Restricted Totality, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Uniqueness of Negative Self-Similarity** (`negative-self-similarity`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, Continuity under Vanishing Shifts, Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture
- **Universal Copula Sum Invariance** (`universal-copula-sum-consistency`) ⇒ Alternating St Petersburg = −1/2, Archimedean Gambles, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Continuity under Vanishing Shifts, Countable Sure-Thing, Expected Utility, Folded Expectation, Full Sum Invariance, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity

## 6. Deliberately deferred

`topics/unbounded-utility/extraction.md` has a section listing claims that were **not** recorded because they need a further reading of the sources. Those are marked deferred rather than open: the answer is likely in the literature and needs transcribing, not discovering. Read that section before starting work.

## 7. How to record an answer

- Proved an implication? Add `topics/unbounded-utility/results/<id>.yaml` with the full premise list and the proof.
- Refuted one? Add `topics/unbounded-utility/models/<id>.yaml` listing what you verified in `satisfies` and `violates`.
- Settling an existing conjecture? For a proof of the same statement, keep its ID, set `was_conjectured: true`, and change its status to `proved`. If the statement changes substantially, retain the original and add a separate record. Refuted proposals stay `status: conjectured`, with proved refuting evidence recorded separately. Answers under extra exploration assumptions are contextual, not global record statuses.
- Not sure? Add it with `status: conjectured`, an empty proof, and say in `notes` what would settle it.
- Then run `python3 scripts/pmap.py validate` and `status`. Never hand-edit the derived counts.

`README.md` has the exact record shapes and the sourcing rules. Follow them; an unsourced or misattributed record is worse than an absent one.
