# Unbounded Utility — working bundle

A self-contained copy of one logical map: the axioms of a subject, the implications between them, the countermodels that refute the remaining implications, and the proofs for all of it. Unzip anywhere and start working.

Contains 43 principles, 94 proved results, 5 conjectures and 18 models, with the source documents they were extracted from.

## Read in this order

1. **`MAP.md`** — everything, in one file: framework, principle statements, every proof, every model construction, and the derived verdicts. Start here.
2. **`OPEN-QUESTIONS.md`** — what the map does not settle, grouped so each entry is a concrete piece of work.
3. **`topics/unbounded-utility/extraction.md`** — how the records were read out of the sources, which transcription decisions were made, and what was deliberately left out.
4. **`topics/unbounded-utility/sources/`** — the original papers.

`data.json` and `derived.json` hold the same content structured, if you would rather compute over it than read it.

## Layout

```
MAP.md OPEN-QUESTIONS.md      the map as prose
data.json derived.json        records, and every derived verdict
topics/unbounded-utility/
  topic.yaml                  title, source catalog, categories, viewer packages
  background.md               the framework in full
  extraction.md               source inventory, transcription decisions, deferred items
  principles/<id>.yaml        one principle per file
  results/<id>.yaml           premises ⇒ conclusion, with its proof
  models/<id>.yaml            satisfies [...] / violates [...]
  writeups/<id>.md            hand-written write-up, overrides the generated one
  checks/                     executable sanity checks for the models
  sources/                    original papers
scripts/pmap.py schema/ viewer/  the tooling, so validate and build work here
```

## Semantics

Everything is relative to the topic background B (see `MAP.md` §1).

- A **result** is a Horn clause, premises ⇒ principle or False. `cl(S)` is the closure of B ∪ S under all proved results.
- A **model** M records `sat(M)` and `viol(M)` and witnesses that `sat(M) ∪ {¬v : v ∈ viol(M)}` is consistent. Derived: `holds(M) = cl(sat(M))`, and `fails(M) = {c : cl(sat(M) ∪ {c}) meets viol(M) or contains False}`. Everything else is unknown in M.
- **P ⇒ c** iff `c ∈ cl(P)`. **P ⇏ c** iff some model has `P ⊆ holds(M)` and `c ∈ fails(M)`. **P ⇒ ¬c** when adjoining c reaches False. This is an exclusion, not a model witness. Inconsistent packages are reported separately, with no explosion. Otherwise the pair is **open**.
- Mutually derivable principles collapse to one node.
- Conjectures are displayed but never used as evidence.
- Deriving False or an explicitly violated principle from a model is a validation error.

**A missing arrow means nothing was recorded.** The map is curated, not exhaustive.

## Adding to it

```yaml
# topics/unbounded-utility/results/<id>.yaml   —   file name must equal the id
id: my-new-result
premises: [principle-a, principle-b]     # every assumption actually used
conclusion: principle-c                 # use false for incompatible premises
status: conjectured                       # promote only after supplying a proof
certificate:
  source_id: misc                         # a source_catalog id; misc for original work
  lean: none
  produced_by: "who proposed the claim"
  recorded_by: "who transcribed it"       # optional, kept separate
  checked_by: []                          # only actual checkers
  date: 'YYYY-MM-DD'
proof: ""
sources:
  - Full reference, with theorem or section and page.
source_names: [Short label]               # one per source, same order
notes: "State what would settle this proposal."
```

```yaml
# topics/unbounded-utility/models/<id>.yaml
id: my-new-model
name: 'Construction family: ordering rule'
satisfies: [principle-a, principle-b]     # only what you actually verified
violates: [principle-c]                   # the engine derives the rest
status: conjectured                      # promote only after checking the model
certificate: {source_id: misc, lean: none, produced_by: "...", checked_by: [], date: 'YYYY-MM-DD'}
description: |
  The construction, and why it has these properties.
sources: [Full reference or an identifiable original proof]
source_names: [Short label]
```

Give models short, systematic names describing their construction or ordering rule: family first, then the rule and any distinguishing variant. Match the write-up title. Keep authorship, conjecture status, and lists of satisfied/violated principles in their own fields. For a conjectured extension, name the proposed extension without inventing a construction. Keep existing record IDs unchanged.

For A ∧ B ⇒ ¬C, record `premises: [a, b, c]` and `conclusion: false`. False is a reserved conclusion, not a principle. The same constraint lets A and C rule out B.

Counterexamples to implications are recorded as models. A result concluding false instead proves incompatibility; it does not establish that any premise package has a model.

## Sourcing rules

These are what make the map worth anything. Follow them exactly.

- Every result and model needs a nonempty `sources`. Give the paper with theorem/section and page, or an identifiable original proof for new work.
- `certificate.source_id` names the **direct** source. Declared sources here:
  - `decision-theory-unbound` — Decision Theory Unbound (published-paper)
  - `symmetries-of-value` — Symmetries of Value (published-paper)
  - `seidenfeld-schervish-kadane-2009` — Preference for Equivalent RVs (published-paper)
  - `russell-isaacs-2021` — Infinite Prospects (published-paper)
  - `unpublished-background-risk` — Unbounded Utility and Background Risk (unpublished) (misc)
  - `misc` — Misc. (misc)
- Use `misc` for original proofs, one-off prompts and user suggestions. Citing a paper's definitions does **not** make that paper the source of your new proof.
- `produced_by` credits the mathematics; `recorded_by` credits transcription only.
- Leave `checked_by: []` unless a named person actually checked it. A human-authored source does not mean a human checked this database's translation of it.
- Never invent an author, a date, a page or a submission label. If you are unsure of a reference, say so in `notes` rather than guessing.
- If you are unsure of the mathematics, record `status: conjectured` with an empty proof and write in `notes` what would settle it. That is a useful contribution; a wrong `proved` is not.
- Do not change the mathematical content of an existing published or human-authored proof. Add a note, or a new record, instead.
- File name equals `id`, kebab-case. Never rename an id that other files reference.
- When an existing record gains content after its certificate date (a newly verified property of a model, an added proof, a corrected statement), append an entry to its `changes` list: `{date, by, summary}` plus, for models, the newly verified `satisfies`/`violates` ids. The Changes tab lists each entry under its own date; leave `certificate.date` as the record's original date.
- Keep the framework fixed. A principle needing a different setting belongs to a different topic.

## Lean

If `topics/unbounded-utility/lean/` is present, the topic has a formalisation. The YAML is the
source of truth for statements: each principle names its Lean definition in `lean_def`,
and every result and model statement is generated from its premises and conclusion into
`Statements.lean`. To prove a record, inhabit its generated `Prop`. Never edit the
generated file, and never hand-set `lean: verified` -- `pmap lean-check` builds the
library, confirms the proof inhabits the generated statement, and rejects anything
still depending on `sorryAx`. `lean: stated` means the statement elaborates and the
proof is missing. See that folder's README for the modelling choices.

## Commands

```sh
pip install -r requirements.txt
python3 scripts/pmap.py validate            # schema, references, consistency. Must pass.
python3 scripts/pmap.py status              # counts, open pairs, redundancies
python3 scripts/pmap.py lynchpins           # open questions ranked by what each answer settles
python3 topics/unbounded-utility/checks/asymmetric_continuous_ultrafilter.py   # topic checks
python3 topics/unbounded-utility/checks/background_risk.py   # topic checks
python3 topics/unbounded-utility/checks/calculation_factorizations.py   # topic checks
python3 topics/unbounded-utility/checks/cancellation_preservation.py   # topic checks
python3 topics/unbounded-utility/checks/comonotonic_witnesses.py   # topic checks
python3 topics/unbounded-utility/checks/countable_sure_thing.py   # topic checks
python3 topics/unbounded-utility/checks/countermodels.py   # topic checks
python3 topics/unbounded-utility/checks/exact_shift_witness.py   # topic checks
python3 topics/unbounded-utility/checks/finite_shift_extension.py   # topic checks
python3 topics/unbounded-utility/checks/finite_two_sample_minimum.py   # topic checks
python3 topics/unbounded-utility/checks/geometric_clipping.py   # topic checks
python3 topics/unbounded-utility/checks/levy_obstruction.py   # topic checks
python3 topics/unbounded-utility/checks/lexicographic_folded_extension.py   # topic checks
python3 topics/unbounded-utility/checks/rational_scale_witnesses.py   # topic checks
python3 topics/unbounded-utility/checks/shift_continuity.py   # topic checks
python3 scripts/pmap.py build               # regenerate build/<topic>/index.html, the map viewer
python3 scripts/pmap.py selftest            # the derivation engine's own tests
python3 scripts/check_falsity.py            # Python/browser semantics and False; needs Node
python3 scripts/pmap.py lean                # regenerate the Lean statements
python3 scripts/pmap.py lean-check          # build the Lean library and audit lean: claims
```

A `CONTRADICTION` from `validate` means the data is inconsistent and must be fixed before anything else. Rerun `validate` after every batch of edits.

## Sending work back

The whole of `topics/unbounded-utility/` is portable: copy it back over the same folder in the main repository, or send the individual new YAML files. Nothing outside that folder needs to change.

Email me (Zach) at [zacharyw.goodsell@gmail.com](mailto:zacharyw.goodsell@gmail.com?subject=%5BLogical%20Maps%5D%20Unbounded%20Utility) with further suggestions.

To contribute to Unbounded Utility, please include **[Logical Maps] Unbounded Utility** in the subject line of your email. You can suggest a new principle, establish a new result, or define a new model, along with supporting documents if necessary (e.g. a PDF or Markdown file). I will be sure to record your role in the contribution if I add it to this page. Thank you!

Worked on an open question without settling it? Feel free to send what you tried and I will put your work into the question’s notes and credit your contribution. This gives it a <span class="iridescent bronze">bronze</span> star in the Conjectures tab. Please also say whether you think the question is important or difficult enough to deserve a <span class="iridescent silver">silver</span> or <span class="iridescent gold">gold</span> star.

To contribute to the Logical Maps project in general, please include **[Logical Maps]** in the subject line.

## Tooling licence

The reusable scripts, schemas, viewer, and starter templates are supplied under [the MIT licence](starter/LICENSE). This does not grant rights to this topic's papers or other separately supplied content.
