# Contribute

Email me (Zach) at [zacharyw.goodsell@gmail.com](mailto:zacharyw.goodsell@gmail.com?subject=%5BLogical%20Maps%5D%20Unbounded%20Utility) with further suggestions.

To contribute to Unbounded Utility, please include **[Logical Maps] Unbounded Utility** in the subject line of your email. You can suggest a new principle, establish a new result, or define a new model, along with supporting documents if necessary (e.g. a PDF or Markdown file). I will be sure to record your role in the contribution if I add it to this page. Thank you!

Worked on an open question without settling it? Feel free to send what you tried and I will put your work into the question’s notes. This gives it a bronze star in the Conjectures tab. Please also say whether you think the question is important or difficult enough to deserve a silver or gold star.

To contribute to the Logical Maps project in general, please include **[Logical Maps]** in the subject line.
