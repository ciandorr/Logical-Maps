# Source extraction: updated 24 September 2026

## Cancellation and Countable Sure-Thing questions (13 September)

The original `conjectured-dtu-cancellation-implies-preservation` statement
is now proved, with its conjecture history retained. Goodsell supplied
the strict-comparison argument; GPT-6 (Codex) supplied the geometric-noise
and finite-mixture argument preserving ties. No continuity premise is
needed. The separated sum principles retain their manuscript attribution;
the connecting proof is recorded under Misc.

The two Countable Sure-Thing proposals are refuted on the standing full
measurable domain by `lexicographic-nonatomic-mass`. On outcomes [0,1],
it orders by mean and then nonatomic mass. Countable additivity proves
Countable Sure-Thing, while a uniform gamble supplies failures of both
Expected Utility and Archimedean Gambles. The two questions retain their
original statements, authorship and conjectured statuses; their verdicts
are computed from the separate proved model. Under DU or DTU their
premises instead conflict with the background.

The Russell–Isaacs source check distinguishes their countably supported
lotteries from the larger domain here. The new coordinate vanishes on
every countably supported law. The countermodel and source comparison
are credited to GPT-6 (Codex), following Goodsell's proof request.
Written proofs and exact diagnostic checks are supplied; no independent
checker or new Lean-verified proof is claimed.

The subsequent audit of `lexicographic-nonatomic-mass` classifies all 39
principles: 23 satisfied and 16 violated. Affine invariance, shift transfer,
finite coupled differences and uniqueness of negative self-similarity
follow from its two coordinates. One fixed choice of scaled uniforms and
a constant refutes sum invariance for every copula. The write-up identifies
the bounded-chart cases with trivial or empty scope, including the current
all-positive-shifts continuity antecedent. No principle definition or
existing theorem premise was changed. GPT-6 (Codex) supplied these further
proofs in response to Goodsell's request on 13 September 2026.

## Addition: unpublished background-risk manuscript (9 September)

The new supplied source is Goodsell, *Unbounded Utility and Background Risk*,
5 June 2026. The draft itself is not included in the public downloads.
It is **unpublished, marked “do not cite”, and erroneous**. Its own provenance
name is **Unbounded Utility and Background Risk (unpublished)**.

The [detailed inventory and audit](writeups/symmetric-dtu-refutes-independent-sum-candidate.md)
records all extracted concepts and separates surviving arguments from the
withdrawn symmetry/total-extension claims. New entries add Full, Independent,
Comonotonic, and Antitonic Sum Invariance, separate independent-sum forward
preservation and cancellation, and CDF-Area Extension. The sum
incompatibilities are expressed as implications to False. Existing reflection and mixture nodes receive terminology
aliases rather than duplicates.

The [CDF-area dominance](writeups/cdf-area-preorder.md) is an explicit proved
incomplete model; the [CDF-area conclosure: total extension](writeups/conjectured-total-independent-sum-extension.md)
now has a proved existence construction, including Independent Sum
Consistency. Goodsell’s conclosure and total-extension construction
preserves the original strict comparisons and supplies totality. The model’s
direct source is his unpublished manuscript; GPT-6 is credited for the
cone-language exposition and additional proof details, not for originating
the construction. Neither reflection requirement is assumed or recorded as
violated. The user's recalled stable-law obstruction remains a conjectured
implication pending an exact witness.

After the falsity migration, this addition contributes **seven principles,
16 relations (15 proved, one conjectured), and two proved models**.
The full topic now has **36 principles, 55 relations, and six models**.
Five former failure nodes were removed: their claims are constraints
concluding False, with the existing result IDs, sources, and proof text
preserved. Their old descriptions are archived in `writeups/falsity-migration.md`. New concrete checks
are in `checks/background_risk.py`. No Lean formalization was added.

A subsequent premise audit records **Rich Outcomes + Simple EU + Stochastic
Dominance + Archimedean Gambles ⇒ False** using the same Goodsell
St Petersburg argument. This strengthens the available connection beyond
the original full-DTU package; its proof and attribution are in
`results/rich-simple-dominance-refutes-archimedean-gambles.yaml`.

The counts and descriptions below document the original two-paper extraction
of 8 September; they are not current totals.

## Original sources

| Key | Supplied file | Published reference |
| --- | --- | --- |
| U | `sources/Nous - 2023 - Goodsell - Decision theory unbound (1).pdf` | Goodsell, *Decision theory unbound*, Noûs 58 (2024), 669–695, DOI 10.1111/nous.12473; online 2023 |
| S | `sources/Goodsell - 2026 - Symmetries of value.pdf` | Goodsell, *Symmetries of value*, Noûs 60 (2026), 16–37, DOI 10.1111/nous.12549 |

Page references in the YAML are **printed journal pages**. For U, PDF page 1
is printed p. 669; for S, PDF page 1 is printed p. 16. Local PDFs were read
directly; no other papers were used as substitute evidence.

## Main extracted relations

All rows are relative to the framework in `background.md`; DTU and Sym are
expanded there and in each YAML record.

| Relation | Source |
| --- | --- |
| Simple EU ⇒ Archimedean Outcomes, Restricted Totality, Restricted Stochastic Equivalence | S p. 22 n. 3; U §§2.3, 3.2 |
| Stochastic Dominance ⇒ Stochastic Equivalence; with Archimedean Outcomes ⇒ Statewise Dominance | U pp. 678–679 |
| Rich + Archimedean Outcomes + Stochastic Equivalence + Statewise Dominance ⇒ Stochastic Dominance | U p. 678 n. 19; real quantile translation |
| Stochastic Equivalence + Mixture Independence ⇒ Sure-Thing | U p. 679 and p. 682 n. 28 |
| Original DTU axiom package ⇒ Simple EU and Mixture Independence | U pp. 679–681 |
| Rich Outcomes + Simple EU + Sure-Thing ⇒ failure of Countable Sure-Thing | U §2.3, pp. 675–676 |
| DTU ⇒ failure of Archimedean Gambles | S p. 22 |
| Under Rich Outcomes: shift + scale ⇔ positive affine invariance | U §4.2; S §5 |
| Under Rich Outcomes: negative affine anti-invariance ⇔ positive affine invariance + reflection anti-invariance | S p. 24 |
| DTU + L¹ Continuity ⇒ Expected Utility | S p. 23 |
| DTU + Sym ⇒ shift transfer and Simple Relative Expectation | S Theorems 3–4 |
| Under DTU + Sym: Relative Expectation ⇔ L¹ Continuity | S Corollary 5 |
| DTU + Sym + L¹ Continuity ⇒ Folded Expectation | S Theorem 6 |
| DTU + Sym ⇒ alternating St Petersburg ~ −1/2 and uniqueness of negative self-similarity | S Theorems 9–10 |
| DTU + Sym + L¹ Continuity ⇒ Arroyo ~ ln 2 and Pasadena ~ ln 2 | S Theorems 8, 11 |
| DTU + Sym + L¹ Continuity is consistent | S Theorem 2, with construction in §5 |
| DTU does not imply Expected Utility, and is consistent with it | U Theorems 1–3, Appendix B |
| DTU + EU + shift + reflection does not imply scale invariance | U Theorems 7, 8, 10 |

These are implications with **joint premises**, not separate arrows from each
premise. Straightforward restrictions (for example EU ⇒ Simple EU) and the
reflection/symmetric-neutrality observation are also recorded.

## Models

1. **Clipped expectation: eventual dominance** (U Theorem 2): incomplete, satisfies
   finite EU and dominance; violates EU. Its lack of Totality has an explicit
   alternating-St-Petersburg witness. The checks also exhibit failure of L¹
   Continuity.
2. **Clipped expectation: exact ultrafilter dominance** (U Theorem 1): total, satisfies DTU, violates
   EU. Source Theorem 10 supplies failure of scale invariance.
3. **Clipped expectation: continuous ultrafilter dominance** (U Theorem 3): satisfies DTU and EU,
   shift and reflection. Source Theorem 10 supplies failure of scale invariance.
4. **Signed-measure cone: affine-symmetric extension** (S Theorem 2): a source-attributed
   nonconstructive existence model for DTU + Sym + L¹ Continuity. Its
   Countable Sure-Thing and Archimedean Gambles failures follow from the same
   St Petersburg arguments as for other DTU models.

Each satisfies/violates entry is either explained in its write-up, inherited
from a recorded implication, or explicitly attributed to a source theorem.
Source-attributed is weaker evidence than an independent proof audit. The direct
source is identified by `certificate.source_id`; `produced_by`, `recorded_by`,
and the empty checker list describe authorship and the separate transcription.

The later DU, shift, and continuity investigation
records the precise canonical role of the standalone
[CDF-area dominance](writeups/cdf-area-preorder.md) model and adds
[Stochastic dominance: finite-support compensation](writeups/finite-support-compensated-dominance.md).
The latter satisfies DU and Shift Invariance but refutes Shift Transfer;
continuity under vanishing shifts suffices to force CDF-area comparisons.
The [finite-shift total extension](writeups/finite-shift-total-extension.md)
added on 13 September 2026 supplies a model of DTU and Shift Invariance
with an explicit strict violation of Shift Transfer. Goodsell proposed
the extension; GPT-6 supplied the separating construction and proof details.

## Provenance and display categories

Direct source filters distinguish **Decision Theory Unbound** (11 records),
**Symmetries of Value** (19 records), and **Misc.** (12 records: ten connecting
proofs and two user-suggested conjectures). Every arrow and model retains its
author, date, and precise source references.
The ten AI arrows are restrictions/compositions added to connect definitions:
`totality-restricts`, `stochastic-equivalence-restricts`,
`expected-utility-implies-simple`, `archimedean-gambles-restricts`,
`positive-affine-implies-shift`, `positive-affine-implies-scale`,
`shift-scale-imply-positive-affine`, `relative-implies-simple-relative`,
`relative-implies-eu`, and `folded-implies-eu`. Their sources explicitly
identify the AI proof as well as the paper definitions it uses.

The graph filter groups all 31 principles into Basic decision theory (15),
Invariance principles (7), Extensions of EUT (5), and Prospect evaluations (4).
Each group has independent select-all/unselect-all controls. Category and
checkbox changes only affect display, not the underlying implication rules.

## Transcription decisions and issues needing care

- S p. 24 prints a same-direction sign in the displayed **Reflection
  Anti-Invariance** definition. Read it as X≽Y iff −X≼−Y. This is forced by
  the negative-affine definition directly above, the introduction, and the
  subsequent proofs. It was checked visually in the PDF.
- The intended reflection axiom uses **one fixed utility origin**, as the
  explanatory prose on p. 24 says. Requiring reflection around every possible
  origin would also imply shifts. The literal phrase "for any utility
  representation" in that display should not silently strengthen this node.
- U p. 673 n. 9 prints an impossible interval in the middle branch of the
  utility definition. The normalized branch is 0≤r≤1, as required for the
  described probabilities. The negative and greater-than-one branches are
  kept separate.
- U pp. 683–684 defines **clipping**: mass beyond ±t moves to the endpoints.
  Its shorthand integral with bounds ±t must not be implemented as deleting
  the tails. We use E[max(−t,min(X,t))]. The prose and figure were checked
  visually. The cone discussion in S §5 inherits a related notational issue.
- S p. 28's Pasadena prose omits `/n`; Table 2 and Theorem 11 include it.
  This extraction uses −(−2)^n/n, probability 2^(−n).
- S Theorem 9 repeats one strict-comparison sign in the concluding sentence;
  the second case is the opposite strict comparison.
- S Theorem 10's expanded formula appears to print `−a^n` where the
  geometric recursion requires `(−a)^n`. The extracted principle records its
  clear **uniqueness in value** conclusion. No questionable expansion is used
  as a formula in the map.
- S p. 27's informal comparison with a reflection needs attention to a
  factor of two if it is used numerically. We do not import that sentence as
  a separate theorem or algorithm.
- U Theorem 10's displayed scale identity should be interpreted using
  E[c_t(aX)] = a E[c_(t/a)(X)]. The printed oscillating-function witness also
  has endpoint and normalization issues. Scale non-implication is recorded
  as the **source theorem's claim**, not as a numerically reconstructed proof.

## Deferred rather than silently asserted

- S Theorem 1 states stronger non-implications even after adding L¹, Relative
  Expectation, Weak Expectation, and Principal Value principles. The present
  models record the weaker, clearly identified U witnesses; they are **not**
  given these extra satisfies flags without a further proof audit.
- Weak Expectation and Principal Value theories are discussed and distinguished
  in S §4, but their full source definitions would need another careful pass.
  Their relative strength is not guessed from the words "principal value".
- The conjecture at the end of S §4 that DTU + Sym + L¹ entails either of those
  theories remains a conjecture. Pasadena's evaluation does not prove it.
- U's Coherent Extensibility concerns a class of alternative orderings and
  extension relations, beyond this topic's single primitive preorder. Its
  role in the consistency discussion is noted but it is not forced into an
  axiom about an individual random variable.
- No Rich Outcomes ⇒ Archimedean Outcomes implication has been inferred from
  the papers' convenient identification of outcomes with ℝ.
- No blanket EU ⇒ affine symmetry, EU ⇒ full Stochastic Equivalence, or
  Countable Sure-Thing equivalence is asserted. EU only governs integrable
  variables; full symmetry and law invariance cover more variables.
- The original failure nodes have now been migrated to implications to
  False. Deriving False triggers a red graph warning and suppresses arrows.
  The Horn rules do not use explosion; model violations can also follow
  from these incompatibility constraints.

## Reproduce

### Candidate additions from the user

Two further **human-proposed conjectures** were recorded on 8 September 2026:

- Countable Sure-Thing + Archimedean Outcomes ⇒ Archimedean Gambles.
- Countable Sure-Thing + Simple EU ⇒ Expected Utility.

These supplement the 36 proved records above. They appear in Conjectures and
as dashed arrows when the graph's Conjectures option is enabled; they do not
participate in proved deductions. Each record identifies the user's proposal
as its source and lists the remaining verification work. The Russell–Isaacs
reference attached to the first is related literature, not a verified
attribution of the exact two-premise claim.

The map is deliberately selective and can grow through later additions.
An unrecorded implication need not be an open problem in the literature.

### Commands

From `logical-maps/`, with its Python requirements installed:

```sh
python3 scripts/pmap.py validate unbounded-utility
python3 topics/unbounded-utility/checks/countermodels.py
python3 scripts/pmap.py build unbounded-utility
```

Open `build/unbounded-utility/index.html`. Source YAML, the framework, and
write-ups remain under `topics/unbounded-utility/`; the original example topic
and shared renderer are unchanged.


### Copula sum invariance additions — 9 September 2026

Zach Goodsell proposed the common-copula generalization in `TODO.md` and requested
universal and existential versions. GPT-6 (Codex) recorded the precise definitions
and supplied the connecting proofs, attributed to Misc. rather than to the
unpublished paper. The general copula terminology follows Benth, Di Nunno and
Schroers, [Definition 2.1 and Theorem 2.3](https://arxiv.org/html/2012.11530v2);
that reference is not the source of the new preference principles.

For a fixed copula C, SC(C) compares actual X,Y before and after adding the same
actual Z whenever both pair laws (X,Z) and (Y,Z) admit C. The universal principle
is ∀C SC(C); the existential principle is ∃C SC(C), with C chosen once for all
triples and marginal laws. Atomic marginals are included, with no uniqueness of
a pair's compatible copula assumed. Numerical operations retain the existing
finite-chart scope.

Recorded connections: Full Sum ⇒ Universal Copula Sum; Universal Copula Sum ⇒
Existential Copula Sum and each of the three existing dependence-restricted sum
principles; Existential Copula Sum ⇒ Shift Invariance. Each existing restricted
sum principle, together with Stochastic Equivalence, also implies Existential
Copula Sum. The latter proofs explicitly transfer comparisons from quantile
realizations. In particular, product copula compatibility is only pairwise
independence from Z, whereas the existing Independent Sum principle requires
independence of Z from the pair (X,Y).

The existing Rich Outcomes + Stochastic Dominance + Antitonic Sum incompatibility
already rules out Universal Copula Sum under those background assumptions; no
duplicate incompatibility record is needed. No model flags or Lean definitions
were added, and the separate background/Lean tasks remain pending.


### Further DU and DTU connections and resistant questions — 9 September 2026

The public result and model records include the new implication proofs,
source-model specializations and an infinitesimal folded-tail countermodel. In particular, under DTU, L¹ Continuity implies
Relative Expectation, which is equivalent to CDF-Area Extension; even Folded
Expectation does not imply L¹ Continuity. Three precise outstanding questions
are recorded as conjectures and do not contribute proved deductions. Each
addition describes reused source material and newly supplied work.


### DU and DTU terminology correction — 9 September 2026

DU does not assume Totality over arbitrary gambles; DTU is DU plus Totality.
The DU/DTU distinction follows *Decision theory unbound*, §3.3, pp. 681–682.
The preset initially used the equivalent formulation with Simple EU; the
subsequent finite-lottery proof below permits treating Simple EU as derived.
DTU has a separate optional preset. Both presets explicitly include Archimedean
Outcomes. Named conjunctions abbreviate these packages while retaining each
record's full, original premises.

The two research reports previously called the six-axiom package DU. Their
package-level summaries, complete-model labels and totality-dependent conjectures
now say DTU. Exact result premises and model flags are unchanged. Incomplete
DU models are eligible under the default background. Claims whose listed
premises do not need Totality remain valid DU consequences.

### Simple EU as a derived DU consequence — 9 September 2026

The new record `rich-archimedean-dominance-independence-imply-simple-eu`
proves Simple EU from Rich Outcomes, Archimedean Outcomes, Stochastic
Dominance and Mixture Independence. It uses common binary endpoints for
finite lotteries, checks all three normalized-chart calibrations and
measurability, and never assumes Totality or Restricted Totality.

The DU preset therefore assumes Rich Outcomes, Archimedean Outcomes,
Stochastic Equivalence, Stochastic Dominance and Mixture Independence;
Simple EU is displayed as a consequence. DTU adds Totality. Together with
the existing Simple EU ⇒ Archimedean Outcomes record, the new proof makes
this equivalent to the previous Simple-EU-based package.

The literal two-premise implication Rich Outcomes + Archimedean Outcomes
⇒ Simple EU is false. The `finite-two-sample-minimum` model supplies an
explicit witness, even with Totality and Stochastic Equivalence. Both new
records identify the connecting work as GPT-6 (Codex), 9 September 2026;
the source finite-lottery argument remains credited to Goodsell. Existing
source-attributed theorem premises and proofs are unchanged.

### Package picture: further model failures — 15 September 2026

Zachary Goodsell asked for a complete picture of what is consistent with
DU + Sym, DTU, DTU + Sym and DU + Sym + Symmetric Neutrality. Claude
(Fable 5.1) computed the picture from the recorded evidence and supplied
explicit witnesses for the cheap gaps; no principle definitions, theorem
premises or existing proofs were changed.

The least DU model (`finite-support-compensated-dominance`) now records
seven further verified failures: the three named prospect evaluations and
uniqueness of negative self-similarity (the prospects are incomparable with
their prescribed values), Comonotonic Sum Invariance, Independent Sum
Preservation and Existential Copula Sum Invariance (one simple equal-mean
pair whose sums with a uniform summand acquire a sloped survival
difference, for every copula). With these, every principle is entailed,
excluded or separated in both directions under DU + Sym.

The exact eventual-dominance model (`eventual-clipped-expectation`) now
records failure of Shift Invariance and Positive Affine Invariance: a
symmetric Laplace gamble X is indifferent to sure 0, yet X + b is strictly
worse than sure b for every b > 0.

Remaining gaps in the requested packages: whether Comonotonic Sum
Invariance is consistent with DTU (the conjectured total comonotonic
extension stays conjectured) or with DTU + Sym and DU + Sym + Neutrality;
whether Existential Copula Sum Invariance is consistent with the two
symmetric packages; whether DTU + Sym implies L¹ Continuity or Expected
Utility; separating models for DU + Sym + Neutrality; whether Independent
Sum Cancellation is consistent with DU + Sym + Neutrality; and a DTU model
violating Shift Invariance (a cone-extension construction orienting a
transfer pair against its own shift is sketched privately and not yet
recorded).

### Copula principles: comonotonic failures, a killing lemma, silver tier — 23 September 2026

Zachary Goodsell asked for work on the copula sum principles, starting from
the law-level reading of them: realize X† = Q_X(U) on the standing uniform
and Z* = Q_Z(W) with (U, W) distributed as the copula C; then SC(C) says,
under Stochastic Equivalence, that X ≽ Y iff X† + Z* ≽ Y† + Z* for all
laws. Claude (Fable 5.1) verified this reading (Z* is canonical only in law,
which is why the recorded bridges from the comonotonic, antitonic and
independent principles need Stochastic Equivalence; for the comonotonic
copula W = U) and recorded it in the notes of the three copula principles,
together with the quantile-difference reduction of Comonotonic Sum
Invariance. The Fubini remark that E[X† − Y†] with the separate Tonelli
identities is the CDF-area preorder is the recorded `cdf-area-preorder`
model, so DU is consistent with comonotonic invariance; no new record.

Six models now record failure of Comonotonic Sum Invariance: the exact,
continuous, geometric, asymmetric and polynomial clipped-expectation
orderings and the eventual-dominance model (where the flag was previously
derived from the shift failure). One witness family serves all windows:
Z = max(C, 0) for a standard Cauchy C, X = 0, and a window-adapted neutral
Y = C₊ + aC₋ − v; the clipped gap is 2∫_{F/2}^{F} P(C > x) dx, positive for
every cutoff F and tending to (2 ln 2)/π. The mechanism is the identity
2E[min(V,F)] − E[min(2V,F)] = 2∫_{F/2}^{F} P(V > x) dx.
`checks/comonotonic_witnesses.py` verifies the closed forms, the identity
on an exact finite law, the neutral constants and the limit. Under DU and
DTU this settles that Expected Utility, Totality, Shift Invariance,
Reflection Anti-Invariance, L¹ Continuity, CDF-Area Extension, Folded
Expectation, Transfer of a Shift and Arroyo = ln 2 do not imply Comonotonic
Sum Invariance, and that DTU alone does not.

For the conjectured total comonotonic extension, the write-up gains a
necessary condition: a killing lemma (from Stochastic Equivalence,
dominance, mixture independence and the preservation half of comonotonic
invariance, a pair whose survival difference and comonotonic shears combine
into a nonpositive nonzero profile cannot satisfy X ≽ Y), an explicit killed
pair with both areas infinite, three certificates that a pair is not killed,
worked block regions, an accounting heuristic suggesting that no pair is
killed in both orientations, and candidate constructions. Zachary Goodsell
raised the conjecture's tier to silver. The conjecture's status is unchanged.
Lean statements were regenerated and audited; every `lean: stated` claim
still elaborates.

Open after this batch: DTU + Comonotonic Sum Invariance itself (decide
killability of regions with no lowest block; formalize the surplus
functional; attempt the Zorn construction with the lemma as pointedness
test); whether the region of the alternating St Petersburg gamble against
−1/2 is killed under the comonotonic copula, which bears on the top DU
lynchpin about Existential Copula Sum Invariance; and Independent Sum
Cancellation for the exact CDF-area preorder.

### Rational and integer factors from comonotonic addition; the exact ordering fails shifts — 24 September 2026

Zachary Goodsell claimed that Comonotonic Sum Invariance implies Positive
Affine Invariance by iterated addition (2A = A + A ≽ B + A ≽ B + B = 2B) and
proposed a rational-factor principle for the remaining step. Claude
(Fable 5.1) recorded what the argument proves and where it stops. New
principles: Rational Scale Invariance, Integer Affine Preservation, Rational
Affine Preservation and Uniqueness of Negative Self-Similarity (integer
ratios). Proved: Rich Outcomes + Stochastic Equivalence + Comonotonic Sum
Invariance give Integer Affine Preservation (adding A to both sides needs B
comonotonic with A, hence Stochastic Equivalence, and the mixed sums
jX + (k − j)Y, hence Rich Outcomes); adding Totality gives Rational Scale
Invariance, the cancellation kX ≽ kY ⇒ X ≽ Y being the only place Totality
enters; Totality + Mixture Independence + Integer Affine Preservation +
Reflection Anti-Invariance give integer-ratio uniqueness, which carries the
alternating St Petersburg and Pasadena evaluations, since both use only the
ratio 2. Two models: `cdf-area-unit-threshold` (Rich Outcomes, Archimedean
Outcomes, Stochastic Equivalence, Stochastic Dominance, Simple EU,
Comonotonic Sum Invariance and Integer Affine Preservation; cancellation
fails at 2, so Rational Scale Invariance, Rational Affine Preservation,
Totality and Mixture Independence fail) and `lexicographic-hamel-tie-break`
(a total law-based order ranking integrable widths by area with a ℚ-linear
Hamel tie-break and a Zorn completion of the infinite-area pairs; invariant
under every rational factor, not under √2; Mixture Independence fails).
Conjectures: DTU + Comonotonic Sum Invariance ⇒ Scale Invariance, and
DU + Comonotonic Sum Invariance ⇒ Rational Affine Preservation. Verdict
updates: the four recorded scale countermodels fail at the factor 2
(U Theorem 10 compares μ with the law of 2X), so they fail Rational Scale
Invariance and Integer Affine Preservation; the four models refuting the
real-ratio uniqueness principle do so at ratio 2 and fail the integer-ratio
principle; the folded-tail cone now derivably fails Comonotonic Sum
Invariance. `checks/rational_scale_witnesses.py` verifies the witnesses.

Goodsell also observed that the exact ultrafilter ordering fails Shift
Invariance: a balanced prospect shifted by 1 stays strictly behind sure 1 at
every truncation level, because clipping C + 1 to [−t, t] clips C to
[−t − 1, t − 1] and loses its upper tail between t − 1 and t + 1, so
v_{C+1}(t) = 1 − ∫_{t−1}^{t+1} P(C > x) dx < 1 while v_C = v_0 = 0. The
deficit vanishes as t → ∞, which is why the continuous quotients keep Shift
Invariance (U Theorem 8). Recorded on `total-exact-ultrafilter` with
`checks/exact_shift_witness.py`. This is the DTU model violating Shift
Invariance listed as open above, so the private cone-extension sketch is no
longer needed for that question; the engine also derives that the exact
ordering fails Transfer of a Shift and Simple Relative Expectation.

Open after this batch: real factors under DTU + Comonotonic Sum Invariance
(no model of that package is known, so a refutation would also settle the
total comonotonic extension); fractional factors under DU + Comonotonic Sum
Invariance, that is integer cancellation without Totality; and whether the
integer-ratio uniqueness principle separates from the real-ratio one under
DTU.


### AI report communicated by Branden Fitelson — 2 October 2026

Read the four-page report *Unbounded Utility: Five Top-Ranked Open Conjectures
Resolved*, dated 30 September 2026. Fitelson communicated the results; the
report says they were produced by Claude agents but gives no model versions.
The separately mentioned detailed and referee reports were not supplied.
GPT-6 (Codex) expanded and informally checked the arguments recorded below.
The source PDF is retained privately, not redistributed with the map.

| Report | Accepted evidence |
| --- | --- |
| §1: alternating St Petersburg = −1/2 does not imply Folded Expectation over DU | `calibrated-geometric-continuous-ultrafilter`, also total |
| §2: Existential Copula Sum Invariance does not imply Independent Sum Invariance | `cdf-area-preorder` now fails Independent Sum Cancellation, by the full block-smoothing proof appended to its write-up |
| §3: Integer Affine Preservation does not imply Negative Affine Anti-Invariance | `asymmetric-liminf-clipped-expectation`, satisfying full Positive Affine Invariance |
| §4(b): alternating evaluation and Existential Copula Sum Invariance are jointly consistent | the calibrated total model, with the fixed shuffle copula |
| §5(a,b): Existential Copula Sum Invariance and Integer Affine Preservation do not imply Independent Sum Invariance | the CDF-area cancellation example and the new `symmetric-liminf-clipped-expectation`, which fails Independent Sum Preservation |

The fixed shuffle proof is included in the calibrated model's write-up and
also adds Existential Copula Sum Invariance to the four existing tolerance-based
continuous ultrafilter models. It does not apply automatically to exact
ultrafilter or eventual zero-tolerance comparisons. Original model authors,
sources and certificate dates are retained, with dated changes for the additions.

The stronger steered-conclosure assertions in §4(a) are **not imported as
proved**. The PDF gives no proof of its analytic Lemma 2, its Fourier bound,
or the claimed obstruction for every convolution kernel. In particular no new
verdict is added for alternating St Petersburg in the existing bare conclosure,
and no total Independent Sum Invariance model with an arbitrarily prescribed
alternating-game value is asserted. This limitation does not affect the fourth
headline conclusion, which has the independently completed shuffle-copula proof.

`checks/fitelson_report.py` contains exact atom/block arithmetic and numerical
diagnostics for the analytic witnesses. These support the written proofs;
neither the diagnostics nor the reported external referee verdicts are Lean
verification. Question counts and rankings printed in the source are historical
and are not copied as current map statistics.

### St Petersburg incompleteness and nonindependent copulas — 3 October 2026

Zachary Goodsell requested that the simplified proof from the preceding
conversation be recorded, with an audit of preservation versus cancellation,
and proposed existential invariance for a copula other than independence.
The original incompleteness theorem and two-pair mechanism were communicated
by Branden Fitelson in *Comonotonic Sum Invariance Forces Incompleteness*,
2 October 2026; the producing AI was not identified. GPT-6 (Codex) supplied
the simple St Petersburg witness and three-background identity on 2 October,
and the direction audit and direct preservation argument on 3 October.

`st-petersburg-refutes-total-comonotonic-preservation` records the full proof.
Weak preservation suffices for each mixture obstruction. The equal-mean
connection also uses only weak preservation, via an explicit increasing
common remainder. Forced incomparability without Totality uses cancellation
once at the final comparison transfer. Under Totality, weak and strict
preservation give a direct contradiction with no separate cancellation
assumption. Three new principles make these directions explicit; Preservation
includes the strict clause, matching the existing independent-sum convention.
The silver total comonotonic extension is refuted by derived evidence, with
its original conjecture and attribution retained as history.

`existential-nonindependent-copula-sum-consistency` quantifies over one fixed
copula different from the product. The existing quarter-shuffle proof
verifies it for seven clipped-expectation models. The new result
`independent-sum-eu-imply-nonindependent-copula` gives a second family:
copulas differing from independence only inside an interior square change
sum laws by bounded zero-mean signed measures, invisible under EU and Mixture
Independence. It applies to the proved total independent-sum extension.

The accompanying write-up proves that the product is nevertheless the unique
copula whose sum operation commutes with all mixtures: two binary laws
recover every rectangle mass H_C(p,q). This is a recipe for failure of a
law identity, not a general preference counterexample. The binary outputs
have equal finite means, and the consistency witnesses rule out a universal
impossibility claim for all nonindependent copulas. It also records a general
sufficient finite-mixture dominance certificate without claiming that such
certificates exist for every copula.

`checks/st_petersburg_comonotonic.py` verifies the infinite-law identities
with exact symbolic St Petersburg recursion; `checks/nonindependent_copulas.py`
checks the concrete copula density and finite-law arithmetic. Neither is a
Lean certificate or an independent referee report. No private PDF is included
in public files or downloads.

### Uninteractive Sum Invariance replaces the existential copula principles — 11 October 2026

Zachary Goodsell, working on the unbounded-utility map on 6 October 2026,
judged the existential copula principles suboptimal and proposed instead
that the ordering be invariant under addition when the tails of the added
variables avoid each other. Claude (Opus 5.5) formulated this as
`uninteractive-sum-invariance`: if $E\min(|X|,|Z|)$ and $E\min(|Y|,|Z|)$ are
finite then $X \succeq Y$ iff $X+Z \succeq Y+Z$. Every pair admitting a
corner-avoiding copula is uninteractive, so the principle implies the
fixed-copula invariance $\mathrm{SC}(C_\sigma)$ for the quarter shuffle, and
with it both existential copula principles, without Stochastic Equivalence.
The same session checked the truncation models: the principle holds in every
continuous clipped-expectation model and both liminf models by dominated
convergence on $|q(x+z)-q(x)-q(z)| \le 2\min(|x|,|z|)$, and fails in the
exact ultrafilter and eventual clipped-expectation models, which fail Shift
Invariance (`uninteractive-sum-implies-shift`).

Claude (Fable 5.1), 10–11 October 2026, proved the two connecting results.
`relative-independence-equivalence-imply-uninteractive-sum`: Relative
Expectation with Mixture Independence cancels any integrable common summand
in any coupling (fair mixtures with the same coin differ by $Z(2B-1)$, which
is integrable with mean zero); Sure-Thing supplies two-cell separability;
and the event $\{|Z| > \max(|X|,|Y|)\}$ splits a general uninteractive triple
into an integrable part and a separable part. Stochastic Equivalence enters
only through Sure-Thing. `uninteractive-sum-equivalence-imply-relative`:
every integrable mean-zero law is a mixture of mean-zero two-point laws, each
realized as $T(Z)-Z$ for a translation swap $T$ of two adjacent intervals
preserving a uniform $Z$, so every such $D$ has a companion $Z$ with
$Z+D \overset{d}{=} Z$; cancelling that summand with Stochastic Equivalence
gives $D \sim 0$, and a constant summand then gives Relative Expectation.
Under DU the new principle is therefore Relative Expectation. Shift
Invariance with Sure-Thing is not enough (`finite-shift-total-extension` has
DTU and Shift but fails Shift Transfer, a consequence of Relative
Expectation), and L¹ Continuity is not needed
(`lexicographic-folded-extension` has Relative Expectation without it). The
bounded-overlap variant is implied; whether it implies the integrable form
under DU is open and reduces to $Y+R \sim Y+E[R]$ for integrable $R \ge 0$.

On Goodsell's instruction the principles `existential-copula-sum-consistency`
and `existential-nonindependent-copula-sum-consistency` were deleted on
11 October 2026, with the ten results that used them:
`antitonic-sum-and-equivalence-imply-existential-copula`,
`antitonic-sum-equivalence-imply-nonindependent-copula`,
`comonotonic-sum-and-equivalence-imply-existential-copula`,
`comonotonic-sum-equivalence-imply-nonindependent-copula`,
`existential-copula-implies-shift`,
`independent-sum-and-equivalence-imply-existential-copula`,
`independent-sum-eu-imply-nonindependent-copula`,
`nonindependent-copula-implies-existential-copula`,
`universal-copula-implies-existential` (its Lean proof, the only verified one
among them, was removed from `Proofs.lean` with the definition
`ExistentialCopulaSumConsistency` in `Principles.lean`; `Statements.lean` is
regenerated by the build; `lean/VERIFICATION.md` remains the 13 September
report) and `universal-copula-implies-nonindependent-copula`. The write-up
`independent-sum-eu-imply-nonindependent-copula.md` went with its result; for
history, it showed that copulas differing from the product only inside an
interior square change sum laws by bounded zero-mean signed measures,
invisible under Expected Utility and Mixture Independence, and that the
product is the unique copula whose sum operation commutes with all mixtures.
`checks/nonindependent_copulas.py` is kept as an orphan diagnostic. Universal
Copula Sum Invariance and its three remaining consequences are unchanged.

Model records: the retired flags were removed from the seven
clipped-expectation models, `finite-support-compensated-dominance` and
`lexicographic-nonatomic-mass`, each with a dated change entry; the
shuffle-copula sections of the write-ups are kept as history and now say what
they prove. `total-continuous-ultrafilter` and
`geometric-continuous-ultrafilter` gain the Relative Expectation flag their
shared clipping proof already established, so Uninteractive Sum Invariance is
derived for all seven models, for `cdf-area-preorder`,
`cdf-conclosure-preorder` and `lexicographic-folded-extension`, and its
failure is derived for `finite-support-compensated-dominance`,
`finite-shift-total-extension`, `total-exact-ultrafilter` and
`eventual-clipped-expectation`. `finite-support-compensated-dominance` and
`lexicographic-nonatomic-mass` also carry direct failure flags, the latter
because its bounded chart lacks Rich Outcomes: with the comonotonic coupling,
$X=U/4 \succ 1/8=Y$ while $X+U/4$ and $Y+U/4$ share the vector $(1/4,1)$.
