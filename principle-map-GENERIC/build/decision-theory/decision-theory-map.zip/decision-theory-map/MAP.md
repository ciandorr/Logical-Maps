# Preference axioms over lotteries — complete map

Topic `decision-theory`. Generated 2026-09-10T15:57:51+00:00.

12 principles, 16 proved results, 2 recorded conjectures, 9 models.

This file is self-contained. Every principle statement, every proof, every model construction and every derived verdict in the database is reproduced below. `README.md` gives the semantics and the rules for adding to it; `OPEN-QUESTIONS.md` lists what is not settled.

## 1. Framework


≽ a reflexive binary relation on Δ(X), X finite with |X| ≥ 3; ≻, ~ its asymmetric and symmetric parts.

**Fixed background assumptions.** None. Every principle below is optional and must be assumed explicitly.

## 2. Background and standing conventions

*Reproduced from `topics/decision-theory/background.md`.*

≽ a reflexive binary relation on Δ(X), X finite with |X| ≥ 3; ≻, ~ its asymmetric and symmetric parts. *(placeholder)*

### Notation

*(placeholder)*

### Conventions

*(placeholder — e.g. which form of independence is meant, what "continuity" means by default)*

### Certificates

*(placeholder — what human / human-assisted / AI / Lean mean here)*

### Literature

*(placeholder)*

## 3. Principles

### All principles

#### Acyclicity — `acyclicity`


There is no finite cycle of strict preferences p₁ ≻ p₂ ≻ … ≻ pₙ ≻ p₁.

Formal: `∀n ∀p₁…pₙ. ¬(p₁ ≻ p₂ ∧ … ∧ pₙ ≻ p₁)`

Tags: ordering.

Sources:

- Sen (1970), Collective Choice and Social Welfare, ch. 1*

#### Archimedean — `archimedean`


For all p, q, r ∈ Δ(X): if p ≻ q ≻ r then there are α, β ∈ (0,1) with αp + (1−α)r ≻ q and q ≻ βp + (1−β)r.

Formal: `∀p q r. p ≻ q ≻ r → ∃α β∈(0,1). αp+(1−α)r ≻ q ∧ q ≻ βp+(1−β)r`

Tags: axiom, topological.

Sources:

- Jensen (1967), An introduction to Bernoullian utility theory I, Swedish Journal of Economics 69

#### Betweenness — `betweenness`


For all p, q ∈ Δ(X) and λ ∈ (0,1): if p ≻ q then p ≻ λp + (1−λ)q ≻ q, and if p ~ q then p ~ λp + (1−λ)q.

Formal: `∀p q, ∀λ∈(0,1). (p ≻ q → p ≻ λp+(1−λ)q ≻ q) ∧ (p ~ q → p ~ λp+(1−λ)q)`

Tags: axiom, mixture.

Sources:

- Chew (1983), A generalization of the quasilinear mean…, Econometrica 51
- Dekel (1986), An axiomatic characterization of preferences under uncertainty, JET 40

#### Closed-graph continuity — `closed-graph-continuity`


The set {(p, q) ∈ Δ(X) × Δ(X) : p ≽ q} is closed in the product topology.

Formal: `IsClosed {(p,q) | p ≽ q}`

Tags: axiom, topological.

Sources:

- Dubra, Maccheroni & Ok (2004), JET 115, Axiom C

#### Completeness — `completeness`


For all p, q ∈ Δ(X): p ≽ q or q ≽ p.

Formal: `∀p q. p ≽ q ∨ q ≽ p`

Tags: ordering.

Sources:

- von Neumann & Morgenstern (1944), Theory of Games and Economic Behavior, §3.5

#### Mixture continuity — `continuity`


For all p, q, r ∈ Δ(X) the sets {λ ∈ [0,1] : λp + (1−λ)q ≽ r} and {λ ∈ [0,1] : r ≽ λp + (1−λ)q} are closed.

Formal: `∀p q r. closed {λ | λp+(1−λ)q ≽ r} ∧ closed {λ | r ≽ λp+(1−λ)q}`

Tags: axiom, topological.

Sources:

- Herstein & Milnor (1953), Econometrica 21, Axiom 2

#### Expected-utility representation — `eu-representation`


There is a function u : X → ℝ such that for all p, q ∈ Δ(X): p ≽ q if and only if EU_u(p) ≥ EU_u(q).

Formal: `∃u:X→ℝ. ∀p q. p ≽ q ↔ Σ_x p(x)u(x) ≥ Σ_x q(x)u(x)`

Tags: representation.

Sources:

- von Neumann & Morgenstern (1944)

#### Independence — `independence`


For all p, q, r ∈ Δ(X) and λ ∈ (0,1]: p ≽ q if and only if λp + (1−λ)r ≽ λq + (1−λ)r.

Formal: `∀p q r, ∀λ∈(0,1]. p ≽ q ↔ λp+(1−λ)r ≽ λq+(1−λ)r`

Tags: axiom, mixture.

Sources:

- Marschak (1950), Rational behavior, uncertain prospects, and measurable utility, Econometrica 18
- Herstein & Milnor (1953), An axiomatic approach to measurable utility, Econometrica 21

#### Expected multi-utility representation — `multi-utility`


There is a set U of functions u : X → ℝ such that for all p, q ∈ Δ(X): p ≽ q if and only if EU_u(p) ≥ EU_u(q) for every u ∈ U.

Formal: `∃U ⊆ (X→ℝ). ∀p q. p ≽ q ↔ ∀u∈U. EU_u(p) ≥ EU_u(q)`

Tags: representation.

Sources:

- Aumann (1962), Utility theory without the completeness axiom, Econometrica 30
- Dubra, Maccheroni & Ok (2004), Expected utility theory without the completeness axiom, JET 115

#### Quasi-transitivity — `quasi-transitivity`


Strict preference is transitive: if p ≻ q and q ≻ r then p ≻ r.

Formal: `∀p q r. p ≻ q → q ≻ r → p ≻ r`

Tags: ordering.

Sources:

- Sen (1969), Quasi-transitivity, rational choice and collective decisions, Review of Economic Studies 36

#### Transitivity — `transitivity`


For all p, q, r ∈ Δ(X): if p ≽ q and q ≽ r then p ≽ r.

Formal: `∀p q r. p ≽ q → q ≽ r → p ≽ r`

Tags: ordering.

Sources:

- von Neumann & Morgenstern (1944), §3.5

#### Weak order — `weak-order`


≽ is complete and transitive.

Formal: `Completeness ∧ Transitivity`

Tags: ordering, bundle.

Sources:

- (none recorded)

## 4. Results

Each result is a Horn clause: the conjunction of its premises entails its conclusion, relative to the framework above. Premises are sufficient; minimality is not claimed.

### 4.1 Proved

#### Closed-graph continuity ⇒ Mixture continuity — `closed-graph-implies-mixture-continuity`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Closed-graph continuity (`closed-graph-continuity`)

Conclusion: Mixture continuity (`continuity`)

Proof.

λ ↦ (λp+(1−λ)q, r) and λ ↦ (r, λp+(1−λ)q) are continuous maps
[0,1] → Δ(X)×Δ(X); the two sections are their preimages of the closed
graph of ≽.

Sources:

- (none recorded)

Record: `topics/decision-theory/results/closed-graph-implies-mixture-continuity.yaml`.

#### Mixture continuity ∧ Completeness ⇒ Archimedean — `continuity-completeness-imply-archimedean`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Mixture continuity (`continuity`)
- Completeness (`completeness`)

Conclusion: Archimedean (`archimedean`)

Proof.

Let p ≻ q ≻ r and set A = {λ : λp+(1−λ)r ≽ q}, B = {λ : q ≽ λp+(1−λ)r}.
Both are closed by continuity and A ∪ B = [0,1] by completeness. Since
1 ∉ B (as p ≻ q) and [0,1]∖B is open, some interval (1−ε, 1] lies in
[0,1]∖B ⊆ A; any α in it with α < 1 gives αp+(1−α)r ≻ q. Symmetrically,
0 ∉ A (as q ≻ r) yields [0, ε) ⊆ B∖A and any β in it with β > 0 gives
q ≻ βp+(1−β)r.

Notes. Completeness is used to conclude λ ∈ A from λ ∉ B; whether continuity alone suffices is left open here.

Sources:

- (none recorded)

Record: `topics/decision-theory/results/continuity-completeness-imply-archimedean.yaml`.

#### Transitivity ∧ Independence ∧ Closed-graph continuity ⇒ Expected multi-utility representation — `dmo-theorem`

Proved result; source **Misc.**; legacy provenance human; produced by literature; checked by nobody; 2026-09-08.

Premises:

- Transitivity (`transitivity`)
- Independence (`independence`)
- Closed-graph continuity (`closed-graph-continuity`)

Conclusion: Expected multi-utility representation (`multi-utility`)

Proof.

Dubra–Maccheroni–Ok, Theorem 1, for compact metric X (finite X is a
special case): a reflexive transitive relation on Δ(X) satisfying
independence and closed-graph continuity has an expected multi-utility
representation. The proof identifies ≽ with a closed convex cone of
signed measures and takes U to be the dual cone.

Notes. Reflexivity is a standing assumption of the framework.

Sources:

- Dubra, Maccheroni & Ok (2004), Expected utility theory without the completeness axiom, JET 115, Theorem 1

Record: `topics/decision-theory/results/dmo-theorem.yaml`.

#### Expected-utility representation ⇒ Completeness — `eu-implies-completeness`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Expected-utility representation (`eu-representation`)

Conclusion: Completeness (`completeness`)

Proof.

Real numbers are totally ordered: EU_u(p) ≥ EU_u(q) or EU_u(q) ≥ EU_u(p).

Sources:

- (none recorded)

Record: `topics/decision-theory/results/eu-implies-completeness.yaml`.

#### Expected-utility representation ⇒ Expected multi-utility representation — `eu-implies-multi-utility`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Expected-utility representation (`eu-representation`)

Conclusion: Expected multi-utility representation (`multi-utility`)

Proof.

Take U = {u}.

Sources:

- (none recorded)

Record: `topics/decision-theory/results/eu-implies-multi-utility.yaml`.

#### Independence ⇒ Betweenness — `independence-implies-betweenness`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Independence (`independence`)

Conclusion: Betweenness (`betweenness`)

Proof.

Fix λ ∈ (0,1) and write m = λp + (1−λ)q. Independence with r = p and
mixing weight 1−λ gives p ≽ q ⟺ (1−λ)p+λp ≽ (1−λ)q+λp, i.e. p ≽ q ⟺ p ≽ m,
and likewise q ≽ p ⟺ m ≽ p. Hence p ≻ q ⟺ p ≻ m and p ~ q ⟺ p ~ m.
Independence with r = q and weight λ gives p ≽ q ⟺ m ≽ q and
q ≽ p ⟺ q ≽ m, so p ≻ q ⟺ m ≻ q. Together: p ≻ q ⟹ p ≻ m ≻ q and
p ~ q ⟹ p ~ m.

Notes. No ordering assumptions are needed because independence is taken in the biconditional form.

Sources:

- (none recorded)

Record: `topics/decision-theory/results/independence-implies-betweenness.yaml`.

#### Transitivity ∧ Independence ∧ Mixture continuity ⇒ Closed-graph continuity — `mixture-continuity-implies-closed-graph`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Transitivity (`transitivity`)
- Independence (`independence`)
- Mixture continuity (`continuity`)

Conclusion: Closed-graph continuity (`closed-graph-continuity`)

Proof.

Let V = {x ∈ ℝ^X : Σx = 0} and D = Δ(X) − Δ(X) ⊆ V (compact, convex,
contains 0). Put K = {q − p : q ≽ p}.

(i) Membership in K depends only on the difference: if q − p = q' − p'
then ½q + ½p' = ½q' + ½p, and by independence (λ = ½, mixing with p'
resp. p) q ≽ p ⟺ ½q+½p' ≽ ½p+½p' and q' ≽ p' ⟺ ½q'+½p ≽ ½p'+½p; the two
right-hand sides are the same pair. So "x ∈ K" is well defined for x ∈ D.

(ii) K is a cone in D: if x ∈ K and tx ∈ D (t > 0) then tx ∈ K. For
t < 1 use independence with r = p: q ≽ p ⟹ tq+(1−t)p ≽ p, whose
difference is t(q−p). For t > 1 apply the t < 1 case to tx.

(iii) K is convex: with x = q−p, y = q'−p' in K, independence gives
½q+½q' ≽ ½p+½q' and ½q'+½p ≽ ½p'+½p, and transitivity gives
½q+½q' ≽ ½p+½p', whose difference is ½x+½y.

(iv) K is closed along every line. Let [x₀, x₁] = ℓ ∩ D for a line ℓ and
x(λ) = λx₁ + (1−λ)x₀. Pick ε > 0 and the uniform lottery c so that
c + εx(λ) ∈ Δ(X) for all λ ∈ [0,1]. By (ii), x(λ) ∈ K ⟺ εx(λ) ∈ K ⟺
c + εx(λ) ≽ c. Since c + εx(λ) = λ(c+εx₁) + (1−λ)(c+εx₀), the set
{λ : x(λ) ∈ K} is a section of the form {λ : λa+(1−λ)b ≽ c}, closed by
mixture continuity.

(v) A convex subset of a finite-dimensional space that meets every line
in a closed set is closed (if x ∈ cl K ∖ K and y is in the relative
interior of K then [y, x) ⊆ K by the accessibility lemma, so K ∩ line(y,x)
is not closed). Hence K is closed, and if (pₙ, qₙ) → (p, q) with qₙ ≽ pₙ
then qₙ − pₙ ∈ K → q − p ∈ K, i.e. q ≽ p.

Notes. This is the bridge between the mixture-continuity axiom used in the vNM literature and the closed-graph axiom used by Dubra–Maccheroni–Ok. It has not been checked by a human; if it fails, the map still reaches multi-utility from closed-graph continuity via dmo-theorem.

Sources:

- (none recorded)

Record: `topics/decision-theory/results/mixture-continuity-implies-closed-graph.yaml`.

<details><summary>Hand-written write-up</summary>

#### Transitivity ∧ Independence ∧ Mixture continuity ⇒ Closed-graph continuity

<p class='cert'>Result — ai; produced by Claude Fable 5.1 (Cowork session), 2026-09-08. Not yet checked.</p>

**Claim.** If $\succcurlyeq$ is reflexive and transitive, satisfies independence, and has closed sections $\{\lambda : \lambda p + (1-\lambda) q \succcurlyeq r\}$ and $\{\lambda : r \succcurlyeq \lambda p + (1-\lambda) q\}$, then $\{(p,q) : p \succcurlyeq q\}$ is closed in $\Delta(X)^2$.

**Proof.** Let $V = \{x \in \mathbb{R}^X : \sum_x x = 0\}$ and $D = \Delta(X) - \Delta(X) \subseteq V$, which is compact, convex, and contains $0$. Put
$$K = \{\, q - p : q \succcurlyeq p \,\}.$$

*(i) $K$ depends only on differences.* If $q - p = q' - p'$ then $\tfrac12 q + \tfrac12 p' = \tfrac12 q' + \tfrac12 p$. By independence with $\lambda = \tfrac12$, $q \succcurlyeq p \iff \tfrac12 q + \tfrac12 p' \succcurlyeq \tfrac12 p + \tfrac12 p'$ and $q' \succcurlyeq p' \iff \tfrac12 q' + \tfrac12 p \succcurlyeq \tfrac12 p' + \tfrac12 p$. The two right-hand sides are the same pair.

*(ii) $K$ is a cone in $D$.* If $x \in K$, $t > 0$ and $tx \in D$, then $tx \in K$. For $t < 1$: from $q \succcurlyeq p$, independence with $r = p$ gives $tq + (1-t)p \succcurlyeq p$, whose difference is $t(q-p)$. For $t > 1$ apply the previous case to $tx$.

*(iii) $K$ is convex.* For $x = q - p$ and $y = q' - p'$ in $K$, independence gives $\tfrac12 q + \tfrac12 q' \succcurlyeq \tfrac12 p + \tfrac12 q'$ and $\tfrac12 q' + \tfrac12 p \succcurlyeq \tfrac12 p' + \tfrac12 p$; transitivity gives $\tfrac12 q + \tfrac12 q' \succcurlyeq \tfrac12 p + \tfrac12 p'$, with difference $\tfrac12 x + \tfrac12 y$.

*(iv) $K$ is closed along every line.* Let $[x_0, x_1] = \ell \cap D$ and $x(\lambda) = \lambda x_1 + (1-\lambda) x_0$. Choose $\varepsilon > 0$ and the uniform lottery $c$ with $c + \varepsilon x(\lambda) \in \Delta(X)$ for all $\lambda$. By (ii), $x(\lambda) \in K \iff \varepsilon x(\lambda) \in K \iff c + \varepsilon x(\lambda) \succcurlyeq c$, and $c + \varepsilon x(\lambda) = \lambda(c + \varepsilon x_1) + (1-\lambda)(c + \varepsilon x_0)$, so $\{\lambda : x(\lambda) \in K\}$ is a section, closed by mixture continuity.

*(v)* A convex subset of a finite-dimensional space meeting every line in a closed set is closed: for $x \in \overline{K} \setminus K$ and $y$ in the relative interior of $K$, $[y, x) \subseteq K$ by the accessibility lemma, so $K \cap \mathrm{line}(y,x)$ is not closed. Hence $K$ is closed, and $(p_n, q_n) \to (p, q)$ with $q_n \succcurlyeq p_n$ gives $q - p \in K$. ∎

**Remark.** This bridges the mixture-continuity axiom of the vNM literature and the closed-graph axiom of Dubra–Maccheroni–Ok. The map reaches the multi-utility representation from closed-graph continuity without it.

</details>

#### Expected multi-utility representation ⇒ Closed-graph continuity — `multi-utility-implies-closed-graph`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Expected multi-utility representation (`multi-utility`)

Conclusion: Closed-graph continuity (`closed-graph-continuity`)

Proof.

{(p,q) : p ≽ q} = ⋂_{u∈U} {(p,q) : EU_u(p) − EU_u(q) ≥ 0}, an intersection
of preimages of [0,∞) under continuous (indeed linear) maps on Δ(X)×Δ(X).

Sources:

- (none recorded)

Record: `topics/decision-theory/results/multi-utility-implies-closed-graph.yaml`.

#### Expected multi-utility representation ⇒ Independence — `multi-utility-implies-independence`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Expected multi-utility representation (`multi-utility`)

Conclusion: Independence (`independence`)

Proof.

EU_u is affine in mixtures, so for λ ∈ (0,1]:
EU_u(λp+(1−λ)r) − EU_u(λq+(1−λ)r) = λ(EU_u(p) − EU_u(q)),
which is ≥ 0 iff EU_u(p) ≥ EU_u(q). Quantify over u ∈ U.

Sources:

- (none recorded)

Record: `topics/decision-theory/results/multi-utility-implies-independence.yaml`.

#### Expected multi-utility representation ⇒ Transitivity — `multi-utility-implies-transitivity`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Expected multi-utility representation (`multi-utility`)

Conclusion: Transitivity (`transitivity`)

Proof.

If EU_u(p) ≥ EU_u(q) and EU_u(q) ≥ EU_u(r) for every u ∈ U then
EU_u(p) ≥ EU_u(r) for every u ∈ U.

Sources:

- (none recorded)

Record: `topics/decision-theory/results/multi-utility-implies-transitivity.yaml`.

#### Quasi-transitivity ⇒ Acyclicity — `quasi-transitivity-implies-acyclicity`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Quasi-transitivity (`quasi-transitivity`)

Conclusion: Acyclicity (`acyclicity`)

Proof.

If p₁ ≻ p₂ ≻ … ≻ pₙ ≻ p₁ then by induction on n, transitivity of ≻ gives
p₁ ≻ pₙ, and with pₙ ≻ p₁ this contradicts asymmetry of ≻.

Sources:

- (none recorded)

Record: `topics/decision-theory/results/quasi-transitivity-implies-acyclicity.yaml`.

#### Transitivity ⇒ Quasi-transitivity — `transitivity-implies-quasi-transitivity`

Proved result; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Transitivity (`transitivity`)

Conclusion: Quasi-transitivity (`quasi-transitivity`)

Proof.

Let p ≻ q ≻ r. Then p ≽ q ≽ r, so p ≽ r. If also r ≽ p then r ≽ p ≽ q
gives r ≽ q, contradicting q ≻ r. So p ≻ r.

Sources:

- (none recorded)

Record: `topics/decision-theory/results/transitivity-implies-quasi-transitivity.yaml`.

#### Completeness ∧ Transitivity ∧ Independence ∧ Mixture continuity ⇒ Expected-utility representation — `vnm-theorem`

Proved result; source **Misc.**; legacy provenance human; produced by literature; checked by nobody; 2026-09-08.

Premises:

- Completeness (`completeness`)
- Transitivity (`transitivity`)
- Independence (`independence`)
- Mixture continuity (`continuity`)

Conclusion: Expected-utility representation (`eu-representation`)

Proof.

The von Neumann–Morgenstern theorem in the Herstein–Milnor mixture-set form.
Continuity plus weak order give, for any p ≽ q ≽ r with p ≻ r, a unique
λ with q ~ λp + (1−λ)r (connectedness of [0,1] and closedness of both
sections). Fix a best and a worst lottery (exist since X is finite and ≽
is a weak order respecting mixtures), define U(q) as that λ, and use
independence to show U is affine in mixtures; then u(x) = U(δ_x)
represents ≽ by expected utility.

Sources:

- von Neumann & Morgenstern (1944), Theory of Games and Economic Behavior, appendix
- Herstein & Milnor (1953), An axiomatic approach to measurable utility, Econometrica 21, Theorem 8
- Kreps (1988), Notes on the Theory of Choice, Theorem 5.15

Record: `topics/decision-theory/results/vnm-theorem.yaml`.

#### Weak order ⇒ Completeness — `weak-order-def-completeness`

Proved result; source **Misc.**; legacy provenance human; produced by definition; checked by nobody; 2026-09-08.

Premises:

- Weak order (`weak-order`)

Conclusion: Completeness (`completeness`)

Proof.

By definition of weak order.

Sources:

- (none recorded)

Record: `topics/decision-theory/results/weak-order-def-completeness.yaml`.

#### Completeness ∧ Transitivity ⇒ Weak order — `weak-order-def-forward`

Proved result; source **Misc.**; legacy provenance human; produced by definition; checked by nobody; 2026-09-08.

Premises:

- Completeness (`completeness`)
- Transitivity (`transitivity`)

Conclusion: Weak order (`weak-order`)

Proof.

By definition of weak order.

Sources:

- (none recorded)

Record: `topics/decision-theory/results/weak-order-def-forward.yaml`.

#### Weak order ⇒ Transitivity — `weak-order-def-transitivity`

Proved result; source **Misc.**; legacy provenance human; produced by definition; checked by nobody; 2026-09-08.

Premises:

- Weak order (`weak-order`)

Conclusion: Transitivity (`transitivity`)

Proof.

By definition of weak order.

Sources:

- (none recorded)

Record: `topics/decision-theory/results/weak-order-def-transitivity.yaml`.

### 4.2 Recorded conjectures

These are displayed but never used as evidence in any derivation below.

#### Transitivity ∧ Independence ∧ Archimedean ⇒ Mixture continuity — `archimedean-independence-imply-continuity`

Conjecture; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Premises:

- Transitivity (`transitivity`)
- Independence (`independence`)
- Archimedean (`archimedean`)

Conclusion: Mixture continuity (`continuity`)

No proof is recorded. This is a conjecture only.

Notes. Known with completeness added (Jensen 1967). Without it the cone K = {q − p : q ≽ p} is convex; the question is whether the Archimedean axiom forces it to be closed.

Sources:

- (none recorded)

Record: `topics/decision-theory/results/archimedean-independence-imply-continuity.yaml`.

#### Completeness ∧ Closed-graph continuity ∧ Betweenness ⇒ Transitivity — `betweenness-continuity-imply-transitivity`

Conjecture; source **Misc.**; legacy provenance human; produced by ZG; checked by nobody; 2026-09-08.

Premises:

- Completeness (`completeness`)
- Closed-graph continuity (`closed-graph-continuity`)
- Betweenness (`betweenness`)

Conclusion: Transitivity (`transitivity`)

No proof is recorded. This is a conjecture only.

Notes. Sample conjecture.

Sources:

- (none recorded)

Record: `topics/decision-theory/results/betweenness-continuity-imply-transitivity.yaml`.

## 5. Models

A model witnesses consistency, and so refutes every implication from what it satisfies to what it violates. Independence is never recorded directly; the model is the record.

### Band relation — `band-relation`

Model; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Satisfies:

- Completeness (`completeness`)
- Acyclicity (`acyclicity`)

Violates:

- Quasi-transitivity (`quasi-transitivity`)

Unknown in this model: Archimedean (`archimedean`), Betweenness (`betweenness`), Closed-graph continuity (`closed-graph-continuity`), Mixture continuity (`continuity`), Independence (`independence`)

Construction.

Fix u : X → ℝ non-constant and ε > 0. Define an asymmetric relation P by
p P q iff EU_u(p) − EU_u(q) ∈ (ε, 2ε], and let p ≽ q iff not q P p. Then
≽ is complete (P is asymmetric) and ≻ = P. P is acyclic because EU_u
strictly increases along any P-chain. But P is not transitive: with
EU_u(p), EU_u(q), EU_u(r) = 3ε, 1.5ε, 0 we have p P q and q P r while
EU_u(p) − EU_u(r) = 3ε ∉ (ε, 2ε].

Executable checks: `topics/decision-theory/checks/countermodels.py`.

Notes. Sanity-checked numerically in checks/countermodels.py. Not yet checked by a human.

Sources:

- (none recorded)

Record: `topics/decision-theory/models/band-relation.yaml`.

### Incomplete, continuous, non-Archimedean — `incomplete-continuous-non-archimedean`

Conjectured model; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Satisfies:

- Transitivity (`transitivity`)
- Mixture continuity (`continuity`)

Violates:

- Archimedean (`archimedean`)

Unknown in this model: nothing; every principle is settled.

Notes. Completeness is used essentially in continuity-completeness-imply-archimedean; no countermodel yet.

Sources:

- (none recorded)

Record: `topics/decision-theory/models/incomplete-continuous-non-archimedean.yaml`.

### Lexicographic EU — `lexicographic-eu`

Model; source **Misc.**; legacy provenance human; produced by literature; checked by nobody; 2026-09-08.

Satisfies:

- Completeness (`completeness`)
- Transitivity (`transitivity`)
- Independence (`independence`)

Violates:

- Mixture continuity (`continuity`)
- Archimedean (`archimedean`)

Unknown in this model: nothing; every principle is settled.

Construction.

Lexicographic expected utility. With X = {a, b, c} let p ≽ q iff
p(a) > q(a), or p(a) = q(a) and p(b) ≥ q(b). This is complete and
transitive (a lexicographic order on ℝ²), and satisfies independence
because mixing with r multiplies the vector of differences by λ, which
preserves lexicographic sign. But {λ : λδ_a + (1−λ)δ_c ≽ δ_b} = (0, 1],
which is not closed.

The same lexicographic order (p ≽ q iff p(a) > q(a), or p(a) = q(a) and
p(b) ≥ q(b)). Here δ_a ≻ δ_b ≻ δ_c, but every mixture βδ_a + (1−β)δ_c
with β > 0 puts positive weight on a and so is strictly preferred to
δ_b; no β with δ_b ≻ βδ_a + (1−β)δ_c exists.

Notes. Derivable from lexicographic-not-archimedean together with continuity-completeness-imply-archimedean (the validator reports it as redundant); kept because it is the form the literature states.

Sources:

- Hausner (1954), Multidimensional utilities, in Decision Processes (Thrall, Coombs & Davis eds.)
- Fishburn (1971), A study of lexicographic expected utility, Management Science 17
- Hausner (1954), Multidimensional utilities
- Fishburn (1971), A study of lexicographic expected utility, Management Science 17

Record: `topics/decision-theory/models/lexicographic-eu.yaml`.

### Non-convex cone — `non-convex-cone`

Model; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Satisfies:

- Completeness (`completeness`)
- Independence (`independence`)
- Closed-graph continuity (`closed-graph-continuity`)

Violates:

- Transitivity (`transitivity`)

Unknown in this model: Acyclicity (`acyclicity`), Quasi-transitivity (`quasi-transitivity`)

Construction.

Let X = {a, b, c} and identify a difference q − p of lotteries with the
point (q(a) − p(a), q(b) − p(b)) ∈ ℝ². Let C ⊆ ℝ² be the closed upper
half-plane together with the closed sector of directions [225°, 270°],
and define q ≽ p iff q − p ∈ C.

Completeness: C ∪ (−C) = ℝ² since −C contains the closed lower
half-plane. Independence: mixing both sides with r multiplies the
difference by λ > 0, and C is a cone. Closed graph: (p, q) ↦ q − p is
continuous and C is closed. Reflexivity: 0 ∈ C.

Transitivity fails: take x at direction 240° and y at direction 170°,
both in C and small enough that p, q = p + x… are lotteries; x + y has
direction ≈ 205°, which is not in C. So with q − p = x and r − q = y we
have q ≽ p and r ≽ q but not r ≽ p.

Executable checks: `topics/decision-theory/checks/countermodels.py`.

Notes. Sanity-checked numerically in checks/countermodels.py (completeness and independence hold, transitivity fails on random samples). Not yet checked by a human. Any non-convex closed cone C with C ∪ −C = ℝ² works.

Sources:

- (none recorded)

Record: `topics/decision-theory/models/non-convex-cone.yaml`.

### Rational levels — `rational-levels`

Model; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Satisfies:

- Completeness (`completeness`)
- Transitivity (`transitivity`)
- Archimedean (`archimedean`)

Violates:

- Mixture continuity (`continuity`)

Unknown in this model: Betweenness (`betweenness`), Independence (`independence`)

Construction.

Let X = {a, b, c} and define a three-valued function V on Δ(X):
V(p) = 2 if p(a) ∈ ℚ; V(p) = 1 if p(a) ∉ ℚ and p(b) ∈ ℚ; V(p) = 0
otherwise. Let p ≽ q iff V(p) ≥ V(q). This is a weak order.

Mixture continuity fails: along the line from δ_a to δ_b the mixture
λδ_a + (1−λ)δ_b has V = 2 exactly when λ ∈ ℚ, so
{λ : λδ_a + (1−λ)δ_b ≽ δ_c} = ℚ ∩ [0,1] is not closed.

Archimedean holds: a chain p ≻ q ≻ r forces V(p) = 2, V(q) = 1, V(r) = 0,
so p(a) ∈ ℚ and r(a) ∉ ℚ, in particular p(a) ≠ r(a). Along
m(α) = αp + (1−α)r the coordinate m(α)(a) = r(a) + α(p(a) − r(a)) is
rational for a dense set of α, so some α ∈ (0,1) close to 1 has
V(m(α)) = 2 > V(q). For the other half, m(β)(a) is irrational for all but
countably many β; and m(β)(b) = r(b) + β(p(b) − r(b)) is irrational for
all but countably many β when p(b) ≠ r(b), and equals r(b) ∉ ℚ when
p(b) = r(b) (because V(r) = 0). So some β ∈ (0,1) close to 0 has
V(m(β)) = 0 < V(q).

Notes. The construction is deliberately artificial: it shows that the Archimedean axiom cannot replace mixture continuity even for weak orders, unless something like independence is added. Not yet checked by a human.

Sources:

- (none recorded)

Record: `topics/decision-theory/models/rational-levels.yaml`.

### Semiorder — `semiorder`

Model; source **Misc.**; legacy provenance ai; produced by Claude Fable 5.1 (Cowork session); checked by nobody; 2026-09-08.

Satisfies:

- Completeness (`completeness`)
- Quasi-transitivity (`quasi-transitivity`)
- Closed-graph continuity (`closed-graph-continuity`)

Violates:

- Transitivity (`transitivity`)
- Independence (`independence`)

Unknown in this model: Betweenness (`betweenness`)

Construction.

A semiorder with a just-noticeable difference. Fix u : X → ℝ non-constant
and ε > 0, and let p ≽ q iff EU_u(p) ≥ EU_u(q) − ε. Completeness: one of
the two differences is ≥ 0 > −ε. Quasi-transitivity: p ≻ q iff
EU_u(p) > EU_u(q) + ε, and this is transitive. Closed graph: the graph is
the preimage of [−ε, ∞) under a continuous map. Transitivity fails: pick
p, q, r with EU_u equal to 0, −0.8ε, −1.6ε; then p ≽ q ≽ r but not p ≽ r.

Executable checks: `topics/decision-theory/checks/countermodels.py`.

Notes. Sanity-checked numerically in checks/countermodels.py. The relation is Luce's semiorder; the verification that it fits this framework is AI-produced and unchecked.

Sources:

- Luce (1956), Semiorders and a theory of utility discrimination, Econometrica 24

Record: `topics/decision-theory/models/semiorder.yaml`.

### SSB utility — `ssb`

Conjectured model; source **Misc.**; legacy provenance human; produced by ZG; checked by nobody; 2026-09-08.

Satisfies:

- Completeness (`completeness`)
- Closed-graph continuity (`closed-graph-continuity`)
- Archimedean (`archimedean`)

Violates:

- Transitivity (`transitivity`)
- Independence (`independence`)

Unknown in this model: nothing; every principle is settled.

Notes. Sample conjecture; which of betweenness and quasi-transitivity hold is to be checked.

Sources:

- Fishburn (1982), Nontransitive measurable utility, Journal of Mathematical Psychology 26

Record: `topics/decision-theory/models/ssb.yaml`.

### Unanimity over two utilities — `unanimity-two-utilities`

Model; source **Misc.**; legacy provenance human; produced by literature; checked by nobody; 2026-09-08.

Satisfies:

- Transitivity (`transitivity`)
- Independence (`independence`)
- Closed-graph continuity (`closed-graph-continuity`)
- Expected multi-utility representation (`multi-utility`)

Violates:

- Completeness (`completeness`)

Unknown in this model: Archimedean (`archimedean`)

Construction.

Unanimity over two utilities. With X = {a, b, c} let p ≽ q iff
p(a) ≥ q(a) and p(b) ≥ q(b) (U = {u₁, u₂} with u₁ = 1_a, u₂ = 1_b).
This is an expected multi-utility representation, hence transitive,
independent and closed-graph continuous; but δ_a and δ_b are
incomparable.

Sources:

- Aumann (1962), Utility theory without the completeness axiom, Econometrica 30
- Dubra, Maccheroni & Ok (2004), JET 115

Record: `topics/decision-theory/models/unanimity-two-utilities.yaml`.

### Weighted utility — `weighted-utility`

Model; source **Misc.**; legacy provenance human; produced by literature; checked by nobody; 2026-09-08.

Satisfies:

- Completeness (`completeness`)
- Transitivity (`transitivity`)
- Closed-graph continuity (`closed-graph-continuity`)
- Betweenness (`betweenness`)

Violates:

- Independence (`independence`)

Unknown in this model: nothing; every principle is settled.

Construction.

Weighted utility. Fix u : X → ℝ and a weight w : X → (0,∞) that is not
constant, and let V(p) = Σ p(x)w(x)u(x) / Σ p(x)w(x); put p ≽ q iff
V(p) ≥ V(q). V is continuous on Δ(X), so ≽ is a weak order with closed
graph. Its indifference sets are the intersections of Δ(X) with
hyperplanes {p : Σ p(x)w(x)(u(x) − v) = 0}, which are straight, so
betweenness holds. Since w is not constant these hyperplanes are not
parallel, so ≽ is not an expected-utility order and (being a continuous
weak order) must violate independence.

Sources:

- Chew (1983), A generalization of the quasilinear mean with applications to the measurement of income inequality and decision theory resolving the Allais paradox, Econometrica 51
- Dekel (1986), An axiomatic characterization of preferences under uncertainty: weakening the independence axiom, JET 40

Record: `topics/decision-theory/models/weighted-utility.yaml`.

## 6. Derived state

Computed from the proved records only, by the closure rules in `README.md`. Conjectures take no part. A missing entry means *not recorded*, not *false*.

### 6.1 Interderivable principles

No two principles are currently interderivable.

### 6.2 Settled single-premise implications (27)

| From | To | Via |
| --- | --- | --- |
| Closed-graph continuity | Mixture continuity | `closed-graph-implies-mixture-continuity` |
| Expected-utility representation | Acyclicity | `eu-implies-multi-utility`, `multi-utility-implies-transitivity`, `transitivity-implies-quasi-transitivity`, `quasi-transitivity-implies-acyclicity` |
| Expected-utility representation | Archimedean | `eu-implies-completeness`, `eu-implies-multi-utility`, `multi-utility-implies-closed-graph`, `closed-graph-implies-mixture-continuity`, `continuity-completeness-imply-archimedean` |
| Expected-utility representation | Betweenness | `eu-implies-multi-utility`, `multi-utility-implies-independence`, `independence-implies-betweenness` |
| Expected-utility representation | Closed-graph continuity | `eu-implies-multi-utility`, `multi-utility-implies-closed-graph` |
| Expected-utility representation | Completeness | `eu-implies-completeness` |
| Expected-utility representation | Mixture continuity | `eu-implies-multi-utility`, `multi-utility-implies-closed-graph`, `closed-graph-implies-mixture-continuity` |
| Expected-utility representation | Independence | `eu-implies-multi-utility`, `multi-utility-implies-independence` |
| Expected-utility representation | Expected multi-utility representation | `eu-implies-multi-utility` |
| Expected-utility representation | Quasi-transitivity | `eu-implies-multi-utility`, `multi-utility-implies-transitivity`, `transitivity-implies-quasi-transitivity` |
| Expected-utility representation | Transitivity | `eu-implies-multi-utility`, `multi-utility-implies-transitivity` |
| Expected-utility representation | Weak order | `eu-implies-completeness`, `eu-implies-multi-utility`, `multi-utility-implies-transitivity`, `weak-order-def-forward` |
| Independence | Betweenness | `independence-implies-betweenness` |
| Expected multi-utility representation | Acyclicity | `multi-utility-implies-transitivity`, `transitivity-implies-quasi-transitivity`, `quasi-transitivity-implies-acyclicity` |
| Expected multi-utility representation | Betweenness | `multi-utility-implies-independence`, `independence-implies-betweenness` |
| Expected multi-utility representation | Closed-graph continuity | `multi-utility-implies-closed-graph` |
| Expected multi-utility representation | Mixture continuity | `multi-utility-implies-closed-graph`, `closed-graph-implies-mixture-continuity` |
| Expected multi-utility representation | Independence | `multi-utility-implies-independence` |
| Expected multi-utility representation | Quasi-transitivity | `multi-utility-implies-transitivity`, `transitivity-implies-quasi-transitivity` |
| Expected multi-utility representation | Transitivity | `multi-utility-implies-transitivity` |
| Quasi-transitivity | Acyclicity | `quasi-transitivity-implies-acyclicity` |
| Transitivity | Acyclicity | `transitivity-implies-quasi-transitivity`, `quasi-transitivity-implies-acyclicity` |
| Transitivity | Quasi-transitivity | `transitivity-implies-quasi-transitivity` |
| Weak order | Acyclicity | `weak-order-def-transitivity`, `transitivity-implies-quasi-transitivity`, `quasi-transitivity-implies-acyclicity` |
| Weak order | Completeness | `weak-order-def-completeness` |
| Weak order | Quasi-transitivity | `weak-order-def-transitivity`, `transitivity-implies-quasi-transitivity` |
| Weak order | Transitivity | `weak-order-def-transitivity` |

### 6.3 Refuted single-premise implications (81)

Read *A ⇏ B*: assuming A alone does not yield B, as the named model shows.

| From | To | Witness model |
| --- | --- | --- |
| Acyclicity | Archimedean | `lexicographic-eu` |
| Acyclicity | Closed-graph continuity | `lexicographic-eu`, `rational-levels` |
| Acyclicity | Completeness | `unanimity-two-utilities` |
| Acyclicity | Mixture continuity | `lexicographic-eu`, `rational-levels` |
| Acyclicity | Expected-utility representation | `band-relation`, `lexicographic-eu`, `rational-levels`, `semiorder`, `unanimity-two-utilities`, `weighted-utility` |
| Acyclicity | Independence | `semiorder`, `weighted-utility` |
| Acyclicity | Expected multi-utility representation | `band-relation`, `lexicographic-eu`, `rational-levels`, `semiorder`, `weighted-utility` |
| Acyclicity | Quasi-transitivity | `band-relation` |
| Acyclicity | Transitivity | `band-relation`, `semiorder` |
| Acyclicity | Weak order | `band-relation`, `semiorder`, `unanimity-two-utilities` |
| Archimedean | Closed-graph continuity | `rational-levels` |
| Archimedean | Mixture continuity | `rational-levels` |
| Archimedean | Expected-utility representation | `non-convex-cone`, `rational-levels`, `semiorder`, `weighted-utility` |
| Archimedean | Independence | `semiorder`, `weighted-utility` |
| Archimedean | Expected multi-utility representation | `non-convex-cone`, `rational-levels`, `semiorder`, `weighted-utility` |
| Archimedean | Transitivity | `non-convex-cone`, `semiorder` |
| Archimedean | Weak order | `non-convex-cone`, `semiorder` |
| Betweenness | Archimedean | `lexicographic-eu` |
| Betweenness | Closed-graph continuity | `lexicographic-eu` |
| Betweenness | Completeness | `unanimity-two-utilities` |
| Betweenness | Mixture continuity | `lexicographic-eu` |
| Betweenness | Expected-utility representation | `lexicographic-eu`, `non-convex-cone`, `unanimity-two-utilities`, `weighted-utility` |
| Betweenness | Independence | `weighted-utility` |
| Betweenness | Expected multi-utility representation | `lexicographic-eu`, `non-convex-cone`, `weighted-utility` |
| Betweenness | Transitivity | `non-convex-cone` |
| Betweenness | Weak order | `non-convex-cone`, `unanimity-two-utilities` |
| Closed-graph continuity | Completeness | `unanimity-two-utilities` |
| Closed-graph continuity | Expected-utility representation | `non-convex-cone`, `semiorder`, `unanimity-two-utilities`, `weighted-utility` |
| Closed-graph continuity | Independence | `semiorder`, `weighted-utility` |
| Closed-graph continuity | Expected multi-utility representation | `non-convex-cone`, `semiorder`, `weighted-utility` |
| Closed-graph continuity | Transitivity | `non-convex-cone`, `semiorder` |
| Closed-graph continuity | Weak order | `non-convex-cone`, `semiorder`, `unanimity-two-utilities` |
| Completeness | Archimedean | `lexicographic-eu` |
| Completeness | Closed-graph continuity | `lexicographic-eu`, `rational-levels` |
| Completeness | Mixture continuity | `lexicographic-eu`, `rational-levels` |
| Completeness | Expected-utility representation | `band-relation`, `lexicographic-eu`, `non-convex-cone`, `rational-levels`, `semiorder`, `weighted-utility` |
| Completeness | Independence | `semiorder`, `weighted-utility` |
| Completeness | Expected multi-utility representation | `band-relation`, `lexicographic-eu`, `non-convex-cone`, `rational-levels`, `semiorder`, `weighted-utility` |
| Completeness | Quasi-transitivity | `band-relation` |
| Completeness | Transitivity | `band-relation`, `non-convex-cone`, `semiorder` |
| Completeness | Weak order | `band-relation`, `non-convex-cone`, `semiorder` |
| Mixture continuity | Completeness | `unanimity-two-utilities` |
| Mixture continuity | Expected-utility representation | `non-convex-cone`, `semiorder`, `unanimity-two-utilities`, `weighted-utility` |
| Mixture continuity | Independence | `semiorder`, `weighted-utility` |
| Mixture continuity | Expected multi-utility representation | `non-convex-cone`, `semiorder`, `weighted-utility` |
| Mixture continuity | Transitivity | `non-convex-cone`, `semiorder` |
| Mixture continuity | Weak order | `non-convex-cone`, `semiorder`, `unanimity-two-utilities` |
| Independence | Archimedean | `lexicographic-eu` |
| Independence | Closed-graph continuity | `lexicographic-eu` |
| Independence | Completeness | `unanimity-two-utilities` |
| Independence | Mixture continuity | `lexicographic-eu` |
| Independence | Expected-utility representation | `lexicographic-eu`, `non-convex-cone`, `unanimity-two-utilities` |
| Independence | Expected multi-utility representation | `lexicographic-eu`, `non-convex-cone` |
| Independence | Transitivity | `non-convex-cone` |
| Independence | Weak order | `non-convex-cone`, `unanimity-two-utilities` |
| Expected multi-utility representation | Completeness | `unanimity-two-utilities` |
| Expected multi-utility representation | Expected-utility representation | `unanimity-two-utilities` |
| Expected multi-utility representation | Weak order | `unanimity-two-utilities` |
| Quasi-transitivity | Archimedean | `lexicographic-eu` |
| Quasi-transitivity | Closed-graph continuity | `lexicographic-eu`, `rational-levels` |
| Quasi-transitivity | Completeness | `unanimity-two-utilities` |
| Quasi-transitivity | Mixture continuity | `lexicographic-eu`, `rational-levels` |
| Quasi-transitivity | Expected-utility representation | `lexicographic-eu`, `rational-levels`, `semiorder`, `unanimity-two-utilities`, `weighted-utility` |
| Quasi-transitivity | Independence | `semiorder`, `weighted-utility` |
| Quasi-transitivity | Expected multi-utility representation | `lexicographic-eu`, `rational-levels`, `semiorder`, `weighted-utility` |
| Quasi-transitivity | Transitivity | `semiorder` |
| Quasi-transitivity | Weak order | `semiorder`, `unanimity-two-utilities` |
| Transitivity | Archimedean | `lexicographic-eu` |
| Transitivity | Closed-graph continuity | `lexicographic-eu`, `rational-levels` |
| Transitivity | Completeness | `unanimity-two-utilities` |
| Transitivity | Mixture continuity | `lexicographic-eu`, `rational-levels` |
| Transitivity | Expected-utility representation | `lexicographic-eu`, `rational-levels`, `unanimity-two-utilities`, `weighted-utility` |
| Transitivity | Independence | `weighted-utility` |
| Transitivity | Expected multi-utility representation | `lexicographic-eu`, `rational-levels`, `weighted-utility` |
| Transitivity | Weak order | `unanimity-two-utilities` |
| Weak order | Archimedean | `lexicographic-eu` |
| Weak order | Closed-graph continuity | `lexicographic-eu`, `rational-levels` |
| Weak order | Mixture continuity | `lexicographic-eu`, `rational-levels` |
| Weak order | Expected-utility representation | `lexicographic-eu`, `rational-levels`, `weighted-utility` |
| Weak order | Independence | `weighted-utility` |
| Weak order | Expected multi-utility representation | `lexicographic-eu`, `rational-levels`, `weighted-utility` |

### 6.4 Open single-premise pairs (24)

Listed in `OPEN-QUESTIONS.md`.

### Negative implications (0)

Read A ⇒ ¬B: A and B cannot hold together. This does not by itself witness a model of A.

None.

### 6.5 What the recorded premise packages entail

Every multi-premise package used by a proved result, with its full consequence set.

#### Completeness + Transitivity + Independence + Mixture continuity

Assumes: `completeness`, `transitivity`, `independence`, `continuity`.

- Rules out (entails their negations): nothing further
- Entails: Acyclicity (`acyclicity`), Archimedean (`archimedean`), Betweenness (`betweenness`), Closed-graph continuity (`closed-graph-continuity`), Expected-utility representation (`eu-representation`), Expected multi-utility representation (`multi-utility`), Quasi-transitivity (`quasi-transitivity`), Weak order (`weak-order`)
- Refuted (a model satisfies the package and violates these): nothing
- Open: nothing

#### Transitivity + Independence + Closed-graph continuity

Assumes: `transitivity`, `independence`, `closed-graph-continuity`.

- Rules out (entails their negations): nothing further
- Entails: Acyclicity (`acyclicity`), Betweenness (`betweenness`), Mixture continuity (`continuity`), Expected multi-utility representation (`multi-utility`), Quasi-transitivity (`quasi-transitivity`)
- Refuted (a model satisfies the package and violates these): Completeness (`completeness`), Expected-utility representation (`eu-representation`), Weak order (`weak-order`)
- Open: Archimedean (`archimedean`)

#### Transitivity + Independence + Mixture continuity

Assumes: `transitivity`, `independence`, `continuity`.

- Rules out (entails their negations): nothing further
- Entails: Acyclicity (`acyclicity`), Betweenness (`betweenness`), Closed-graph continuity (`closed-graph-continuity`), Expected multi-utility representation (`multi-utility`), Quasi-transitivity (`quasi-transitivity`)
- Refuted (a model satisfies the package and violates these): Completeness (`completeness`), Expected-utility representation (`eu-representation`), Weak order (`weak-order`)
- Open: Archimedean (`archimedean`)

#### Mixture continuity + Completeness

Assumes: `continuity`, `completeness`.

- Rules out (entails their negations): nothing further
- Entails: Archimedean (`archimedean`)
- Refuted (a model satisfies the package and violates these): Expected-utility representation (`eu-representation`), Independence (`independence`), Expected multi-utility representation (`multi-utility`), Transitivity (`transitivity`), Weak order (`weak-order`)
- Open: Acyclicity (`acyclicity`), Betweenness (`betweenness`), Closed-graph continuity (`closed-graph-continuity`), Quasi-transitivity (`quasi-transitivity`)

#### Completeness + Transitivity

Assumes: `completeness`, `transitivity`.

- Rules out (entails their negations): nothing further
- Entails: Acyclicity (`acyclicity`), Quasi-transitivity (`quasi-transitivity`), Weak order (`weak-order`)
- Refuted (a model satisfies the package and violates these): Archimedean (`archimedean`), Closed-graph continuity (`closed-graph-continuity`), Mixture continuity (`continuity`), Expected-utility representation (`eu-representation`), Independence (`independence`), Expected multi-utility representation (`multi-utility`)
- Open: Betweenness (`betweenness`)

## 8. Where this came from

Source documents are in `topics/decision-theory/sources/`. The extraction log, with transcription decisions and deliberately deferred items, is `topics/decision-theory/extraction.md`. Read it before trusting any single page reference.
