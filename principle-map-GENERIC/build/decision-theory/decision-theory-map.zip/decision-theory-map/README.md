# Preference axioms over lotteries — working bundle

A self-contained copy of one principle map: the axioms of a subject, the implications between them, the countermodels that refute the remaining implications, and the proofs for all of it. Unzip anywhere and start working.

Contains 12 principles, 16 proved results, 2 conjectures and 9 models, with the source documents they were extracted from.

## Read in this order

1. **`MAP.md`** — everything, in one file: framework, principle statements, every proof, every model construction, and the derived verdicts. Start here.
2. **`OPEN-QUESTIONS.md`** — what the map does not settle, grouped so each entry is a concrete piece of work.
3. **`topics/decision-theory/extraction.md`** — how the records were read out of the sources, which transcription decisions were made, and what was deliberately left out.
4. **`topics/decision-theory/sources/`** — the original papers.

`data.json` and `derived.json` hold the same content structured, if you would rather compute over it than read it.

## Layout

```
MAP.md OPEN-QUESTIONS.md      the map as prose
data.json derived.json        records, and every derived verdict
topics/decision-theory/
  topic.yaml                  title, source catalog, categories, viewer packages
  background.md               the framework in full
  extraction.md               source inventory, transcription decisions, deferred items
  principles/<id>.yaml        one principle per file
  results/<id>.yaml           premises ⇒ conclusion, with its proof
  models/<id>.yaml            satisfies [...] / violates [...]
  writeups/<id>.md            hand-written write-up, overrides the generated one
  checks/                     executable sanity checks for the models
  sources/                    original papers
scripts/pmap.py schema/ viewer/  the tooling, so validate and build work here
```

## Semantics

Everything is relative to the topic background B (see `MAP.md` §1).

- A **result** is a Horn clause, premises ⇒ conclusion. `cl(S)` is the closure of B ∪ S under all proved results.
- A **model** M records `sat(M)` and `viol(M)` and witnesses that `sat(M) ∪ {¬v : v ∈ viol(M)}` is consistent. Derived: `holds(M) = cl(sat(M))`, and `fails(M) = {c : cl(sat(M) ∪ {c}) ∩ viol(M) ≠ ∅}`. Everything else is unknown in M.
- **P ⇒ c** iff `c ∈ cl(P)`. **P ⇏ c** iff some model has `P ⊆ holds(M)` and `c ∈ fails(M)`. Otherwise the pair is **open**.
- Mutually derivable principles collapse to one node.
- Conjectures are displayed but never used as evidence.
- `holds(M) ∩ viol(M) ≠ ∅` is a validation error, not a discovery.

**A missing arrow means nothing was recorded.** The map is curated, not exhaustive.

## Adding to it

```yaml
# topics/decision-theory/results/<id>.yaml   —   file name must equal the id
id: my-new-result
premises: [principle-a, principle-b]     # every assumption actually used
conclusion: principle-c
status: proved                            # or: conjectured
certificate:
  source_id: misc                         # a source_catalog id; misc for original work
  lean: none
  produced_by: "who proved the mathematics"
  recorded_by: "who transcribed it"       # optional, kept separate
  checked_by: []                          # only actual checkers
  date: 'YYYY-MM-DD'
proof: |
  The argument, at the level of detail a referee would want.
sources:
  - Full reference, with theorem or section and page.
source_names: [Short label]               # one per source, same order
notes: ""
```

```yaml
# topics/decision-theory/models/<id>.yaml
id: my-new-model
name: Human-readable name
satisfies: [principle-a, principle-b]     # only what you actually verified
violates: [principle-c]                   # the engine derives the rest
status: proved
certificate: {source_id: misc, lean: none, produced_by: "...", checked_by: [], date: 'YYYY-MM-DD'}
description: |
  The construction, and why it has these properties.
sources: [Full reference or an identifiable original proof]
source_names: [Short label]
```

Independences are **only** ever recorded as models. Never as a result.

## Sourcing rules

These are what make the map worth anything. Follow them exactly.

- Every result and model needs a nonempty `sources`. Give the paper with theorem/section and page, or an identifiable original proof for new work.
- `certificate.source_id` names the **direct** source. Declared sources here:
- Use `misc` for original proofs, one-off prompts and user suggestions. Citing a paper's definitions does **not** make that paper the source of your new proof.
- `produced_by` credits the mathematics; `recorded_by` credits transcription only.
- Leave `checked_by: []` unless a named person actually checked it. A human-authored source does not mean a human checked this database's translation of it.
- Never invent an author, a date, a page or a submission label. If you are unsure of a reference, say so in `notes` rather than guessing.
- If you are unsure of the mathematics, record `status: conjectured` with an empty proof and write in `notes` what would settle it. That is a useful contribution; a wrong `proved` is not.
- Do not change the mathematical content of an existing published or human-authored proof. Add a note, or a new record, instead.
- File name equals `id`, kebab-case. Never rename an id that other files reference.
- Keep the framework fixed. A principle needing a different setting belongs to a different topic.

## Lean

If `topics/decision-theory/lean/` is present, the topic has a formalisation. The YAML is the
source of truth for statements: each principle names its Lean definition in `lean_def`,
and every result and model statement is generated from its premises and conclusion into
`Statements.lean`. To prove a record, inhabit its generated `Prop`. Never edit the
generated file, and never hand-set `lean: verified` -- `pmap lean-check` builds the
library, confirms the proof inhabits the generated statement, and rejects anything
still depending on `sorryAx`. `lean: stated` means the statement elaborates and the
proof is missing. See that folder's README for the modelling choices.

## Commands

```sh
pip install -r requirements.txt
python3 scripts/pmap.py validate            # schema, references, consistency. Must pass.
python3 scripts/pmap.py status              # counts, open pairs, redundancies
python3 topics/decision-theory/checks/countermodels.py   # numerical checks of the models
python3 scripts/pmap.py build --no-pdf      # regenerate build/<topic>/index.html, the map viewer
python3 scripts/pmap.py selftest            # the derivation engine's own tests
python3 scripts/pmap.py lean                # regenerate the Lean statements
python3 scripts/pmap.py lean-check          # build the Lean library and audit lean: claims
```

A `CONTRADICTION` from `validate` means the data is inconsistent and must be fixed before anything else. Rerun `validate` after every batch of edits.

## Sending work back

The whole of `topics/decision-theory/` is portable: copy it back over the same folder in the main repository, or send the individual new YAML files. Nothing outside that folder needs to change.
