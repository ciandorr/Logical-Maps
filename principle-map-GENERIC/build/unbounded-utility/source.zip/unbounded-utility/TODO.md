# Unbounded Utility — to-do

- [x] Add universal/existential copula sum invariance principles — one common copula for (X,Z) and (Y,Z), universally quantified or chosen once for all triples; definitions and connecting results added 9 September 2026.
- [ ] Set up contribution protocol (`contribute.md`)
- [ ] Fix and write background (`background.md`, `extraction.md`)
- [ ] Fix Lean setup (see `lean/REVIEW.md`)
- [ ] Execute Lean formalization (`lean/`)
- [ ] Rename Models tab
- [ ] Format according to website
