# Unbounded Utility — complete map

Topic `unbounded-utility`. Generated 2026-09-09T05:30:47+00:00.

38 principles, 79 proved results, 4 recorded conjectures, 13 models.

This file is self-contained. Every principle statement, every proof, every model construction and every derived verdict in the database is reproduced below. `README.md` gives the semantics and the rules for adding to it; `OPEN-QUESTIONS.md` lists what is not settled.


Logical map of decision-theoretic principles when utility is unbounded.

## 1. Framework


Gambles are measurable outcome-valued random variables on an atomless standard probability space. All such variables are available (Prospect Richness is standing). ≽ is reflexive and transitive, not assumed total or law-invariant. Outcomes are linearly ordered, with distinct reference outcomes 0 and 1, and sure-indifferent outcomes identified. A possibly partial real utility chart is defined by binary certainty comparisons; see background.md. Rich Outcomes supplies all real levels; Archimedean Outcomes rules out outcomes beyond the finite chart. M_p(X,Y) is randomized selection, never the pointwise sum pX+(1-p)Y.

**Notation.** X ≽ Y; X ≻ Y iff X ≽ Y and not Y ≽ X; X ~ Y iff both. L(X) is the law, X|E is X on E and sure 0 elsewhere. Numerical expressions use the normalized utility chart.

**Fixed background assumptions.** None. Every principle below is optional and must be assumed explicitly.

**Named package `du` (DU).** Rich Outcomes (`rich-outcomes`), Archimedean Outcomes (`archimedean-outcomes`), Stochastic Equivalence (`stochastic-equivalence`), Stochastic Dominance (`stochastic-dominance`), Mixture Independence (`independence`). Loaded by default in the viewer.

**Named package `dtu` (DTU).** Rich Outcomes (`rich-outcomes`), Archimedean Outcomes (`archimedean-outcomes`), Totality (`totality`), Stochastic Equivalence (`stochastic-equivalence`), Stochastic Dominance (`stochastic-dominance`), Mixture Independence (`independence`).

## 2. Background and standing conventions

*Reproduced from `topics/unbounded-utility/background.md`.*

This map records logical connections between principles analysed in my **Decision theory unbound** (2024) and **Symmetries of value** (2026), as well as an unpublished work-in-progress called **Unbounded Utility and Background Risk**.

### Setup

A gamble is a measurable **outcome-valued random variable** X on a fixed
atomless standard probability space, which can be represented by [0,1] with
Lebesgue measure or by countably many independent fair coin tosses. All such
variables are available. 

The primitive preference relation ≽ on gambles is always assumed reflexive and transitive. Outcomes are ordered by preference over certain gambles. Indifferent outcomes are identified. The optional Outcome Richness axiom says there are outcomes of every real utility value, and the optional Archimedean axiom says that there are no infinitesimal or infinite difference in utility levels.

The theory **DU** is the weakest background considered in my papers. In addition to Outcome Richness and Archimedean axioms, it has:
(a) The Sure-Thing principle/Independence.
(b) Stochastic Equivalence (equally distributed gambles are equally good).
(c) Statewise Dominance.

**DU does not assume Totality for arbitrary gambles. DTU is DU plus Totality.**
Restricted Totality concerns only simple gambles and is compatible with DU
leaving other pairs incomparable.

The map's removable DU preset assumes Rich Outcomes, Archimedean Outcomes,
Stochastic Equivalence, Stochastic Dominance and Mixture Independence.
**Simple Expected Utility is derived rather than assumed.** Its
[recorded derivation](topics/unbounded-utility/writeups/rich-archimedean-dominance-independence-imply-simple-eu.html)
uses Rich Outcomes, Archimedean Outcomes, Stochastic Dominance and Mixture
Independence. Rich Outcomes and Archimedean Outcomes alone are not claimed
to imply it. Simple EU then supplies Restricted Totality.

The distribution-based formulation in *Decision theory unbound*, §3.3,
pp. 681–682, instead assumes Simple Expected Utility. With the other DU
assumptions, this is equivalent to the preset: the new derivation gives
Simple EU, and Simple EU conversely implies Archimedean Outcomes. Rich
Outcomes and Stochastic Equivalence remain separately selectable in this map.
The DTU preset adds Totality; only DU is selected by default.

Long conjunctions are abbreviated as DU or DTU where the recorded premises
give the same assumptions. The full conjunction remains available in the
pop-up and the individual premises in the result write-up.

Research summaries use these names consistently. Individual result write-ups
always list their exact premises, which may be weaker than either package.

### Literature

SSK preference for equivalent.

Russell n Isaacs

Easwaran

etc. (add relevant citations).

## 3. Principles

### Basic decision theory

#### Archimedean Gambles — `archimedean-gambles`


For any gambles X ≻ Y ≻ Z, there is p ∈ (0,1) with Y ~ M_p(X,Z). Unlike Archimedean Outcomes, X,Y,Z may themselves be unbounded gambles.

Tags: mixture, continuity.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 22, footnote 3

#### Archimedean Outcomes — `archimedean-outcomes`


For any three sure outcomes a ≻ b ≻ c, some nontrivial mixture of the outer two is equally good as the intermediate one: b ~ M_p(a,c) for some p ∈ (0,1). Only the three inputs are sure outcomes. This is the no-infinite-ratios condition, not continuity of preferences over arbitrary gambles.

Formal: `a ≻ b ≻ c ⇒ ∃p∈(0,1): b ~ M_p(a,c)`

Tags: outcomes.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 22, footnote 3
- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 678

#### Countable Sure-Thing — `countable-sure-thing`


For every countable measurable partition (E_n) into events of positive probability, if X|E_n ≽ Y|E_n for every n, then X ≽ Y. If one conditional comparison is strict, X ≻ Y.

Tags: conditioning, countable.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.2, p. 674

#### Mixture Independence — `independence`


For all X,Y,Z and 0<p<1, X ≽ Y iff M_p(X,Z) ≽ M_p(Y,Z), where M is the fixed randomized-selection construction described in the background.

Formal: `X ≽ Y ⇔ M_p(X,Z) ≽ M_p(Y,Z)`

Tags: mixture.

Notes. Mixture identities are identities in law; without Stochastic Equivalence they cannot be substituted as preference identities. Bridges to Sure-Thing explicitly retain Stochastic Equivalence.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 679
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 23

#### L¹ Continuity (random variables) — `l1-continuity`


On variables with real utility levels, if E|u(X_n)−u(X)| → 0 and X_n ≽ Y for every n, then X ≽ Y. Only the upper-section clause is imposed, matching the paper. Distance can be infinite between other pairs.

Formal: `E|u(X_n)−u(X)|→0 and ∀n X_n ≽ Y ⇒ X ≽ Y`

Tags: continuity.

Notes. Uses the actual coupling of random variables, so does not build in law invariance. With Stochastic Equivalence and the standing availability of all variables this is equivalent to the paper’s extended Wasserstein-1 (infimum-over-couplings) formulation; see writeups/l1-translation.md.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 23

#### Restricted Stochastic Equivalence — `restricted-stochastic-equivalence`


If simple gambles X,Y have the same law, then X ~ Y.

Tags: distribution, finite.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.3, p. 675

#### Restricted Totality — `restricted-totality`


Every two simple (finite-valued) gambles are comparable. Outcome comparability is already standing in this topic.

Tags: ordering, finite.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.3, p. 675

#### Rich Outcomes — `rich-outcomes`


Every real number r occurs as a utility level of a sure outcome: for each r ∈ ℝ there is an outcome o_r with u(o_r)=r, with u defined by the normalized binary-mixture comparisons in the background. This does not assert that every outcome has a finite real level.

Formal: `∀r∈ℝ ∃o∈O_fin: u(o)=r`

Tags: outcomes.

Notes. Stronger than merely having no upper bound. Kept separate from Archimedean Outcomes at the user’s request. No Rich Outcomes ⇒ Archimedean Outcomes edge is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.2, p. 673 (called Unbounded Utility)
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, pp. 22–23

#### Simple Expected Utility — `simple-eu`


The normalized real utility chart u is defined on every outcome, is measurable, and ranks every pair of simple random variables exactly by finite expected utility: X ≽ Y iff E[u(X)] ≥ E[u(Y)]. Surjectivity of u is not included here.

Formal: `X,Y simple ⇒ (X ≽ Y ⇔ E[u(X)] ≥ E[u(Y)])`

Tags: expectation, finite.

Notes. The papers sometimes bundle a bijective representation with Simple EUT. Here its surjectivity is split out as Rich Outcomes. This principle does entail Archimedean Outcomes.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 680
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 23

#### Statewise Dominance — `statewise-dominance`


If X ≥ Y almost surely in the sure-outcome order, then X ≽ Y; if also P(X>Y)>0, then X ≻ Y.

Tags: dominance.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, pp. 678–679

#### Stochastic Dominance — `stochastic-dominance`


If P(X>o) ≥ P(Y>o) for every outcome threshold o, then X ≽ Y; if one threshold inequality is strict, X ≻ Y. Thresholds use the sure-outcome order.

Tags: dominance, distribution.

Notes. Includes the weak clause, as in the random-variable statement of the 2024 paper. The 2026 distribution formulation writes only the strict clause because equality of laws has already been identified there.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 678

#### Stochastic Equivalence — `stochastic-equivalence`


If X and Y have the same probability law over outcomes, then X ~ Y. The variables remain distinct objects; indifference is an additional axiom.

Formal: `L(X)=L(Y) ⇒ X ~ Y`

Tags: distribution.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.2, p. 674

#### Sure-Thing — `sure-thing`


For an event E with 0<P(E)<1, if X|E ~ Y|E, then X ≽ Y iff X|Eᶜ ≽ Y|Eᶜ. Here X|E equals X on E and sure 0 elsewhere; it is not a conditional expectation.

Tags: conditioning.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.2, p. 673

#### Totality — `totality`


For all gambles X,Y, either X ≽ Y or Y ≽ X.

Tags: ordering.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.2, p. 673

### Invariance principles

#### Antitonic Sum Invariance — `antitonic-sum-consistency`


If X and Z are antitonic, and Y and Z are antitonic, then X ≽ Y iff X+Z ≽ Y+Z. A pair is antitonic when one member is nondecreasing and the other nonincreasing in a common uniform random variable.

Tags: background-risk.

Notes. Numerical scope: real-utility variables for which the indicated sums exist in the outcome chart. These are pointwise utility sums, not randomized mixtures. Stochastic Equivalence remains a separate principle. On laws, use Q_X(U)+Q_Z(1−U). Constant variables count as both comonotonic and antitonic. Atoms are handled by quantiles up to null sets.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.2, p. 18; Theorem 6, p. 19

#### Comonotonic Sum Invariance — `comonotonic-sum-consistency`


If X and Z are comonotonic, and Y and Z are comonotonic, then X ≽ Y iff X+Z ≽ Y+Z. A pair is comonotonic when its members admit nondecreasing representations in one common uniform random variable.

Tags: background-risk.

Notes. Numerical scope: real-utility variables for which the indicated sums exist in the outcome chart. These are pointwise utility sums, not randomized mixtures. Stochastic Equivalence remains a separate principle. On laws the sums are represented by Q_X(U)+Q_Z(U) and Q_Y(U)+Q_Z(U), using increasing quantiles. No law-invariance of preferences is built into this node.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.2, p. 18; Theorem 7, pp. 19–20

#### Existential Copula Sum Invariance — `existential-copula-sum-consistency`


There exists one copula C such that SC(C) holds for all eligible X,Y,Z. The copula is chosen once for the preference relation, independently of the triple and its marginal laws. A copula C is a Borel probability measure on [0,1]² with both marginals uniform. Write H_C(u,v)=C([0,u]×[0,v]). A real-utility pair (A,B) admits C when P(A≤a,B≤b)=H_C(F_A(a),F_B(b)) for every real a,b. Define SC(C): for every eligible triple X,Y,Z for which both (X,Z) and (Y,Z) admit this same C, X ≽ Y iff X+Z ≽ Y+Z.

Formal: `∃ C ∈ Cop₂, SC(C).`

Tags: background-risk, copula.

Notes. Numerical scope: variables in the finite real utility chart for which both pointwise sums exist as gambles. The copula fixes dependence, not the marginal utility distributions. With atoms a pair may admit several copulas; require the displayed compatibility condition, not a uniquely assigned copula. Preferences compare the actual random variables, not their laws or equivalence classes; no indifference of same-law variables is assumed. The dependence condition concerns each pair separately and places no extra condition on the joint law of (X,Y,Z). Proposal: Zachary Goodsell; precise recording: GPT-6 (Codex), 9 September 2026.

Sources:

- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).
- **Copula Measures and Sklar’s Theorem (definitions)** — Fred Espen Benth, Giulia Di Nunno and Dennis Schroers, Copula Measures and Sklar’s Theorem in Arbitrary Dimensions, arXiv:2012.11530v2, Definition 2.1 and Theorem 2.3; https://arxiv.org/html/2012.11530v2. Reference for copula terminology only, not these preference principles or implication proofs.

#### Full Sum Invariance — `full-sum-consistency`


For all X,Y,Z, with arbitrary dependence, X ≽ Y iff X+Z ≽ Y+Z.

Tags: background-risk.

Notes. Numerical scope: real-utility variables for which the indicated sums exist in the outcome chart. These are pointwise utility sums, not randomized mixtures. Stochastic Equivalence remains a separate principle.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §1, pp. 1–2; §6.1, p. 17

#### Independent Sum Cancellation — `independent-sum-cancellation`


Whenever Z is independent of (X,Y), X+Z ≽ Y+Z implies X ≽ Y.

Tags: background-risk.

Notes. Numerical scope: real-utility variables for which the indicated sums exist in the outcome chart. These are pointwise utility sums, not randomized mixtures. Stochastic Equivalence remains a separate principle. Extracted as an optional axiom, not accepted as a theorem about the CDF-area construction. Convolution can mix positive and negative contributions; the printed proof does not establish cancellation.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; Lemma 1, p. 8 (reverse direction, proof gap)

#### Independent Sum Invariance — `independent-sum-consistency`


Whenever Z is independent of the pair (X,Y), X ≽ Y iff X+Z ≽ Y+Z.

Tags: background-risk.

Notes. Numerical scope: real-utility variables for which the indicated sums exist in the outcome chart. These are pointwise utility sums, not randomized mixtures. Stochastic Equivalence remains a separate principle. With Stochastic Equivalence and the full real domain this is the manuscript’s Convolution Invariance: compare the two laws before and after convolution by the same probability law. Joint independence supplies a canonical common-noise realization; it does not assume that X and Y are independent.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §1, pp. 1–4; §2, p. 6

#### Independent Sum Preservation — `independent-sum-preservation`


Whenever Z is independent of (X,Y), X ≽ Y implies X+Z ≽ Y+Z, and X ≻ Y implies X+Z ≻ Y+Z.

Tags: background-risk.

Notes. Numerical scope: real-utility variables for which the indicated sums exist in the outcome chart. These are pointwise utility sums, not randomized mixtures. Stochastic Equivalence remains a separate principle. An explicit separation of the valid forward part of the source’s convolution claim. Weak preservation alone would not ensure preservation of strict preference.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; Lemma 1, pp. 7–8 (forward direction)

#### Negative Affine Anti-Invariance — `negative-affine-anti-invariance`


For all real a>0 and b, X ≽ Y iff −aY+b ≽ −aX+b.

Tags: symmetry.

Notes. Arithmetic uses the utility chart, on finite-level variables with the required transformed outcomes available. The source’s full ℝ setting is supplied by Rich Outcomes and Simple EU in theorem packages.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.2, pp. 686–688
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

#### Positive Affine Invariance — `positive-affine-invariance`


For all real a>0 and b, X ≽ Y iff aX+b ≽ aY+b.

Tags: symmetry.

Notes. Arithmetic uses the utility chart, on finite-level variables with the required transformed outcomes available. The source’s full ℝ setting is supplied by Rich Outcomes and Simple EU in theorem packages.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.2, pp. 686–688
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

#### Reflection Anti-Invariance — `reflection-anti-invariance`


X ≽ Y iff −Y ≽ −X, using the one fixed normalized origin 0.

Tags: symmetry.

Notes. Arithmetic changes outcomes via their utility levels; it is not a relabeling of the utility function. Applies to finite-level variables when the indicated outcome transformation is available. Full-group implications explicitly assume Rich Outcomes. Reflection reverses the comparison; the displayed same-direction sign on p. 24 of Symmetries is a source typo, as its other definitions and proofs confirm.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.2, pp. 686–688
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

#### Scale Invariance — `scale-invariance`


For every real a>0, X ≽ Y iff aX ≽ aY.

Tags: symmetry.

Notes. Arithmetic uses the utility chart, on finite-level variables with the required transformed outcomes available. The source’s full ℝ setting is supplied by Rich Outcomes and Simple EU in theorem packages.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.2, pp. 686–688
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

#### Shift Invariance — `shift-invariance`


For every real b, X ≽ Y iff X+b ≽ Y+b.

Tags: symmetry.

Notes. Arithmetic uses the utility chart, on finite-level variables with the required transformed outcomes available. The source’s full ℝ setting is supplied by Rich Outcomes and Simple EU in theorem packages.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.2, pp. 686–688
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

#### Universal Copula Sum Invariance — `universal-copula-sum-consistency`


For every copula C, SC(C) holds. A copula C is a Borel probability measure on [0,1]² with both marginals uniform. Write H_C(u,v)=C([0,u]×[0,v]). A real-utility pair (A,B) admits C when P(A≤a,B≤b)=H_C(F_A(a),F_B(b)) for every real a,b. Define SC(C): for every eligible triple X,Y,Z for which both (X,Z) and (Y,Z) admit this same C, X ≽ Y iff X+Z ≽ Y+Z.

Formal: `∀ C ∈ Cop₂, SC(C).`

Tags: background-risk, copula.

Notes. Numerical scope: variables in the finite real utility chart for which both pointwise sums exist as gambles. The copula fixes dependence, not the marginal utility distributions. With atoms a pair may admit several copulas; require the displayed compatibility condition, not a uniquely assigned copula. Preferences compare the actual random variables, not their laws or equivalence classes; no indifference of same-law variables is assumed. The dependence condition concerns each pair separately and places no extra condition on the joint law of (X,Y,Z). Proposal: Zachary Goodsell; precise recording: GPT-6 (Codex), 9 September 2026.

Sources:

- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).
- **Copula Measures and Sklar’s Theorem (definitions)** — Fred Espen Benth, Giulia Di Nunno and Dennis Schroers, Copula Measures and Sklar’s Theorem in Arbitrary Dimensions, arXiv:2012.11530v2, Definition 2.1 and Theorem 2.3; https://arxiv.org/html/2012.11530v2. Reference for copula terminology only, not these preference principles or implication proofs.

### Extensions of EUT

#### CDF-Area Extension — `cdf-area-extension`


The normalized utility chart is total and measurable. Write S_X(t)=P(u(X)>t), d=S_X−S_Y, A₊=∫max(d,0)dt and A₋=∫max(−d,0)dt over ℝ. Whenever at least one of A₊,A₋ is finite, X ≽ Y iff A₊≥A₋. If both are infinite, this axiom imposes no comparison.

Tags: background-risk.

Notes. This names the requirement to extend the manuscript’s base preorder, preserving its strict comparisons. It is distinct from the exact CDF-area model, which leaves every both-infinite pair incomparable. Survival-CDF endpoint conventions do not change these Lebesgue areas. No subtraction ∞−∞ is used.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §3, pp. 7–8; §4, p. 8 (strictness-preserving extensions)

#### Expected Utility — `expected-utility`


The normalized chart u is defined on all outcomes and is measurable. Whenever u(X),u(Y) are integrable, X ≽ Y iff E[u(X)] ≥ E[u(Y)]. Expectations here are finite Lebesgue expectations; this says nothing about two +∞ expectations or conditionally convergent sums.

Tags: expectation.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.1, p. 685
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 23

#### Folded Expectation — `folded-expectation`


Put h_X(t)=P(u(X)>t)−P(u(X)<−t) for t≥0. If ∫₀∞|h_X(t)|dt and ∫₀∞|h_Y(t)|dt are finite, compare X,Y exactly by F(X)=∫₀∞h_X(t)dt and F(Y). Boundary atoms do not change these integrals.

Tags: expectation.

Notes. Absolute Lebesgue integrability of the combined tail difference is essential. Mere convergence of an improper integral is a different proposal. Symmetric laws have F=0, however heavy their tails.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, pp. 27–29

#### Relative Expectation — `relative-expectation`


For real-utility variables X,Y on the same probability space, if E|u(X)−u(Y)|<∞, then X ≽ Y iff E[u(X)−u(Y)] ≥ 0. Their individual expectations may both be undefined.

Tags: expectation, relative.

Notes. This is a same-space random-variable principle. Stochastic Equivalence is retained separately when importing the paper’s arbitrary-coupling formulation about laws.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, p. 26

#### Simple Relative Expectation — `simple-relative-expectation`


For real-utility variables X,Y on the same probability space, if u(X)−u(Y) takes finitely many values, X ≽ Y iff E[u(X)−u(Y)] ≥ 0. X and Y themselves need not be simple or integrable.

Tags: expectation, relative, finite.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, p. 26

### Calculation methods

#### Uniqueness of Negative Self-Similarity — `negative-self-similarity`


Fix 0<p<1, a>0, b∈ℝ and Z. If X ~ M_p(−aX+b,Z) and Y ~ M_p(−aY+b,Z), then X ~ Y. This records the uniqueness-in-value content of Theorem 10.

Tags: mixture, symmetry.

Notes. The paper also supplies a geometric-mixture solution. Its expanded formula has an apparent sign/power typo; the extraction records the unambiguous uniqueness statement.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 10, pp. 30–31

#### Transfer of a Shift Across a Mixture — `shift-transfer`


For all real b and 0<p<1, M_p(X+b/p,Y) ~ M_p(X,Y+b/(1−p)). Variables and transformed outcomes are in the real utility chart.

Tags: mixture, symmetry.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 3, pp. 25–26

#### Symmetric Gambles Are Neutral — `symmetric-neutrality`


If u(X) and −u(X) have the same law, then X ~ 0.

Tags: evaluation, symmetry.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, p. 27

### Prospect evaluations

#### Alternating St Petersburg = −1/2 — `alternating-st-petersburg-value`


Every X with P(u(X)=(−2)^n)=2^(−n), n≥1, is indifferent to sure utility −1/2.

Tags: evaluation.

Notes. A comparison with a sure outcome, not an assertion that the ordinary expected utility exists.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 9, p. 30

#### Arroyo = ln 2 — `arroyo-value`


Every X with P(u(X)=(−1)^(n+1)(n+1))=1/[n(n+1)], n≥1, is indifferent to sure utility ln 2.

Tags: evaluation.

Notes. A comparison with a sure outcome, not an assertion that the ordinary expected utility exists.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 8, pp. 29–30

#### Pasadena = ln 2 — `pasadena-value`


Every X with P(u(X)=−(−2)^n/n)=2^(−n), n≥1, is indifferent to sure utility ln 2.

Tags: evaluation.

Notes. A comparison with a sure outcome, not an assertion that the ordinary expected utility exists.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 11, pp. 32–33

## 4. Results

Each result is a Horn clause: the conjunction of its premises entails its conclusion, relative to the framework above. Premises are sufficient; minimality is not claimed.

### 4.1 Proved

#### Antitonic Sum Invariance ∧ Stochastic Equivalence ⇒ Existential Copula Sum Invariance — `antitonic-sum-and-equivalence-imply-existential-copula`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Antitonic Sum Invariance (`antitonic-sum-consistency`)
- Stochastic Equivalence (`stochastic-equivalence`)

Conclusion: Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

Proof.

Choose the antidiagonal copula once. Given any eligible original triple whose pairs admit it, realize a triple (X′,Y′,Z′) with utility coordinates (Q_X(U), Q_Y(U), Q_Z(1−U)) on the standing atomless space, where Q denotes increasing marginal quantiles. Each new pair has the same joint law as its original counterpart, and each is antitonic. Thus the new variables have the original marginal laws, and X′+Z′ and Y′+Z′ have the original sum laws. Apply Antitonic Sum Invariance to the new triple. Stochastic Equivalence and transitivity transfer both sides of its biconditional to the original variables. This proves SC(C) for the chosen copula.

Notes. Stochastic Equivalence is explicit because this proof passes through a new realization. No stronger implication without that premise is recorded here. Quantile endpoint values affect no law; choose valid outcomes at exceptional points.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original copula sum consistency definitions and connecting proofs recorded in this project, 9 September 2026, implementing Zachary Goodsell’s proposal.
- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).

Record: `topics/unbounded-utility/results/antitonic-sum-and-equivalence-imply-existential-copula.yaml`.

#### Antitonic Sum Invariance ⇒ Shift Invariance — `antitonic-sum-implies-shift`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; 2026-09-09.

Premises:

- Antitonic Sum Invariance (`antitonic-sum-consistency`)

Conclusion: Shift Invariance (`shift-invariance`)

Proof.

Choose Z to be the constant utility b. A constant is independent of every pair and is both comonotonic and antitonic with every variable, so the sum biconditional becomes X ≽ Y iff X+b ≽ Y+b. Apply this wherever the shifted outcomes exist.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.2, p. 18; definitions on pp. 3–4

Record: `topics/unbounded-utility/results/antitonic-sum-implies-shift.yaml`.

#### Archimedean Gambles ⇒ Archimedean Outcomes — `archimedean-gambles-restricts`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Archimedean Gambles (`archimedean-gambles`)

Conclusion: Archimedean Outcomes (`archimedean-outcomes`)

Proof.

Sure outcomes are particular gambles. Restrict the triple of quantified gambles to constants.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, p. 22, footnote 3
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/archimedean-gambles-restricts.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/archimedean-gambles-restricts.yaml`.

#### CDF-Area Extension ⇒ Stochastic Dominance — `cdf-area-implies-dominance`

Proved result; source **Unbounded Utility and Background Risk (unpublished)**; produced by Zachary Goodsell (unpublished manuscript); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; 2026-09-09.

Premises:

- CDF-Area Extension (`cdf-area-extension`)

Conclusion: Stochastic Dominance (`stochastic-dominance`)

Proof.

Under stochastic dominance, S_X≥S_Y pointwise, so A₋=0 and A₊≥0. This forces X ≽ Y. If some threshold is strictly improved, one-sided continuity makes d positive on an interval, giving A₊>0, possibly infinite; then Y ≽ X is false. Equality of laws gives two zero areas.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; Lemma 1, p. 8

Record: `topics/unbounded-utility/results/cdf-area-implies-dominance.yaml`.

#### CDF-Area Extension ⇒ Expected Utility — `cdf-area-implies-eu`

Proved result; source **Unbounded Utility and Background Risk (unpublished)**; produced by Zachary Goodsell (unpublished manuscript); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; 2026-09-09.

Premises:

- CDF-Area Extension (`cdf-area-extension`)

Conclusion: Expected Utility (`expected-utility`)

Proof.

The axiom supplies a total measurable chart. For integrable u(X),u(Y), both areas are finite, and the survival-function identity gives A₊−A₋=E[u(X)]−E[u(Y)]. Apply the defining biconditional.

Notes. This is a property of every strictness-preserving extension of the base relation, independent of its unproved convolution cancellation claim.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; Lemma 1, pp. 7–8

Record: `topics/unbounded-utility/results/cdf-area-implies-eu.yaml`.

#### CDF-Area Extension ⇒ Relative Expectation — `cdf-area-implies-relative`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; 2026-09-09.

Premises:

- CDF-Area Extension (`cdf-area-extension`)

Conclusion: Relative Expectation (`relative-expectation`)

Proof.

For the actual coupling, ∫|S_X−S_Y|dt ≤ E|u(X)−u(Y)|. If the latter is finite, Fubini applied to 1_{u(X)>t}−1_{u(Y)>t} gives ∫(S_X−S_Y)dt=E[u(X)−u(Y)]. Both areas are finite, so the CDF-area comparison is exactly the comparison of this expectation with zero.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §3, pp. 7–8

Record: `topics/unbounded-utility/results/cdf-area-implies-relative.yaml`.

#### Comonotonic Sum Invariance ∧ Stochastic Equivalence ⇒ Existential Copula Sum Invariance — `comonotonic-sum-and-equivalence-imply-existential-copula`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Stochastic Equivalence (`stochastic-equivalence`)

Conclusion: Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

Proof.

Choose the diagonal copula once. Given any eligible original triple whose pairs admit it, realize a triple (X′,Y′,Z′) with utility coordinates (Q_X(U), Q_Y(U), Q_Z(U)) on the standing atomless space, where Q denotes increasing marginal quantiles. Each new pair has the same joint law as its original counterpart, and each is comonotonic. Thus the new variables have the original marginal laws, and X′+Z′ and Y′+Z′ have the original sum laws. Apply Comonotonic Sum Invariance to the new triple. Stochastic Equivalence and transitivity transfer both sides of its biconditional to the original variables. This proves SC(C) for the chosen copula.

Notes. Stochastic Equivalence is explicit because this proof passes through a new realization. No stronger implication without that premise is recorded here. Quantile endpoint values affect no law; choose valid outcomes at exceptional points.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original copula sum consistency definitions and connecting proofs recorded in this project, 9 September 2026, implementing Zachary Goodsell’s proposal.
- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).

Record: `topics/unbounded-utility/results/comonotonic-sum-and-equivalence-imply-existential-copula.yaml`.

#### Comonotonic Sum Invariance ⇒ Shift Invariance — `comonotonic-sum-implies-shift`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; 2026-09-09.

Premises:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)

Conclusion: Shift Invariance (`shift-invariance`)

Proof.

Choose Z to be the constant utility b. A constant is independent of every pair and is both comonotonic and antitonic with every variable, so the sum biconditional becomes X ≽ Y iff X+b ≽ Y+b. Apply this wherever the shifted outcomes exist.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.2, p. 18; definitions on pp. 3–4

Record: `topics/unbounded-utility/results/comonotonic-sum-implies-shift.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Dominance ∧ L¹ Continuity (random variables) ∧ Independent Sum Cancellation ⇒ Independent Sum Preservation — `continuous-total-cancellation-implies-preservation`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex); checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Dominance (`stochastic-dominance`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Independent Sum Cancellation (`independent-sum-cancellation`)

Conclusion: Independent Sum Preservation (`independent-sum-preservation`)

Proof.

First, Totality and Independent Sum Cancellation preserve every strict comparison: if X is strictly preferred to Y but X+Z were not strictly preferred to Y+Z, Totality of the sums would give Y+Z weakly preferred to X+Z, and cancellation would contradict X strictly preferred to Y. Now suppose X is weakly preferred to Y. For each n>=1, X+1/n strictly stochastically dominates X, so X+1/n is strictly preferred to Y. The shifts exist by Rich Outcomes and Z stays independent of the pair (X+1/n,Y). Strict preservation therefore gives (X+Z)+1/n strictly preferred to Y+Z. These upper gambles converge to X+Z in the actual L1 distance, which is exactly 1/n, regardless of whether X or Z has a finite expectation. The upper-section clause of L1 Continuity yields X+Z weakly preferred to Y+Z. Together with the first step this is weak and strict Independent Sum Preservation.

Notes. Original work: connecting proof by a strict-order argument and a constant-shift L1 limit. This is not claimed as a new model or as a theorem already proved in the cited papers. Only the existing UPPER continuity clause is used. No integrability of X,Y,Z, mixture independence, or stochastic-equivalence substitution is required. Rich Outcomes ensures the arbitrarily small real shifts are available; arithmetic remains restricted to the finite real chart. Under DTU plus L1 Continuity, Cancellation, Preservation and full Independent Sum Invariance are therefore equivalent. Combining this with the existing Levy obstruction rules out Cancellation under DTU plus L1 Continuity and Symmetric Neutrality, without adding a redundant incompatibility record.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), 9 September 2026, original shift-and-continuity argument in writeups/continuous-total-cancellation-implies-preservation.md.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), §3, p. 23: source for the upper-section L1 Continuity axiom only.
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, unpublished manuscript, 5 June 2026, Lemma 1, pp. 7–8: source for the independent-sum principles only.

Record: `topics/unbounded-utility/results/continuous-total-cancellation-implies-preservation.yaml`.

<details><summary>Hand-written write-up</summary>

#### L¹ continuity turns independent-sum cancellation into preservation

**Proved implication:** Rich Outcomes + Totality + Stochastic Dominance +
L¹ Continuity + Independent Sum Cancellation implies Independent Sum
Preservation.

The proof concerns numerical gambles in the finite real chart. Rich Outcomes
makes every real translation below available. Additional outcomes outside
that chart are not used.

##### 1. Cancellation already preserves strict comparisons

Suppose $X\succ Y$ and $Z$ is independent of $(X,Y)$. If
$X+Z\not\succ Y+Z$, Totality of the two sums implies
$Y+Z\succeq X+Z$. Cancellation, with the two compared variables exchanged,
would give $Y\succeq X$, contradicting $X\succ Y$. Hence

$$X\succ Y\quad\Longrightarrow\quad X+Z\succ Y+Z.$$

This argument does not establish preservation of indifference. Cancellation
can, as an abstract order property, prevent reversal of a strict order while
allowing a map to break a tie. The next step closes precisely that gap.

##### 2. Constant shifts supply strict approximations

For every real-valued random variable $X$ and every $\delta>0$, the variable
$X+\delta$ strictly stochastically dominates $X$. All weak tail inequalities
follow from $X+\delta>X$ pointwise. To see that at least one is strict,
partition $\mathbb R$ into the intervals
$(k\delta,(k+1)\delta]$, $k\in\mathbb Z$. At least one has positive
$X$-probability, and at its upper endpoint $t$ we have

$$\Pr(X+\delta>t)-\Pr(X>t)
  =\Pr(t-\delta<X\le t)>0.$$

Stochastic Dominance therefore gives $X+\delta\succ X$. For any outcomes
outside the finite chart the weak comparison also follows pointwise from
the outcome order; the displayed strict threshold lies in the chart.

If $X\succeq Y$, transitivity of the preorder gives
$X+\delta\succ Y$: the contrary comparison $Y\succeq X+\delta$ would
contradict $X+\delta\succ X$.

Independence of $Z$ from $(X,Y)$ implies independence from
$(X+\delta,Y)$, since translation is a measurable transformation of the
pair. Applying the first step now yields

$$(X+Z)+\delta\succ Y+Z.$$

##### 3. Only upper-section continuity is needed

Take $\delta_n=1/n$. The actual, pointwise-coupled variables satisfy

$$E\bigl|((X+Z)+\delta_n)-(X+Z)\bigr|=\delta_n\longrightarrow0.$$

The upper-section clause in the project's L¹ Continuity principle applies
to $(X+Z)+\delta_n\succeq Y+Z$ and gives
$X+Z\succeq Y+Z$. It does not require $X$, $Y$, $Z$, or their sums to
have finite expectations. Along with step 1, this proves both clauses of
Independent Sum Preservation.

No comparison of same-law copies, Mixture Independence, or lower-section
continuity has been used.

##### Consequences under DTU

Together with the already recorded decomposition, the result makes
**Cancellation, Preservation, and full Independent Sum Invariance
equivalent under DTU + L¹ Continuity**. Thus the existing Lévy obstruction
also rules out Cancellation under DTU + L¹ Continuity + Symmetric Neutrality.
These consequences are left to the inference engine, rather than stored as
duplicate arrows.

Without L¹ Continuity, the argument stops at strict preservation. The map
separately records the conjecture that DTU alone might close that gap.

**Original work: connecting proof using a shift approximation.**
GPT-6 (Codex), 9 September 2026. Goodsell's *Symmetries of value*, §3, p. 23,
supplies the upper-section continuity definition; his *Unbounded Utility
and Background Risk* (unpublished), Lemma 1, pp. 7–8, supplies the sum
principles. Neither paper is being credited with this additional proof.
Direct source: Misc. No independent checker or Lean verification is claimed.

</details>

#### Stochastic Dominance ⇒ Stochastic Equivalence — `dominance-implies-equivalence`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Stochastic Dominance (`stochastic-dominance`)

Conclusion: Stochastic Equivalence (`stochastic-equivalence`)

Proof.

Equal laws give equal upper-tail probabilities at every outcome threshold. Apply the weak dominance clause in both directions.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 678

Record: `topics/unbounded-utility/results/dominance-implies-equivalence.yaml`.

#### Archimedean Outcomes ∧ Stochastic Dominance ⇒ Statewise Dominance — `dominance-implies-statewise`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Archimedean Outcomes (`archimedean-outcomes`)
- Stochastic Dominance (`stochastic-dominance`)

Conclusion: Statewise Dominance (`statewise-dominance`)

Proof.

Use the real outcome chart supplied by Archimedean Outcomes. If X≥Y almost surely, {Y>t}⊆{X>t} modulo null events. If P(X>Y)>0, the countable family of rational cuts contains a cut with P(Y≤t<X)>0; approximate by a realized outcome threshold if necessary. The strict tail inequality then gives strict preference.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, pp. 678–679 and footnote 19

Record: `topics/unbounded-utility/results/dominance-implies-statewise.yaml`.

#### Rich Outcomes ∧ Stochastic Dominance ∧ Antitonic Sum Invariance ⇒ False (⊥) — `dominance-refutes-antitonic-sum`

Proved result; source **Unbounded Utility and Background Risk (unpublished)**; produced by Zachary Goodsell (unpublished manuscript); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Stochastic Dominance (`stochastic-dominance`)
- Antitonic Sum Invariance (`antitonic-sum-consistency`)

Conclusion: False (⊥) (`false`)

Proof.

Let P have St Petersburg law and S have the symmetric mixture ½P+½(−P). Write ⊕Anti for the law of the antitonic sum. Since P has law ½δ₂+½(2P), pairing opposite quantiles gives S⊕Anti P = ½(P+2)+½P, which strictly stochastically dominates P=0⊕Anti P. Antitonic Sum Invariance would therefore give S ≻ 0 (both weak directions allow strict cancellation). Applying it again with common summand of law S gives S⊕Anti S ≻ 0⊕Anti S. Symmetry of the quantiles makes the left law δ₀ and the right law S, so 0 ≻ S, a contradiction. Dominance supplies Stochastic Equivalence for every law identity used. This does not assume Symmetric Neutrality or Totality.

Notes. Representation update: the former negative conclusion is expressed by adding antitonic-sum-consistency to the premises and concluding False. The mathematical claim, source, and proof are unchanged.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; Theorem 6, p. 19

Record: `topics/unbounded-utility/results/dominance-refutes-antitonic-sum.yaml`.

#### Rich Outcomes ∧ Stochastic Dominance ∧ Full Sum Invariance ⇒ False (⊥) — `dominance-refutes-full-sum`

Proved result; source **Unbounded Utility and Background Risk (unpublished)**; produced by Zachary Goodsell (unpublished manuscript); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Stochastic Dominance (`stochastic-dominance`)
- Full Sum Invariance (`full-sum-consistency`)

Conclusion: False (⊥) (`false`)

Proof.

Let P,Q each have St Petersburg law P(P=2ⁿ)=2⁻ⁿ, n≥1, coupled antitonically so exactly one equals 2. Dominance supplies Stochastic Equivalence, hence P~Q. Full Sum Invariance with common summand P would give 2P~P+Q. But P+Q has the law of 2P+2: for n≥2 it takes 2ⁿ+2 with probability 2^(1−n). This strictly stochastically dominates the law of 2P, contradicting the asserted indifference. Rich Outcomes and standing prospect richness supply the variables and sums.

Notes. The draft credits the earlier full-sum impossibility to Seidenfeld, Schervish and Kadane. This record uses the explicit witness in the supplied manuscript; it is not a new attribution of their exact theorem.

Representation update: the former negative conclusion is expressed by adding full-sum-consistency to the premises and concluding False. The mathematical claim, source, and proof are unchanged.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.1, p. 17

Record: `topics/unbounded-utility/results/dominance-refutes-full-sum.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ L¹ Continuity (random variables) ⇒ Expected Utility — `dtu-l1-implies-eu`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Expected Utility (`expected-utility`)

Proof.

Source-stated implication, §3, p. 23: adding L¹ Continuity to DTU yields Expected Utility. Stochastic Equivalence makes the quotient ordering on laws well-defined; the remaining premises give exactly the source’s DTU, with the surjectivity part of its Simple EU supplied separately by Rich Outcomes. The L¹ translation write-up establishes that the random-variable continuity axiom implies the source’s metric continuity. Apply the stated theorem and pull its expected-utility comparison back to X,Y. The source does not supply an expanded proof of the underlying implication; this is a theorem application and translation, not a new proof of that theorem.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 23

Record: `topics/unbounded-utility/results/dtu-l1-implies-eu.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Archimedean Gambles ⇒ False (⊥) — `dtu-refutes-archimedean-gambles`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Archimedean Gambles (`archimedean-gambles`)

Conclusion: False (⊥) (`false`)

Proof.

Let S have P(u(S)=2^n)=2^(−n). For any real c choose N with N>c. The simple truncation min(S,2^N) has expectation N+1 and is stochastically dominated by S. Thus S≻c. In particular S≻1≻0. Every M_p(S,0), p>0, is also better than every sure outcome: its simple truncations have arbitrarily large finite expectations. Hence none is indifferent to 1. This violates Archimedean Gambles while preserving Archimedean Outcomes.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Representation update: the former negative conclusion is expressed by adding archimedean-gambles to the premises and concluding False. The mathematical claim, source, and proof are unchanged.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 22

Record: `topics/unbounded-utility/results/dtu-refutes-archimedean-gambles.yaml`.

#### Rich Outcomes ∧ Archimedean Outcomes ∧ Stochastic Equivalence ∧ Statewise Dominance ⇒ Stochastic Dominance — `equivalence-and-statewise-imply-dominance`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Statewise Dominance (`statewise-dominance`)

Conclusion: Stochastic Dominance (`stochastic-dominance`)

Proof.

On the full real chart, first-order dominance permits quantile realizations X′,Y′ using the same uniform random variable with X′≥Y′ almost surely. Distinct laws give P(X′>Y′)>0. Statewise Dominance compares these realizations, and Stochastic Equivalence plus transitivity transfers that comparison to X,Y. All realizations exist by standing Prospect Richness.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, footnote 19 (RV/quantile translation)

Record: `topics/unbounded-utility/results/equivalence-and-statewise-imply-dominance.yaml`.

#### Rich Outcomes ∧ Expected Utility ∧ Stochastic Equivalence ∧ Mixture Independence ∧ Stochastic Dominance ∧ L¹ Continuity (random variables) ⇒ Relative Expectation — `eu-independence-l1-imply-relative`

Proved result; source **Misc.**; produced by GPT-6 (Codex) (connecting proof by conditional truncation); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Expected Utility (`expected-utility`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Mixture Independence (`independence`)
- Stochastic Dominance (`stochastic-dominance`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Relative Expectation (`relative-expectation`)

Proof.

First take an integrable actual difference D=X−Y with ED=0. On E_n={|X|≤n,|Y|≤n}, put p_n=P(E_n) and c_n=E[D 1_E_n]/p_n, starting after p_n>0. Set X_n=X−c_n on E_n and X_n=Y elsewhere. The conditional laws of X−c_n and Y on E_n are bounded with equal expectations, so Expected Utility, Stochastic Equivalence and Mixture Independence give X_n~Y; when p_n=1 use Expected Utility directly. Furthermore E|X_n−X|≤E[|D|1_(E_n complement)]+|E[D1_E_n]|→0. Upper-section L1 Continuity gives X≽Y. Interchanging X,Y proves Y≽X. For arbitrary mean m, apply this zero-mean argument to X and Y+m to obtain X~Y+m. Stochastic Dominance compares Y+m with Y strictly according to the sign of m, giving exactly Relative Expectation.

Notes. Original work: moderate connecting argument by truncation adaptation. The source supplies the expectation/continuity principles and their implication with full affine symmetry. This proof instead compares bounded conditional pieces and corrects their means before taking upper-section limits. In combination with the existing DTU+L1-to-EU record, it removes symmetry from the DTU+L1-to-Relative implication. No lower-section continuity, prior Relative Expectation, Shift Transfer or Shift Invariance is assumed. This is work accounting, not a claim of literature priority. Stochastic Equivalence is retained to show the conditional- law replacements explicitly, although it follows from Stochastic Dominance in this topic.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof in Logical Maps, 9 September 2026; writeups/eu-independence-l1-imply-relative.md.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, L1 Continuity and DTU+L1 implying Expected Utility, §3, p. 23; Relative Expectation and Corollary 5 in the full DTU+Sym context, pp. 26–27.

Record: `topics/unbounded-utility/results/eu-independence-l1-imply-relative.yaml`.

<details><summary>Hand-written write-up</summary>

#### Expected Utility, Independence and L¹ Continuity yield Relative Expectation

**Claim.** Rich Outcomes + Expected Utility + Stochastic Equivalence + Mixture
Independence + Stochastic Dominance + L¹ Continuity imply Relative Expectation.

In particular, the map's existing DTU + L¹ Continuity implication to Expected
Utility shows that **DTU + L¹ Continuity implies Relative Expectation without
affine symmetry**. Only the recorded upper-section continuity clause is used.

Write the variables' finite utility coordinates as $X,Y$. Rich Outcomes and
Expected Utility supply all real coordinates and the total measurable chart.

##### Zero-mean integrable differences

Suppose $D=X-Y$ is integrable and $\mathbb E D=0$. Define

$$E_n=\{|X|\le n,\ |Y|\le n\},\qquad p_n=\Pr(E_n).$$

These measurable events increase to the whole sample space, so $p_n\to1$.
Discard any initial terms with $p_n=0$. Put

$$c_n=\frac{\mathbb E[D\mathbf1_{E_n}]}{p_n},\qquad
X_n=\begin{cases}X-c_n&\text{on }E_n,\\Y&\text{off }E_n.\end{cases} \tag{1}$$

The conditional laws of $X-c_n$ and $Y$ on $E_n$ are bounded and have the
same expectation, since

$$\mathbb E[X-c_n\mid E_n]-\mathbb E[Y\mid E_n]
=\frac{\mathbb E[D\mathbf1_{E_n}]}{p_n}-c_n=0.$$

Realize those conditional laws as variables on the standing atomless space.
Expected Utility makes them indifferent. If $p_n<1$, both $X_n$ and $Y$
have probability-mixture laws with these conditional variables in their
$E_n$ branches and the same conditional law of $Y$ on $E_n^c$ in their other
branches. Mixture Independence and Stochastic Equivalence therefore imply

$$X_n\sim Y. \tag{2}$$

If $p_n=1$, $c_n=\mathbb E D=0$ and both original variables have bounded
laws, hence finite expectations; Expected Utility gives (2) directly. Values
on a null complement cause no integrability problem. This endpoint case
does not apply Mixture Independence with a forbidden weight of one.

The actual coupling in (1) obeys

$$\begin{aligned}
\mathbb E|X_n-X|
&\le \mathbb E[|D|\mathbf1_{E_n^c}]+p_n|c_n|\\
&=\mathbb E[|D|\mathbf1_{E_n^c}]
 +|\mathbb E[D\mathbf1_{E_n}]|\longrightarrow0.
\end{aligned}$$

Dominated convergence and $\mathbb E D=0$ justify the limit. The first weak
comparison in (2), followed by upper-section L¹ Continuity with fixed $Y$,
gives $X\succeq Y$. Repeat the same construction with $X,Y$ interchanged to
obtain $Y\succeq X$. We have therefore proved

$$\mathbb E|X-Y|<\infty,\quad \mathbb E(X-Y)=0
\quad\Longrightarrow\quad X\sim Y. \tag{3}$$

The second comparison in (3) comes from a second *upper-section* limit. It
does not infer closure of lower sections from the given axiom.

##### General means and strict comparison

For an arbitrary integrable difference, put $m=\mathbb E(X-Y)$. Rich Outcomes
supplies $Y+m$. Since $X-(Y+m)$ has zero mean and is integrable, (3) gives

$$X\sim Y+m. \tag{4}$$

If $m>0$, the translated law $Y+m$ stochastically dominates $Y$: its survival
function is $S_Y(t-m)\ge S_Y(t)$. At least one comparison is strict. Indeed
the intervals $(km,(k+1)m]$, $k\in\mathbb Z$, cover the line, so some such
interval has positive probability and its upper endpoint supplies a strict
tail comparison. Rich Outcomes makes that threshold an available outcome.
Thus Stochastic Dominance gives $Y+m\succ Y$. If $m<0$ the reverse argument
gives $Y\succ Y+m$; if $m=0$ the two variables are identical.

Together with (4) and transitivity these cases prove exactly

$$X\succeq Y\iff\mathbb E(X-Y)\ge0.$$

No Totality, symmetry, Shift Transfer or Shift Invariance is used. The shift
in (4) is constructed as a random variable and compared by (3); it is not a
transport of a preference by an unassumed invariance axiom. Stochastic
Equivalence is written explicitly to license the conditional-law mixture
replacements, even though this topic's Stochastic Dominance implies it.

##### Attribution and scope

**Original work: moderate connecting argument by truncation adaptation.**
Zachary Goodsell supplies the principles and Corollary 5's implication in
the full DTU+Sym context. The present proof uses bounded conditional pieces,
mean corrections and two upper-section limits to remove the symmetry
assumptions in the stated sufficient package. It is credited as a connecting
proof, not as a theorem already attributed to the paper. This describes work
performed for the map, not literature priority.

Combined with the existing source-based DTU + L¹ Continuity implication to
Expected Utility, this yields the claimed DTU consequence. It does not claim
the converse: the separate infinitesimal folded-tail model satisfies DTU,
Relative Expectation and even Folded Expectation while violating L¹ Continuity.

**Sources.** Zachary Goodsell, *Symmetries of value*, §3, p. 23, and pp. 26–27
(Relative Expectation and Corollary 5). Connecting proof: GPT-6 (Codex),
9 September 2026. No independent checker or Lean proof is claimed.

</details>

#### Existential Copula Sum Invariance ⇒ Shift Invariance — `existential-copula-implies-shift`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

Conclusion: Shift Invariance (`shift-invariance`)

Proof.

Choose the single copula C supplied by the existential principle. For Z equal to a constant b, F_Z(z) is either 0 or 1. Every copula satisfies H_C(u,0)=0 and H_C(u,1)=u, so (X,b) and (Y,b) admit C for every X,Y. SC(C) therefore gives X ≽ Y iff X+b ≽ Y+b whenever the shifted gambles exist. This uses the actual constant summand and needs no Stochastic Equivalence.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original copula sum consistency definitions and connecting proofs recorded in this project, 9 September 2026, implementing Zachary Goodsell’s proposal.
- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).

Record: `topics/unbounded-utility/results/existential-copula-implies-shift.yaml`.

#### Expected Utility ⇒ Simple Expected Utility — `expected-utility-implies-simple`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Expected Utility (`expected-utility`)

Conclusion: Simple Expected Utility (`simple-eu`)

Proof.

All simple variables have finite real expected utility. Restrict Expected Utility to them.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.1, p. 685
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/expected-utility-implies-simple.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/expected-utility-implies-simple.yaml`.

#### Rich Outcomes ∧ Folded Expectation ⇒ Arroyo = ln 2 — `folded-evaluates-arroyo`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (folded Arroyo evaluation); GPT-6 (Codex) (explicit unshifted tail calculation and premise audit); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Folded Expectation (`folded-expectation`)

Conclusion: Arroyo = ln 2 (`arroyo-value`)

Proof.

For Arroyo A, the folded tail h_A(t) on [m+1,m+2), m>=1, is the alternating remainder sum over n>=m+1 of (-1)^(n+1)/(n(n+1)), whose absolute value is at most 1/((m+1)(m+2)). Thus h_A is absolutely integrable. At cutoff T=N+1 its integral is the alternating harmonic prefix through N, plus (N+1) times that alternating probability remainder. The remainder has absolute value at most 1/(N+2), so the integral tends to ln 2. Sure ln 2 has the same folded expectation and exists by Rich Outcomes. Folded Expectation gives A~ln 2.

Notes. Original work: source extraction with a small calculation/premise audit. Goodsell already states the folded value of Arroyo immediately before Theorem 8. This record makes Folded Expectation the explicit sufficient principle; the unshifted calculation avoids invoking Shift Invariance from the larger theorem package. It is not a new evaluation or a claim of literature novelty. No independent checker or Lean certification is asserted.

Sources:

- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37, DOI 10.1111/nous.12549, discussion preceding Theorem 8 and Theorem 8, pp. 29–30: Arroyo has folded expectation ln 2.
- **GPT-6 calculation 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/folded-evaluates-arroyo.md: unshifted absolutely integrable tail calculation exposing the sufficient premises.

Record: `topics/unbounded-utility/results/folded-evaluates-arroyo.yaml`.

<details><summary>Hand-written write-up</summary>

#### Folded Expectation directly evaluates Arroyo

**Source and work accounting.** Zachary Goodsell's *Symmetries of value*,
pp. 29–30, explicitly states that Arroyo has folded expectation \(\ln2\), and
Theorem 8 gives its evaluation. The unshifted tail calculation below was
supplied by GPT-6 (Codex), 9 September 2026, to expose the smaller sufficient
package. It is a source extraction with a small calculation and premise audit,
not a new discovery of Arroyo's value. No independent checker or Lean
certification is asserted.

Assume Rich Outcomes and Folded Expectation. Let

\[
\Pr(A=(-1)^{n+1}(n+1))=\frac1{n(n+1)},\qquad n\ge1,
\]

and write \(h(t)=\Pr(A>t)-\Pr(A<-t)\) for \(t\ge0\).
For \(t\in[m+1,m+2)\), \(m\ge1\), apart from immaterial endpoints,

\[
h(t)=\sum_{n=m+1}^{\infty}\frac{(-1)^{n+1}}{n(n+1)}.
\]

The alternating-series estimate gives

\[
|h(t)|\le\frac1{(m+1)(m+2)}.
\]

On \([0,2)\) the tail difference is bounded by one. Thus

\[
\int_0^\infty |h(t)|\,dt
\le2+\sum_{m=1}^{\infty}\frac1{(m+1)(m+2)}<\infty.
\]

For a symmetric cutoff \(T=N+1\), bounded tail integration gives

\[
\int_0^{N+1}h(t)\,dt
=\sum_{n=1}^{N}\frac{(-1)^{n+1}}n
 +(N+1)\sum_{n=N+1}^{\infty}\frac{(-1)^{n+1}}{n(n+1)}.
\]

The final term has absolute value at most \(1/(N+2)\), while the finite
alternating harmonic sum tends to \(\ln2\). Therefore Arroyo's absolutely
defined folded expectation is \(\ln2\). Sure \(\ln2\), available by Rich
Outcomes, has the same folded expectation. The axiom gives

\[
A\sim\ln2.
\]

This holds for every random variable with the indicated utility law because
the folded-tail condition itself depends only on that law. No separate
Stochastic Equivalence, shift symmetry, continuity or DU package is needed.
The use of the limit above computes an already absolutely integrable folded
tail; it does not silently interpret a conditionally convergent expected
utility as an ordinary Lebesgue expectation.

</details>

#### Archimedean Outcomes ∧ Folded Expectation ⇒ Expected Utility — `folded-implies-eu`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Archimedean Outcomes (`archimedean-outcomes`)
- Folded Expectation (`folded-expectation`)

Conclusion: Expected Utility (`expected-utility`)

Proof.

For an integrable real utility variable, the integral of the absolute folded tail difference is bounded by E|u(X)|, and the tail-integral formula gives F(X)=E[u(X)]. Archimedean Outcomes makes the chart total. Restrict the Folded Expectation comparison to integrable X,Y.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, p. 27
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/folded-implies-eu.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/folded-implies-eu.yaml`.

#### Rich Outcomes ∧ Folded Expectation ⇒ Symmetric Gambles Are Neutral — `folded-implies-symmetric-neutrality`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Folded Expectation (`folded-expectation`)

Conclusion: Symmetric Gambles Are Neutral (`symmetric-neutrality`)

Proof.

For a symmetric real law, h_X(t)=0 almost everywhere, so F(X)=0. The zero constant also has folded value zero; apply Folded Expectation.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, pp. 27–28

Record: `topics/unbounded-utility/results/folded-implies-symmetric-neutrality.yaml`.

#### Rich Outcomes ∧ Mixture Independence ∧ Folded Expectation ⇒ Relative Expectation — `folded-independence-imply-relative`

Proved result; source **Misc.**; produced by GPT-6 (Codex) (connecting proof using Goodsell's folded-expectation principle); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Mixture Independence (`independence`)
- Folded Expectation (`folded-expectation`)

Conclusion: Relative Expectation (`relative-expectation`)

Proof.

For actual-coupling real-utility variables X,Y with E|X−Y| finite, the survival difference d=S_X−S_Y is absolutely integrable and its integral is E(X−Y). Let A=M_(1/2)(X,−Y) and B=M_(1/2)(Y,−Y). Except at atom thresholds, h_A(t)=(d(t)+d(−t))/2 and h_B(t)=0. Thus A and B have folded expectations E(X−Y)/2 and zero. Folded Expectation compares them exactly by that sign. Mixture Independence cancels their common −Y branch, giving X≽Y iff E(X−Y)≥0. Rich Outcomes supplies the reflected finite-chart variable −Y. Neither Totality nor a law replacement in preferences is used.

Notes. Original work: small connecting proof. Goodsell supplies both evaluation principles and the forward route from relative to folded expectation under symmetry. This entry gives the converse route by a common reflected mixture, with an explicit integrability bound and a smaller sufficient premise package. This records work done for the map, not a claim of priority in the literature. No independent checker or Lean verification is asserted.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof in Logical Maps, 9 September 2026; writeups/folded-independence-imply-relative.md.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Relative Expectation and Folded Expectation definitions and Theorem 6, pp. 26–29.

Record: `topics/unbounded-utility/results/folded-independence-imply-relative.yaml`.

<details><summary>Hand-written write-up</summary>

#### Folded Expectation and Mixture Independence imply Relative Expectation

**Claim.** Rich Outcomes + Mixture Independence + Folded Expectation imply Relative Expectation.

Write the finite utility coordinates of the given variables as $X,Y$, and suppose
$\mathbb E|X-Y|<\infty$ in their actual coupling. Put

$$S_X(t)=\Pr(X>t),\qquad d(t)=S_X(t)-S_Y(t).$$

The indicator identity for the interval between two real numbers, followed by
Tonelli and Fubini, gives

$$\int_{\mathbb R}|d(t)|\,dt\le\mathbb E|X-Y|<\infty,
\qquad \int_{\mathbb R}d(t)\,dt=\mathbb E(X-Y). \tag{1}$$

Rich Outcomes supplies the reflected variable $-Y$. Form the actual fixed-lift
mixtures

$$A=M_{1/2}(X,-Y),\qquad B=M_{1/2}(Y,-Y).$$

The second mixture has a symmetric law. For positive $t$, put
$h_Z(t)=\Pr(Z>t)-\Pr(Z<-t)$. Probability-mixture linearity gives

$$h_B(t)=0,\qquad h_A(t)=\tfrac12(h_X(t)-h_Y(t))
=\tfrac12(d(t)+d(-t))\quad\text{a.e.} \tag{2}$$

The last equality can fail only when $t$ or $-t$ is an atom threshold of one
of the laws, a countable and hence Lebesgue-null set. Equations (1) and (2)
show that both mixtures are foldable, with

$$\int_0^\infty|h_A(t)|\,dt\le\tfrac12\int_{\mathbb R}|d(t)|\,dt<\infty,
\qquad F(A)=\tfrac12\mathbb E(X-Y),\qquad F(B)=0.$$

Folded Expectation therefore gives

$$A\succeq B\iff\mathbb E(X-Y)\ge0.$$

Mixture Independence, applied to the common $-Y$ branch, gives
$A\succeq B\iff X\succeq Y$. This is exactly Relative Expectation, including
indifference at zero and the failure of the weak comparison for negative mean.

The proof uses identities of mixture laws to compute folded tails, but it does
not replace one random variable with an equal-law variable in a preference.
Folded Expectation itself licenses the two comparisons being used. Thus neither
Stochastic Equivalence nor Totality is an omitted premise. No L¹ Continuity,
reflection axiom or full affine symmetry is needed.

**Original work: small connecting proof.** The two expectation principles and
the source's forward implication are Zachary Goodsell's. The common-reflected-
mixture proof supplies a converse useful to the map, rather than importing a
claim that the paper already proves that converse. The integrability bound is
essential: conditional improper convergence is insufficient. This accounting
is not a claim of literature novelty.

**Sources.** Zachary Goodsell, *Symmetries of value*, pp. 26–29, especially the
definitions and Theorem 6. Connecting proof and premise audit: GPT-6 (Codex),
9 September 2026. No independent checker or Lean proof is claimed.

</details>

#### Full Sum Invariance ⇒ Antitonic Sum Invariance — `full-sum-implies-antitonic`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; 2026-09-09.

Premises:

- Full Sum Invariance (`full-sum-consistency`)

Conclusion: Antitonic Sum Invariance (`antitonic-sum-consistency`)

Proof.

Restrict the universal quantifier over X,Y,Z to triples satisfying the stated dependence condition. Both directions of the same biconditional remain available.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.1–2, pp. 17–18

Record: `topics/unbounded-utility/results/full-sum-implies-antitonic.yaml`.

#### Full Sum Invariance ⇒ Comonotonic Sum Invariance — `full-sum-implies-comonotonic`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; 2026-09-09.

Premises:

- Full Sum Invariance (`full-sum-consistency`)

Conclusion: Comonotonic Sum Invariance (`comonotonic-sum-consistency`)

Proof.

Restrict the universal quantifier over X,Y,Z to triples satisfying the stated dependence condition. Both directions of the same biconditional remain available.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.1–2, pp. 17–18

Record: `topics/unbounded-utility/results/full-sum-implies-comonotonic.yaml`.

#### Full Sum Invariance ⇒ Independent Sum Invariance — `full-sum-implies-independent`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; 2026-09-09.

Premises:

- Full Sum Invariance (`full-sum-consistency`)

Conclusion: Independent Sum Invariance (`independent-sum-consistency`)

Proof.

Restrict the universal quantifier over X,Y,Z to triples satisfying the stated dependence condition. Both directions of the same biconditional remain available.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.1–2, pp. 17–18

Record: `topics/unbounded-utility/results/full-sum-implies-independent.yaml`.

#### Full Sum Invariance ⇒ Universal Copula Sum Invariance — `full-sum-implies-universal-copula`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Full Sum Invariance (`full-sum-consistency`)

Conclusion: Universal Copula Sum Invariance (`universal-copula-sum-consistency`)

Proof.

Fix any copula C and any eligible triple whose two pairs admit C. Full Sum Invariance applies to this triple regardless of dependence and supplies the required biconditional. Since C was arbitrary, SC(C) holds for every copula.

Notes. No converse is asserted: Universal Copula Sum Invariance only constrains triples for which the two pairs admit a common copula; Full Sum Invariance constrains all eligible triples.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original copula sum consistency definitions and connecting proofs recorded in this project, 9 September 2026, implementing Zachary Goodsell’s proposal.
- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).

Record: `topics/unbounded-utility/results/full-sum-implies-universal-copula.yaml`.

#### Mixture Independence ∧ Transfer of a Shift Across a Mixture ⇒ Shift Invariance — `independence-shift-transfer-imply-shift`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Mixture Independence (`independence`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)

Conclusion: Shift Invariance (`shift-invariance`)

Proof.

Fix eligible X,Y,X+b,Y+b. Shift Transfer at p=1/2 with transfer parameter b/2 gives M_1/2(X+b,X)~M_1/2(X,X+b) and M_1/2(Y+b,X)~M_1/2(Y,X+b). Mixture Independence with common second argument X+b identifies X≽Y with the comparison between the latter two right-hand mixtures. Substitute the displayed indifferences and cancel the common second argument X by Independence. The resulting comparison is X+b≽Y+b. The equivalences work in both directions and require no exchange of mixture branches.

Notes. Original work: direct consequence. Use the shifted first variable itself as the common gamble, avoiding a Rich Outcomes premise for a new sure outcome b; cancel two half-mixtures. This describes the work needed for this database entry, not a claim of novelty in the literature.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof and premise audit in the Logical Maps project, 9 September 2026; see the accompanying handwritten write-up.

Record: `topics/unbounded-utility/results/independence-shift-transfer-imply-shift.yaml`.

<details><summary>Hand-written write-up</summary>

#### Mixture Independence and Shift Transfer imply Shift Invariance

**Claim.** Mixture Independence + Shift Transfer imply Shift Invariance.

Fix real-utility variables $X,Y$ and $b\in\mathbb R$ such that $X+b$ and $Y+b$ are available. Apply Shift Transfer with mixture weight $1/2$ and transfer parameter $b/2$, first to $(X,X)$ and then to $(Y,X)$:

$$M_{1/2}(X+b,X)\sim M_{1/2}(X,X+b),$$
$$M_{1/2}(Y+b,X)\sim M_{1/2}(Y,X+b).$$

Transitivity of the standing preorder lets an indifferent object replace either side of a weak comparison. Therefore

$$\begin{aligned}
X\succeq Y
&\iff M_{1/2}(X,X+b)\succeq M_{1/2}(Y,X+b)\\
&\iff M_{1/2}(X+b,X)\succeq M_{1/2}(Y+b,X)\\
&\iff X+b\succeq Y+b.
\end{aligned}$$

The first and last equivalences are exactly Mixture Independence, with common second arguments $X+b$ and $X$ respectively.

No branch interchange, independent copy, totality assumption or law identity occurs. Using $X$ as the common gamble also avoids assuming the availability of a new sure outcome at utility $b$: all transformations used were already stipulated to exist in this instance of Shift Invariance.

**Original work: direct consequence.** This is a two-application specialization followed by mixture cancellation. The choice of common gamble is the small domain check needed to avoid unnecessary outcome-richness assumptions. No literature novelty is asserted.

**Attribution.** GPT-6 (Codex), 9 September 2026, original connecting argument for this project. No independent checker or Lean proof is claimed.

</details>

#### Stochastic Equivalence ∧ Mixture Independence ⇒ Sure-Thing — `independence-to-sure-thing`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Stochastic Equivalence (`stochastic-equivalence`)
- Mixture Independence (`independence`)

Conclusion: Sure-Thing (`sure-thing`)

Proof.

Let p=P(E). Realize the conditional laws on E and Eᶜ as A,B for X and C,D for Y. Law invariance gives X~M_p(A,B), Y~M_p(C,D), X|E~M_p(A,0), Y|E~M_p(C,0). Independence cancels 0 to yield A~C from the hypothesis. Replace indifferent mixture components and cancel the common E component: X≽Y iff B≽D. The latter is equivalent to X|Eᶜ≽Y|Eᶜ by independence and law invariance.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 679 and p. 682, footnote 28

Record: `topics/unbounded-utility/results/independence-to-sure-thing.yaml`.

#### Independent Sum Invariance ∧ Stochastic Equivalence ⇒ Existential Copula Sum Invariance — `independent-sum-and-equivalence-imply-existential-copula`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Independent Sum Invariance (`independent-sum-consistency`)
- Stochastic Equivalence (`stochastic-equivalence`)

Conclusion: Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

Proof.

Choose the product copula once. For an eligible triple admitting that copula in both pairs, Z is separately independent of X and Y, but need not be independent of (X,Y). On the standing atomless space realize independent uniforms U,V, and utility coordinates X′=Q_X(U), Y′=Q_Y(U), Z′=Q_Z(V). Now Z′ is independent of (X′,Y′). The marginal laws and both pair laws agree with those of the original triple; consequently so do the two sum laws. Independent Sum Invariance gives the biconditional for the new triple. Stochastic Equivalence and transitivity transfer it to the original comparisons. This establishes SC(C) for the product copula.

Notes. The Stochastic Equivalence premise licenses copying the variables; pairwise independence alone does not license applying the existing jointly-independent sum principle to the original triple.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original copula sum consistency definitions and connecting proofs recorded in this project, 9 September 2026, implementing Zachary Goodsell’s proposal.
- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).

Record: `topics/unbounded-utility/results/independent-sum-and-equivalence-imply-existential-copula.yaml`.

#### Independent Sum Invariance ⇒ Independent Sum Cancellation — `independent-sum-implies-cancellation`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; 2026-09-09.

Premises:

- Independent Sum Invariance (`independent-sum-consistency`)

Conclusion: Independent Sum Cancellation (`independent-sum-cancellation`)

Proof.

Take the reverse direction of the biconditional.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §1–2; Lemma 1, p. 8

Record: `topics/unbounded-utility/results/independent-sum-implies-cancellation.yaml`.

#### Independent Sum Invariance ⇒ Independent Sum Preservation — `independent-sum-implies-preservation`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; 2026-09-09.

Premises:

- Independent Sum Invariance (`independent-sum-consistency`)

Conclusion: Independent Sum Preservation (`independent-sum-preservation`)

Proof.

Take the forward weak implication. If X ≻ Y but Y+Z ≽ X+Z, the reverse implication with X,Y swapped gives Y ≽ X, a contradiction. Thus strict preference is preserved too.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §1–2; Lemma 1, p. 8

Record: `topics/unbounded-utility/results/independent-sum-implies-preservation.yaml`.

#### Independent Sum Invariance ⇒ Shift Invariance — `independent-sum-implies-shift`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; 2026-09-09.

Premises:

- Independent Sum Invariance (`independent-sum-consistency`)

Conclusion: Shift Invariance (`shift-invariance`)

Proof.

Choose Z to be the constant utility b. A constant is independent of every pair and is both comonotonic and antitonic with every variable, so the sum biconditional becomes X ≽ Y iff X+b ≽ Y+b. Apply this wherever the shifted outcomes exist.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.2, p. 18; definitions on pp. 3–4

Record: `topics/unbounded-utility/results/independent-sum-implies-shift.yaml`.

#### Rich Outcomes ∧ Stochastic Dominance ∧ Mixture Independence ∧ Symmetric Gambles Are Neutral ∧ Independent Sum Preservation ⇒ False (⊥) — `levy-refutes-neutral-independent-preservation`

Proved result; source **Misc.**; produced by Zachary Goodsell (stable-law obstruction proposal); GPT-6 (Codex) (specified witness and proof completion); recorded by GPT-6 (Codex); checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Independent Sum Preservation (`independent-sum-preservation`)

Conclusion: False (⊥) (`false`)

Proof.

Let L be positive with density exp(-1/(4t))/(2 sqrt(pi) t^(3/2)), t>0. Its Laplace transform is exp(-sqrt(s)), so independent copies L1+L2 have the law of 4L; its survival is erf(1/(2 sqrt(t))). Let epsilon be an independent fair sign, W=epsilon L1, and D=L2-L1. Both W and D have symmetric laws, hence are indifferent to zero. Independent Sum Preservation applied in both directions to W~0 gives W+L2~L2. The law of W+L2 is the equal mixture of 4L and D. Mixture Independence, D~0, and Stochastic Equivalence (entailed by Dominance) therefore give L~M_(1/2)(4L,0). For t>0 the latter mixture has survival erf(1/sqrt(t))/2, strictly less than erf(1/(2 sqrt(t))) by strict concavity of erf on the positive half-line. At negative thresholds both survivals equal one, and at zero they are one and one half. Thus L strictly stochastically dominates that mixture, contradicting their indifference. The write-up supplies the transform calculation, all law replacements, and the exact scope of the reduced premises.

Notes. Original work: proof adaptation and completion of Goodsell's proposed stable-law obstruction. Goodsell supplied the symmetry-plus-independent- background-risk mechanism; GPT-6 supplied this exact single-index law, the intermediate symmetric difference, the erf dominance proof, and the weaker sufficient premise package. No priority or literature-novelty claim is made. Only weak preservation in both directions is used; the existing Independent Sum Preservation principle is stronger. Totality, Simple EU, independent-sum cancellation, and reflection anti-invariance are not needed. This proves the earlier symmetric-DTU incompatibility candidate as a consequence without rewriting its original conjectural proof or attribution. The executable check is a numerical diagnostic, not the proof or a Lean certificate.

Sources:

- **Goodsell stable-law proposal 9 Sep** — Zachary Goodsell, project conversation, 9 September 2026: proposal that neutral symmetric stable-law mixtures yield an obstruction after adding a common independent stable variable.
- **GPT-6 proof completion 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/levy-refutes-neutral-independent-preservation.md: explicit positive index-1/2 Levy witness, mixture reduction, strict tail comparison, and premise reduction.
- **NIST DLMF 7.7.8** — NIST Digital Library of Mathematical Functions, equation 7.7.8, https://dlmf.nist.gov/7.7.E8: Gaussian integral used to check the Laplace transform; mathematical identity only, not a source for this decision-theoretic argument.

Record: `topics/unbounded-utility/results/levy-refutes-neutral-independent-preservation.yaml`.

<details><summary>Hand-written write-up</summary>

#### A Lévy obstruction to neutral symmetric gambles and independent sums

**Proved implication:** Rich Outcomes + Stochastic Dominance + Mixture
Independence + Symmetric Gambles Are Neutral + Independent Sum Preservation
implies **False**.

**Original work: proof adaptation and completion.** Zachary Goodsell proposed
the stable-law obstruction: neutral symmetric gambles can cease to be
indifferent after adding independent background risk. GPT-6 (Codex),
9 September 2026, supplied the exact positive index-$1/2$ law below, the
intermediate symmetric difference, the complete dominance comparison, and
the reduced sufficient premises. This completes that proposed mechanism;
it does not claim a new construction independent of Goodsell's suggestion,
or priority over the literature. The direct source for this completion is
**Misc.**, with the proposal and analytic reference credited separately.
No independent checker or Lean verification is claimed.

##### 1. The positive stable variable

Use the finite utility chart supplied by Rich Outcomes and let $L$ have density

$$
f(t)=\frac{1}{2\sqrt{\pi}}t^{-3/2}e^{-1/(4t)},\qquad t>0.
$$

Its survival function is

$$
S_L(t)=
\begin{cases}
1,&t\leq0,\\
\operatorname{erf}\!\left(\dfrac{1}{2\sqrt t}\right),&t>0,
\end{cases}
\qquad
\operatorname{erf}(x)=\frac{2}{\sqrt\pi}\int_0^x e^{-u^2}\,du.
$$

Substitution $u=1/(2\sqrt t)$ gives normalization and this survival formula.
The same substitution gives, for $s>0$,

$$
E[e^{-sL}]
=\frac{2}{\sqrt\pi}\int_0^\infty
 e^{-u^2-s/(4u^2)}\,du
=e^{-\sqrt s}.
$$

For completeness, write $I(a)=\int_0^\infty e^{-u^2-a^2/u^2}\,du$.
For $a>0$, differentiation under the integral and substitution $v=a/u$
give $I'(a)=-2I(a)$. Dominated convergence gives $I(0)=\sqrt\pi/2$,
so $I(a)=(\sqrt\pi/2)e^{-2a}$. The integral identity is also recorded in
[NIST DLMF, equation 7.7.8](https://dlmf.nist.gov/7.7.E8).

Consequently independent copies $L_1,L_2$ satisfy

$$L_1+L_2\overset d=4L,$$

because both sides have Laplace transform $e^{-2\sqrt s}$, and Laplace
transforms determine probability laws on $[0,\infty)$. Thus the stability
index is explicitly $1/2$; no ambiguous scale convention is needed.

##### 2. What the preference principles force

Realize $L_1,L_2$ and a fair sign $\varepsilon\in\{-1,1\}$ independently
on the standing atomless probability space. Set

$$W=\varepsilon L_1,\qquad D=L_2-L_1.$$

The laws of $W$ and $D$ are symmetric about zero: for $D$, exchange the two
independent identically distributed inputs. Symmetric Gambles Are Neutral
therefore gives $W\sim0$ and $D\sim0$.

The variable $L_2$ is independent of $(W,0)$. Applying the weak part of
Independent Sum Preservation to each direction of $W\sim0$ yields

$$W+L_2\sim L_2.$$

Conditioning on the independent fair sign shows

$$
W+L_2\overset d=M_{1/2}(L_1+L_2,D)
\overset d=M_{1/2}(4L,D).
$$

These are identities of laws, not identities of the fixed random-variable
mixture lift. Stochastic Dominance entails Stochastic Equivalence by applying
its weak clause in both directions when all tails agree, so these law
replacements are licensed. Mixture Independence applied to $D\sim0$ gives

$$M_{1/2}(4L,D)\sim M_{1/2}(4L,0).$$

To use the displayed form of Mixture Independence, first place $D$ and $0$
in the first mixture branch, with common second branch $4L$, and then exchange
the equal-weight branches by Stochastic Equivalence. Finally $L_2\sim L$
by that same principle. Transitivity now forces

$$\boxed{L\sim M_{1/2}(4L,0).}$$

##### 3. Strict stochastic dominance contradicts that indifference

Put $B=M_{1/2}(4L,0)$. For $t>0$, setting $x=1/(2\sqrt t)>0$ gives

$$S_L(t)=\operatorname{erf}(x),\qquad
S_B(t)=\tfrac12\operatorname{erf}(2x).$$

The function $\operatorname{erf}$ vanishes at zero and is strictly concave
on the positive half-line, because

$$\operatorname{erf}''(x)=-\frac{4x}{\sqrt\pi}e^{-x^2}<0\quad(x>0).$$

Hence $\operatorname{erf}(x)>\tfrac12\operatorname{erf}(2x)$ for every
$x>0$. At $t<0$ both survival functions are one; at $t=0$, they are
respectively one and one half. Thus $L$ weakly dominates $B$ at every
threshold and strictly dominates at some threshold. Stochastic Dominance
requires $L\succ B$, contradicting $L\sim B$.

All variables used take finite utility levels. The ordered chart embeds all
real levels by Rich Outcomes. If there are additional outcomes outside the
chart, their thresholds cut the realized real levels into upper rays; the
same real-threshold inequalities and their one-sided limits prove dominance
at those thresholds as well. No claim about utility arithmetic outside the
chart is used.

##### Consequences and limits

The result rules out Independent Sum Preservation under DU plus Symmetric
Gambles Are Neutral, and therefore rules out Independent Sum Invariance
under that package. It settles the
[earlier symmetric-DTU incompatibility candidate](symmetric-dtu-refutes-independent-sum-candidate.html)
through a new proof record, preserving the candidate's original attribution.

The proof needs no Totality, Simple Expected Utility, reflection principle,
or independent-sum cancellation. Only weak forward sum preservation is used
to preserve an indifference; the current preservation node also requires
strict preservation, so it supplies more than is needed.

The check `checks/levy_obstruction.py` verifies the chosen transform and tail
formulas numerically at finitely many points. The analytic argument above,
not those samples, establishes the universal dominance statement.

</details>

#### Rich Outcomes ∧ Negative Affine Anti-Invariance ⇒ Positive Affine Invariance — `negative-affine-implies-positive-affine`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Positive Affine Invariance (`positive-affine-invariance`)

Proof.

Compose x↦−x with x↦−ax+b. Both reverse the ordering, so their composition x↦ax+b preserves it. Rich Outcomes supplies all intermediate outcome levels.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

Record: `topics/unbounded-utility/results/negative-affine-implies-positive-affine.yaml`.

#### Negative Affine Anti-Invariance ⇒ Reflection Anti-Invariance — `negative-affine-implies-reflection`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Reflection Anti-Invariance (`reflection-anti-invariance`)

Proof.

Set a=1,b=0. The order is reversed.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24 (corrected sign)

Record: `topics/unbounded-utility/results/negative-affine-implies-reflection.yaml`.

#### Rich Outcomes ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Uniqueness of Negative Self-Similarity ⇒ Alternating St Petersburg = −1/2 — `negative-self-similarity-evaluates-alternating`

Proved result; source **Misc.**; produced by Zachary Goodsell (source argument); GPT-6 (Codex) (adaptation and premise audit); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)

Conclusion: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)

Proof.

Let A have P(u(A)=(−2)^n)=2^(−n), n≥1. Splitting off the first atom gives L(A)=L(M_1/2(−2A,−2)); hence A~M_1/2(−2A,−2) by Stochastic Equivalence. The sure gamble c=−1/2 is another fixed point in value: M_1/2(−2c,−2)=M_1/2(1,−2) has simple expectation −1/2, so Simple EU gives c~M_1/2(−2c,−2). Negative Self-Similarity at p=1/2,a=2,b=0,Z=−2 now gives A~c. Rich Outcomes supplies all outcomes used. No Totality, Mixture Independence or affine invariance is required once the uniqueness principle itself is assumed.

Notes. Original work: proof adaptation. Recognize the alternating St Petersburg law and the sure value −1/2 as two solutions of the same negative self-similarity equation, and apply the already extracted uniqueness principle. This describes the work needed for this database entry, not a claim of novelty in the literature.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), proof adaptation and premise audit in the Logical Maps project, 9 September 2026; see the accompanying handwritten write-up.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorems 9–10, pp. 30–31. The cited argument is adapted with the explicitly listed sufficient premises; the reduced-premise claim is the present project contribution.

Record: `topics/unbounded-utility/results/negative-self-similarity-evaluates-alternating.yaml`.

<details><summary>Hand-written write-up</summary>

#### Negative Self-Similarity evaluates Alternating St Petersburg

**Claim.** Rich Outcomes + Stochastic Equivalence + Simple EU + Uniqueness of Negative Self-Similarity imply Alternating St Petersburg $=-1/2$.

Let $A$ be any gamble with

$$\mathbb P\bigl(u(A)=(-2)^n\bigr)=2^{-n},\qquad n\geq1.$$

Use numerical utility notation. Multiplication by $-2$ moves the $n$th atom to the $(n+1)$st value. Consequently

$$\mathcal L(A)=\mathcal L\bigl(M_{1/2}(-2A,-2)\bigr).$$

Indeed, the sure branch gives the first atom $-2$ probability $1/2$, and the transformed branch gives each value $(-2)^m$, $m\geq2$, probability $\frac12\,2^{-(m-1)}=2^{-m}$. Stochastic Equivalence therefore yields

$$A\sim M_{1/2}(-2A,-2). \tag{1}$$

Let $c$ be sure utility $-1/2$. Its corresponding mixture is

$$M_{1/2}(-2c,-2)=M_{1/2}(1,-2),$$

which is simple and has expected utility $-1/2$. Simple EU gives

$$c\sim M_{1/2}(-2c,-2). \tag{2}$$

Equations (1) and (2) are two instances of the same fixed-point equation with $p=1/2$, $a=2$, $b=0$ and $Z$ sure $-2$. Uniqueness of Negative Self-Similarity therefore implies $A\sim c$, which is the desired evaluation.

Rich Outcomes ensures the availability of the sure values and transformed variables. The proof uses no finite expectation for $A$, and it does not need Totality, Mixture Independence, Stochastic Dominance or affine invariance as additional assumptions.

**Original work: proof adaptation.** The new connection factors the source's alternating-prospect evaluation through its separately recorded uniqueness principle. The only calculation is the displayed one-step distributional recursion and the simple fixed point. No literature novelty is asserted.

**Attribution.** The evaluation and uniqueness principles are from Zachary Goodsell, *Symmetries of value*, Theorems 9–10, pp. 30–31. Their reduced-premise connection was recorded by GPT-6 (Codex), 9 September 2026. No independent checker or Lean proof is claimed.

</details>

#### Rich Outcomes ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Mixture Independence ∧ Symmetric Gambles Are Neutral ∧ Shift Invariance ⇒ Transfer of a Shift Across a Mixture — `neutrality-shift-imply-shift-transfer`

Proved result; source **Misc.**; produced by Zachary Goodsell (source argument); GPT-6 (Codex) (premise reduction and explicit cancellation proof); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Mixture Independence (`independence`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Shift Invariance (`shift-invariance`)

Conclusion: Transfer of a Shift Across a Mixture (`shift-transfer`)

Proof.

Symmetric Neutrality and Shift Invariance imply M_(1/2)(X+c,-X)~c/2: center its two branches by subtracting c/2 to obtain a symmetric law. Put L=M_p(X+b/p,Y) and R=M_p(X,Y+b/(1-p)). Regroup the law of M_(1/2)(L,-R) into weights p and 1-p of the two centered pairs. They have sure values b/(2p) and -b/(2(1-p)); Simple EU and Independence therefore make their mixture neutral. The law of M_(1/2)(R,-R) is also symmetric and neutral. Cancelling the common -R branch by Mixture Independence yields L~R. Stochastic Equivalence licenses every regrouping and fixed-lift replacement.

Notes. Original work: small proof adaptation and premise reduction. The paired-law construction is Goodsell's Theorem 3. The present proof isolates symmetric neutrality and shifts as its symmetry inputs and spells out cancellation; neither Scale Invariance nor Totality is needed. This assesses the work performed for the map, not priority in the literature. No independent checker or Lean certification is asserted.

Sources:

- **GPT-6 premise audit 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/neutrality-shift-imply-shift-transfer.md: reduced-premise proof for the Logical Maps DU investigation.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37, DOI 10.1111/nous.12549, Theorem 3, pp. 25–26: paired-reflection and centering argument.

Record: `topics/unbounded-utility/results/neutrality-shift-imply-shift-transfer.yaml`.

<details><summary>Hand-written write-up</summary>

#### Symmetric neutrality and shifts suffice for transfer across mixtures

**Source and work accounting.** The paired-reflection argument is Zachary
Goodsell's *Symmetries of value*, Theorem 3, pp. 25–26. The contribution here is
a small premise reduction and an explicit cancellation proof, recorded by GPT-6
(Codex), 9 September 2026. No independent checker or Lean certification is asserted.

Assume Rich Outcomes, Stochastic Equivalence, Simple EU, Mixture Independence,
Symmetric Neutrality and Shift Invariance. Totality and Scale Invariance are
not used. Work in the normalized real utility chart.

For a gamble $X$ and real $c$, the law of

\[
M_{1/2}(X+c/2,-X-c/2)
\]

is symmetric. Neutrality makes this gamble indifferent to zero. Shift both
outcomes by $c/2$. Shift Invariance, followed by Stochastic Equivalence to
identify the resulting fixed-lift realization, gives

\[
M_{1/2}(X+c,-X)\sim c/2. \tag{1}
\]

Fix $0<p<1$ and $b\in\mathbb R$, and put

\[
L=M_p(X+b/p,Y),\qquad R=M_p(X,Y+b/(1-p)).
\]

The law of $M_{1/2}(L,-R)$ can be regrouped as

\[
M_p\left(
 M_{1/2}(X+b/p,-X),
 M_{1/2}(Y,-Y-b/(1-p))
\right).
\]

By (1), the two inner mixtures are indifferent to $b/(2p)$ and

\[
-\frac{b}{2(1-p)},
\]

respectively. Mixture Independence propagates these indifferences; Simple EU
makes their outer mixture indifferent to zero, since its expectation is

\[
p\frac{b}{2p}+(1-p)\frac{-b}{2(1-p)}=0.
\]

Consequently $M_{1/2}(L,-R)\sim0$. Symmetric Neutrality also gives

\[
M_{1/2}(R,-R)\sim0.
\]

Transitivity of indifference and Mixture Independence cancel the common

\[
-R
\]

branch and yield $L\sim R$, which is Shift Transfer. Every regrouping above
is an identity of laws and uses Stochastic Equivalence before being used as
a preference identity. Rich Outcomes supplies the finite constants and all
the displayed translations.

Under DU this gives a useful sufficient route to Simple Relative Expectation:
Symmetric Neutrality plus Shift Invariance suffice. The source theorem's full
negative-affine package already supplies them, but its scale component is not
needed for this conclusion. This is an account of work performed for the map,
not a claim of priority in the literature.

</details>

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Mixture Independence ∧ Symmetric Gambles Are Neutral ⇒ Reflection Anti-Invariance — `neutrality-totality-independence-imply-reflection`

Proved result; source **Unbounded Utility and Background Risk (unpublished)**; produced by Zachary Goodsell (unpublished manuscript); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Mixture Independence (`independence`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)

Conclusion: Reflection Anti-Invariance (`reflection-anti-invariance`)

Proof.

Suppose X ≽ Y but not −Y ≽ −X. Totality gives −X ≻ −Y. Mixture Independence (including its strict consequence), transitivity, and Stochastic Equivalence to interchange mixture branches give M_½(X,−X) ≻ M_½(Y,−Y). Each mixture has a symmetric law, so Symmetric Neutrality makes both indifferent to 0, a contradiction. Therefore −Y ≽ −X. Applying the same implication to −Y,−X proves the converse. Rich Outcomes supplies the reflected variables.

Notes. The draft calls Symmetric Neutrality “Reflection Symmetry”. This argument does not use the failed extension lemma.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; p. 12 n. 1 (continuing on p. 13)

Record: `topics/unbounded-utility/results/neutrality-totality-independence-imply-reflection.yaml`.

#### Rich Outcomes ∧ Archimedean Outcomes ∧ Totality ∧ Stochastic Dominance ∧ Sure-Thing ⇒ Simple Expected Utility — `original-dtu-implies-simple-eu`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Totality (`totality`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)

Conclusion: Simple Expected Utility (`simple-eu`)

Proof.

Goodsell §3.2 gives the finite-lottery representation consequence of the original DTU axioms. Stochastic Dominance includes law invariance; Sure-Thing becomes Independence on laws. Restrict to finite gambles and use the outcome mixture calibrations to obtain the normalized vNM utility representation. Prospect Richness, Preordering and comparable outcomes are standing here.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, pp. 679–681 (representation result)

Record: `topics/unbounded-utility/results/original-dtu-implies-simple-eu.yaml`.

#### Positive Affine Invariance ⇒ Scale Invariance — `positive-affine-implies-scale`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Positive Affine Invariance (`positive-affine-invariance`)

Conclusion: Scale Invariance (`scale-invariance`)

Proof.

Set b=0.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/positive-affine-implies-scale.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/positive-affine-implies-scale.yaml`.

#### Positive Affine Invariance ⇒ Shift Invariance — `positive-affine-implies-shift`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Positive Affine Invariance (`positive-affine-invariance`)

Conclusion: Shift Invariance (`shift-invariance`)

Proof.

Set a=1.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/positive-affine-implies-shift.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/positive-affine-implies-shift.yaml`.

#### Rich Outcomes ∧ Positive Affine Invariance ∧ Reflection Anti-Invariance ⇒ Negative Affine Anti-Invariance — `positive-reflection-imply-negative`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)

Conclusion: Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Proof.

Apply reflection to reverse the comparison, then the positive transformation x↦ax+b to preserve that reversed comparison.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

Record: `topics/unbounded-utility/results/positive-reflection-imply-negative.yaml`.

#### Independent Sum Preservation ∧ Independent Sum Cancellation ⇒ Independent Sum Invariance — `preservation-cancellation-imply-independent-sum`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; 2026-09-09.

Premises:

- Independent Sum Preservation (`independent-sum-preservation`)
- Independent Sum Cancellation (`independent-sum-cancellation`)

Conclusion: Independent Sum Invariance (`independent-sum-consistency`)

Proof.

Weak preservation gives the forward implication and cancellation the reverse. Together these are precisely Independent Sum Invariance.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; Lemma 1, p. 8

Record: `topics/unbounded-utility/results/preservation-cancellation-imply-independent-sum.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Mixture Independence ∧ Reflection Anti-Invariance ⇒ Symmetric Gambles Are Neutral — `reflection-implies-symmetric-neutrality`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Mixture Independence (`independence`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)

Conclusion: Symmetric Gambles Are Neutral (`symmetric-neutrality`)

Proof.

Let H=M_1/2(X,−X). Its reflected law equals its own law, so H~−H. If H≻0, reflection gives −H≺0, contradiction; likewise if H≺0. Totality gives H~0. If X itself has symmetric law, Stochastic Equivalence gives −X~X and H~X, since the mixture then has X’s law. Thus X~0.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, pp. 25, 27

Record: `topics/unbounded-utility/results/reflection-implies-symmetric-neutrality.yaml`.

#### Rich Outcomes ∧ Archimedean Outcomes ∧ Stochastic Dominance ∧ Relative Expectation ⇒ CDF-Area Extension — `relative-dominance-imply-cdf-area`

Proved result; source **Misc.**; produced by GPT-6 (Codex), connecting argument using the recorded quantile-area method; recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Stochastic Dominance (`stochastic-dominance`)
- Relative Expectation (`relative-expectation`)

Conclusion: CDF-Area Extension (`cdf-area-extension`)

Proof.

Archimedean Outcomes supplies a total chart, measurable by the background convention; Rich Outcomes supplies all intermediate utility levels. Dominance entails Stochastic Equivalence. Quantile couple A,B with the marginal laws of X,Y. Nested threshold events and Tonelli give E[(A−B)₊]=A₊ and E[(A−B)₋]=A₋, the two survival-difference areas. If both are finite, Relative Expectation compares A,B exactly by A₊−A₋, and equivalence transfers the result to X,Y. If A₊=∞ and A₋<∞, put D=A−B and Z_N=B+min(D₊,N)−D₋. Then Z_N≤A, E|Z_N−B|<∞, and E[Z_N−B] tends to +∞. For some N, Relative Expectation gives Z_N≻B; weak Dominance gives A≽Z_N, hence A≻B. Swap the variables for the other one-infinite case. These exhaust the cases required by CDF-Area Extension.

Notes. Original work: connecting argument and proof adaptation. Reuses the recorded quantile-area/Tonelli identity and supplies the truncated-positive-difference step for the one-infinite-area case. The converse is not attributed as a theorem of the unpublished manuscript. Under DU this establishes CDF-Area Extension iff Relative Expectation. No Totality, Mixture Independence, L¹ Continuity or affine invariance is needed as an additional premise. This describes work for the map, not a claim of literature novelty.

Sources:

- **GPT-6 connecting proof 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/relative-dominance-imply-cdf-area.md: quantile-coupling converse to the existing area-to-relative implication, with one-sided truncation for a single infinite area.
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026 (unpublished), §3, pp. 7–8: source of the CDF-area comparison. The existing project writeups/cdf-area-preorder.md and results/cdf-area-implies-relative.yaml contain related quantile-area and integrable-difference calculations.

Record: `topics/unbounded-utility/results/relative-dominance-imply-cdf-area.yaml`.

<details><summary>Hand-written write-up</summary>

#### Relative Expectation and Dominance recover CDF-area comparisons

**Proved implication:** Rich Outcomes + Archimedean Outcomes + Stochastic
Dominance + Relative Expectation imply CDF-Area Extension.

**Original work: connecting argument and proof adaptation.** GPT-6 (Codex),
9 September 2026, combines the existing quantile-area identity with a
one-sided truncation of the utility difference. Goodsell's unpublished
*Unbounded Utility and Background Risk*, §3, supplies the area rule;
this converse is a project connecting proof, not attributed as a theorem
from that manuscript. No independent checker, Lean verification or
literature-novelty claim is made.

##### Framework and the quantile identity

Archimedean Outcomes makes the utility chart total; its measurability is a
standing chart convention. Rich Outcomes supplies every finite real level
used below. Write numerical utility variables as \(X,Y\), and put

\[
d(t)=S_X(t)-S_Y(t),\qquad A_\pm=\int_{\mathbb R}d_\pm(t)\,dt.
\]

Dominance implies Stochastic Equivalence, so preferences can be transferred
to new realizations once their marginal laws have been checked. Let \(U\)
be uniform on the standing sample space and set
\(A=Q_X(U), B=Q_Y(U)\) using increasing quantiles. These have the original
marginal laws. Assign finite valid outcomes at the null quantile endpoints.

For each threshold, the upper-level events of these two nondecreasing
functions of \(U\) are nested. Thus

\[
P(A>t,B\le t)=(S_X(t)-S_Y(t))_+.
\]

Integrating the elementary identity
\((a-b)_+=\int\mathbf1_{\{b\le t<a\}}\,dt\) and applying Tonelli gives

\[
E[(A-B)_+]=A_+,\qquad E[(A-B)_-]=A_-.
\tag{1}
\]

These equalities allow infinite values and do not subtract two infinities.

##### Both areas finite

If \(A_+,A_-<\infty\), equation (1) shows that the actual difference
\(A-B\) is integrable, with mean \(A_+-A_-\). Relative Expectation gives
\(A\succeq B\iff A_+\ge A_-\). Stochastic Equivalence transfers both
directions to \(X,Y\), including indifference when the areas are equal.

##### Exactly one infinite area

Suppose \(A_+=\infty\) and \(A_-<\infty\). Put \(D=A-B\), and for a
positive integer \(N\) define

\[
Z_N=B+\min(D_+,N)-D_-.
\]

This is a measurable finite-valued-at-each-state utility variable, so the
full real chart realizes it as a gamble. It need not be a *simple* gamble.
Pointwise, \(Z_N\le A\), and

\[
E|Z_N-B|\le N+A_-<\infty,\qquad
E[Z_N-B]=E[\min(D_+,N)]-A_-\longrightarrow+\infty.
\]

Choose \(N\) with positive mean. Relative Expectation gives
\(Z_N\succ B\), while pointwise domination gives stochastic domination,
hence \(A\succeq Z_N\). In a preorder, a weak comparison followed by a
strict comparison is strict, so \(A\succ B\). Transfer to \(X,Y\) by
Stochastic Equivalence. The case \(A_+<\infty,A_-=\infty\) follows by
exchanging the variables and gives \(Y\succ X\).

These are all cases constrained by CDF-Area Extension. When both areas are
infinite, neither that principle nor this proof demands a comparison.

##### Consequence under DU

DU supplies the outcome and dominance premises. Combined with the already
recorded implication from CDF-Area Extension to Relative Expectation,
this establishes their equivalence under DU. No continuity, mixture
independence, totality or affine symmetry is used in this proof.

</details>

#### Archimedean Outcomes ∧ Relative Expectation ⇒ Expected Utility — `relative-implies-eu`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Archimedean Outcomes (`archimedean-outcomes`)
- Relative Expectation (`relative-expectation`)

Conclusion: Expected Utility (`expected-utility`)

Proof.

Archimedean Outcomes makes the real chart total. If u(X),u(Y) are integrable, so is their difference, and E[u(X)−u(Y)]=E[u(X)]−E[u(Y)]. Apply Relative Expectation.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, pp. 26–27
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/relative-implies-eu.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/relative-implies-eu.yaml`.

#### Relative Expectation ⇒ Simple Relative Expectation — `relative-implies-simple-relative`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Relative Expectation (`relative-expectation`)

Conclusion: Simple Relative Expectation (`simple-relative-expectation`)

Proof.

A finite-valued difference is integrable. Restrict Relative Expectation to such pairs.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, p. 26
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/relative-implies-simple-relative.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/relative-implies-simple-relative.yaml`.

#### Rich Outcomes ∧ Stochastic Equivalence ∧ Relative Expectation ∧ Symmetric Gambles Are Neutral ∧ Shift Invariance ⇒ Folded Expectation — `relative-neutrality-shift-imply-folded`

Proved result; source **Misc.**; produced by Zachary Goodsell (source argument); GPT-6 (Codex) (adaptation and premise audit); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Relative Expectation (`relative-expectation`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Shift Invariance (`shift-invariance`)

Conclusion: Folded Expectation (`folded-expectation`)

Proof.

For a foldable real-utility X, couple a copy A of X and a copy B of −X comonotonically as A=Q_X(U), B=−Q_X(1−U). The survival-function difference is h_X(t) for t>0 and h_X(−t) for t<0, except at countably many atom thresholds. Thus E|A−B|=2∫₀∞|h_X| and E(A−B)=2F(X). The midpoint Z=(A+B)/2 has a symmetric law, while A−Z is integrable with mean F(X). Relative Expectation gives A~Z+F(X); Symmetric Neutrality and Shift Invariance give Z+F(X)~F(X). Stochastic Equivalence gives X~A. Therefore each foldable X is indifferent to its folded expectation, and the standing sure-outcome order compares any two such variables exactly by these real numbers.

Notes. Original work: proof adaptation. Expand the quantile symmetrization behind Goodsell’s folded-expectation argument and retain only Relative Expectation, neutrality, shift invariance and the explicit domain/law assumptions; full affine symmetry and Totality are unnecessary. This describes the work needed for this database entry, not a claim of novelty in the literature.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), proof adaptation and premise audit in the Logical Maps project, 9 September 2026; see the accompanying handwritten write-up.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 6, pp. 27–29. The cited argument is adapted with the explicitly listed sufficient premises; the reduced-premise claim is the present project contribution.

Record: `topics/unbounded-utility/results/relative-neutrality-shift-imply-folded.yaml`.

<details><summary>Hand-written write-up</summary>

#### Relative Expectation, Neutrality and Shift Invariance imply Folded Expectation

**Claim.** Rich Outcomes + Stochastic Equivalence + Relative Expectation + Symmetric Neutrality + Shift Invariance imply Folded Expectation.

Write the real utility variable of a gamble as $X$. Put

$$h_X(t)=\mathbb P(X>t)-\mathbb P(X<-t),\qquad
F(X)=\int_0^\infty h_X(t)\,dt,$$

and suppose $\int_0^\infty|h_X(t)|\,dt<\infty$. Let $S_X(t)=\mathbb P(X>t)$, and set $d(t)=S_X(t)-S_{-X}(t)$.

For positive $t$, $d(t)=h_X(t)$. For negative $t$, $d(t)=h_X(-t)$ except possibly when $t$ or $-t$ is an atom threshold. There are at most countably many such thresholds, so

$$\int_{\mathbb R}|d(t)|\,dt=2\int_0^\infty|h_X(t)|\,dt<\infty,
\qquad \int_{\mathbb R}d(t)\,dt=2F(X). \tag{1}$$

Let $U$ be uniform and $Q_X$ an increasing quantile for $X$. Define

$$A=Q_X(U),\qquad B=-Q_X(1-U).$$

Arbitrary finite values may be assigned at the null quantile endpoints. These have the laws of $X$ and $-X$, and both are nondecreasing functions of $U$. Their upper-threshold events are therefore nested for every threshold, up to null sets. Tonelli's theorem and the elementary interval-length identity give

$$\begin{aligned}
\mathbb E|A-B|
&=\int_{\mathbb R}\mathbb E\left|\mathbf1_{\{A>t\}}-\mathbf1_{\{B>t\}}\right|\,dt\\
&=\int_{\mathbb R}|S_X(t)-S_{-X}(t)|\,dt<\infty.
\end{aligned}$$

Since this integral is finite, Fubini also gives $\mathbb E(A-B)=\int d=2F(X)$.

Now set

$$Z=\frac{A+B}{2}=\frac{Q_X(U)-Q_X(1-U)}2.$$

Replacing $U$ by $1-U$ negates $Z$ without changing its law. Thus Symmetric Neutrality gives $Z\sim0$. Moreover, $A-Z=(A-B)/2$ is integrable with mean $F(X)$. Relative Expectation applied in both directions gives

$$A\sim Z+F(X),$$

because their actual difference has mean zero. Shift Invariance transports $Z\sim0$ to $Z+F(X)\sim F(X)$, and Stochastic Equivalence gives $X\sim A$. Consequently

$$X\sim F(X).$$

The same argument applies to any other foldable $Y$. The standing linear sure-outcome order then yields $X\succeq Y$ exactly when $F(X)\geq F(Y)$.

Rich Outcomes supplies the midpoint, shifted variables and sure folded values. All are finite-chart variables, even when their individual ordinary expectations are undefined. No conditional improper integral is used: the absolute integrability in (1) is what justifies both Tonelli/Fubini steps. Totality, Mixture Independence and full affine symmetry are absent from the proof.

**Original work: proof adaptation.** The source's folded-expectation argument uses a comparison with a symmetric prospect. The present contribution expands that comparison as an explicit quantile coupling and audits which assumptions it needs. This is a reduced-premise connection for the database, not a literature-novelty claim.

**Attribution.** Source construction: Zachary Goodsell, *Symmetries of value*, Theorem 6, pp. 27–29. Explicit coupling proof and premise audit: GPT-6 (Codex), 9 September 2026. No independent checker or Lean proof is claimed.

</details>

#### Rich Outcomes ∧ Stochastic Equivalence ∧ Mixture Independence ∧ Relative Expectation ∧ Uniqueness of Negative Self-Similarity ⇒ Pasadena = ln 2 — `relative-self-similarity-evaluates-pasadena`

Proved result; source **Misc.**; produced by Zachary Goodsell (Highland Park and Q constructions); GPT-6 (Codex) (negative-self-similarity factorization and explicit couplings); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Mixture Independence (`independence`)
- Relative Expectation (`relative-expectation`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)

Conclusion: Pasadena = ln 2 (`pasadena-value`)

Proof.

For Pasadena P, replace the negative payoff -4^k/(2k) by -4^k/(2k-1) to obtain Highland Park H. The actual pointwise difference P-H is nonnegative and has expectation ln 2. Write H in law as M_(2/3)(Q,-2Q), where Q takes 2^(2k-1)/(2k-1) with probability 3/4^k. Couple Q with S of law M_(1/4)(4Q,0) by sending its first atom to zero and its kth atom, k>=2, to four times its (k-1)st value. The difference has absolute expectation 3 and expectation zero, so Relative Expectation gives Q~S. Substitute this comparison into the Q branch of H and regroup: H~M_(1/2)(-2H,0). Zero solves the same fixed-value equation. Negative Self-Similarity yields H~0. Relative Expectation gives P~H+ln 2; a half-mixture shift transfer, itself an integrable zero-mean comparison, and Independence give H+ln 2~ln 2. All distributional replacements are licensed by Stochastic Equivalence.

Notes. Original work: moderate proof adaptation. The two distributions and integrable-difference identities come from Goodsell's Theorem 11. The new step factors the proof through the already recorded uniqueness principle: H is a fixed value of X -> M_(1/2)(-2X,0), so one can replace the source's Totality/positive-affine square-root argument by Negative Self-Similarity. No separate Totality, Scale Invariance, Reflection Anti-Invariance, or L1 Continuity is required. Exact couplings and remainder bounds are supplied in the write-up and diagnostic. This is work accounting, not a claim of literature novelty.

Sources:

- **GPT-6 factorization 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/relative-self-similarity-evaluates-pasadena.md: factorization through negative self-similarity and explicit integrable couplings.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37, DOI 10.1111/nous.12549, Theorem 11, pp. 32–33: Pasadena, Highland Park, and Q constructions and relative-expectation identities.

Record: `topics/unbounded-utility/results/relative-self-similarity-evaluates-pasadena.yaml`.

<details><summary>Hand-written write-up</summary>

#### Pasadena from Relative Expectation and Negative Self-Similarity

**Source and work accounting.** Pasadena's modification to Highland Park and
the auxiliary prospect \(Q\) are Zachary Goodsell's constructions in
*Symmetries of value*, Theorem 11, pp. 32–33. The new factorization below uses
the recorded uniqueness principle in place of the source's Totality and
positive-affine argument. GPT-6 (Codex), 9 September 2026, supplied this
moderate proof adaptation, the explicit couplings, and the remainder bounds.
This describes work done for the map, not priority in the literature. No
independent checker or Lean certification is asserted.

Assume Rich Outcomes, Stochastic Equivalence, Mixture Independence, Relative
Expectation and Uniqueness of Negative Self-Similarity. We do not assume
Totality, Scale Invariance, reflection, or L¹ Continuity. All arithmetic below
is within the real utility chart; Rich Outcomes supplies the required outcomes.

##### 1. Pasadena and Highland Park have an integrable difference

Couple Pasadena \(P\) and Highland Park \(H\) using the same integer
\(N\), where \(\Pr(N=n)=2^{-n}\). For \(k\ge1\), put

\[
\begin{aligned}
P(2k-1)=H(2k-1)&=\frac{2^{2k-1}}{2k-1},\\
P(2k)&=-\frac{4^k}{2k},&H(2k)&=-\frac{4^k}{2k-1}.
\end{aligned}
\]

The difference \(P-H\) is nonnegative. Its expectation and absolute
expectation are both

\[
\sum_{k=1}^{\infty}\frac1{2k(2k-1)}=\ln2. \tag{1}
\]

The equality follows by pairing the alternating harmonic series; the series
in (1) itself is nonnegative and absolutely convergent. Relative Expectation
therefore gives \(P\sim H+\ln2\), since the difference between these two
actually coupled variables is integrable with mean zero.

##### 2. The auxiliary relative-expectation identity

Let \(Q\) take

\[
a_k=\frac{2^{2k-1}}{2k-1}
\quad\text{with probability}\quad\frac3{4^k},\qquad k\ge1.
\]

The positive and negative masses in the preceding definition of \(H\)
give the identity of laws

\[
H\overset d=M_{2/3}(Q,-2Q). \tag{2}
\]

For an explicit coupling of \(Q\) with a variable \(S\), use the same
index \(k\), put \(S=0\) when \(k=1\), and put \(S=4a_{k-1}\)
when \(k\ge2\). Its law is

\[
S\overset d=M_{1/4}(4Q,0).
\]

At \(k=1\) the expectation contribution from \(Q-S\) is \(3/2\).
For \(k\ge2\), the contribution is

\[
\frac3{4^k}(a_k-4a_{k-1})
=-\frac3{(2k-1)(2k-3)}.
\]

Telescoping yields

\[
\sum_{k=2}^{K}\frac3{(2k-1)(2k-3)}
=\frac32\left(1-\frac1{2K-1}\right).
\]

Consequently \(E[Q-S]=0\) and \(E|Q-S|=3\). Relative Expectation
and Stochastic Equivalence give

\[
Q\sim M_{1/4}(4Q,0). \tag{3}
\]

##### 3. Highland Park satisfies a negative fixed-value equation

Substitute (3) into the \(Q\) branch of (2) by Mixture Independence.
Regrouping laws gives

\[
\begin{aligned}
H
&\sim \tfrac16(4Q)+\tfrac12\delta_0+\tfrac13(-2Q)\\
&\overset d=M_{1/2}(-2H,0).
\end{aligned} \tag{4}
\]

In these two lines, scalar coefficients outside parentheses denote
randomized-mixture weights, not pointwise averages of utilities. The last
identity follows directly by pushing the law in (2) through \(x\mapsto-2x\).
No affine transformation has been applied to a preference equality.
Stochastic Equivalence licenses all distributional regrouping.

The sure zero also satisfies

\[
0\sim M_{1/2}(-2\cdot0,0).
\]

Apply Uniqueness of Negative Self-Similarity with
\(p=1/2,a=2,b=0,Z=0\). Equation (4) and the sure-zero equation yield

\[
H\sim0. \tag{5}
\]

This is the central factorization. It avoids extracting a square root of
a positive scaling relation, the point at which the source proof uses
Totality and Positive Affine Invariance.

##### 4. Transfer the finite difference to a sure value

For completeness, the limited shift consequence needed here follows from
the listed assumptions. For any \(X\) and real \(c\), the two variables

\[
M_{1/2}(X+c,0),\qquad M_{1/2}(X,c)
\]

under the fixed mixture lift have difference \(c\) on the first half and
\(-c\) on the second half, apart from irrelevant endpoints. Relative
Expectation makes them indifferent. If \(X\sim0\), Mixture Independence
and Stochastic Equivalence also give

\[
M_{1/2}(X,c)\sim M_{1/2}(0,c)\sim M_{1/2}(c,0).
\]

Cancel the common zero branch to obtain \(X+c\sim c\). Apply this with
\(X=H\), \(c=\ln2\), and (5). Together with the comparison from (1),
it proves

\[
P\sim H+\ln2\sim\ln2.
\]

Any variable with Pasadena's law is indifferent to the constructed \(P\)
by Stochastic Equivalence, so the conclusion has the universal form of the
recorded evaluation principle.

`checks/calculation_factorizations.py` verifies the telescoping coupling
identities with exact fractions and explicit remaining-series bounds. Those
diagnostics supplement this proof; they do not certify the preference axioms.

</details>

#### Rich Outcomes ∧ Archimedean Outcomes ∧ Stochastic Dominance ∧ Mixture Independence ⇒ Simple Expected Utility — `rich-archimedean-dominance-independence-imply-simple-eu`

Proved result; source **Misc.**; produced by GPT-6 (Codex) (finite-lottery proof and premise audit using Goodsell's framework); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)

Conclusion: Simple Expected Utility (`simple-eu`)

Proof.

Stochastic Dominance gives Stochastic Equivalence and strictly orders binary mixtures of fixed distinct sure endpoints by the probability of the better endpoint. Archimedean Outcomes calibrates each outcome against 0 and 1, giving a unique finite chart value u. For any two simple gambles, choose common sure endpoints enclosing their finite supports and 0,1. Every supported outcome is indifferent to a binary mixture of these endpoints. Independence and law invariance replace the finite branches and flatten the resulting compound lotteries. The endpoint probability of an outcome o is q(0)+(q(1)-q(0))*u(o), by the chart's three binary calibration clauses. Thus the two flattened probabilities compare exactly as their finite expected chart utilities. The chart is strictly increasing; Rich Outcomes supplies an outcome o_r at every real level, making each inverse upper ray {u>r} the measurable outcome ray {o>o_r}. The chart is therefore total and measurable, as required by Simple EU. No Totality over arbitrary gambles or gamble continuity is used. See the write-up for endpoint, calibration and finite-mixture details.

Notes. Original work: small proof adaptation and premise audit. The source supplies the finite-lottery representation and DU framework; this entry writes out the argument without global Totality and without presupposing Simple EU or Restricted Totality. It is a new connecting proof, not a change to the existing source-attributed original-dtu-implies-simple-eu record. Rich and Archimedean Outcomes alone are not sufficient: dominance and mixture independence supply essential steps in this proof. The DU and DTU presets can therefore omit Simple EU as an assumed axiom while retaining it as a derived consequence. No minimality, literature priority, independent certification or Lean verification is claimed.

Sources:

- **GPT-6 finite-lottery proof 9 Sep** — GPT-6 (Codex), Logical Maps, 9 September 2026; proof and premise audit in writeups/rich-archimedean-dominance-independence-imply-simple-eu.md, following Zachary Goodsell’s request to derive Simple EU from the more basic DU axioms.
- **Decision Theory Unbound** — Zachary Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695, DOI 10.1111/nous.12473, §3.2 pp. 678–681 and §3.3 pp. 681–682: utility calibration, finite expected utility and the DU/DTU distinction.

Record: `topics/unbounded-utility/results/rich-archimedean-dominance-independence-imply-simple-eu.yaml`.

<details><summary>Hand-written write-up</summary>

#### Simple EU from the more basic DU axioms

**Proved implication:** Rich Outcomes + Archimedean Outcomes + Stochastic
Dominance + Mixture Independence imply Simple Expected Utility.

Totality over arbitrary gambles is not assumed. Nor is Restricted Totality
or Simple EU assumed: comparison of all simple gambles is a conclusion.
Rich Outcomes and Archimedean Outcomes **alone** do not give this result.

**Source and contribution.** Goodsell's *Decision theory unbound*, §3.2,
pp. 678–681, supplies the utility calibration and finite-lottery representation;
§3.3, pp. 681–682, distinguishes DU from DTU. This is a small proof adaptation
and premise audit by GPT-6 (Codex), 9 September 2026, writing out why global
Totality is unnecessary in the mixture formulation. The original
source-attributed representation record is retained. No literature priority,
independent certification or Lean verification is claimed.

##### Binary comparisons and law invariance

Stochastic Dominance includes its weak clause. Applying it in both directions
to equally distributed gambles gives Stochastic Equivalence. We may therefore
use identities in law for the fixed randomized-selection operation $M_p$.

For sure outcomes $a<b$, write

\[
B_{a,b}(p)=M_p(b,a),\qquad 0\le p\le1.
\]

The endpoint cases have the same laws as sure $a$ and sure $b$. If $p>q$,
every upper tail of $B_{a,b}(p)$ is at least that of $B_{a,b}(q)$, with a
strict difference at the outcome threshold $a$. Stochastic Dominance gives

\[
B_{a,b}(p)\succ B_{a,b}(q).
\tag{1}
\]

In particular, these binary gambles are comparable and have distinct values
for distinct probabilities. This follows from dominance, not a Totality axiom.

##### A total, uniquely calibrated chart

Archimedean Outcomes applies separately in the three possible ranges of a
sure outcome $o$:

- For $0<o<1$, it gives $o\sim M_r(1,0)$ for some $0<r<1$.
- For $o>1$, it gives $1\sim M_p(o,0)$ for some $0<p<1$; set $r=1/p>1$.
- For $o<0$, it gives $0\sim M_p(1,o)$ for some $0<p<1$; set
  $r=-p/(1-p)<0$.

Use $u(0)=0$ and $u(1)=1$ at the references. These are precisely the three
clauses defining the normalized chart, so every outcome has a finite chart
value $u(o)$. Equation (1) makes the probability in each calibration unique.
It also places a nontrivial binary mixture strictly between its endpoints,
so a calibration cannot put an outcome in the wrong one of these three ranges.

##### Finite lotteries reduce to common binary endpoints

Fix two simple gambles $X,Y$. Choose $a$ and $b$ as the minimum and maximum
of their finite ranges together with the reference outcomes $0,1$. Then
$a<b$. For every outcome $o$ in this interval, Archimedean Outcomes and (1)
give a unique $q(o)\in[0,1]$ such that

\[
o\sim B_{a,b}(q(o)).
\tag{2}
\]

Here $q(a)=0$ and $q(b)=1$ use the endpoint identities; only interior
outcomes require Archimedean Outcomes. Since sure outcomes have their
standing linear order, (1) and (2) imply that $q$ strictly preserves that
order. In particular, $q(1)>q(0)$.

Mixture Independence preserves indifference in a mixture branch.
Stochastic Equivalence permits interchange of the two branches and
reassociation of compound mixtures, so it also permits substitution in
the other branch. Inductively replace each outcome of a finite lottery
using (2), then flatten its finite compound mixture in law. If $X$ assigns
probabilities $\alpha_i$ to outcomes $o_i$, this yields

\[
X\sim B_{a,b}\!\left(\sum_i\alpha_iq(o_i)\right).
\tag{3}
\]

Discard zero-probability atoms by Stochastic Equivalence. A remaining
one-atom law is already sure; otherwise the inductive substitutions use
only mixture weights strictly between zero and one. No independence
assertion at weights zero or one is needed.

The same substitution and flattening applied to the chart calibrations
gives a common affine expression for all $o$ in the interval. Write
$r=u(o)$:

- If $0\le r\le1$, then
  $q(o)=r q(1)+(1-r)q(0)$.
- If $r>1$, then
  $q(1)=r^{-1}q(o)+(1-r^{-1})q(0)$.
- If $r<0$, put $p=-r/(1-r)$. Then
  $q(0)=p q(1)+(1-p)q(o)$.

In each case, uniqueness in (1) justifies equating the flattened
probabilities. Rearranging gives

\[
q(o)=q(0)+(q(1)-q(0))u(o).
\tag{4}
\]

Equations (1), (3) and (4), and $q(1)-q(0)>0$, now give

\[
X\succeq Y
\quad\Longleftrightarrow\quad
\mathbb E[u(X)]\ge\mathbb E[u(Y)].
\tag{5}
\]

All sums in this step are finite. This proves Restricted Totality as part
of the conclusion, without comparing arbitrary nonsimple gambles.

##### Measurability and the role of Rich Outcomes

Apply the common-endpoint argument to any pair of sure outcomes and $0,1$.
Equation (4) shows that the global chart $u$ strictly preserves the outcome
order. Rich Outcomes supplies, for every $r\in\mathbb R$, an outcome
$o_r$ with $u(o_r)=r$. Therefore

\[
\{o:u(o)>r\}=\{o:o>o_r\}.
\]

These upper rays are measurable by the standing outcome-space convention.
The real upper rays generate the Borel sigma-algebra, so $u$ is measurable.
Together with chart totality and (5), this proves the complete recorded
Simple EU principle, including its measurability requirement.

##### What changes in the map

DU now assumes Rich Outcomes, Archimedean Outcomes, Stochastic Equivalence,
Stochastic Dominance and Mixture Independence. This theorem derives Simple
EU. DTU adds Totality to the same preset. The former Simple-EU-based
formulation is equivalent, using the existing Simple EU ⇒ Archimedean
Outcomes result for the reverse implication.

The additional premises must not be dropped from the theorem record merely
because the DU background usually supplies them. The
[Two-sample minimum: zero extension](finite-two-sample-minimum.md) demonstrates why the
unqualified Rich + Archimedean Outcomes ⇒ Simple EU arrow would be false.

</details>

#### Rich Outcomes ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Archimedean Gambles ⇒ False (⊥) — `rich-simple-dominance-refutes-archimedean-gambles`

Proved result; source **Misc.**; produced by Zachary Goodsell (St Petersburg argument); GPT-6 (Codex), explicit reduction of the sufficient premises; recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Archimedean Gambles (`archimedean-gambles`)

Conclusion: False (⊥) (`false`)

Proof.

Let S take utility 2ⁿ with probability 2⁻ⁿ for n≥1. Rich Outcomes and standing prospect richness supply S, its finite truncations T_N=min(S,2ᴺ), and the required mixtures. For N≥1, E[T_N]=N+1. By Simple EU, T_N is indifferent to the sure utility N+1. Stochastic Dominance gives S ≽ T_N, hence S ≻ c for every real c by choosing N+1>c. Thus S ≻ 1 ≻ 0. Fix any p∈(0,1) and choose N with p(N+1)>1. The mixture M_p(S,0) stochastically dominates the finite-valued mixture M_p(T_N,0), which Simple EU makes indifferent to the sure utility p(N+1)>1. Therefore M_p(S,0) ≻ 1 for every p∈(0,1). Archimedean Gambles would require one such mixture to be indifferent to 1, a contradiction. Only the standing preorder is used to compose these comparisons; no Totality or Mixture Independence is required.

Notes. This is the existing Goodsell argument with its sufficient assumptions made explicit, not a new counterexample. The original source-attributed DTU result is retained unchanged. Stochastic Equivalence follows from this topic’s dominance axiom, but is not separately needed in the displayed proof. Relative to these assumptions, Archimedean Gambles is ruled out; adding it to the background yields False.

Sources:

- **GPT-6 premise audit 9 Sep** — GPT-6 (Codex), project premise audit, 9 September 2026: the St Petersburg proof recorded in dtu-refutes-archimedean-gambles uses only Rich Outcomes, Simple EU, and Stochastic Dominance. This record makes that sufficient subpackage explicit.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 22: St Petersburg obstruction to Archimedean Gambles.

Record: `topics/unbounded-utility/results/rich-simple-dominance-refutes-archimedean-gambles.yaml`.

#### Rich Outcomes ∧ Simple Expected Utility ∧ Sure-Thing ∧ Countable Sure-Thing ⇒ False (⊥) — `rich-simple-sure-thing-refutes-countable`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Simple Expected Utility (`simple-eu`)
- Sure-Thing (`sure-thing`)
- Countable Sure-Thing (`countable-sure-thing`)

Conclusion: False (⊥) (`false`)

Proof.

Use the strengthened St Petersburg contradiction from §2.3. Simple EU supplies Restricted Totality, Restricted Stochastic Equivalence and finite conditional EU calculations. With independent sequences of fair tosses let A be first-toss St Petersburg, B the same starting at toss 2, and C an independent St Petersburg variable. Conditional on B=2^n, A is a fair mixture of 2 and 2^(n+1), so its conditional expected value exceeds B by 1; Countable Sure-Thing would give A≻B. Partition the A,C space by the maximum of their finite stopping times. On each cell they are simple and their restricted laws coincide, so Countable Sure-Thing would give A~C. Repeat for B,C to get B~C, contradicting Preordering. Null sets can be assigned a finite outcome without changing the simple-law comparisons.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Representation update: the former negative conclusion is expressed by adding countable-sure-thing to the premises and concluding False. The mathematical claim, source, and proof are unchanged.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.3, pp. 675–676

Record: `topics/unbounded-utility/results/rich-simple-sure-thing-refutes-countable.yaml`.

#### Rich Outcomes ∧ Shift Invariance ∧ Scale Invariance ⇒ Positive Affine Invariance — `shift-scale-imply-positive-affine`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Shift Invariance (`shift-invariance`)
- Scale Invariance (`scale-invariance`)

Conclusion: Positive Affine Invariance (`positive-affine-invariance`)

Proof.

Apply Scale Invariance and then Shift Invariance. Rich Outcomes supplies all intermediate outcome levels.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §§3, 5, pp. 24, 34
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/shift-scale-imply-positive-affine.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/shift-scale-imply-positive-affine.yaml`.

#### Rich Outcomes ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Mixture Independence ∧ Transfer of a Shift Across a Mixture ⇒ Simple Relative Expectation — `shift-transfer-implies-simple-relative`

Proved result; source **Misc.**; produced by Zachary Goodsell (source argument); GPT-6 (Codex) (adaptation and premise audit); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Mixture Independence (`independence`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)

Conclusion: Simple Relative Expectation (`simple-relative-expectation`)

Proof.

Write D=u(X)−u(Y), with finitely many values d_i of positive probabilities p_i, and let Y_i have the conditional law of Y given D=d_i. The law of M_1/2(X,0) is the finite mixture with weights p_i of M_1/2(Y_i+d_i,0). Shift Transfer gives M_1/2(Y_i+d_i,0)~M_1/2(Y_i,d_i). Mixture Independence propagates these indifferences through the finite mixture; Stochastic Equivalence licenses conditional-law realizations, regrouping and branch exchanges. The resulting law is M_1/2(Y,D), so M_1/2(X,0)~M_1/2(Y,D). Two mixture cancellations then give X≽Y iff D≽0, and Simple EU makes this equivalent to E[D]≥0. Rich Outcomes supplies the sure d_i and the simple gamble realizing D.

Notes. Original work: proof adaptation. Isolate the actual inputs to Goodsell’s Theorem 4: once Shift Transfer is supplied as a principle, neither Totality, Stochastic Dominance nor full affine symmetry is needed. This describes the work needed for this database entry, not a claim of novelty in the literature.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), proof adaptation and premise audit in the Logical Maps project, 9 September 2026; see the accompanying handwritten write-up.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 4, pp. 26–27. The cited argument is adapted with the explicitly listed sufficient premises; the reduced-premise claim is the present project contribution.

Record: `topics/unbounded-utility/results/shift-transfer-implies-simple-relative.yaml`.

<details><summary>Hand-written write-up</summary>

#### Shift Transfer recovers Simple Relative Expectation

**Claim.** Rich Outcomes + Stochastic Equivalence + Simple EU + Mixture Independence + Shift Transfer imply Simple Relative Expectation.

Use numerical utility notation throughout. Suppose $D=X-Y$ has finitely many values. Ignore probability-zero values, and write its remaining values as $d_1,\ldots,d_k$, with probabilities $p_1,\ldots,p_k>0$. Rich Outcomes supplies a sure outcome for each $d_i$ and the simple gamble with utility variable $D$.

For each $i$, choose $Y_i$ with the conditional law of $Y$ given $D=d_i$. Such real-valued laws can be realized on the standing atomless standard probability space. The corresponding conditional law of $X$ is that of $Y_i+d_i$. In particular, by laws,

$$\mathcal L\bigl(M_{1/2}(X,0)\bigr)
=\sum_{i=1}^k p_i\,\mathcal L\bigl(M_{1/2}(Y_i+d_i,0)\bigr).$$

Shift Transfer, with transfer parameter $d_i/2$, gives

$$M_{1/2}(Y_i+d_i,0)\sim M_{1/2}(Y_i,d_i).$$

Mixture Independence propagates indifferences through a finite randomized mixture. To justify replacement in a second branch, first exchange branches using Stochastic Equivalence, apply Independence, and exchange back. Iterating over a binary realization of the finite mixture therefore gives

$$M_{1/2}(X,0)\sim M_{1/2}(Y,D). \tag{1}$$

Here the law of the mixture after all replacements is

$$\sum_i p_i\left(\tfrac12\mathcal L(Y_i)+\tfrac12\delta_{d_i}\right)
=\tfrac12\mathcal L(Y)+\tfrac12\mathcal L(D),$$

which is precisely the law on the right of (1). Stochastic Equivalence licenses both law identities, and so also disposes of the ignored null values.

We can now cancel mixtures:

$$\begin{aligned}
X\succeq Y
&\iff M_{1/2}(X,0)\succeq M_{1/2}(Y,0)\\
&\iff M_{1/2}(Y,D)\succeq M_{1/2}(Y,0)\\
&\iff D\succeq0\\
&\iff\mathbb E D\geq0.
\end{aligned}$$

The first equivalence is Independence. The second uses (1) and the preorder. The third exchanges branches by Stochastic Equivalence and applies Independence with common second argument $Y$. The final equivalence is Simple EU applied to the simple gamble $D$ and sure zero.

No Totality, Stochastic Dominance, reflection or scaling principle is needed. Conditional laws are only a proof construction: every preference replacement of a same-law variable is explicitly licensed by Stochastic Equivalence. Rich Outcomes ensures availability of the newly formed numerical outcomes and does not serve as a hidden total-chart assumption.

**Original work: proof adaptation.** This is Goodsell's finite-shift redistribution argument from Theorem 4, reorganized to identify its actual sufficient premises. The source's use of affine symmetry enters through Shift Transfer, which is now exposed as a separate input. No literature novelty is asserted.

**Attribution.** Original argument: Zachary Goodsell, *Symmetries of value*, Theorem 4, pp. 26–27. Reduced-premise formulation and random-variable audit: GPT-6 (Codex), 9 September 2026. No independent checker or Lean proof is claimed.

</details>

#### Simple Expected Utility ⇒ Archimedean Outcomes — `simple-eu-implies-archimedean-outcomes`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Simple Expected Utility (`simple-eu`)

Conclusion: Archimedean Outcomes (`archimedean-outcomes`)

Proof.

For a≻b≻c put p=(u(b)−u(c))/(u(a)−u(c)). Then 0<p<1 and the simple variable M_p(a,c) has expectation u(b), so is indifferent to b.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, p. 22, footnote 3

Record: `topics/unbounded-utility/results/simple-eu-implies-archimedean-outcomes.yaml`.

#### Simple Expected Utility ⇒ Restricted Stochastic Equivalence — `simple-eu-implies-restricted-equivalence`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Simple Expected Utility (`simple-eu`)

Conclusion: Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)

Proof.

Equal laws of simple variables give equal finite expectations. Simple EU therefore gives both preference directions.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §§2.3, 3.2

Record: `topics/unbounded-utility/results/simple-eu-implies-restricted-equivalence.yaml`.

#### Simple Expected Utility ⇒ Restricted Totality — `simple-eu-implies-restricted-totality`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Simple Expected Utility (`simple-eu`)

Conclusion: Restricted Totality (`restricted-totality`)

Proof.

Finite real expectations are comparable, and Simple EU represents the preference in both directions.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, pp. 22–23

Record: `topics/unbounded-utility/results/simple-eu-implies-restricted-totality.yaml`.

#### Simple Relative Expectation ⇒ Transfer of a Shift Across a Mixture — `simple-relative-implies-shift-transfer`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Simple Relative Expectation (`simple-relative-expectation`)

Conclusion: Transfer of a Shift Across a Mixture (`shift-transfer`)

Proof.

Put A=M_p(X+b/p,Y) and B=M_p(X,Y+b/(1−p)), using the same fixed mixture lift. Their actual utility difference is b/p on the first branch, of probability p, and −b/(1−p) on the second branch. It is simple and has mean zero. Simple Relative Expectation in both directions therefore gives A~B. No law replacement or independence assumption is used.

Notes. Original work: direct consequence. Observe that the two mixtures have a two-valued, zero-mean difference under the actual common lift, and apply Simple Relative Expectation. This describes the work needed for this database entry, not a claim of novelty in the literature.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof and premise audit in the Logical Maps project, 9 September 2026; see the accompanying handwritten write-up.

Record: `topics/unbounded-utility/results/simple-relative-implies-shift-transfer.yaml`.

<details><summary>Hand-written write-up</summary>

#### Simple Relative Expectation implies Shift Transfer

**Claim.** Simple Relative Expectation implies Transfer of a Shift Across a Mixture, without additional preference axioms.

Fix an eligible pair of real-utility variables $X,Y$, a real number $b$, and $0<p<1$. Here and below arithmetic acts on their normalized utility levels. Set

$$A=M_p(X+b/p,Y),\qquad B=M_p(X,Y+b/(1-p)).$$

The fixed mixture lift uses the same branch event and the same rescaled sample in both variables. Consequently

$$u(A)-u(B)=\begin{cases}b/p,&0\leq w<p,\\-b/(1-p),&p\leq w\leq1.\end{cases}$$

Thus the difference is simple and its expectation is

$$p\frac bp-(1-p)\frac b{1-p}=0.$$

Simple Relative Expectation gives both $A\succeq B$ and $B\succeq A$, as required. Any exceptional fixed endpoint convention affects only finitely many null sample points, so it neither destroys finiteness of the difference's range nor changes its mean.

The argument concerns the actual random variables. It does not replace them by equal-law copies, and it uses only the transformed outcomes already required to state Shift Transfer. In particular, neither Stochastic Equivalence nor Rich Outcomes is a hidden premise.

**Original work: direct consequence.** The work is identifying the two-valued difference and checking that the fixed random-variable mixture convention licenses its use. This is a database connection, with no claim of literature novelty.

**Attribution.** Connecting argument: GPT-6 (Codex), 9 September 2026. The principles themselves were extracted from Zachary Goodsell, *Symmetries of value*, Theorems 3–4. No independent checker or Lean proof is claimed.

</details>

#### Rich Outcomes ∧ Simple Relative Expectation ∧ L¹ Continuity (random variables) ⇒ Relative Expectation — `simple-relative-l1-imply-relative`

Proved result; source **Misc.**; produced by Zachary Goodsell (source argument); GPT-6 (Codex) (adaptation and premise audit); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Simple Relative Expectation (`simple-relative-expectation`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Relative Expectation (`relative-expectation`)

Proof.

For real-utility X,Y with D=u(X)−u(Y) integrable, choose simple q_n→D in L1 and put d_n=q_n+E[D]−E[q_n], so d_n is simple, has mean E[D], and tends to D in L1. Rich Outcomes supplies X_n with utility u(Y)+d_n. If E[D]≥0, Simple Relative Expectation gives X_n≽Y, and upper-section L1 Continuity gives X≽Y. To prove the converse when E[D]<0, put c=−E[D]/2>0. The already proved forward direction gives Y≽X+c, while Simple Relative Expectation gives X+c≻X. Transitivity yields Y≻X, ruling out X≽Y. No lower-section continuity, totality, law invariance or symmetry is used.

Notes. Original work: proof adaptation. Expand the forward approximation idea of Goodsell’s Corollary 5, correct the approximations to preserve their means, and recover strictness using a positive constant perturbation so that only the recorded upper-section continuity clause is needed. This describes the work needed for this database entry, not a claim of novelty in the literature.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), proof adaptation and premise audit in the Logical Maps project, 9 September 2026; see the accompanying handwritten write-up.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Corollary 5, p. 27. The cited argument is adapted with the explicitly listed sufficient premises; the reduced-premise claim is the present project contribution.

Record: `topics/unbounded-utility/results/simple-relative-l1-imply-relative.yaml`.

<details><summary>Hand-written write-up</summary>

#### Simple Relative Expectation and L¹ Continuity imply Relative Expectation

**Claim.** Rich Outcomes + Simple Relative Expectation + L¹ Continuity imply Relative Expectation.

All variables in this proof are in the real utility chart; write their utilities as $X,Y$ to simplify notation. Fix $D=X-Y$ with $\mathbb E|D|<\infty$, and write $m=\mathbb E D$. Simple functions are dense in $L^1$, so choose simple $q_n$ with $\mathbb E|q_n-D|\to0$. Define

$$d_n=q_n+m-\mathbb E q_n.$$

These are still simple, satisfy $\mathbb E d_n=m$, and obey

$$\mathbb E|d_n-D|\leq \mathbb E|q_n-D|+|m-\mathbb E q_n|
\leq 2\mathbb E|q_n-D|\longrightarrow0.$$

Rich Outcomes supplies every finite level needed to form the measurable gambles $X_n=Y+d_n$.

First suppose $m\geq0$. Because $X_n-Y=d_n$ is simple with mean $m$, Simple Relative Expectation gives $X_n\succeq Y$ for every $n$. The actual coupling satisfies $\mathbb E|X_n-X|\to0$. The upper-section clause of L¹ Continuity therefore gives $X\succeq Y$.

This proves the nonnegative-mean direction for every integrable-difference pair. For the converse, suppose $m<0$ and put $c=-m/2>0$. We have

$$\mathbb E[Y-(X+c)]=-m-c=-m/2>0.$$

The direction just proved gives $Y\succeq X+c$. Simple Relative Expectation, applied to the constant difference $c$, gives $X+c\succ X$: its forward weak comparison holds and its reverse weak comparison fails. If $X\succeq Y$, transitivity would give $X\succeq X+c$, a contradiction. Hence $X\not\succeq Y$ whenever $m<0$.

Together these establish exactly $X\succeq Y\iff\mathbb E(X-Y)\geq0$.

The mean correction is essential for obtaining approximants on the required side when $m=0$. The positive perturbation handles strictness without assuming lower-section closure. No Totality, Stochastic Equivalence, Mixture Independence, reflection or affine symmetry is used. Rich Outcomes supplies intermediate real utility levels; it is not silently used to exclude outcomes outside the chart.

**Original work: proof adaptation.** Goodsell's Corollary 5 supplies the approximation idea in the full DTU+Sym context. The present work removes unused assumptions and spells out the mean correction and one-sided-continuity strictness argument. This describes the work for this entry, not literature novelty.

**Attribution.** Source idea: Zachary Goodsell, *Symmetries of value*, Corollary 5, p. 27. Reduced-premise proof: GPT-6 (Codex), 9 September 2026. No independent checker or Lean proof is claimed.

</details>

#### Stochastic Equivalence ⇒ Restricted Stochastic Equivalence — `stochastic-equivalence-restricts`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Stochastic Equivalence (`stochastic-equivalence`)

Conclusion: Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)

Proof.

Restrict the quantifiers to simple random variables.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.3, p. 675
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/stochastic-equivalence-restricts.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/stochastic-equivalence-restricts.yaml`.

#### Rich Outcomes ∧ Archimedean Outcomes ∧ Totality ∧ Stochastic Dominance ∧ Sure-Thing ⇒ Mixture Independence — `sure-thing-to-independence`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Totality (`totality`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)

Conclusion: Mixture Independence (`independence`)

Proof.

Source reduction, §3.2: in the original DTU framework, Stochastic Dominance yields Stochastic Equivalence. Preferences therefore descend to laws. Every law and its conditional realizations are available by Prospect Richness, and the paper identifies Sure-Thing in this quotient with von Neumann–Morgenstern Independence. Pull this implication back along X↦L(X). The full original DTU assumptions are retained; a weaker converse for arbitrary incomplete orders has not been extracted.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 679

Record: `topics/unbounded-utility/results/sure-thing-to-independence.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Symmetric Gambles Are Neutral ∧ Independent Sum Invariance ⇒ False (⊥) — `symmetric-dtu-refutes-independent-sum-candidate`

Proved result; source **Misc.**; produced by Zachary Goodsell (proposed claim and stable-law obstruction); GPT-6 (Codex) (completion via reduced-premise Lévy theorem); recorded by GPT-6 (Codex), 2026-09-09; original proposal retained, now settled by the recorded Lévy proof; checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Independent Sum Invariance (`independent-sum-consistency`)

Conclusion: False (⊥) (`false`)

Proof.

Independent Sum Invariance entails Independent Sum Preservation. The other premises include Rich Outcomes, Stochastic Dominance, Mixture Independence and Symmetric Gambles Are Neutral. Apply levy-refutes-neutral-independent-preservation to obtain False. The new proof uses a specified positive index-1/2 Lévy law and an intermediate symmetric difference; it completes Goodsell’s proposed mechanism with fewer assumptions, rather than relying on the withdrawn manuscript proof.

Notes. Settled 9 September 2026 by levy-refutes-neutral-independent-preservation. Original work: direct consequence of that proof completion; no additional mathematical construction is needed for this larger premise package. Goodsell’s proposal and the historical source audit are preserved. The previous open-status wording below records the state before completion.

Historical notes:
Records the user’s proposed incompatibility with a deliberately sufficient package. The user recalls balanced mixtures involving stable indices 1 and 1/2, neutral by symmetry, becoming strictly dominance-ordered after convolution by a common index-1/2 law. Exact laws, skewness, scale, location, mixture weights, and a global strict-dominance proof remain to be specified. The draft explicitly withdraws its symmetry lemma; that proof failure alone is not a proof of this implication. Excluded from proved inference and known-inconsistency warnings.

Representation update: the former negative conclusion is expressed by adding independent-sum-consistency to the premises and concluding False. The mathematical claim, source, and proof are unchanged.

Sources:

- **Goodsell proposal 9 Sep** — Zachary Goodsell, project conversation, 9 September 2026: revised conjecture omitting reflection and recollection of a stable-distribution obstruction
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §4, pp. 10–14 (withdrawn consistency argument)
- **GPT-6 proof completion 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/levy-refutes-neutral-independent-preservation.md: complete reduced-premise proof of Goodsell’s stable-law obstruction.

Record: `topics/unbounded-utility/results/symmetric-dtu-refutes-independent-sum-candidate.yaml`.

<details><summary>Hand-written write-up</summary>

#### Symmetric DTU versus independent sums — settled

**Proved implication:** DTU + Symmetric Gambles Are Neutral + Independent Sum
Invariance implies **False**.

**Proof.** Independent Sum Invariance supplies Independent Sum Preservation.
Apply the [completed Lévy obstruction](levy-refutes-neutral-independent-preservation.html),
which needs only Rich Outcomes, Stochastic Dominance, Mixture Independence,
Symmetric Neutrality and that preservation property.

**Original work: direct consequence of a proof completion.** Goodsell supplied
the claim and stable-law obstruction proposal; GPT-6 (Codex), 9 September 2026,
supplied the specified witness and reduced-premise proof in the linked record.
This larger-premise consequence needs no further construction. Source: Misc.;
no independent checker or Lean verification is asserted.

##### Historical source audit

The audit below is preserved from before the proof completion. Its statements
that the incompatibility was conjectured or lacked a proof describe that earlier
state; they are superseded by the proved result above. The withdrawn manuscript
argument is not reinstated.


**Conjectured implication:** Rich Outcomes + Totality + Stochastic Equivalence
+ Simple EU + Stochastic Dominance + Mixture Independence + Symmetric
Neutrality + Independent Sum Invariance ⇒ False. There is no completed
proof recorded for this implication. The audit below separates it from the
verified portions of the manuscript.

**Local source:** Zachary Goodsell, *Unbounded Utility and Background Risk*,
5 June 2026, 21 pages. Supplied as
`Goodsell - Unpublished (do not cite) - Erroneous.pdf` in `sources/`.
**Unpublished; do not cite; erroneous.** The short provenance name in the map
is **Unbounded Utility and Background Risk (unpublished)**. These references identify
which supplied document an entry came from; they do not endorse its claims
or describe it as a published paper. PDF and printed page numbers coincide.

Extraction recorded by GPT-6 (Codex), 9 September 2026, following Goodsell’s
request to preserve the interesting principles and extension construction.
No separate checker or formal verification is claimed.

##### Principle inventory

| Manuscript discussion | Map representation |
| --- | --- |
| Expected Utility, pp. 3–4 | Existing Expected Utility; finite expectations retain the topic’s established scope |
| Totality, p. 4 | Existing Totality; reflexivity and transitivity remain standing |
| Preferences over probability distributions | Existing optional Stochastic Equivalence; translated to random variables |
| Stochastic Dominance, pp. 3–4 | Existing weak-plus-strict Stochastic Dominance |
| Independence / Convexity, pp. 3, 6 | Existing Mixture Independence, with a source terminology alias |
| Reflection Symmetry, pp. 3–4 | Existing Symmetric Neutrality, with an alias; not a second node |
| Reflection Anti-Invariance, pp. 3–4 | Existing Reflection Anti-Invariance |
| Full Sum Invariance, pp. 1–2, 17 | New arbitrary-dependence sum biconditional |
| Independent Sum Invariance / Convolution Invariance, pp. 1–6 | New independent-common-summand biconditional |
| Forward and reverse portions of Lemma 1, p. 8 | Separate Independent Sum Preservation (weak and strict) and Cancellation |
| Relative-area base relation and strict extension, pp. 7–8 | New CDF-Area Extension, plus the exact incomplete model |
| Fixed-copula sum-consistency family, p. 18 | General family documented below; independent, comonotonic and antitonic nodes instantiated |
| Comonotonic Sum Invariance, pp. 18–20 | New node; verified in the explicit area model |
| Antitonic Sum Invariance, pp. 18–19 | New node; incompatibility with dominance recorded |
| Real-valued utility domain throughout | Existing Rich Outcomes and Archimedean Outcomes remain distinct |

Full, Antitonic, and Independent Sum incompatibilities are now recorded as
implications to False, with the relevant sum principle added to the other
premises. There are no separate failure nodes. The independent-sum
incompatibility currently has only a **conjectured** arrow. It must not
trigger a known-inconsistency warning.

For a fixed copula $\kappa$, the general schema compares
$Q_X(U)+Q_Z(V)$ with $Q_Y(U)+Q_Z(V)$ for $(U,V)\sim\kappa$.
A choice of copula specifies an axiom; the schema is not silently promoted to
one axiom universally quantifying over every copula. The three distinguished
instances are the product, comonotonic, and antitonic copulas. All comparisons
in the database remain comparisons of random variables, and law identities
are used in proofs only with Stochastic Equivalence or a premise implying it.

“Coherent Indifference” is mentioned in the introduction as background to an
earlier impossibility result, but not defined in this manuscript. No new
axiom is invented from that mention. Conclosure and extension are construction
operations on relations, not additional primitive properties of an individual
gamble. The model write-up preserves them in their appropriate role.

##### What survives

The full-sum St Petersburg counterexample (§6.1) and antitonic impossibility
(Theorem 6) are recorded with explicit proofs. The latter requires neither
Totality nor Symmetric Neutrality. Full Sum Invariance restricts to the
three dependence-specific principles. Each of those implies Shift Invariance
by taking a constant summand. Independent Sum Invariance splits into forward
preservation and reverse cancellation.

The footnote on pp. 12–13 establishes, under totality, law invariance and
mixture independence, that Symmetric Neutrality implies Reflection
Anti-Invariance. This argument is independent of the failed construction.

The base area preorder is a proved incomplete model. Theorem 7’s comonotonic
argument can be made rigorous using separate positive and negative quantile
areas, avoiding undefined differences of infinities. Its independent-sum
**forward** property follows from Tonelli. See
[the detailed construction](cdf-area-preorder.html).

CDF-Area Extension implies Expected Utility, Relative Expectation, and
Stochastic Dominance. It does **not** automatically transfer the exact
model’s invariance properties to every extension: newly supplied comparisons
must themselves respect any requested invariance axioms.

##### Failed claims and remaining gaps

- **Lemma 3 / Theorem 4, pp. 10–12:** the manuscript explicitly acknowledges
  that the symmetry-extension proof fails. Convolving an odd function with
  an arbitrary probability law need not preserve oddness. Convolution with a
  nonzero point mass already translates the function away from its symmetry
  center. The claimed symmetric consistency model is not entered as proved.
- **Lemma 1, p. 8:** convolved positive and negative parts can overlap. The
  asserted identification with the positive and negative parts of the
  convolved difference is false. This invalidates the given cancellation
  proof; it does not by itself disprove cancellation for the base relation.
- **Equation (16), p. 8:** reflection substitution introduces an incorrect
  minus sign. The area model’s anti-invariance nevertheless has a direct
  corrected proof.
- **Lemma 2, pp. 9–10:** the proposed chain construction shows forward
  transformation closure, not the reverse cancellation clauses its use
  requires. Taking the genuine closure by intersection is possible, but
  the total-extension write-up now spells out Goodsell’s conclosure in
  cone language, including strictness-preservation details that do not
  rely on this lemma’s chain description.
- **Theorem 5, pp. 12–14:** neither the failed symmetric seed nor the
  questionable closure calculation establishes the symmetric total extension.
  A separate [proved total extension without either reflection requirement](conjectured-total-independent-sum-extension.html)
  uses Goodsell’s conclosure and total-extension strategy, with cone-language
  exposition and additional proof details recorded by GPT-6. It establishes
  the previously conjectured package, including Independent Sum Invariance,
  without rehabilitating the original symmetry lemma.
- **Cauchy discussion, pp. 15–16:** the draft’s objections to a particular
  attempted dominance comparison do not establish its own consistency
  theorem. No new consistency or incompatibility arrow is inferred from
  its plots or tail heuristics.

##### User’s recalled stable-law obstruction

Goodsell reports that the main consistency claim is false and recalls
balanced mixtures involving stable parameters 1 and 1/2. By symmetry, the
relevant prospects should both be indifferent to zero; convolution with a
common parameter-1/2 law is recalled to create strict stochastic dominance.
If those specifications work, independent-sum invariance transports the
initial indifference to the convolved pair, contradicting strict dominance.

The recollection does not yet fix whether the parameters refer to stability
indices or another parameter, nor the skewness, scale, location, mixture
weights, and full dominance comparison. The map records the resulting
proposed incompatibility with a sufficient DTU-plus-neutrality package as
**conjectured**, source **Goodsell proposal 9 Sep**. No numerical plot or
partially specified stable law is used as a proof. This leaves the author’s
withdrawal explicit while separating it from a checked mathematical witness.

##### Provenance and scope

New manuscript arguments and its explicit construction use the manuscript’s
own direct source. Original restriction/decomposition proofs use **Misc.**,
with **GPT-6 generated 9 Sep** identifying the contribution. The total-extension model is attributed directly to
**Unbounded Utility and Background Risk (unpublished)**: its CDF-area
construction, conclosure, and extension strategy are Goodsell’s. The
cone-language exposition and additional proof details are separately
credited as **GPT-6 proof details 9 Sep**, not as a new AI construction. The remaining
stable-law conjecture uses **Misc.**, with **Goodsell proposal 9 Sep**.
Source definitions are cited separately, and no published proof was rewritten.

After migrating the failure nodes, the additions are seven principles,
sixteen implications (fifteen proved and
one conjectured), one proved incomplete model, and one proved total
extension model. The graph remains selective; no claim is made to exhaust all true
consequences. No Lean formalization was added.

</details>

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ⇒ Alternating St Petersburg = −1/2 — `symmetry-evaluates-alternating`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)

Proof.

The law identity A =d M_1/2(−2,−2A) gives indifference by Stochastic Equivalence. If A≻−1/2 then −2A≺1, so Independence and Simple EU imply A~M_1/2(−2,−2A)≺M_1/2(−2,1)~−1/2, contradiction. The opposite strict case is analogous. Totality gives A~−1/2.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 9, p. 30

Record: `topics/unbounded-utility/results/symmetry-evaluates-alternating.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ⇒ Uniqueness of Negative Self-Similarity — `symmetry-implies-negative-self-similarity`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Uniqueness of Negative Self-Similarity (`negative-self-similarity`)

Proof.

If X≻Y, negative affine anti-invariance makes −aX+b≺−aY+b. Independence with the common Z then reverses the strict comparison between their mixtures. The assumed fixed-point indifferences imply X≺Y, contradiction. Interchange X,Y for the other strict case and use Totality.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 10, pp. 30–31

Record: `topics/unbounded-utility/results/symmetry-implies-negative-self-similarity.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ⇒ Transfer of a Shift Across a Mixture — `symmetry-implies-shift-transfer`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Transfer of a Shift Across a Mixture (`shift-transfer`)

Proof.

This is Theorem 3 transported from laws to random variables using Stochastic Equivalence. Reflection, Totality and Independence first make a half-mixture of V and −V indifferent to 0. Shift invariance then gives M_1/2(V+c,−V)~c/2. Pair the terms on the two sides of the proposed transfer with their negatives; both reduce to the same simple constant mixture. Independence cancels the common terms.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 3, pp. 25–26

Record: `topics/unbounded-utility/results/symmetry-implies-shift-transfer.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ⇒ Simple Relative Expectation — `symmetry-implies-simple-relative`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Simple Relative Expectation (`simple-relative-expectation`)

Proof.

Theorem 4. If D=u(X)−u(Y) has finite range, work with the diluted variables M_1/2(X,0), M_1/2(Y,0). Partition into the finitely many values of D. Transfer each constant difference to the zero branch by Theorem 3. Finite mixture substitution leaves M_1/2(Y,D) in place of M_1/2(X,0). Independence and Simple EU reduce the comparison to E[D]≥0. Law invariance permits each rearrangement of branches.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 4, pp. 26–27

Record: `topics/unbounded-utility/results/symmetry-implies-simple-relative.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ∧ L¹ Continuity (random variables) ⇒ Arroyo = ln 2 — `symmetry-l1-evaluates-arroyo`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Arroyo = ln 2 (`arroyo-value`)

Proof.

Theorem 8 evaluates the folded tail difference of A+1/2. Pair its positive and negative tails: the residual weights are 1/[2n(2n−1)]−1/[2n(2n+1)] at heights 2n+1/2, a positive integrable tail whose expectation is 1/2+ln 2. Folded Expectation gives A+1/2~1/2+ln 2. Shift Invariance gives A~ln 2.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 8, pp. 29–30

Record: `topics/unbounded-utility/results/symmetry-l1-evaluates-arroyo.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ∧ L¹ Continuity (random variables) ⇒ Pasadena = ln 2 — `symmetry-l1-evaluates-pasadena`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Pasadena = ln 2 (`pasadena-value`)

Proof.

Theorem 11. Couple Pasadena P with Highland Park H, retaining each outcome probability and replacing each negative denominator 2n by 2n−1. Then E[H−P]=−ln 2 with integrable difference. The paper writes H as M_2/3(Q,−2Q). It proves by Relative Expectation that Q~M_1/4(4Q,0), then Totality and affine invariance give Q~M_1/2(2Q,0). Reflection and Independence yield H~0; Relative Expectation together with shift transfer then gives P~ln 2. These are preference equalities, not ordinary expectations of P or H.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 11, pp. 32–33

Record: `topics/unbounded-utility/results/symmetry-l1-evaluates-pasadena.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ∧ L¹ Continuity (random variables) ⇒ Folded Expectation — `symmetry-l1-implies-folded`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Folded Expectation (`folded-expectation`)

Proof.

Theorem 6 couples the positive and negative utility tails in opposing order. Absolute integrability of the folded tail difference yields an integrable difference of these tail variables, with expectation F(X). Relative Expectation (Corollary 5) and reflection identify X with sure F(X). Apply the same construction to Y and compare the constants. Law invariance transfers the chosen couplings to the original variables.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 6, p. 27 and Figure 7, p. 29

Record: `topics/unbounded-utility/results/symmetry-l1-implies-folded.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ∧ L¹ Continuity (random variables) ⇒ Relative Expectation — `symmetry-l1-implies-relative`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Relative Expectation (`relative-expectation`)

Proof.

Corollary 5. Approximate an integrable difference u(X)−u(Y) in L¹ by simple differences, apply Theorem 4, and use L¹ continuity to pass to the limit. This is recorded with the full source context DTU+Sym; the equivalence between its law metric and this topic’s random-variable continuity requires Stochastic Equivalence.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Corollary 5, p. 27

Record: `topics/unbounded-utility/results/symmetry-l1-implies-relative.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ∧ Relative Expectation ⇒ L¹ Continuity (random variables) — `symmetry-relative-implies-l1`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Relative Expectation (`relative-expectation`)

Conclusion: L¹ Continuity (random variables) (`l1-continuity`)

Proof.

This is the reverse direction of Corollary 5 in its full DTU+Sym context. Pull preferences down to probability laws using Stochastic Equivalence and apply the source equivalence between Relative Expectation Theory and the extended L¹ metric continuity. Actual-coupling convergence implies convergence in that infimum metric, giving the random-variable clause. The source states this as a corollary without an expanded reverse-direction proof; no claim of an independent proof audit is made.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Corollary 5, p. 27

Record: `topics/unbounded-utility/results/symmetry-relative-implies-l1.yaml`.

#### Totality ∧ Independent Sum Preservation ⇒ Independent Sum Cancellation — `total-preservation-implies-independent-cancellation`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex); checked by nobody; 2026-09-09.

Premises:

- Totality (`totality`)
- Independent Sum Preservation (`independent-sum-preservation`)

Conclusion: Independent Sum Cancellation (`independent-sum-cancellation`)

Proof.

Suppose Z is independent of (X,Y) and X+Z is weakly preferred to Y+Z. If X were not weakly preferred to Y, Totality would give Y strictly preferred to X. The strict clause of Independent Sum Preservation would then give Y+Z strictly preferred to X+Z, contradicting the assumed weak comparison. Hence X is weakly preferred to Y.

Notes. Original work: elementary connecting deduction; no model construction or imported theorem proof is needed. Preservation in this project includes STRICT preservation. Under Totality, that extra clause makes preservation equivalent to full Independent Sum Invariance by the already recorded decomposition. Weak preservation alone would not justify this implication. No dominance, mixture independence, stochastic equivalence, continuity, or outcome richness is used.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), 9 September 2026, original strict-order argument in writeups/total-preservation-implies-independent-cancellation.md.
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, unpublished manuscript, 5 June 2026, Lemma 1, pp. 7–8: source for the separated preservation/cancellation principles, not this connecting proof.

Record: `topics/unbounded-utility/results/total-preservation-implies-independent-cancellation.yaml`.

<details><summary>Hand-written write-up</summary>

#### Under Totality, strict sum preservation supplies cancellation

**Proved implication:** Totality + Independent Sum Preservation implies
Independent Sum Cancellation.

Let $Z$ be independent of $(X,Y)$, and suppose $X+Z\succeq Y+Z$.
If $X\not\succeq Y$, Totality gives $Y\succ X$. The strict clause of
Independent Sum Preservation then gives $Y+Z\succ X+Z$, which includes
$X+Z\not\succeq Y+Z$. This contradicts the assumption. Therefore
$X\succeq Y$.

Consequently, under DTU, **Independent Sum Preservation is equivalent to
Independent Sum Invariance**: cancellation follows by this argument,
and the existing preservation/cancellation decomposition supplies the
biconditional. In an incomplete preorder, lack of $X\succeq Y$ need not
give $Y\succ X$, so the same reasoning does not apply to the incomplete
CDF-area model.

The current Preservation node demands both weak and strict preservation.
Keeping that strict clause visible is essential to this deduction.

**Original work: elementary connecting deduction.** GPT-6 (Codex),
9 September 2026. The definitions were extracted from Zachary Goodsell,
*Unbounded Utility and Background Risk* (unpublished), Lemma 1, pp. 7–8;
the connecting proof above is recorded under Misc., not attributed to the
manuscript. No independent checker or Lean verification is claimed.

</details>

#### Totality ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ⇒ Uniqueness of Negative Self-Similarity — `totality-independence-negative-affine-imply-self-similarity`

Proved result; source **Misc.**; produced by Zachary Goodsell (source argument); GPT-6 (Codex) (adaptation and premise audit); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Totality (`totality`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Uniqueness of Negative Self-Similarity (`negative-self-similarity`)

Proof.

Fix p,a,b,Z and write T(V)=−aV+b and F(V)=M_p(T(V),Z). Negative Affine Anti-Invariance reverses strict preference under T, while Mixture Independence preserves strict preference between first arguments with the common Z. Hence F reverses strict preference. If X~F(X) and Y~F(Y) but X≻Y, then F(Y)≻F(X), so Y≻X by the two indifferences, a contradiction. The case Y≻X is symmetric. Totality leaves only X~Y. The other premises in the original full DTU+Sym package are unused.

Notes. Original work: proof adaptation. Audit Goodsell’s Theorem 10 argument and remove its unused Rich Outcomes, Stochastic Equivalence, Simple EU and Stochastic Dominance premises. This describes the work needed for this database entry, not a claim of novelty in the literature.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), proof adaptation and premise audit in the Logical Maps project, 9 September 2026; see the accompanying handwritten write-up.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 10, pp. 30–31. The cited argument is adapted with the explicitly listed sufficient premises; the reduced-premise claim is the present project contribution.

Record: `topics/unbounded-utility/results/totality-independence-negative-affine-imply-self-similarity.yaml`.

<details><summary>Hand-written write-up</summary>

#### A smaller sufficient package for Negative Self-Similarity

**Claim.** Totality + Mixture Independence + Negative Affine Anti-Invariance imply Uniqueness of Negative Self-Similarity.

Fix an eligible instance of the principle, with $0<p<1$, $a>0$, $b\in\mathbb R$ and common gamble $Z$. Define, for the variables under consideration,

$$T(V)=-aV+b,\qquad F(V)=M_p(T(V),Z).$$

Negative Affine Anti-Invariance supplies

$$V\succ W\ \Longrightarrow\ T(W)\succ T(V).$$

Indeed, it supplies the weak comparison in this direction, while the opposite weak comparison would imply $W\succeq V$, contradicting strictness. Mixture Independence likewise preserves strictness between first arguments with the same second argument: apply its biconditional to both weak comparison directions. Thus

$$V\succ W\ \Longrightarrow\ F(W)\succ F(V).$$

Suppose now that $X\sim F(X)$ and $Y\sim F(Y)$. If $X\succ Y$, the last implication and the fixed-point indifferences give $Y\succ X$, contradicting the strict part of a preorder. The case $Y\succ X$ is identical. Under Totality, two variables which are not indifferent must be strictly ranked in one of these two directions. Therefore $X\sim Y$.

Only the affine transformations already required by the two fixed-point hypotheses are used. There is no replacement by a same-law variable, no need to construct any additional utility level, and no invocation of expected utility or dominance.

**Original work: proof adaptation.** The mathematical argument is Goodsell's Theorem 10 argument. The new database work is its premise audit: four assumptions from the full source package are unnecessary here. This is not a claim that the uniqueness argument is original to the AI or new in the literature.

**Attribution.** Original uniqueness argument: Zachary Goodsell, *Symmetries of value*, Theorem 10, pp. 30–31. Reduced-premise statement and audit: GPT-6 (Codex), 9 September 2026. No independent checker or Lean proof is claimed.

</details>

#### Totality ⇒ Restricted Totality — `totality-restricts`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Totality (`totality`)

Conclusion: Restricted Totality (`restricted-totality`)

Proof.

Restrict the quantifiers to simple random variables.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.3, p. 675
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/totality-restricts.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/totality-restricts.yaml`.

#### Universal Copula Sum Invariance ⇒ Antitonic Sum Invariance — `universal-copula-implies-antitonic`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Universal Copula Sum Invariance (`universal-copula-sum-consistency`)

Conclusion: Antitonic Sum Invariance (`antitonic-sum-consistency`)

Proof.

Use the antidiagonal copula, the law of (U,1−U), with H(u,v)=max(u+v−1,0). In an antitonic pair one lower-threshold event is an initial uniform interval and the other is a final interval; their intersection has this probability, including for atomic marginals. Both antitonic pairs therefore admit the same copula. SC(C) applies to the original triple, with no law-invariance premise.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original copula sum consistency definitions and connecting proofs recorded in this project, 9 September 2026, implementing Zachary Goodsell’s proposal.
- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).

Record: `topics/unbounded-utility/results/universal-copula-implies-antitonic.yaml`.

#### Universal Copula Sum Invariance ⇒ Comonotonic Sum Invariance — `universal-copula-implies-comonotonic`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Universal Copula Sum Invariance (`universal-copula-sum-consistency`)

Conclusion: Comonotonic Sum Invariance (`comonotonic-sum-consistency`)

Proof.

Use the diagonal copula, the law of (U,U) for uniform U, with H(u,v)=min(u,v). For a comonotonic pair, the lower-threshold events are nested up to null sets, so its joint CDF is min(F_A(a),F_B(b)). Thus both comonotonic pairs (X,Z) and (Y,Z) admit this same copula. Applying SC(C) gives the desired biconditional for the actual X,Y,Z. No replacement of variables in a preference comparison is used.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original copula sum consistency definitions and connecting proofs recorded in this project, 9 September 2026, implementing Zachary Goodsell’s proposal.
- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).

Record: `topics/unbounded-utility/results/universal-copula-implies-comonotonic.yaml`.

#### Universal Copula Sum Invariance ⇒ Existential Copula Sum Invariance — `universal-copula-implies-existential`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Universal Copula Sum Invariance (`universal-copula-sum-consistency`)

Conclusion: Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

Proof.

The class of bivariate copulas is nonempty: the product of two uniform laws is a copula. Instantiate the universal principle at that copula to obtain one fixed witness for the existential principle.

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original copula sum consistency definitions and connecting proofs recorded in this project, 9 September 2026, implementing Zachary Goodsell’s proposal.
- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).

Record: `topics/unbounded-utility/results/universal-copula-implies-existential.yaml`.

#### Universal Copula Sum Invariance ⇒ Independent Sum Invariance — `universal-copula-implies-independent`

Proved result; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Universal Copula Sum Invariance (`universal-copula-sum-consistency`)

Conclusion: Independent Sum Invariance (`independent-sum-consistency`)

Proof.

If Z is independent of (X,Y), it is independent of X and independent of Y. Hence the joint CDFs of (X,Z) and (Y,Z) both factor through the product copula H(u,v)=uv. Instantiate Universal Copula Sum Consistency at that copula and apply it to the original triple.

Notes. The converse construction needs care: the product-copula condition gives pairwise independence from Z, which need not be independence from the pair (X,Y).

Sources:

- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original copula sum consistency definitions and connecting proofs recorded in this project, 9 September 2026, implementing Zachary Goodsell’s proposal.
- **Zach Goodsell proposal 9 Sep** — Zachary Goodsell, project TODO.md copula-sum proposal and request to add universal/existential variants, 9 September 2026; precise definitions recorded by GPT-6 (Codex).

Record: `topics/unbounded-utility/results/universal-copula-implies-independent.yaml`.

### 4.2 Recorded conjectures

These are displayed but never used as evidence in any derivation below.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Independent Sum Cancellation ⇒ Independent Sum Preservation — `conjectured-dtu-cancellation-implies-preservation`

Conjecture; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex); checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Independent Sum Cancellation (`independent-sum-cancellation`)

Conclusion: Independent Sum Preservation (`independent-sum-preservation`)

No proof is recorded. This is a conjecture only.

Notes. Original work: conjecture formulation and partial analysis, not a proof or consistency witness. Totality plus cancellation already preserves strict comparisons. The unsettled issue is whether DTU forces common independent noise to preserve indifference as well. The new proved result continuous-total-cancellation-implies-preservation settles this after adding L1 Continuity: shift the upper variable by 1/n and pass to the limit. Without continuity that limiting step is unavailable. A proof must close the indifference gap without assuming continuity; a countermodel must satisfy all six DTU axioms plus cancellation and exhibit a tied pair that independent noise separates. Such a model would necessarily violate L1 Continuity. The existing total independent-sum extension satisfies both directions and does not separate them. This is an open entry in this map, not a claim about whether the question has been settled in the literature.

Sources:

- **GPT-6 conjecture 9 Sep** — GPT-6 (Codex), 9 September 2026, follow-up question and partial analysis in writeups/conjectured-dtu-cancellation-implies-preservation.md.
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, unpublished manuscript, 5 June 2026, Lemma 1, pp. 7–8: source for the separated sum principles, not this conjecture.

Record: `topics/unbounded-utility/results/conjectured-dtu-cancellation-implies-preservation.yaml`.

<details><summary>Hand-written write-up</summary>

#### Does DTU alone turn cancellation into full independent-sum invariance?

**Conjectured implication, not proved:** DTU + Independent Sum Cancellation
implies Independent Sum Preservation.

Here DTU is the complete displayed package: Rich Outcomes, Totality,
Stochastic Equivalence, Simple Expected Utility, Stochastic Dominance,
and Mixture Independence. No continuity axiom is included.

##### What is already established

Cancellation and Totality preserve strict comparisons. If $X\succ Y$ but
$Y+Z\succeq X+Z$, cancellation would give $Y\succeq X$, a contradiction.
Totality of the sums therefore gives $X+Z\succ Y+Z$.

Under these assumptions, weak preservation can fail only by breaking an
existing indifference. Thus the exact remaining question is:

$$X\sim Y,\quad Z\perp(X,Y)
\quad\stackrel{?}{\Longrightarrow}\quad X+Z\sim Y+Z.$$

Adding L¹ Continuity settles this affirmatively by
[the new constant-shift proof](continuous-total-cancellation-implies-preservation.html).
For every $n$, dominance gives $X+1/n\succ Y$, and strict preservation gives
$(X+Z)+1/n\succ Y+Z$. Upper-section L¹ closure yields the required weak
comparison, and exchanging $X,Y$ supplies the other one.

##### The obstruction to removing continuity

The last limiting inference is not a consequence of preorder totality.
The framework intentionally allows non-Archimedean comparisons of
unbounded gambles. Having all the positively shifted approximants above a
fixed gamble does not, by itself, put their limit above it.

It would therefore be insufficient to repeat that proof and silently take
the limit. A positive solution must use further structure from DTU, for
example Mixture Independence, to show that independent noise cannot split
an indifferent pair. A negative solution must construct a DTU preorder
satisfying Cancellation and give a tied pair whose independent sums become
strictly ranked. The proved continuity result guarantees that any such
countermodel violates L¹ Continuity.

The existing total CDF-area conclosure extension satisfies full Independent
Sum Invariance; it cannot distinguish Cancellation from Preservation.
The incomplete exact area model cannot do so either without additional
work: it lacks Totality, and its cancellation property is not established.

**Original work: conjecture formulation and partial analysis.**
GPT-6 (Codex), 9 September 2026. The sum principles come from Goodsell's
*Unbounded Utility and Background Risk* (unpublished), Lemma 1, pp. 7–8.
The proposed implication is recorded under Misc. and is not attributed to
that manuscript. This is an unresolved entry in this project, not a claim
of literature novelty. No independent checker or Lean verification is claimed.

</details>

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Shift Invariance ⇒ Transfer of a Shift Across a Mixture — `conjectured-dtu-shift-implies-transfer`

Conjecture; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Shift Invariance (`shift-invariance`)

Conclusion: Transfer of a Shift Across a Mixture (`shift-transfer`)

No proof is recorded. This is a conjecture only.

Notes. Original work: conjecture formulation and partial analysis, not a proof or consistency witness. The candidate asks whether DTU plus Shift Invariance alone implies Shift Transfer, equivalently under DTU Simple Relative Expectation. The recorded neutrality-shift-imply-shift-transfer proof settles the question after adding Symmetric Neutrality. The DTU+L1-to-EU and eu-independence-l1-imply-relative proofs settle it after adding L1 Continuity, through Relative Expectation. Consequently a separating model would have to fail both neutrality and L1 Continuity. The continuous clipping models already satisfy Relative Expectation; the new lexicographic folded-tail model fails continuity but still satisfies Relative Expectation and neutrality. Neither family supplies the required separation. A proof must derive transfer without either supplementary premise, or a countermodel must exhibit an actual failed transfer instance while verifying DTU and every common constant shift. Conjectured here labels an unresolved question in this map; it expresses neither confidence that the implication is true nor a literature-wide claim that the question is open.

Sources:

- **GPT-6 question 9 Sep** — GPT-6 (Codex), 9 September 2026, follow-up DU investigation; precise unresolved implication and partial analysis in writeups/conjectured-dtu-shift-implies-transfer.md.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37, DOI 10.1111/nous.12549, Theorems 3–4, pp. 25–27: source for Shift Transfer and its derivation with full affine symmetry, not this conjecture.

Record: `topics/unbounded-utility/results/conjectured-dtu-shift-implies-transfer.yaml`.

<details><summary>Hand-written write-up</summary>

#### Does DTU plus Shift Invariance imply Shift Transfer?

**Status: unresolved question in this map.** The implication is entered as
conjectured so that it appears in the Conjectures tab. No proof or separating
model is claimed, and the entry expresses neither confidence in its truth nor
a claim that the literature has left it open.

The question was formulated by GPT-6 (Codex), 9 September 2026. The principles
and the stronger affine-symmetry derivations are Zachary Goodsell's
*Symmetries of value*, Theorems 3–4, pp. 25–27; the paper is not attributed
this reduced-premise conjecture. Original work here consists of identifying
the precise remaining gap and checking the available model families.

With all six DTU axioms assumed, does

\[
X\succeq Y\quad\Longleftrightarrow\quad X+b\succeq Y+b
\quad\text{for every real }b
\]

already force

\[
M_p(X+b/p,Y)\sim M_p(X,Y+b/(1-p))
\quad(0<p<1)?
\]

Under DTU, the recorded implications make the latter equivalent to Simple
Relative Expectation, so the question can equally be read as whether a
common-shift symmetry determines comparisons under every simple pointwise
perturbation.

Two additional hypotheses settle it:

- **Symmetric Neutrality:** the new
  [neutrality-and-shift proof](neutrality-shift-imply-shift-transfer.md)
  centers paired laws, then cancels a common mixture branch. Scale Invariance
  is unnecessary, but the neutral value of the centered laws is essential
  to that proof.
- **L¹ Continuity:** DTU plus L¹ Continuity gives Expected Utility, and the
  [conditional-truncation proof](eu-independence-l1-imply-relative.md) then
  gives Relative Expectation. That implies Simple Relative Expectation and
  Shift Transfer, even without a prior shift-symmetry assumption.

A countermodel must therefore fail **both** Symmetric Neutrality and L¹
Continuity. The symmetric and asymmetric continuous clipping models already
satisfy Relative Expectation and so cannot separate the question. The
[Folded-tail cone: lexicographic extension](lexicographic-folded-extension.md) does fail
L¹ Continuity, but retains neutrality and Relative Expectation, so it also
satisfies transfer. The exact clipping records do not establish the required
Shift Invariance and cannot simply be claimed as counterexamples.

To settle the entry positively, one must derive the transfer equality without
using either supplementary hypothesis. To settle it negatively, one must
verify a model of all six DTU axioms and Shift Invariance, and exhibit particular
\(X,Y,b,p\) for which the displayed transfer indifference fails. A failure of
one attempted proof, or an unverified model flag, would not suffice.

</details>

#### Countable Sure-Thing ∧ Archimedean Outcomes ⇒ Archimedean Gambles — `countable-sure-thing-outcomes-to-gambles`

Conjecture; source **Misc.**; produced by User suggestion, 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; checked by nobody; 2026-09-08.

Premises:

- Countable Sure-Thing (`countable-sure-thing`)
- Archimedean Outcomes (`archimedean-outcomes`)

Conclusion: Archimedean Gambles (`archimedean-gambles`)

No proof is recorded. This is a conjecture only.

Notes. Record the user's two-premise proposal as stated, relative to this topic's standing framework. The related Russell–Isaacs theorem uses Countable Independence, complete preferences, and countably supported lotteries; its passage from acts to lotteries assumes law invariance. A proof in the present random-variable framework, or identification of any additional necessary premises, is still required. Neither Totality nor Stochastic Equivalence should silently be treated as background. Excluded from proved deductions until verified.

Sources:

- **User suggestion 8 Sep** — User suggestion in this project's conversation, 2026-09-08; proposed implication, not a completed proof.
- **Infinite Prospects (candidate source)** — Possible related reference, not verified as establishing this exact arrow: Jeffrey Sanford Russell and Yoaav Isaacs, Infinite Prospects, Philosophy and Phenomenological Research 103 (2021), 178–198, DOI 10.1111/phpr.12704. Author-hosted manuscript, §§4–5 and Appendix A, especially pp. 15, 22, 25: https://www.yoaavisaacs.com/uploads/6/9/2/0/69204575/infinite-prospects-final.pdf

Record: `topics/unbounded-utility/results/countable-sure-thing-outcomes-to-gambles.yaml`.

#### Countable Sure-Thing ∧ Simple Expected Utility ⇒ Expected Utility — `countable-sure-thing-simple-to-full-eu`

Conjecture; source **Misc.**; produced by User suggestion, 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; checked by nobody; 2026-09-08.

Premises:

- Countable Sure-Thing (`countable-sure-thing`)
- Simple Expected Utility (`simple-eu`)

Conclusion: Expected Utility (`expected-utility`)

No proof is recorded. This is a conjecture only.

Notes. Candidate extension from finite-valued gambles to all integrable utility random variables. Verification must cover the full measurable domain, including variables with non-atomic distributions, and both directions of the expected-utility comparison. Do not silently add Rich Outcomes, Totality, Stochastic Equivalence, or Sure-Thing as premises. Rich Outcomes is optional here; the existing unbounded-utility inconsistency argument is not by itself a proof of this two-premise implication. Excluded from proved deductions until verified.

Sources:

- **User suggestion 8 Sep** — User suggestion in this project's conversation, 2026-09-08; proposed implication, not a completed proof.
- **Decision Theory Unbound** — Related motivation rather than a verified theorem with these exact premises: Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695, DOI 10.1111/nous.12473, §4.1, pp. 685–686.

Record: `topics/unbounded-utility/results/countable-sure-thing-simple-to-full-eu.yaml`.

## 5. Models

A model witnesses consistency, and so refutes every implication from what it satisfies to what it violates. Independence is never recorded directly; the model is the record.

### Signed-measure cone: affine-symmetric extension — `affine-symmetric-extension`

Model; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- L¹ Continuity (random variables) (`l1-continuity`)

Violates:

- Countable Sure-Thing (`countable-sure-thing`)
- Archimedean Gambles (`archimedean-gambles`)

Unknown in this model: Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

Construction.

Goodsell (2026), Theorem 2 constructs a total preference satisfying DTU, both affine symmetry principles, and L¹ Continuity. Start with the cone of Theorem 12, use Theorem 13 to extend any nontotal cone while preserving convexity, scale and reflection, and apply Zorn’s lemma. Fixed required comparisons preserve finite EU, dominance and prospect shifts; the end of §5 asserts preservation of L¹ Continuity. Pull the resulting ordering back from laws to all real-valued random variables. The two violations follow from the explicit St Petersburg witnesses in this topic. See the write-up for the scope of this source-based existence certificate.

Notes. This is a nonconstructive existence model, not an implemented comparator. Its existence and L¹ clause are source-attributed. No numerical test is claimed to verify Zorn’s lemma or the source proof.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 2, p. 24; Theorems 12–13 and end of §5, pp. 35–36

Record: `topics/unbounded-utility/models/affine-symmetric-extension.yaml`.

Write-up.

#### Signed-measure cone: affine-symmetric extension

Source: Goodsell, *Symmetries of value*, Theorem 2 (p. 24), with the
construction in Theorems 12–13 and the end of §5 (pp. 35–36).
Human model: Zachary Goodsell. Recorded and translated by GPT-6 (Codex);
no transcription checker asserted.

Theorem 2 asserts the consistency of DTU + Sym + L¹ Continuity. The source
constructs the ordering on probability laws via cones in the real vector
space of finite signed measures, then extends a partial ordering to a total
one. Signed measures are auxiliary proof objects, not this topic's gambles.

More specifically, Theorem 12 supplies a cone C that has the required finite
EU, dominance, scale, reflection, and prospect-shift properties, without
Totality. Theorem 13 says that a nontotal convex cone satisfying scale and
reflection has a proper extension preserving those properties and all its
existing weak and strict comparisons. Unions of chains preserve these
properties, so Zorn's lemma supplies a maximal extension. If it were nontotal,
Theorem 13 would extend it again, contradiction. Fixed required comparisons
for finite EU, dominance, and prospect shifts survive extensions. The end of
§5 asserts that the constructed model also has L¹ Continuity.

Pull the source's resulting preorder on probability laws back along X↦L(X)
on the domain of all real-valued random variables. Reflexivity, transitivity,
and Totality pull back immediately, and Stochastic Equivalence holds by
construction. The source's bijective utility representation supplies both
Rich Outcomes and this topic's Simple EU. Randomized-selection laws give
Mixture Independence, and utility transformations give the stated affine
symmetries. The L¹ translation write-up transfers source continuity to the
random-variable clause. This verifies that the cited existence theorem
applies to precisely the package listed in the model record.

The recorded St Petersburg implications then show that Countable Sure-Thing
and Archimedean Gambles fail in this model, while Archimedean Outcomes holds.
It also witnesses that adding the symmetries and L¹ is compatible with all the
evaluations extracted from §4.

This certificate is a **source theorem application and domain translation**.
It is not an implementation of the nonconstructive ordering or an independent
audit of the source's cone-extension theorem and continuity argument. No
numerical check can establish those existence claims.

### Clipped expectation: continuous ultrafilter dominance [−t, 2t] — `asymmetric-continuous-ultrafilter`

Model; source **Symmetries of Value**; produced by Zachary Goodsell (construction and source non-implication); GPT-6 (Codex) (explicit specialization and additional property calculations); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Expected Utility (`expected-utility`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Relative Expectation (`relative-expectation`)
- CDF-Area Extension (`cdf-area-extension`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)

Violates:

- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Folded Expectation (`folded-expectation`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)

Unknown in this model: Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Scale Invariance (`scale-invariance`)

Construction.

Take all real-valued random variables and q_t(x)=max(-t,min(x,2t)). For a cobounded ultrafilter U on t>0, put X≽Y iff for every ε>0 the set {t:E[q_t(X)]≥E[q_t(Y)]−ε} belongs to U. The continuous quotient preserves DTU, finite EU, L¹ Continuity, Relative Expectation, CDF-Area Extension, Shift Invariance, and Transfer of a Shift Across a Mixture. A standard symmetric Cauchy variable has value ln(2)/π>0, violating neutral symmetry, reflection and Folded Expectation. It and zero provide distinct fixed values for the negative self-similarity map X↦M_(1/2)(−2X,0). Paired atoms give Alternating St Petersburg value zero. The accompanying write-up proves every recorded flag.

Executable checks: `topics/unbounded-utility/checks/asymmetric_continuous_ultrafilter.py`.

Notes. Original work: source-model specialization and additional verification. The asymmetric construction and the non-implication of reflection even under DTU + L¹ Continuity + Relative Expectation are already Goodsell’s: Symmetries of value, Theorem 1 (p. 24), citing Decision theory unbound, Remark 3. They are not new AI results. The 2024 paper supplies the continuous quotient and separate increasing cutoffs; Corollary 3 already permits nonzero values for symmetric gambles. Work recorded here chooses f(t)=2t and g(t)=t and spells out the CDF-area/shift-transfer verification and exact Cauchy, alternating-game and negative-self-similarity witnesses. These added calculations are not a claim of literature novelty. No scale or sum-invariance verdict is asserted without proof. Diagnostic checks do not certify the general axioms or ultrafilter existence.

Sources:

- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 1, p. 24. Already states the failure of affine-symmetry implications under DTU, including with L¹ Continuity and Relative Expectation, and cites Decision theory unbound, Remark 3, for the reflection countermodel.
- **GPT-6 generated 9 Sep** — GPT-6 (Codex), explicit source-model specialization and additional calculations, 9 September 2026; writeups/asymmetric-continuous-ultrafilter.md, in response to Zachary Goodsell's request to investigate consequences and countermodels from DU.
- **Decision Theory Unbound** — Zachary Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, Appendix B, Definition 3, Lemma 6 and proof of Theorem 3, pp. 691–692; Remark 3 and Corollary 3, pp. 692–693. Source of the clipped-expectation ultrafilter, continuous quotient, and asymmetric-cutoff strategy, including the possibility of assigning nonzero values to symmetric gambles.

Record: `topics/unbounded-utility/models/asymmetric-continuous-ultrafilter.yaml`.

Write-up.

#### Clipped expectation: continuous ultrafilter dominance [−t, 2t]

**Direct source: Symmetries of Value.** Zachary Goodsell’s *Symmetries of
value*, Theorem 1 (p. 24), already states that DTU does not imply the affine
symmetry principles, including when L¹ Continuity and Relative Expectation
are added. Its reflection countermodel explicitly invokes *Decision theory
unbound*, Remark 3. Thus both the asymmetric construction and this stronger
non-implication belong to Goodsell; they are not new AI results.

The underlying continuous quotient appears in *Decision theory unbound*,
Appendix B, Definition 3, Lemma 6 and proof of Theorem 3 (pp. 691–692).
Remark 3 and Corollary 3 (pp. 692–693) supply separate increasing unbounded
cutoffs and symmetric gambles with arbitrary real values, including nonzero
ones.

**Original work: source-model specialization and additional verification.**
GPT-6 (Codex), 9 September 2026, chose the explicit cutoffs f(t)=2t, g(t)=t
and recorded the detailed proofs below. The added work is the displayed
CDF-area and shift-transfer verification, exact Cauchy and alternating-game
values, and negative-self-similarity witness. The L¹/Relative Expectation
non-implication is already stated in the source; its proof here is an explicit
verification, not a newly discovered separation. No literature-novelty claim,
independent checker or Lean verification is asserted.

##### Construction and the DTU axioms

Take $O=\mathbb R$ with its usual order, Borel structure and identity utility,
and all measurable real random variables on the topic's fixed probability
space. Put

$$q_t(x)=\max(-t,\min(x,2t)),\qquad
v_X(t)=E[q_t(X)],\qquad t>0.$$

Fix an ultrafilter $\mathcal U$ on $(0,\infty)$ containing every tail
$(s,\infty)$. Define

$$X\succeq Y\quad\Longleftrightarrow\quad
\forall\varepsilon>0,\quad
\{t:v_X(t)-v_Y(t)\ge-\varepsilon\}\in\mathcal U.\tag{1}$$

Existence of this ultrafilter uses the usual ultrafilter lemma, as in the
source construction; this is a mathematical existence model, not an
implemented algorithm for arbitrary comparisons.

Reflexivity is immediate. For transitivity, intersect the two large sets
obtained with $\varepsilon/2$. If $X\not\succeq Y$, there is an
$\varepsilon>0$ such that $v_Y-v_X>\varepsilon$ on a large set.
Consequently $Y\succeq X$, proving **Totality**.

Equal laws have equal $v$-functions, so **Stochastic Equivalence** holds.
Constants and all values of each simple gamble eventually lie inside the
clipping window. Their comparisons are therefore exactly their ordinary
expectation comparisons. The normalized chart is the identity: the binary
calibration equations give the usual real values. This proves **Rich
Outcomes** and **Simple Expected Utility**, including all standing chart
conventions.

For the fixed randomized mixture, equality of its law with the mixture law
gives

$$v_{M_p(X,Z)}=p v_X+(1-p)v_Z.$$

Subtracting the corresponding expression with $Y$ and rescaling
$\varepsilon$ by $p>0$ proves the full **Mixture Independence** biconditional.

Write $S_X(s)=\Pr(X>s)$. The elementary clipped-tail identity gives

$$v_X(t)-v_Y(t)=\int_{-t}^{2t}(S_X(s)-S_Y(s))\,ds.\tag{2}$$

If $S_X\ge S_Y$ pointwise, this is nonnegative. If an inequality is strict
at a threshold, right continuity supplies an interval where the difference
is bounded below by a positive constant. All sufficiently large windows
contain that interval, giving a fixed strictly positive gap in (2). Thus
(1) preserves both weak and strict **Stochastic Dominance**. These
verifications establish the entire DTU package.

Two useful consequences of (1) will be used below. Adding a function tending
to zero to $v_X-v_Y$ does not change the comparison, by an
$\varepsilon/2$ argument. If $v_X-v_Y$ tends to a finite number $r$, the
comparison holds exactly when $r\ge0$; when the limit is zero both directions
hold. A limit of $+\infty$ or $-\infty$ yields the corresponding strict
comparison.

##### Expectation, CDF area, and continuity

For integrable $X$, $q_t(X)\to X$ pointwise and $|q_t(X)|\le |X|$.
Dominated convergence gives $v_X(t)\to E[X]$. The preceding limit criterion
proves **Expected Utility**.

Clipping is 1-Lipschitz. Whenever $E|X-Y|<\infty$,

$$q_t(X)-q_t(Y)\longrightarrow X-Y,\qquad
|q_t(X)-q_t(Y)|\le |X-Y|.$$

Hence $v_X-v_Y\to E[X-Y]$, even when the individual expectations do not
exist. The limit criterion proves **Relative Expectation** for the variables'
actual coupling, without replacing that coupling by a more convenient one.

For **CDF-Area Extension**, put $d=S_X-S_Y$ and
$A_\pm=\int_{\mathbb R}d_\pm$. The nested windows $[-t,2t]$ exhaust
$\mathbb R$, so their positive and negative integrals tend monotonically to
$A_+$ and $A_-$. If at least one area is finite, (2) tends to their
well-defined difference in the extended reals. If both are finite and equal,
the limit is zero; if the positive area is larger, including the case of a
single positive infinity, the limit is positive; the reverse cases are
negative. Thus $X\succeq Y$ holds exactly when $A_+\ge A_-$ in every case
specified by the principle. Nothing here specifies the both-infinite pairs.

For **L¹ Continuity**, suppose $\delta_n=E|X_n-X|\to0$ and
$X_n\succeq Y$ for every $n$. The Lipschitz property gives

$$|v_{X_n}(t)-v_X(t)|\le\delta_n\quad\text{for every }t.$$

Fix $\varepsilon>0$, and choose $n$ with $\delta_n<\varepsilon/2$.
On a large set, $v_{X_n}-v_Y\ge-\varepsilon/2$, hence
$v_X-v_Y\ge-\varepsilon$. This is precisely (1) for $X\succeq Y$.
The proof verifies the topic's upper-section clause on the full domain,
including nonintegrable $X$ and $Y$.

##### Shifts

For each fixed real $b$ and arbitrary $X$,

$$q_t(X+b)-q_t(X)\longrightarrow b,\qquad
|q_t(X+b)-q_t(X)|\le |b|.$$

Dominated convergence gives $v_{X+b}-v_X\to b$. Simultaneously shifting
$X,Y$ therefore changes their comparison function by a function tending to
zero. This proves **Shift Invariance**, in both directions.

For $0<p<1$, subtract the values of the two mixtures in **Transfer of a
Shift Across a Mixture**:

$$\begin{aligned}
&v_{M_p(X+b/p,Y)}-v_{M_p(X,Y+b/(1-p))}\\
&\qquad=p(v_{X+b/p}-v_X)
 -(1-p)(v_{Y+b/(1-p)}-v_Y)\longrightarrow b-b=0.
\end{aligned}$$

The mixtures are therefore indifferent. Neither shift conclusion has used
reflection symmetry or finite individual expectations.

##### A symmetric Cauchy has positive value

Let $C_\sigma$ have the symmetric Cauchy density
$\sigma/[\pi(\sigma^2+x^2)]$, where $\sigma>0$. Such a variable is available
on the fixed atomless probability space. Direct integration over the window
and its two clipped tails gives

$$v_{C_\sigma}(t)=
\frac{\sigma}{2\pi}\log\frac{\sigma^2+4t^2}{\sigma^2+t^2}
+\frac{2t}{\pi}\arctan\frac{\sigma}{2t}
-\frac{t}{\pi}\arctan\frac{\sigma}{t}
\longrightarrow \frac{\sigma\log2}{\pi}.\tag{3}$$

Indeed the logarithmic term tends to $\sigma\log2/\pi$, while the last
two terms each tend in magnitude to $\sigma/\pi$ and cancel. Put
$k=\log2/\pi>0$. Equation (3) yields $C_1\sim k\succ0$.

This one comparison proves three failures:

- **Symmetric Gambles Are Neutral** fails: $C_1$ and $-C_1$ have the same
  law but $C_1\not\sim0$.
- **Reflection Anti-Invariance** fails: $C_1\succeq0$, whereas
  $0\not\succeq-C_1$. Its special case $a=1,b=0$ also directly refutes
  **Negative Affine Anti-Invariance**.
- **Folded Expectation** fails: both $C_1$ and zero have identically zero
  combined symmetric tail difference, so that principle would require
  them to be indifferent.

For **Uniqueness of Negative Self-Similarity**, take
$p=1/2$, $a=2$, $b=0$, and $Z=0$. The variables $-2C_1$ and $C_2$ have
the same law. By (3) and mixture linearity,

$$v_{M_{1/2}(-2C_1,0)}\longrightarrow\tfrac12(2k)=k,
\qquad C_1\sim M_{1/2}(-2C_1,0).$$

Zero also satisfies $0\sim M_{1/2}(-2\cdot0,0)$. The two fixed values
are distinct because $C_1\succ0$. This refutes precisely the recorded
uniqueness principle.

##### Alternating St Petersburg is zero

Let $A$ take $(-2)^n$ with probability $2^{-n}$, $n\ge1$. Group consecutive
odd and even indices. Each pair has a negative outcome $-a$ of probability
$2r$ and positive outcome $2a$ of probability $r$, where $a,r>0$.
For every $t>0$,

$$q_t(-a)=-\min(a,t),\qquad q_t(2a)=2\min(a,t),$$

so the pair contributes exactly zero. Clipping makes the expectation
absolutely integrable, which licenses grouping the countably many pairs.
Thus $v_A(t)=0$ for every $t$, and $A\sim0$. In particular
**Alternating St Petersburg = −1/2** fails.

##### Scope of the verification

This model establishes, among other separations, that DTU together with
CDF-Area Extension, Relative Expectation, L¹ Continuity, and both shift
principles still does not force symmetric neutrality or reflection. No
scale or sum-invariance verdict has been inferred from this construction.
The map can derive further failures from its separately proved
incompatibility records.

`checks/asymmetric_continuous_ultrafilter.py` checks the paired-atom
cancellations with exact rational arithmetic, finite-law clipped-tail and
mixture identities, the Lipschitz bound, and the explicit Cauchy limits.
Those checks are sanity checks of concrete calculations; the universal
properties and ultrafilter comparisons are proved analytically above.

### CDF-area dominance — `cdf-area-preorder`

Model; source **Unbounded Utility and Background Risk (unpublished)**; produced by Zachary Goodsell (unpublished manuscript); recorded by GPT-6 (Codex), 2026-09-09; extraction and random-variable translation; checked by nobody; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Expected Utility (`expected-utility`)
- Relative Expectation (`relative-expectation`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)

Violates:

- Totality (`totality`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Folded Expectation (`folded-expectation`)
- Full Sum Invariance (`full-sum-consistency`)
- Antitonic Sum Invariance (`antitonic-sum-consistency`)

Unknown in this model: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`)

Construction.

Use real outcomes with their identity utility. For d=S_X−S_Y, define X ≽R Y iff ∫d₋<∞ and ∫d₊≥∫d₋. This is the manuscript’s explicit base preorder, satisfying DU but not DTU because Totality fails. Its elementary properties, comonotonic sum consistency, and forward independent-sum preservation are established in the accompanying write-up, with the quantile-area argument made valid for infinite areas. The draft’s proof does not establish reverse independent-sum cancellation, so full Independent Sum Invariance is not asserted. Symmetric Cauchy versus zero has both areas infinite, witnessing incompleteness and failure of Symmetric Neutrality and Folded Expectation. The St Petersburg arguments supply the two sum-consistency violations.

Executable checks: `topics/unbounded-utility/checks/background_risk.py`.

Notes. This is the concrete base construction, not the draft’s withdrawn total symmetric extension. Strict comparisons are part of the construction. No claim that convolution cancellation is false is inferred from a gap in its proof.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §3, pp. 7–8; Theorems 6–7, pp. 19–20
- **GPT-6 generated 9 Sep** — GPT-6 (Codex), original connecting proof recorded 9 September 2026 in this project; explicit quantile-area/Tonelli details and Cauchy witnesses in writeups/cdf-area-preorder.md

Record: `topics/unbounded-utility/models/cdf-area-preorder.yaml`.

Write-up.

#### CDF-area dominance

This is a model of **DU**, but not **DTU**, because Totality fails.

**Source:** Zachary Goodsell, *Unbounded Utility and Background Risk*, 5 June
2026, §3 (pp. 7–8) and Theorem 7 (pp. 19–20). The supplied manuscript is
**unpublished, marked “do not cite”, and erroneous**. This local provenance
record does not endorse its withdrawn consistency theorem. The construction
is Goodsell’s; the explicit area, Tonelli, and counterexample details below
were recorded by GPT-6 (Codex), 9 September 2026. No separate checker or Lean
verification is claimed.

##### Construction

Take all real-valued random variables, with real outcomes and identity utility.
Let $S_X(t)=\Pr(X>t)$ and put

$$d=S_X-S_Y,\qquad A_+=\int_{\mathbb R}d_+(t)\,dt,
\qquad A_-=\int_{\mathbb R}d_-(t)\,dt.$$

Define

$$X\succeq_R Y\quad\Longleftrightarrow\quad
A_-<\infty\ \text{and}\ A_+\ge A_-.$$

Thus both finite equal areas give indifference; one infinite area gives a
strict comparison in the appropriate direction; two infinite areas give
incomparability. Never evaluate $\infty-\infty$. The draft uses survival CDFs
with a different endpoint convention, which has no effect on the integrals.

##### Preorder, expectation, and symmetry

Reflexivity is immediate. For transitivity write
$d_{XZ}=d_{XY}+d_{YZ}$. If the two component comparisons hold, their negative
parts are integrable. So is the negative part of their sum, since
$(a+b)_-\le a_-+b_-$. Signed integration is additive when negative parts are
integrable, including a possible positive infinity. Both component integrals
are nonnegative, so the sum comparison holds.

The relation depends only on laws. For integrable $X,Y$, both areas are finite
and $A_+-A_-=E[X]-E[Y]$. This verifies Expected Utility, hence the identity
chart, Simple EU, and Archimedean Outcomes; Rich Outcomes is explicit in the
model. More generally, if $E|X-Y|<\infty$ in the actual coupling, then

$$\int|S_X-S_Y|\le E|X-Y|,\qquad
\int(S_X-S_Y)=E[X-Y],$$

by the indicator formula and Fubini. This verifies Relative Expectation even
when the individual expectations are undefined.

Stochastic dominance gives $d\ge0$. Strict dominance gives a positive area:
strict inequality at a threshold persists on an interval by one-sided
continuity. Hence the relation preserves both weak and strict dominance.

Mixing both gambles with a common third law multiplies $d$ by the positive
mixture weight. It multiplies both areas by that weight, proving the full
Mixture Independence biconditional, including cases with infinite areas.

For $a>0$, replacing $X,Y$ by $aX+b,aY+b$ multiplies both areas by $a$.
Thus Positive Affine Invariance holds. Reflection and reversal give
$d_{-Y,-X}(t)=d_{X,Y}(-t)$ almost everywhere, leaving each area unchanged.
Thus Reflection Anti-Invariance holds as well. The minus sign in the draft’s
equation (16) is a substitution error; Lebesgue integration under $t\mapsto-t$
does not negate the integral.

##### Comonotonic Sum Invariance

Let $Q_X,Q_Y$ be increasing quantiles. Tonelli applied to the regions between
the two graphs gives the *separate*, nonnegative area identities

$$A_+=\int_0^1(Q_X(u)-Q_Y(u))_+\,du,\qquad
A_-=\int_0^1(Q_Y(u)-Q_X(u))_+\,du.$$

These identities include infinite areas. For example, the first counts the
region where $Q_Y(u)\le t<Q_X(u)$, either by horizontal or vertical sections.
Monotonicity makes the length of its section at $t$ equal to
$(S_X(t)-S_Y(t))_+$, up to irrelevant endpoint conventions.

A comonotonic sum has quantile $Q_X+Q_Z$ almost everywhere. Adding $Q_Z$ to
both quantiles leaves their difference, and therefore **both** areas,
unchanged. This proves the biconditional on the entire domain. It supplies
the missing infinite-area justification in the manuscript’s informal
“rotate the CDF” argument in Theorem 7.

##### Independent sums: the forward result

For an independent common summand with law $\xi$, the new survival difference
is $h=d*\xi$. Suppose $X\succeq_R Y$, so $g=d_-$ is integrable. Set $f=d_+$.
Then $h=f*\xi-g*\xi$ and

$$h_-\le g*\xi,\qquad \int(g*\xi)=\int g<\infty.$$

Tonelli gives $\int(f*\xi)=\int f$, possibly infinite. Since the negative
term is integrable, the signed integral of $h$ equals the original signed
integral of $d$, with the same finite or positive-infinite value. Therefore
weak **and strict** comparisons are preserved.

This does **not** establish the reverse implication. The printed proof
identifies $f*\xi,g*\xi$ with $h_+,h_-$, which is unjustified: the two
convolutions can overlap and cancel. For a simple example, let $X$ be equally
likely $-1$ or $1$, let $Y=0$, and let $\xi$ be equally likely $0$ or $1$.
Originally both areas are $1/2$; after convolution both are $1/4$. Tonelli
still preserves the integrals of the separately convolved $f$ and $g$.
This demonstrates the false identification; it is **not** a counterexample
to convolution invariance itself. Independent Sum Cancellation, and hence
full Independent Sum Invariance, remain unasserted for this exact model.
A [total extension satisfying Independent Sum Invariance](conjectured-total-independent-sum-extension.html)
is now proved separately: saturating the area cone first supplies
cancellation while preserving its strict comparisons, after which an
invariant maximal-cone argument supplies totality.

##### Verified failures

For a standard symmetric Cauchy variable $C$, comparison with zero has two
infinite areas: on each side the absolute area is the corresponding infinite
first tail moment. Thus $C$ and $0$ are incomparable. This witnesses failure
of Totality and Symmetric Neutrality (the draft’s “Reflection Symmetry”).
Folded Expectation also fails: the symmetric tail difference is identically
zero, so that principle would demand $C\sim0$.

Full and Antitonic Sum Invariance fail by the recorded St Petersburg
arguments, which require only Rich Outcomes and Stochastic Dominance.
See [the full-sum witness](dominance-refutes-full-sum.html) and
[the antitonic witness](dominance-refutes-antitonic-sum.html).

The executable check `checks/background_risk.py` tests finite-law area and
quantile identities, mixture behavior, the convolution-overlap example, and
exact St Petersburg tail identities. It is a sanity check, not a numerical
proof about all distributions or any transfinite extension.

See also the [source inventory and failed-claim audit](symmetric-dtu-refutes-independent-sum-candidate.html).

### CDF-area conclosure — `cdf-conclosure-preorder`

Model; source **Unbounded Utility and Background Risk (unpublished)**; produced by Zachary Goodsell (CDF-area construction and conclosure); GPT-6 (Codex) (construction-stage extraction and property audit); recorded by GPT-6 (Codex); checked by nobody; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Expected Utility (`expected-utility`)
- Simple Expected Utility (`simple-eu`)
- Relative Expectation (`relative-expectation`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)

Violates:

- Totality (`totality`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)

Unknown in this model: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`)

Construction.

Use all real outcomes with identity utility. In the vector space of survival differences, let C={v: integral(v_-) is finite and integral(v_+) is at least integral(v_-)} be Goodsell's CDF-area cone. Define Sat(C)={v: T_xi v belongs to C for some probability law xi}, where T_xi is convolution by xi, and set X >= Y iff S_X-S_Y belongs to Sat(C). This is Goodsell's conclosure, stopped before the total-extension step. The previously recorded commutation and strict-preservation argument makes it a cone extending the area comparisons strictly and invariant in both directions under every independent convolution. Reflection of the survival difference conjugates xi to its reflected law; positive affine changes conjugate xi to its positively scaled law. The area cone is invariant under these changes, so the conclosure inherits reflection anti-invariance and positive affine invariance. It fails Symmetric Neutrality by the completed Levy obstruction. Since a comparable symmetric gamble in any law-invariant reflection-anti-invariant preorder must be indifferent to zero, this model must also fail Totality. It is consequently a model of DU, but not DTU: Totality is the additional DTU axiom.

Executable checks: `topics/unbounded-utility/checks/levy_obstruction.py`.

Notes. Original work: construction-stage extraction and model adaptation/property audit. The CDF-area seed and conclosure construction are Goodsell's, and the stage already appears in the recorded total-extension proof. GPT-6 now records this intermediate model separately, proves the inherited affine/reflection symmetries by kernel conjugation, and establishes its incompleteness using the completed Goodsell stable-law proposal. No new independent invention of conclosure or claim of literature novelty is made. The construction quantifies over all probability kernels; it is not a computable comparison algorithm. No comonotonic sum property is asserted: conclosure does not automatically inherit the exact area's comonotonic invariance. No independent checker or Lean verification is claimed.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026 (unpublished), sections 3-4, pages 7-14: CDF-area construction and conclosure. Supplied manuscript marked do not cite and erroneous in its symmetric total-extension claim.
- **GPT-6 conclosure proof details 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/conjectured-total-independent-sum-extension.md, sections 1-3: previously recorded cone-language description and strictness-preservation proof for Goodsell conclosure.
- **GPT-6 model property audit 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/cdf-conclosure-preorder.md: extraction of the intermediate model, conjugation proofs for its inherited symmetries, and incompleteness from the completed Goodsell Levy obstruction.

Record: `topics/unbounded-utility/models/cdf-conclosure-preorder.yaml`.

Write-up.

#### CDF-area conclosure

This model satisfies **DU**, together with
CDF-Area Extension, Independent Sum Invariance, Positive Affine Invariance,
and Reflection Anti-Invariance. It fails Totality and Symmetric Gambles Are
Neutral. Since DTU is DU plus Totality, this is a DU model but not a DTU
model. Thus reflection anti-invariance remains compatible with independent
sums when completeness is dropped.

**Original work: construction-stage extraction and model adaptation/property
audit.** The CDF-area seed and conclosure construction belong to Zachary
Goodsell, *Unbounded Utility and Background Risk* **(unpublished)**,
5 June 2026, sections 3–4, pp. 7–14. The supplied manuscript is marked
“do not cite” and erroneous in its symmetric total-extension claim; this
record does not reinstate that claim. This intermediate stage already appears
in the [recorded total-extension proof](conjectured-total-independent-sum-extension.html).
GPT-6 (Codex), 9 September 2026, supplied the separate model record,
the conjugation checks for its affine/reflection symmetries, and the deduction
of incompleteness from the completed Goodsell stable-law obstruction.
Conclosure is not presented as an independently invented AI construction,
and no literature-novelty claim is made. No independent checker or Lean
verification is claimed.

##### Construction and area preservation

Use real outcomes and identity utility. Let $V$ be the vector space of
survival functions of finite signed Borel measures of total mass zero,
identified almost everywhere. Each $S_X-S_Y$ belongs to $V$. Define

$$C=\left\{v\in V:\int v_-<\infty,\quad
                     \int v_+\geq\int v_-\right\},$$

and, for probability laws $\xi$,

$$T_\xi v(t)=\int v(t-z)\,d\xi(z),\qquad
 D=\operatorname{Sat}(C)=\{v:\exists\xi,\ T_\xi v\in C\}.$$

Then set $X\succeq_DY$ precisely when $S_X-S_Y\in D$. This is Goodsell's
conclosure of the area relation before taking any maximal total extension.

Here are the closure details, also recorded in sections 1–3 of the
[total-extension construction](conjectured-total-independent-sum-extension.html).

1. $C$ is a cone, and forward convolution preserves all of its weak and
   strict comparisons. Indeed $(T_\xi v)_-\leq T_\xi(v_-)$; Tonelli
   preserves the integrals of the separately convolved positive and negative
   parts. When the negative part is integrable, the signed integral is
   preserved, including a possible positive-infinite value.
2. If $T_\xi v,T_\eta w\in C$, then
   $T_{\xi*\eta}(v+w)=T_\eta T_\xi v+T_\xi T_\eta w\in C$.
   Together with positive scalar closure, this makes $D$ a cone containing
   $C$; hence it induces a reflexive transitive relation.
3. For every $\rho$, $v\in D$ iff $T_\rho v\in D$. In the forward
   direction, convolve an existing witness by $\rho$ and use commutation.
   In the reverse direction, compose $\rho$ with a witnessing convolution.
4. If $v\in C\setminus(-C)$ but $-v\in D$, some $\xi$ would give
   $-T_\xi v\in C$. Forward strict preservation simultaneously gives
   $T_\xi v\in C\setminus(-C)$, a contradiction. Thus $D$ preserves
   every strict area comparison, as well as every weak one.

Consequently the model satisfies CDF-Area Extension. Expected Utility,
Simple EU, Relative Expectation, and Stochastic Dominance follow by the
recorded area arguments. Its sure-outcome chart is the identity, so Rich
Outcomes and Archimedean Outcomes hold. Preferences depend only on laws,
so Stochastic Equivalence holds.

Mixtures with a common law multiply the survival difference by $p>0$.
Cone membership is equivalent under positive scalar multiplication, proving
Mixture Independence. Independent common summands apply $T_\xi$ to the
survival difference. Property 3 proves Independent Sum Invariance, including
cancellation and hence both weak and strict forward preservation.

##### The inherited outcome symmetries

For reflection and reversal of the compared pair, the new survival difference
is $Rv(t)=v(-t)$ almost everywhere. Both areas of $v$ are unchanged under
$R$, so $RC=C$. If $\check\xi$ is the reflected law, then

$$R T_\xi = T_{\check\xi}R.$$

Reflecting a witness for $v\in D$ therefore supplies a witness for $Rv\in D$.
Applying reflection twice gives the converse. As $Rv$ is the survival
difference for $-Y$ versus $-X$ when $v=S_X-S_Y$, this is exactly
Reflection Anti-Invariance:

$$X\succeq_DY\quad\Longleftrightarrow\quad -Y\succeq_D-X.$$

For $a>0$ and $b\in\mathbb R$, put $A_{a,b}v(t)=v((t-b)/a)$.
The two areas are each multiplied by $a$, so $A_{a,b}C=C$. If $a\xi$
denotes the pushforward of $\xi$ by $z\mapsto az$, then

$$A_{a,b}T_\xi=T_{a\xi}A_{a,b}.$$

Thus a witness for $v\in D$ supplies one for $A_{a,b}v\in D$.
Using the inverse affine transformation proves the converse, establishing
Positive Affine Invariance. The kernel is scaled by $a$; it is not also
translated by $b$, since $b$ already translates the compared gambles.

##### Why the model is incomplete

The [completed Lévy obstruction](levy-refutes-neutral-independent-preservation.html)
shows that Rich Outcomes, Stochastic Dominance, Mixture Independence, and
Independent Sum Preservation cannot coexist with Symmetric Gambles Are
Neutral. The model has all four antecedent properties, so it fails the
neutrality principle.

The obstruction gives concrete candidate witnesses: for independent positive
Lévy variables $L_1,L_2$ and an independent fair sign $\varepsilon$, at
least one of

$$W=\varepsilon L_1\qquad\text{and}\qquad D_0=L_2-L_1$$

is not indifferent to zero in this model. Both have symmetric laws. We do
not claim to determine which candidate the existential convolution test
leaves undecided.

For any symmetric-law variable $X$, Stochastic Equivalence gives $X\sim-X$.
If $X\succeq_D0$, reflection gives $0\succeq_D-X$, hence $0\succeq_DX$.
If $0\succeq_DX$, the reversed argument gives $X\succeq_D0$. Thus a
symmetric variable comparable with zero must be indifferent to zero.
The nonneutral candidate above is therefore **incomparable** with zero,
proving failure of Totality. This also explains why the symmetry inherited
by this incomplete model does not contradict the new impossibility result.

The construction quantifies over arbitrary probability laws, so this is an
existence model rather than an executable ranking algorithm. Its listed
check, `checks/levy_obstruction.py`, only verifies finite numerical
diagnostics for the analytic witness used to establish these failures.
Comonotonic Sum Invariance and other unproved properties are left open;
they are not inherited automatically merely because they hold in the
unsaturated area preorder.

### CDF-area: total comonotonic extension — `conjectured-total-comonotonic-area-extension`

Conjectured model; source **Misc.**; produced by Zachary Goodsell (area construction and broader comonotonic consistency question); GPT-6 (Codex) (precise total CDF-area extension candidate); recorded by GPT-6 (Codex); checked by nobody; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)

Violates:


Unknown in this model: nothing; every principle is settled.

Construction.

Proposed existence claim, not a completed construction: a total preorder on all real-valued random variables that strictly extends Goodsell's CDF-area preorder and satisfies both Mixture Independence and Comonotonic Sum Invariance. Real outcomes and the inherited area comparisons supply Rich Outcomes, Simple Expected Utility and Stochastic Dominance; require Stochastic Equivalence explicitly. The incomplete exact CDF-area preorder already satisfies all these properties except Totality. Seek a total extension preserving both the mixture comparisons and the comonotonic-sum biconditionals. The existing total independent-sum extension does not establish this: convolution is linear on survival differences, whereas comonotonic addition is translation of increasing quantiles, and its compatibility with the extension step remains unproved. No symmetry, independent-sum, continuity or negative verdict is asserted for this candidate.

Notes. Original work: precise candidate formulation and comparison of two extension problems. The base area construction, its comonotonic property, and the broader unresolved consistency question are credited to Goodsell. The manuscript's Theorem 7 supplies only the incomplete area model, not this proposed total CDF-area extension. No new completed model is claimed. To settle positively, give a total extension and verify that adjoining comparisons preserves every old strict area comparison, full Mixture Independence, and comonotonic preservation and cancellation. To settle negatively, derive an incompatibility from the displayed package. A generic order extension is insufficient, and the total convolution model is not evidence that comonotonic invariance survives. No claim is made that the question is open in the literature.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, unpublished manuscript, 5 June 2026, §3, pp. 7–8, and discussion before Theorem 7 and Theorem 7, pp. 19–20: CDF-area construction, its comonotonic invariance, and the broader unresolved consistency question.
- **GPT-6 conjecture 9 Sep** — GPT-6 (Codex), 9 September 2026, proposed total-extension package and obstacle analysis in writeups/conjectured-total-comonotonic-area-extension.md.

Record: `topics/unbounded-utility/models/conjectured-total-comonotonic-area-extension.yaml`.

Write-up.

#### CDF-area: total comonotonic extension

**Conjectured model, not constructed:** a preorder satisfying DTU,
CDF-Area Extension, and Comonotonic Sum Invariance.

The precise proposed package is Rich Outcomes, Totality, Stochastic
Equivalence, Simple Expected Utility, Stochastic Dominance, Mixture
Independence, CDF-Area Extension, and Comonotonic Sum Invariance. The proposed
outcome space is $\mathbb R$ with identity utility. No reflection, neutral
symmetry, independent-sum, or continuity requirement is imposed.

##### The starting model is already known

Goodsell's exact CDF-area preorder declares $X\succeq_RY$ when

$$\int(S_X-S_Y)_-<\infty,
\qquad \int(S_X-S_Y)_+\ge\int(S_X-S_Y)_-.$$

It satisfies DU and the proposed additional principles, but fails the
Totality axiom needed for DTU. In particular,
comonotonic invariance follows from the separate area identities

$$\int(S_X-S_Y)_\pm
  =\int_0^1(Q_X-Q_Y)_\pm,$$

and from adding the same increasing quantile $Q_Z$ to $Q_X,Q_Y$.
Both identities allow infinite areas. See the
[existing construction and verification](cdf-area-preorder.html).

The need for totality is real: pairs with both signed areas infinite remain
incomparable in this exact model, including a standard symmetric Cauchy
variable versus zero.

The discussion immediately before Theorem 7, p. 19, already identifies a
broader comonotonic consistency question as unsettled in the manuscript.
Theorem 7's partial answer uses the incomplete area relation. The present
entry specifies a total CDF-area extension as the target; it does not
attribute a proof or proposal of that exact package to the source.

##### Why the existing total-extension proof does not answer this

The [total independent-sum extension](conjectured-total-independent-sum-extension.html)
uses linear convolution operators on differences of survival functions.
Positive sums of those operators are positive multiples of another
convolution operator. That property makes its orientation and saturation
argument work.

Comonotonic addition is instead translation in quantile coordinates:

$$(Q_X,Q_Y)\longmapsto(Q_X+Q_Z,Q_Y+Q_Z).$$

Its preservation for the seed area relation does not show preservation for
newly adjoined comparisons. Meanwhile Mixture Independence is conveniently
linear in survival coordinates and is not generally linear in quantiles.
Thus simply repeating the convolution proof with a different word for its
operators does not prove this candidate.

##### What would settle the entry

A positive solution must complete the order while preserving every weak
and strict area comparison, full Mixture Independence, and both directions
of the comonotonic-sum comparison. A negative solution must give an explicit
incompatibility from the displayed package. Requiring only an arbitrary
total extension would not answer the question.

This candidate asks for a model of the comonotonic instance specifically.
The existing total independent-sum model already supplies a model of
Existential Copula Sum Invariance using the product copula, so the weaker
existential-copula consistency question is not being reopened here.

**Original work: precise candidate formulation and obstacle analysis.**
Goodsell's *Unbounded Utility and Background Risk* (unpublished), §3,
pp. 7–8, and the discussion before Theorem 7 and Theorem 7, pp. 19–20,
supply the area construction, comonotonic claim, and broader consistency
question. GPT-6 (Codex), 9 September 2026, formulated this precise
total-extension entry and recorded the gap. The candidate's direct source
is Misc.; the underlying construction remains attributed to Goodsell.
No new completed construction, literature novelty, independent check,
or Lean verification is claimed.

### CDF-area conclosure: total extension — `conjectured-total-independent-sum-extension`

Model; source **Unbounded Utility and Background Risk (unpublished)**; produced by Zachary Goodsell — CDF-area construction, conclosure, and total-extension strategy; recorded by GPT-6 (Codex), 2026-09-09 — cone-language exposition and additional proof details for strictness preservation and total extension; checked by nobody; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- CDF-Area Extension (`cdf-area-extension`)
- Expected Utility (`expected-utility`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Relative Expectation (`relative-expectation`)

Violates:

- Full Sum Invariance (`full-sum-consistency`)
- Antitonic Sum Invariance (`antitonic-sum-consistency`)
- Countable Sure-Thing (`countable-sure-thing`)
- Archimedean Gambles (`archimedean-gambles`)

Unknown in this model: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Scale Invariance (`scale-invariance`)

Construction.

Use real outcomes with identity utility. In the vector space of survival functions of finite signed measures of mass zero, let C be the CDF-area cone. Its weak and strict comparisons are preserved by forward convolution. Take Goodsell’s conclosure of C, expressed in cone language by declaring v positive whenever some convolution Tξv belongs to C; commutation ensures cone closure and full convolution cancellation, and forward strict preservation prevents collapse of old strict comparisons. A convolution-invariant cone D can be extended to orient any incomparable v: first adjoin all d+aTξv, then saturate. Convex mixtures of convolution kernels show that this intermediate cone has the same indifferent part as D and preserves strictness under forward convolution. Zorn’s lemma yields a total invariant cone extending C strictly. Pull its order back to random variables through survival differences. This proves Totality, CDF-Area Extension, Mixture Independence and Independent Sum Invariance; expectation and dominance follow from the area rule. The accompanying write-up proves every closure and orientation step. Known violations follow from the recorded St Petersburg/DU impossibility arguments.

Notes. The construction, conclosure operation, and total-extension strategy are attributed to Zachary Goodsell and his unpublished manuscript. GPT-6 supplied the cone-language exposition and additional proof details in the write-up; these are not attributed verbatim to the manuscript, and no independently originated AI construction is claimed. Upgraded from conjectured after those details were recorded; the stable ID is retained. Neither reflection requirement is assumed or listed as violated. The raw area cone’s cancellation remains unasserted: conclosure can enlarge it. This is nonconstructive existence using Zorn’s lemma. No independent checker or Lean verification is claimed.

Sources:

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026 (unpublished), §§3–4, pp. 7–14: CDF-area construction, conclosure, and total-extension strategy. Supplied manuscript marked “do not cite” and erroneous in its symmetry-extension claim.
- **GPT-6 proof details 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/conjectured-total-independent-sum-extension.md: cone-language exposition of Goodsell’s conclosure and additional details establishing strictness preservation and the total-extension step; not an independently originated construction.
- **Goodsell clarification 9 Sep** — Zachary Goodsell, project conversation, 9 September 2026: extension without reflection and clarification that the saturation construction is conclosure.

Record: `topics/unbounded-utility/models/conjectured-total-independent-sum-extension.yaml`.

Write-up.

#### CDF-area conclosure: total extension

**Status: proved by the argument below.** This is a nonconstructive existence
model, using Zorn’s lemma. The mathematical proposal and base construction
come from Zachary Goodsell, *Unbounded Utility and Background Risk*
**(unpublished)**, 5 June 2026, §§3–4, pp. 7–14, and Goodsell’s project
requests of 9 September 2026. The supplied manuscript is marked “do not cite”
and erroneous in its symmetry-extension claim.

**Attribution:** the CDF-area construction, conclosure operation, and
strategy of extending the ordering to totality are Zachary Goodsell’s. The
model’s direct source is *Unbounded Utility and Background Risk (unpublished)*.
GPT-6 (Codex), 9 September 2026, supplied the cone-language exposition and
additional details for strictness preservation and the extension step below.
“Convolution saturation” here is an explicit description of Goodsell’s
conclosure, not a separately originated construction. These additional proof
details are not claimed to appear verbatim in the manuscript. The erroneous
symmetry-extension argument is not used.

No independent checker or Lean verification is claimed. The stable record ID
retains its original `conjectured-` prefix; the status and displayed name have
been updated.

##### Existence claim

There exists a total preorder on all real-valued random variables that:

- extends the CDF-area preorder, preserving every weak and strict comparison;
- satisfies Stochastic Equivalence, Expected Utility, Relative Expectation,
  and Stochastic Dominance;
- satisfies Mixture Independence and Independent Sum Invariance, including
  cancellation of an arbitrary independent common summand.

Real outcomes with identity utility supply Rich Outcomes, Archimedean
Outcomes, and the normalized chart. Neither Symmetric Neutrality nor
Reflection Anti-Invariance is required by this construction. Their failure
is not inferred merely from their omission.

##### 1. Linear space and convolution operators

Let $V$ be the real vector space of survival functions of finite signed Borel
measures on $\mathbb R$ of total mass zero, identified almost everywhere.
In particular $S_X-S_Y\in V$ for all real-valued random variables. Every
nonzero signed measure of total mass zero is a positive scalar multiple of a
difference of probability measures, by its Jordan decomposition.

For each probability law $\xi$, write

$$T_\xi v(t)=\int v(t-z)\,d\xi(z).$$

These linear operators map $V$ into $V$. They commute,
$T_\xi T_\eta=T_{\xi*\eta}$, include the identity $T_{\delta_0}$, and obey

$$aT_\xi+bT_\eta=(a+b)T_{(a\xi+b\eta)/(a+b)}\quad(a,b\ge0,\ a+b>0).$$

This last identity says that a positive combination of convolution operators
is a positive scalar times another convolution operator. It is essential to
the orientation argument. No reflection operator is included.

For an additive cone $A\subseteq V$, closed under multiplication by
nonnegative real scalars, write

$$L_A=A\cap(-A),\qquad A^{\mathrm{str}}=A\setminus(-A).$$

These are its indifferent and strictly positive parts. An extension preserves
strict comparisons when it does not acquire the negative of an old strictly
positive vector.

##### 2. The area cone preserves strictness under forward convolution

Define

$$C=\{v\in V:\ \int v_-<\infty,\quad \int v_+\ge\int v_-\}.$$

This is an additive cone: negative parts satisfy
$(v+w)_-\le v_-+w_-$, and integration is additive for signed functions with
integrable negative part, allowing a positive-infinite result. Its lineality
space is $L_C=\{v\in L^1:\int v=0\}$.

For every $\xi$, both $T_\xi C\subseteq C$ and
$T_\xi C^{\mathrm{str}}\subseteq C^{\mathrm{str}}$. Indeed, if $v\in C$,
then $(T_\xi v)_-\le T_\xi(v_-)$ has finite integral. Tonelli preserves the
integrals of the separately convolved positive and negative terms. Since the
negative term is integrable, the signed integral of $T_\xi v$ equals that of
$v$, whether finite or positive infinite. A positive integral stays positive;
a zero integral stays zero. See also the
[base-model proof](cdf-area-preorder.html).

This establishes only forward preservation for $C$. We do not assume that
$T_\xi v\in C$ implies $v\in C$.

##### 3. Conclosure supplies cancellation safely

For any cone $A$ preserved forward, weakly and strictly, by every $T_\xi$,
express its conclosure (convolution saturation) by

$$\operatorname{Sat}(A)=\{v:\text{for some probability law }\xi,
\ T_\xi v\in A\}.$$

This is a cone containing $A$. If $T_\xi v\in A$ and $T_\eta w\in A$,
then

$$T_{\xi*\eta}(v+w)=T_\eta(T_\xi v)+T_\xi(T_\eta w)\in A,$$

which proves closure under addition; scalar closure is immediate. Moreover,
for every probability law $\rho$,

$$v\in\operatorname{Sat}(A)\quad\Longleftrightarrow\quad
T_\rho v\in\operatorname{Sat}(A).$$

For the forward direction convolve an existing witness by $\rho$. For the
reverse direction compose $\rho$ with the witness for $T_\rho v$.

This is the **least** fully convolution-invariant cone containing $A$:
if $D$ is any such cone and $T_\xi v\in A$, then $T_\xi v\in D$, so
cancellation in $D$ forces $v\in D$. Thus $\operatorname{Sat}(A)\subseteq D$.
Mixture closure is already encoded by the cone structure. This identifies
the operation with Goodsell’s conclosure in these coordinates.

Crucially, saturation preserves every strict comparison of $A$. If
$v\in A^{\mathrm{str}}$ but $-v\in\operatorname{Sat}(A)$, some $\xi$
would give $-T_\xi v\in A$. Forward strict preservation gives
$T_\xi v\in A^{\mathrm{str}}$, a contradiction.

Thus $D_0=\operatorname{Sat}(C)$ extends the area cone without losing
strictness and satisfies full convolution cancellation. The resulting
membership equivalence also makes every convolution preserve its strict
comparisons: apply it to both $v$ and $-v$.

##### 4. Orienting an incomparable vector

Let $D$ be any cone satisfying
$v\in D\iff T_\xi v\in D$ for every $\xi$. Suppose that neither $v$ nor
$-v$ belongs to $D$. Then no $T_\xi v$ belongs to $D$ or $-D$ either.

Adjoin $v$ and all its forward transforms by setting

$$K=\{d+aT_\xi v:\ d\in D,\ a\ge0,\ \xi\text{ a probability law}\}.$$

The positive-combination identity from §1 proves that $K$ is a cone;
commutation and forward invariance of $D$ prove forward invariance of $K$.

**No old strict comparison collapses.** In fact $K\cap(-K)=L_D$. To see
this, if $k=d_1+aT_\xi v$ and $-k=d_2+bT_\eta v$, then

$$0=d_1+d_2+(a+b)T_\theta v$$

for a probability law $\theta$ when $a+b>0$. This would imply
$-T_\theta v\in D$, hence $-v\in D$, contrary to incomparability.
Consequently $a=b=0$ and $k\in L_D$. The reverse inclusion is immediate.

**Forward convolution preserves strictness in $K$.** Suppose
$x=d+aT_\xi v\in K$ and $T_\rho x\in L_D$. If $a>0$, then

$$-aT_{\rho*\xi}v=T_\rho d-T_\rho x\in D,$$

which again implies $-v\in D$, impossible. If $a=0$, the two memberships
$T_\rho d\in D$ and $-T_\rho d\in D$, together with cancellation in $D$,
imply $d\in L_D$. Thus a strictly positive element of $K$ cannot become
indifferent after convolution, since the indifferent part of $K$ is exactly
$L_D$.

We can therefore apply §3 to $K$. The cone
$D'=\operatorname{Sat}(K)$ is fully convolution invariant, contains $D$ and
$v$, and preserves all strict comparisons of $D$. It is a proper extension
of $D$. This establishes the orientation step for the genuine closure,
rather than for a chain description that omits cancellation.

##### 5. Maximal extension and totality

Consider the set of cones $D$ containing $D_0$, fully convolution invariant,
and satisfying

$$D\cap(-C^{\mathrm{str}})=\varnothing.$$

It is nonempty by §3. The union of any increasing chain is again such a cone:
closure and convolution membership equivalence involve only finitely many
memberships, and none of its members can contain a forbidden vector. Zorn’s
lemma therefore supplies a maximal member $D_*$.

If some $v$ belonged to neither $D_*$ nor $-D_*$, §4 would give a proper
extension preserving all its strict comparisons, hence still avoiding
$-C^{\mathrm{str}}$. That contradicts maximality. Therefore

$$D_*\cup(-D_*)=V.$$

Define preferences on the original random variables by

$$X\succeq_*Y\quad\Longleftrightarrow\quad S_X-S_Y\in D_*.$$

Cone closure gives reflexivity and transitivity; the displayed coverage gives
totality. Membership depends only on laws, so Stochastic Equivalence holds.
Containment of $C$ and avoidance of $-C^{\mathrm{str}}$ preserve every weak
and strict area comparison, exactly as required by CDF-Area Extension.

Mixing both laws with a common law multiplies their survival difference by
$p>0$. Cone membership is equivalent under positive scalar multiplication,
proving Mixture Independence in both directions. Adding a common independent
summand applies $T_\xi$ to that difference. The defining invariance of $D_*$
proves Independent Sum Invariance in both directions.

Expected Utility, Relative Expectation, and Stochastic Dominance follow from
CDF-Area Extension by the recorded implications. All required comparisons
of sure outcomes and finite gambles therefore agree with the identity chart.

##### Scope and known failures

This proves the previously proposed existence package, including convolution
invariance, without either reflection requirement. It does not establish
convolution cancellation for the **exact incomplete area preorder** itself:
its saturation can add comparisons. Nor does it show that arbitrary total
extensions inherit any invariance automatically.

Full Sum Invariance and Antitonic Sum Invariance fail by the recorded
Rich-Outcomes-plus-Dominance witnesses. Countable Sure-Thing and Archimedean
Gambles fail by the existing DU consequences. These explain the model’s
`violates` entries. No further symmetry or comonotonic-sum properties are
asserted for the chosen maximal cone.

The author’s withdrawn **symmetric** consistency claim remains withdrawn.
The separate [stable-law incompatibility candidate and source audit](symmetric-dtu-refutes-independent-sum-candidate.html)
still lack an exact verified stable-law witness; that is not needed for this
positive existence construction.

### Clipped expectation: eventual dominance — `eventual-clipped-expectation`

Model; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Sure-Thing (`sure-thing`)
- Scale Invariance (`scale-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)

Violates:

- Totality (`totality`)
- Expected Utility (`expected-utility`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Countable Sure-Thing (`countable-sure-thing`)
- Archimedean Gambles (`archimedean-gambles`)
- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)

Unknown in this model: Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`)

Construction.

Take all real-valued random variables and let c_t(x)=max(−t,min(x,t)). Define X≽Y iff ∃s∀t>s E[c_t(X)]≥E[c_t(Y)]. The full construction, verification, and explicit witnesses are in the accompanying write-up. This is the incomplete DU model from Decision theory unbound, Theorem 2; it fails the additional Totality axiom of DTU. It witnesses consistency of the unbounded framework and failure of full EU despite finite EU.

Executable checks: `topics/unbounded-utility/checks/countermodels.py`.

Notes. Clipping sends tails to ±t; it is not deletion of tail mass. No Shift Invariance claim is needed for this model.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, Theorem 2, pp. 683–685; Theorems 7 and 9, p. 693

Record: `topics/unbounded-utility/models/eventual-clipped-expectation.yaml`.

Write-up.

#### Clipped expectation: eventual dominance

Source: Goodsell, *Decision theory unbound*, Theorem 2, pp. 683–685;
Theorems 7 and 9, p. 693. Human model: Zachary Goodsell.
Recorded and translated by GPT-6 (Codex); no transcription checker asserted.

Take O=ℝ, all measurable random variables, and

$$c_t(x)=\max(-t,\min(x,t)),\qquad v_X(t)=\mathbb E[c_t(X)].$$

Define X≽Y iff there is s such that v_X(t)≥v_Y(t) for every t>s.

Reflexivity is immediate; transitivity follows by taking the larger of the
two thresholds. Equal-law variables have identical v-functions. Constants
have v_x(t)=x for all sufficiently large t. Hence Rich Outcomes holds,
and finite mixtures of constants have their usual expected utilities.
In particular Simple EU and Archimedean Outcomes hold.

For a randomized mixture, v_M(t)=p v_X(t)+(1-p)v_Z(t). Since p>0, comparison
with a common Z cancels, proving Independence. The recorded implication using
Stochastic Equivalence gives Sure-Thing.

For first-order dominance, use the tail-integral identity for clipped
expectations. The difference v_X(t)-v_Y(t) is the integral of the difference
of the upper-tail functions on [-t,t]. It is nonnegative. If one tail
inequality is strict, right continuity supplies an interval with positive
integral; all sufficiently large truncations therefore have a positive gap.
The preference is strictly better. This proves the weak and strict dominance
clauses, and the topic's Statewise Dominance consequence follows. Thus this
is a DU model. It is not a DTU model, since Totality fails as shown below.

Reflection gives v_(-X)(t)=-v_X(t). Positive rescaling gives
v_(aX)(t)=a v_X(t/a); eventual comparisons are unchanged by this
reparametrization. Thus reflection and scale invariance hold. No Shift
Invariance flag is needed or claimed here.

If X has symmetric law, every clipped expectation is zero by the oddness of
c_t. Thus X~0 in this model, verifying Symmetric Gambles Are Neutral even
though Totality fails.

##### Failure of Totality

Let A take (-2)^n with probability 2^(-n), n≥1. At t=2^k,

$$v_A(2^k)=\sum_{n=1}^k(-1)^n+
              2^k\sum_{n>k}(-1)^n2^{-n}
          =\begin{cases}-2/3&k\text{ odd},\\-1/3&k\text{ even}.\end{cases}$$

Consequently neither A≽-1/2 nor -1/2≽A holds: each comparison fails at
arbitrarily large truncation levels. This is an explicit incomparability,
not a conclusion drawn from failing to find a comparison.
It also directly violates the node Alternating St Petersburg = −1/2.

##### Failure of Expected Utility and L¹ Continuity

Let N take n with probability 2^(-n), n≥1. Then E[N]=2 but, for integer k≥1,

$$v_N(k)=\mathbb E[\min(N,k)]=2-2^{1-k}<2.$$

The same strict bound holds at every finite truncation level above 2.
Thus 2≻N and EU is false. For the continuity witness, put

$$N_k=\min(N,k)+2^{1-k}.$$

Each N_k is simple and has expectation 2, so N_k~2. Yet
E|N_k-N|≤2·2^(1-k)→0 and N is not at least as good as 2. This violates
exactly the recorded upper-section L¹ Continuity clause.

##### Failure of the two gamble-level principles

The recorded Countable Sure-Thing counterargument uses only Rich Outcomes,
Simple EU, and Sure-Thing, all verified above. It therefore applies to this
model. For Archimedean Gambles, S with P(S=2^n)=2^(-n) is better than every
constant: its truncations at 2^k have expectation k+1. For p>0,
M_p(S,0) likewise has unbounded truncated expectations. Hence S≻1≻0
but no such mixture is indifferent to 1.

`checks/countermodels.py` verifies representative exact witness calculations.
The universal statements above are analytic proofs, not conclusions from
finite sampling.

### Two-sample minimum: zero extension — `finite-two-sample-minimum`

Model; source **Misc.**; produced by GPT-6 (Codex); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Totality (`totality`)
- Restricted Totality (`restricted-totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)

Violates:

- Simple Expected Utility (`simple-eu`)
- Mixture Independence (`independence`)
- Stochastic Dominance (`stochastic-dominance`)
- Statewise Dominance (`statewise-dominance`)

Unknown in this model: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)

Construction.

Take all measurable real-valued random variables. When the law of X has finite support, put V(X)=E[min(X1,X2)] for independent copies X1,X2; for every other law put V(X)=0. Rank all gambles by their finite real scores V. This is a total law-invariant preorder with sure score V(x)=x. The raw outcome coordinate x differs from the normalized utility chart: the outcome at chart level r is x=r² for r>=0 and x=−r²/(1−2r) for r<0. This is a continuous increasing bijection of the real line, satisfying all three binary calibration clauses. Thus the chart is total, measurable and onto, and Archimedean Outcomes holds: a binary mixture of a>c has score c+(a−c)p², which reaches any intermediate b at p=sqrt((b−c)/(a−c)). Nevertheless the fair raw-outcome gamble {1,4} has score 7/4, below sure 9/4, although both have expected chart utility 3/2. The write-up also gives exact mixture-independence and dominance failures.

Executable checks: `topics/unbounded-utility/checks/finite_two_sample_minimum.py`.

Notes. Original work: elementary countermodel construction, calibration audit and explicit finite witnesses. This records the work performed for the project, without asserting literature novelty. Finite support refers to the probability law, so changes on null sets do not change the assigned score. The value-zero clause for all other laws makes the construction a total preorder on the full standing domain; its dominance failures are explicit. The example shows that Rich Outcomes and Archimedean Outcomes alone do not entail Simple EU, even after adding Totality and Stochastic Equivalence. Additional DU premises such as Mixture Independence remain essential to the separate representation argument. Other principle verdicts are left to recorded implications or future analysis. No independent checker or Lean verification is asserted.

Sources:

- **GPT-6 counterexample 9 Sep** — GPT-6 (Codex), Logical Maps project discussion, 9 September 2026: counterexample developed in response to the proposed Rich Outcomes plus Archimedean Outcomes implication to Simple Expected Utility; full construction and proofs in writeups/finite-two-sample-minimum.md.

Record: `topics/unbounded-utility/models/finite-two-sample-minimum.yaml`.

Write-up.

#### Two-sample minimum: zero extension

This model satisfies **Rich Outcomes, Archimedean Outcomes, Totality and
Stochastic Equivalence**, while violating Simple Expected Utility and Mixture
Independence. The distinction between the **raw outcome coordinate** and the
**normalized utility chart** is essential to the construction.

**Source and work accounting.** GPT-6 (Codex), Logical Maps project discussion,
9 September 2026. This is an elementary countermodel construction with an
explicit calibration audit and finite witnesses, recorded under Misc. The
work accounting concerns this project and makes no claim of literature
novelty. No independent checker or Lean verification is asserted.

##### The preference on the full domain

Take outcomes to be the real line with its usual Borel structure and order,
and take all measurable real-valued random variables on the standing atomless
probability space. Reference outcomes are the raw numbers 0 and 1.

For a finitely supported law

\[
\mu=\sum_{i=1}^n p_i\delta_{x_i},
\]

put

\[
V(\mu)=\sum_{i,j=1}^n p_i p_j\min(x_i,x_j).
\tag{1}
\]

This is the expected minimum of two independent draws from that law. For
every law that does **not** have finite support, put $V(\mu)=0$. Define

\[
X\succeq Y\quad\Longleftrightarrow\quad
V(\mathcal L(X))\ge V(\mathcal L(Y)).
\tag{2}
\]

Every score is a finite real number. Consequently (2) is reflexive,
transitive and total. It depends only on laws, proving Stochastic Equivalence.
It also proves Restricted Totality and Restricted Stochastic Equivalence.
Finite support is a property of the law: a variable with infinitely many
exceptional values on a null set receives the same score as its almost-sure
finite-valued representative.

A sure raw outcome $x$ has score $x$, so the sure preference order agrees
exactly with the ordinary order on the outcome space, as the framework requires.

##### Binary mixtures and Archimedean Outcomes

For raw outcomes $a>c$, a mixture with probability $p$ of $a$ has minimum

\[
\min(X_1,X_2)=a
\]

only when both independent draws give $a$, an event of probability $p^2$.
Thus

\[
V(M_p(a,c))=c+(a-c)p^2.
\tag{3}
\]

For any $a>b>c$, choose

\[
p=\sqrt{\frac{b-c}{a-c}}\in(0,1).
\]

Equation (3) gives $M_p(a,c)\sim b$, proving Archimedean Outcomes.

##### The actual normalized chart

The framework defines a chart level $r$ by binary comparisons with reference
outcomes 0 and 1. It does not identify that level with an arbitrary numerical
label on outcomes. In this model the raw outcome at chart level $r$ is

\[
f(r)=
\begin{cases}
r^2,&r\ge0,\\
-\dfrac{r^2}{1-2r},&r<0.
\end{cases}
\tag{4}
\]

All three branches of the chart definition can be checked directly:

- For $0\le r\le1$, equation (3) gives $V(M_r(1,0))=r^2=f(r)$.
- For $r>1$, it gives $V(M_{1/r}(f(r),0))=f(r)/r^2=1$.
- For $r<0$, put $p=-r/(1-r)\in(0,1)$. Then
  $V(M_p(1,f(r)))=f(r)+(1-f(r))p^2=0$.

These equations also determine the raw outcome uniquely. The first branch
requires a raw outcome between 0 and 1, the second one strictly above 1,
and the last one strictly below 0: a nontrivial binary-mixture score is
strictly between the scores of its distinct endpoints. Solving in the
respective ranges gives exactly (4).

The function $f$ is a continuous strictly increasing bijection of the real
line. On the negative half-line,

\[
f'(r)=\frac{2r(r-1)}{(1-2r)^2}>0;
\]

its limits at the ends of the real line are $-\infty$ and $+\infty$,
and its two formulas meet at zero. The normalized utility chart is therefore
the continuous inverse

\[
u(x)=f^{-1}(x)=
\begin{cases}
\sqrt{x},&x\ge0,\\
x-\sqrt{x^2-x},&x<0.
\end{cases}
\tag{5}
\]

The chart is single-valued, defined on every outcome, measurable and onto
the real line. In particular, **Rich Outcomes holds with precisely the
framework's calibration-based meaning**, including every negative level.

##### Simple Expected Utility fails

Let $X=M_{1/2}(4,1)$, with 4 and 1 still denoting raw outcomes, and let

\[
Y=\text{sure }9/4.
\]

Their normalized chart utilities satisfy

\[
E[u(X)]=\frac12\cdot2+\frac12\cdot1=\frac32
=u(9/4)=E[u(Y)].
\]

But their scores are

\[
V(X)=1+(4-1)\left(\frac12\right)^2=\frac74,
\qquad V(Y)=\frac94.
\]

Thus $Y\succ X$, contradicting the indifference required by Simple Expected
Utility. Another normalized chart cannot repair this discrepancy, because
the calibration computation established that (5) is the unique chart.

##### Mixture Independence fails

Put $L=M_{1/2}(4,0)$. Equation (3) gives $V(L)=1$, so $L\sim1$.
The law of $M_{1/2}(L,1)$ gives raw outcomes 0, 1 and 4 probabilities

\[
\frac14,\quad\frac12,\quad\frac14.
\]

For two independent draws from this law, the minimum is at least 1 with
probability $9/16$, and is 4 with probability $1/16$. Hence

\[
V(M_{1/2}(L,1))=\frac9{16}+3\frac1{16}=\frac34<1
=V(M_{1/2}(1,1)).
\]

The true comparison $L\succeq1$ becomes false after mixing both sides
equally with sure 1, violating Mixture Independence.

##### The explicit dominance failures

Let $U(\omega)=2+\omega$ on $[0,1]$ with Lebesgue measure. Its law is
uniform on $[2,3]$, so the second clause of the construction assigns

\[
V(U)=0<1=V(\text{sure }1).
\]

Nevertheless $U>1$ at every state. This disproves Statewise Dominance.
It also disproves Stochastic Dominance: the survival probability for $U$
is at least that of sure 1 at every threshold, and is strictly greater at
threshold 1. The preference ranks sure 1 strictly above $U$.

The model therefore witnesses that even Rich Outcomes, Archimedean Outcomes,
Totality and Stochastic Equivalence together do not imply Simple EU.
The separate DU representation argument must use its additional premises.

The accompanying exact-arithmetic diagnostic checks the displayed finite
scores and representative calibrations in all three chart ranges. The
analytic arguments above establish the universal claims.

### Clipped expectation: continuous ultrafilter dominance [−4ⁿ, 4ⁿ] — `geometric-continuous-ultrafilter`

Model; source **Misc.**; produced by Zachary Goodsell (continuous clipping construction); GPT-6 (Codex) (geometric-cutoff specialization and additional verifications); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- CDF-Area Extension (`cdf-area-extension`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Folded Expectation (`folded-expectation`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Shift Invariance (`shift-invariance`)

Violates:

- Scale Invariance (`scale-invariance`)
- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)

Unknown in this model: Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Pasadena = ln 2 (`pasadena-value`)

Construction.

Use real outcomes with identity utility, choose a free ultrafilter U on positive integers, and put v_X(n)=E[max(−4^n,min(X,4^n))]. Define X ≽ Y iff for every ε>0, {n:v_X(n)≥v_Y(n)−ε} belongs to U. This specializes Goodsell’s continuous clipped-expectation construction to geometric cutoffs. The write-up proves DTU, CDF-Area Extension, L¹ Continuity and Folded Expectation directly, with reflection and shift. For alternating St Petersburg A, v_A(n)=−1/3 and v_(2A)(n)=−4/3 for every n≥1, so A ≻ −1/2 while 2A ≺ −1. This verifies failure of Scale Invariance and the recorded alternating evaluation without relying on the printed scale witness. A and sure −1/2 both satisfy the same negative self-similarity equation, but have different values, so that uniqueness principle also fails.

Executable checks: `topics/unbounded-utility/checks/geometric_clipping.py`.

Notes. Original work: model adaptation and direct verification. Reuses Goodsell’s continuous ultrafilter ordering; the preference construction is not claimed as original. New work here chooses cutoffs 4^n to fix an exact alternating-game value, gives an explicit scaling reversal and nonunique self-similarity witness, and proves additional area/continuity/folded flags. This describes work performed in this project, not a claim of novelty in the literature. A free ultrafilter is nonconstructive; the numerical check verifies the finite formulas and estimates, not ultrafilter existence or all quantified axioms.

Sources:

- **Decision Theory Unbound** — Zachary Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, Appendix B, Definition 3, Lemma 6 and proof of Theorem 3, pp. 691–692; Theorems 7–10, pp. 693–695: underlying continuous clipping construction and original scale-failure strategy.
- **GPT-6 model adaptation 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/geometric-continuous-ultrafilter.md: geometric-cutoff specialization, explicit alternating-St-Petersburg witness, and additional CDF-area/L¹/folded-expectation verifications.

Record: `topics/unbounded-utility/models/geometric-continuous-ultrafilter.yaml`.

Write-up.

#### Clipped expectation: continuous ultrafilter dominance [−4ⁿ, 4ⁿ]

Source: **Misc.** Construction by Zachary Goodsell; specialization and the additional
proofs below by GPT-6 (Codex), 9 September 2026. No independent checker or Lean
verification is asserted.

**Original work: model adaptation and direct verification.** We reuse the continuous
ultrafilter construction from *Decision theory unbound*, Appendix B, Definition 3,
Lemma 6 and Theorem 3. Choosing geometric cutoffs supplies an explicit alternating-game
evaluation and scaling reversal. The CDF-area, L¹ and folded-expectation verifications
below establish extra properties of this construction. This is an account of work
done for the map, not a claim that these observations are new in the literature.

##### Construction and DTU

Outcomes are real utilities; all measurable random variables on the standing sample
space are available. Choose a free ultrafilter \(\mathcal U\) on the positive integers.
Put \(t_n=4^n\), \(c_t(x)=\max(-t,\min(x,t))\), and

\[
v_X(n)=E[c_{t_n}(X)],\qquad
X\succeq Y\iff
\forall\varepsilon>0\quad
\{n:v_X(n)-v_Y(n)\ge-\varepsilon\}\in\mathcal U.
\]

Changing a comparison sequence by a sequence tending to zero leaves this relation
unchanged. A positive lower bound on an ultrafilter-large set gives strict preference.
If a difference converges to a finite number, its comparison is exactly the sign of
that number, including indifference at zero.

Reflexivity is immediate. For transitivity, intersect the two sets corresponding
to tolerance \(\varepsilon/2\). If \(X\not\succeq Y\), ultrafilter dichotomy gives
an \(\varepsilon>0\) and an ultrafilter-large set where
\(v_Y-v_X>\varepsilon\). Thus \(Y\succ X\), establishing totality.
These statements use addition and positive scalar multiplication of comparison
sequences; no multiplication of arbitrary unbounded quotient classes is needed.

Equal laws have identical clipped expectations. For bounded, hence simple, variables
clipping eventually disappears; their comparisons are ordinary expectations. In
particular the normalized chart is the identity and every real utility is realized.
Randomized mixtures satisfy
\(v_{M_p(X,Z)}=p v_X+(1-p)v_Z\), so cancelling the common term and rescaling
\(\varepsilon\) proves both directions of Mixture Independence.

For survival functions \(S_X\), bounded layer integration gives

\[
v_X(n)-v_Y(n)=\int_{-t_n}^{t_n}(S_X(s)-S_Y(s))\,ds.
\]

Stochastic dominance makes the integrand nonnegative. If it is strictly positive
at one threshold, right-continuity gives a positive integral over some bounded
interval. Every sufficiently large cutoff therefore has a fixed positive gap.
This proves strict as well as weak Stochastic Dominance, and finishes DTU.

##### Additional expectation and continuity properties

Write \(d=S_X-S_Y\) and \(A_\pm=\int d_\pm\). If at least one of these areas is
finite, monotone convergence of the positive and negative parts over
\([-t_n,t_n]\) shows that the clipped difference tends to the well-defined extended
difference \(A_+-A_-\). The preceding sign criterion proves **CDF-Area Extension**,
including the equality case and both possible infinite signs. Consequently the
recorded CDF-area implications give Relative Expectation and Expected Utility.

For **L¹ Continuity**, clipping is 1-Lipschitz, so for every cutoff

\[
|v_{X_k}(n)-v_X(n)|\le E|X_k-X|.
\]

If this last quantity tends to zero and every \(X_k\succeq Y\), fix
\(\varepsilon>0\) and choose one \(k\) with error below \(\varepsilon/2\).
On the ultrafilter-large set where \(v_{X_k}-v_Y\ge-\varepsilon/2\), we have
\(v_X-v_Y\ge-\varepsilon\). This is exactly the required upper-section closure.
It also applies when other distances in the domain are infinite.

For **Folded Expectation**, put
\(h_X(s)=P(X>s)-P(X<-s)\). Layer integration gives
\(v_X(n)=\int_0^{t_n}h_X(s)\,ds\); boundary atoms change no integral.
If \(h_X,h_Y\) are absolutely integrable, these converge to their folded
expectations. Their finite difference is therefore compared by its sign.

Reflection negates every clipped expectation, proving **Reflection Anti-Invariance**.
For a real constant \(b\),
\(c_t(X+b)-c_t(X)\to b\) pointwise with absolute value at most \(|b|\).
Dominated convergence shows that shifting both compared variables changes the
clipped difference by a sequence tending to zero. This proves **Shift Invariance**.
No individual integrability of the variables is required.

##### Explicit failures of scale, alternating evaluation and uniqueness

Let \(A\) have \(P(A=(-2)^j)=2^{-j}\), \(j\ge1\). For
\(2^k\le t\le2^{k+1}\), summing the finite prefix and the geometric tail gives

\[
E[c_t(A)]
=\sum_{j=1}^k(-1)^j+
  \frac{(-1)^{k+1}t}{3\,2^k}.
\]

At \(t_n=4^n\), this equals \(-1/3\), whereas
\(E[c_{t_n}(2A)]=2E[c_{t_n/2}(A)]=-4/3\). Hence

\[
A\sim-1/3\succ-1/2,
\qquad 2A\sim-4/3\prec-1.
\]

This is a concrete scaling reversal in every free-ultrafilter choice used here.
It also directly violates the recorded Alternating St Petersburg Value principle.

The law of \(A\) is the half-mixture of \(-2A\) and sure \(-2\): the sure
branch supplies the first atom and the other branch supplies all subsequent atoms.
Stochastic Equivalence gives
\(A\sim M_{1/2}(-2A,-2)\). The sure gamble \(q=-1/2\) satisfies the same
fixed-value equation by Simple EU, since
\(\frac12(-2q)+\frac12(-2)=q\). Nevertheless \(A\not\sim q\).
With \(p=1/2,a=2,b=0,Z=-2\), these are two witnesses refuting **Uniqueness of
Negative Self-Similarity**.

##### Scope and validation

The model satisfies DTU together with CDF-Area Extension, L¹ Continuity, Folded
Expectation, reflection and shift, yet fails scale and the two calculation/evaluation
principles just exhibited. Further exclusions are derived by the map's implication
records, not asserted without evidence. The free ultrafilter remains nonconstructive.

`checks/geometric_clipping.py` checks the geometric-tail calculation against a
separate finite-sum calculation with a rigorous residual bound, the scaling reversal,
and the finite Lipschitz estimate. Those checks are diagnostics; the quantified
claims rely on the proofs above.

##### References

- Zachary Goodsell, *Decision theory unbound*, Noûs 58 (2024), 669–695,
  DOI 10.1111/nous.12473, Appendix B, pp. 691–695. Original construction and
  scale-failure strategy; the explicit witness above is a separate verification.
- GPT-6 (Codex), project research on 9 September 2026: this specialization,
  additional property proofs and explicit witnesses.

### Folded-tail cone: lexicographic extension — `lexicographic-folded-extension`

Model; source **Misc.**; produced by GPT-6 (Codex) (folded-tail quotient and infinitesimal separation), adapting Zachary Goodsell's area-cone and total-extension methods; recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- CDF-Area Extension (`cdf-area-extension`)
- Relative Expectation (`relative-expectation`)
- Folded Expectation (`folded-expectation`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Shift Invariance (`shift-invariance`)

Violates:

- L¹ Continuity (random variables) (`l1-continuity`)
- Scale Invariance (`scale-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)

Unknown in this model: Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Pasadena = ln 2 (`pasadena-value`)

Construction.

Take all real-valued random variables. In the vector space spanned by their folded-tail profiles h_X(t)=P(X>t)−P(X<−t), t>0, quotient out every integrable profile of integral zero. The base positive cone consists of profiles with integrable negative part and nonnegative finite or positive-infinite integral. Put e=[h_1], q=−1/2, and f=[h_A−h_q] for the alternating St Petersburg gamble A. Both sign areas of h_A−h_q are infinite, so this cone meets span(e,f) only in the nonnegative e ray. Add the lexicographic cone a e+b f>0 iff a>0 or a=0,b>0, then extend the resulting pointed cone to a total pointed cone by Zorn's lemma. Define X≽Y by membership of [h_X−h_Y]. The write-up verifies every satisfied axiom. In particular q≺A≺q+ε for every ε>0. Hence constants q+1/n converge in L¹ to q and all exceed A, while q does not weakly exceed A; the recorded upper-section L¹ Continuity fails. The distributional recursion of A gives a scaling reversal and nonunique negative self-similarity. The total extension is an existence construction, not an algorithm.

Executable checks: `topics/unbounded-utility/checks/lexicographic_folded_extension.py`.

Notes. Original work: substantial model adaptation and separation. Goodsell supplies the area-order idea, folded-tail evaluations, alternating-game recursion and use of total cone extensions. Work here passes to folded profiles modulo zero-integral L1 profiles, inserts an infinitesimal lexicographic comparison, proves that the two cones remain compatible, and gives an explicit upper-section continuity counterexample. This establishes DTU + Folded Expectation (even with Relative Expectation, reflection, shift and CDF-Area Extension) does not imply L1 Continuity. It does not contradict the source equivalence under full affine symmetry: Scale Invariance fails in this model. This is work accounting, not a claim of literature priority. The executable diagnostic checks exact dyadic tails and finite lexicographic witnesses; it does not execute the nonconstructive extension or certify the quantified axioms.

Sources:

- **GPT-6 model adaptation 9 Sep** — GPT-6 (Codex), original model adaptation and separation in Logical Maps, 9 September 2026; writeups/lexicographic-folded-extension.md.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Folded Expectation and its tail representation, pp. 27–29; alternating St Petersburg and negative self-similarity, pp. 29–31; cone-extension framework, §5, pp. 33–37.
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §3, pp. 7–8, the base area preorder. Its withdrawn symmetric-extension theorem is not used.

Record: `topics/unbounded-utility/models/lexicographic-folded-extension.yaml`.

Write-up.

#### Folded-tail cone: lexicographic extension

**Result.** There exists a model of DTU + Folded Expectation + Relative Expectation
+ CDF-Area Extension + Reflection Anti-Invariance + Shift Invariance which fails
L¹ Continuity. Scale Invariance, the alternating St Petersburg evaluation and
Uniqueness of Negative Self-Similarity fail too.

The construction assigns the alternating gamble a value *infinitesimally above*
$-1/2$: it is strictly better than $-1/2$ but strictly worse than $-1/2+\varepsilon$
for every real $\varepsilon>0$. The word "infinitesimal" describes comparisons
in an ordered vector space; no hyperreal field is assumed.

##### 1. Folded profiles and the base cone

Use all real-valued random variables on the standing sample space, with identity
utility. For each $X$ define its folded-tail profile on $(0,\infty)$ by

$$h_X(t)=\Pr(X>t)-\Pr(X<-t).$$

Let $W$ be the real vector space spanned by these profiles, identifying functions
that agree Lebesgue-almost everywhere. Define the linear subspace

$$N=\left\{g\in W\cap L^1(0,\infty):\int_0^\infty g(t)\,dt=0\right\},
\qquad V=W/N.$$

This quotient is part of the model's construction, not a change to the topic's
standing random-variable objects. Preferences will still be defined on every
actual random variable.

In $W$ put

$$C=\left\{g:\int g_-<\infty,\quad \int g_+\ge\int g_-\right\}.$$

Here either sign area may initially be infinite; membership requires a finite
negative area. Thus the signed integral is well-defined and nonnegative, with
$+\infty$ allowed. Addition and nonnegative scalar multiplication make $C$ a
convex cone. The inequality $(g+k)_-\le g_-+k_-$ and additivity of the
one-sided signed integral prove addition closure. Moreover

$$C\cap(-C)=N,\qquad C+N=C.$$

Indeed membership in both signs makes both areas finite and equal; adding an
integrable zero-integral profile preserves integrability of the negative part
and the integral. Consequently the image $K=C/N$ is a **pointed** convex cone
in $V$: $K\cap(-K)=\{0\}$.

Write $e=[h_1]$. Since $h_1=\mathbf1_{(0,1)}$ a.e., its integral is one and
$e\ne0$. Every integrable profile $g$ has

$$[g]=\left(\int g\right)e. \tag{1}$$

This identity will enforce both ordinary and folded expected-value comparisons
in every pointed cone extending $K$.

##### 2. An oscillating profile and a compatible lexicographic plane

Let $A$ be the alternating St Petersburg gamble

$$\Pr(A=(-2)^j)=2^{-j},\qquad j\ge1,$$

and let $q=-1/2$ be a sure outcome. Define $f=[h_A-h_q]$.
For every integer $k\ge1$ and every $t\in(2^k,2^{k+1})$, direct summation of
the geometric tail gives

$$h_A(t)=\sum_{j=k+1}^\infty(-1)^j2^{-j}
=\frac{(-1)^{k+1}}{3\,2^k}. \tag{2}$$

As $h_q(t)=0$ for $t>1/2$, each interval $(2^k,2^{k+1})$ contributes exactly
$1/3$ to the absolute area of $h_A-h_q$, with sign alternating between
positive and negative intervals. Thus **both sign areas are infinite**.
Adding any integrable function cannot change that fact, for either nonzero
scalar multiple of this profile.

It follows that $e,f$ are linearly independent in $V$, and that

$$K\cap\operatorname{span}\{e,f\}=\{a e:a\ge0\}. \tag{3}$$

To check (3), a representative of $ae+bf$ is
$a h_1+b(h_A-h_q)+n$ with $n\in N$. If $b\ne0$, both sign areas remain
infinite, so it is not in $C$. If $b=0$, the profile is integrable with integral
$a$, so membership is equivalent to $a\ge0$.

On this plane define the lexicographic cone

$$D=\{ae+bf:a>0\}\;\cup\;\{bf:b\ge0\}.$$

This is a pointed convex cone, and

$$0<_D f<_D\varepsilon e\qquad\text{for every }\varepsilon>0. \tag{4}$$

The sum $K+D$ is also pointed. If $k_1+d_1=-(k_2+d_2)$ with $k_i\in K$
and $d_i\in D$, then

$$k_1+k_2=-(d_1+d_2)\in K\cap\operatorname{span}\{e,f\}.$$

By (3) the left side is $ae$ for $a\ge0$, while $-ae\in D$ forces $a=0$.
Pointedness of the two original cones now gives $k_1=k_2=d_1=d_2=0$.
Thus adjoining (4) does not collapse any strictly positive comparison in $K$.

##### 3. Total extension

Partially order by inclusion the pointed convex cones containing $K+D$.
The union of a chain is still pointed and convex: each forbidden pair or
finite closure operation would already occur in one member of the chain.
Zorn's lemma therefore gives a maximal such cone $T$.

It is total: $T\cup(-T)=V$. Otherwise choose $v$ with neither $v$ nor $-v$
in $T$. Then $T+\mathbb R_{\ge0}v$ remains pointed. Indeed a vector and its
negative in this new cone would give

$$0=t_1+t_2+(a+b)v,\qquad t_1,t_2\in T,\quad a,b\ge0.$$

If $a+b>0$, this puts $-v$ in $T$, a contradiction; if $a+b=0$, pointedness
of $T$ forces both terms to be zero. This would properly enlarge $T$, also
a contradiction. Every nonzero element of $K+D$ stays strictly positive
because a pointed extension cannot also contain its negative.

Define preferences by

$$X\succeq Y\quad\Longleftrightarrow\quad[h_X-h_Y]\in T. \tag{5}$$

The total cone is an existence construction; no comparison algorithm for
arbitrary profiles is claimed.

##### 4. Verification of the satisfied principles

**Preordering, Totality and Stochastic Equivalence.** Cone addition gives
transitivity, zero gives reflexivity, and totality of $T$ compares every pair.
Equal laws give identical profiles, so they are indifferent.

**Rich Outcomes and Simple EU.** All reals are outcomes. Simple variables have
integrable folded profiles whose integrals are their ordinary expectations.
Equation (1) compares them exactly by those expectations, including sure
outcomes and all calibrating binary lotteries. Hence the normalized utility
chart is the identity, and every real utility level is realized.

**Mixture Independence.** Probability-mixture linearity gives

$$h_{M_p(X,Z)}-h_{M_p(Y,Z)}=p(h_X-h_Y).$$

For $p>0$, cone membership is unchanged by this multiplication in either
direction, proving the full biconditional.

**Weak and strict Stochastic Dominance.** Put $d=S_X-S_Y$. Except at atom
thresholds,

$$h_X(t)-h_Y(t)=d(t)+d(-t)\qquad(t>0). \tag{6}$$

If $d\ge0$, the profile in (6) is nonnegative and belongs to $C$. If dominance
is strict at some threshold, right-continuity of survival functions supplies
a bounded interval of positive area. Thus (6) has strictly positive finite
or infinite integral. Its class is a nonzero member of $K$, so the comparison
is strict in $T$ too.

**CDF-Area Extension.** Suppose first that $\int_{\mathbb R}d_-<\infty$.
By (6),

$$\int_0^\infty(h_X-h_Y)_-
\le\int_{\mathbb R}d_-<\infty.$$

Change of variables in the well-defined one-sided integral gives

$$\int_0^\infty(h_X-h_Y)=\int_{\mathbb R}d,$$

including $+\infty$. If the latter is positive the class is strictly positive
in $K$; if zero it vanishes in $V$; if negative it is strictly negative.
When only $\int d_+$ is finite, apply the same reasoning to $-d$. These
are exactly all comparisons required by CDF-Area Extension, with strictness
and equality preserved. Both-infinite pairs remain unrestricted by that axiom.

**Relative Expectation.** If the actual difference $X-Y$ is integrable,
the indicator and Fubini formulas give $d\in L^1(\mathbb R)$ and
$\int d=\mathbb E(X-Y)$. Equations (1) and (6) therefore give exactly the
required sign comparison.

**Folded Expectation.** If $h_X,h_Y$ are both integrable, equation (1) gives
$[h_X-h_Y]=(F(X)-F(Y))e$. Definition (5) compares them exactly by their
folded expectations.

**Reflection Anti-Invariance.** The exact identity $h_{-X}=-h_X$ gives
$h_{-Y}-h_{-X}=h_X-h_Y$. Thus reversing and reflecting a comparison leaves
its class unchanged.

**Shift Invariance.** For every real $b$, the pointwise difference
$(X+b)-X=b$ is integrable. The Relative Expectation computation above gives

$$[h_{X+b}-h_X]=be.$$

Consequently shifting both compared variables leaves their difference class
unchanged. This argument requires no individual integrability of $X$ or $Y$.

##### 5. Explicit failures

By (1), $[h_q]=qe$, and by definition $[h_A]=qe+f$. Equations (4) and (5)
therefore give

$$q\prec A\prec q+\varepsilon\qquad(\varepsilon>0). \tag{7}$$

For **failure of the recorded upper-section L¹ Continuity**, take
$X_n=q+1/n$, $X=q$, and $Y=A$. Their actual-coupling distances satisfy
$\mathbb E|X_n-X|=1/n\to0$, and every $X_n\succeq Y$, but $X\not\succeq Y$.
No lower-section continuity is assumed or needed for this witness.

For the **scaling reversal**, use the law identity

$$A\overset d=M_{1/2}(-2A,-2).$$

It gives $[h_A]=-[h_{2A}]/2-e$, hence

$$[h_{2A}]=-e-2f.$$

Thus $A\succ-1/2$, while $2A\prec-1$. Scale Invariance fails at scale two.
The first of these inequalities also directly refutes the specified alternating
St Petersburg value.

For **failure of Uniqueness of Negative Self-Similarity**, both $A$ and sure
$q=-1/2$ satisfy $X\sim M_{1/2}(-2X,-2)$. For $A$ this follows from the
law recursion and Stochastic Equivalence; for $q$ it is Simple EU. Yet (7)
says $A\not\sim q$.

##### Attribution, original work and limits

**Original work: substantial model adaptation and separation.** Zachary
Goodsell supplies the base area-preorder idea, the folded-tail evaluation
principle, the alternating-gamble recursion and the use of total cone
extensions. The present model changes the ordered space to folded profiles
modulo all zero-integral L¹ profiles, adds the compatible infinitesimal plane,
and proves the explicit continuity separation. Its direct source is **Misc.**,
with GPT-6 (Codex) credited for that adaptation. This is an account of work
performed for the map, not a claim of literature priority.

The construction does **not** contradict *Symmetries of value*, Corollary 5:
that result assumes full affine symmetry, including Scale Invariance, which
fails here. The source's unpublished erroneous symmetric-extension theorem
is not invoked. The extension step in §3 is proved directly and imposes no
additional convolution or scaling invariance.

The diagnostic `checks/lexicographic_folded_extension.py` checks the exact
dyadic tail formula, the repeated positive/negative area contributions,
lexicographic witness inequalities and the distributional recursion. It does
not simulate Zorn's lemma or certify arbitrary infinite-dimensional claims.
No independent checker or Lean proof is claimed.

**References.** Zachary Goodsell, *Symmetries of value*, pp. 27–31 and §5,
pp. 33–37; *Unbounded Utility and Background Risk*, unpublished manuscript,
§3, pp. 7–8 (the base area preorder only). Model adaptation and proofs:
GPT-6 (Codex), 9 September 2026.

### Clipped expectation: continuous ultrafilter dominance [−4ⁿ, 4²ⁿ] — `polynomial-asymmetric-continuous-ultrafilter`

Model; source **Misc.**; produced by Zachary Goodsell (asymmetric continuous clipping construction); GPT-6 (Codex) (cutoff specialization and evaluation calculations); recorded by GPT-6 (Codex), 2026-09-09; checked by nobody; 2026-09-09.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- CDF-Area Extension (`cdf-area-extension`)
- Relative Expectation (`relative-expectation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)

Violates:

- Pasadena = ln 2 (`pasadena-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)

Unknown in this model: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Positive Affine Invariance (`positive-affine-invariance`), Scale Invariance (`scale-invariance`)

Construction.

Let q_n(x)=max(-4^n,min(x,4^(2n))) and choose a free ultrafilter U on the positive integers. Define X>=Y iff for every epsilon>0 the set {n:E[q_n(X)]-E[q_n(Y)]>=-epsilon} belongs to U. This is Goodsell's continuous asymmetric clipping construction with unequal polynomial growth of the two cutoffs. Its linear clipped expectations, increasing cutoff intervals, and uniform Lipschitz bound give DTU, CDF-Area Extension, Relative Expectation, L1 Continuity, and the shift properties. Pasadena's clipped expectations converge to (3/2) ln 2; hence P~(3/2) ln 2, strictly above the recorded value ln 2. Arroyo's clipped expectations equal (n+1) ln 2+o(1) and diverge to positive infinity, so Arroyo is strictly above every sure outcome. A symmetric Cauchy variable also has clipped expectations tending to positive infinity, refuting Symmetric Neutrality. These are quantified asymptotic conclusions, not finite-cutoff approximations used as values.

Executable checks: `topics/unbounded-utility/checks/calculation_factorizations.py`.

Notes. Original work: model specialization with moderate evaluation calculations. The asymmetric clipping method and its strong expectation/continuity compatibility with failure of reflection are already Goodsell's. This entry selects upper cutoff equal to the square of the lower cutoff and computes its different Pasadena value and unbounded Arroyo value. The general construction is not a new AI invention. No independent checker or Lean certification is asserted. The free ultrafilter remains nonconstructive; the diagnostic checks finite formulas and convergence estimates rather than ultrafilter existence.

Sources:

- **GPT-6 cutoff calculations 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/polynomial-asymmetric-continuous-ultrafilter.md: cutoff specialization, Pasadena/Arroyo evaluations, and explicit verification of the inherited axioms.
- **Decision Theory Unbound** — Zachary Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695, DOI 10.1111/nous.12473, Appendix B, Definition 3, Lemma 6, Remark 3 and Corollary 3, pp. 691–693: continuous clipped-expectation quotient and separate cutoff functions.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37, DOI 10.1111/nous.12549, Theorem 1, p. 24: asymmetric source model and failure of reflection even with DTU, L1 Continuity and Relative Expectation; pp. 28–33 for the named prospects.

Record: `topics/unbounded-utility/models/polynomial-asymmetric-continuous-ultrafilter.yaml`.

Write-up.

#### Clipped expectation: continuous ultrafilter dominance [−4ⁿ, 4²ⁿ]

**Source and work accounting.** This uses Zachary Goodsell's asymmetric
continuous clipping construction from *Decision theory unbound*, Appendix B,
Definition 3, Lemma 6, Remark 3 and Corollary 3, pp. 691–693. Its compatibility
with DTU, Relative Expectation and L¹ Continuity while failing reflection is
already recorded in *Symmetries of value*, Theorem 1, p. 24. The work supplied
by GPT-6 (Codex), 9 September 2026, is the cutoff choice and the explicit
Pasadena/Arroyo evaluations below, with verification of inherited properties.
This is a model specialization, not a new invention of asymmetric clipping
or a claim of priority in the literature. No independent checker or Lean
certification is asserted.

##### 1. The source construction with upper cutoff equal to the square of the lower

Use all real-valued random variables on the standing sample space. Let

\[
L_n=4^n,\quad U_n=4^{2n},\quad
q_n(x)=\max(-L_n,\min(x,U_n)),\quad v_X(n)=E[q_n(X)].
\]

Choose a free ultrafilter \(\mathcal U\) on the positive integers and set

\[
X\succeq Y\quad\Longleftrightarrow\quad
\forall\varepsilon>0\ \{n:v_X(n)-v_Y(n)\ge-\varepsilon\}\in\mathcal U.
\tag{1}
\]

A comparison difference converging to a finite number is ranked by its sign,
with indifference at zero. If \(v_X(n)\to+\infty\), then \(X\) is strictly
better than every sure real outcome; this does not assign a real certainty
equivalent to \(X\).

Reflexivity follows directly from (1). To prove transitivity, intersect the
two ultrafilter-large comparison sets for tolerance \(\varepsilon/2\).
If \(X\not\succeq Y\), some positive tolerance is violated on an
ultrafilter-large set, making \(Y\succ X\). Thus the relation is total.
Changing any comparison sequence by an ordinary sequence tending to zero
does not affect it.

The clipped expectations depend only on laws. Bounded, in particular simple,
variables are eventually unchanged by clipping, so the utility chart is the
identity and simple gambles have ordinary expected utility comparisons.
All real sure outcomes are available. Moreover,

\[
v_{M_p(X,Z)}=p v_X+(1-p)v_Z,
\]

so cancellation and rescaling tolerances prove both directions of Mixture
Independence. These facts establish all DTU clauses except dominance.

For survival functions \(S_X\), bounded layer integration gives

\[
v_X(n)-v_Y(n)=\int_{-L_n}^{U_n}(S_X(t)-S_Y(t))\,dt. \tag{2}
\]

Dominance makes this integrand nonnegative. If it is positive at one threshold,
right-continuity makes its integral positive on some bounded interval. Once
that interval is inside the cutoffs, there is a fixed positive comparison gap.
This establishes weak and strict Stochastic Dominance and completes DTU.

##### 2. The stronger expectation, continuity and shift properties

The intervals in (2) increase to all of \(\mathbb R\). If at least one
of the positive and negative areas of \(S_X-S_Y\) is finite, monotone
convergence of the two nonnegative areas makes the clipped differences tend
to their well-defined extended difference. Equation (1) therefore gives
exactly **CDF-Area Extension**, including strict infinite-area cases and
the zero case.

For any actually coupled \(X,Y\), clipping is 1-Lipschitz and tends
pointwise to the identity. If \(E|X-Y|<\infty\), then

\[
|q_n(X)-q_n(Y)|\le|X-Y|,
\qquad v_X(n)-v_Y(n)\longrightarrow E[X-Y].
\]

Dominated convergence and (1) prove **Relative Expectation** directly.
Likewise, if \(E|X_k-X|\to0\), then for every cutoff

\[
|v_{X_k}(n)-v_X(n)|\le E|X_k-X|.
\]

If every \(X_k\succeq Y\), choose one \(k\) with this error below
\(\varepsilon/2\), and use its ultrafilter-large comparison set with
tolerance \(\varepsilon/2\). This proves \(X\succeq Y\) and hence
the recorded upper-section **L¹ Continuity**.

For any constant \(b\), dominated convergence applied to
\(q_n(X+b)-q_n(X)\) gives limit \(b\), since this difference is bounded
in absolute value by \(|b|\). The two shifts cancel in a comparison,
proving **Shift Invariance**. The fixed-lift variables in **Shift Transfer**
have integrable difference \(b/p\) on a set of probability \(p\) and
\(-b/(1-p)\) on its complement; its mean is zero. Relative Expectation
proves their indifference.

##### 3. Pasadena has value \((3/2)\ln2\)

For Pasadena \(P\), separate its odd and even indices:

\[
\begin{array}{c|c|c}
 &\text{payoff}&\text{probability}\\\hline
\text{positive branch }k&4^k/[2(2k-1)]&2/4^k\\
\text{negative branch }k&-4^k/(2k)&1/4^k
\end{array}
\]

Let \(K_+(n)\) be the largest positive index whose payoff does not exceed
\(U_n\), and \(K_-(n)\) the largest negative index whose magnitude does
not exceed \(L_n\). The defining inequalities show

\[
K_+(n)=2n+O(\log n),\qquad K_-(n)=n+O(\log n).
\tag{3}
\]

For example, take logarithms of
\(4^{K_+}/[2(2K_+-1)]\le4^{2n}<4^{K_++1}/[2(2K_++1)]\);
the corresponding negative-branch inequalities work identically.

Summing the clipped geometric tails exactly yields

\[
v_P(n)=
\sum_{k=1}^{K_+(n)}\frac1{2k-1}
-\sum_{k=1}^{K_-(n)}\frac1{2k}
+\frac{2U_n}{3\,4^{K_+(n)}}
-\frac{L_n}{3\,4^{K_-(n)}}. \tag{4}
\]

The two clipped-tail terms tend to zero: the next positive-payoff inequality
bounds the positive term by \(4/[3(2K_++1)]\), and the next negative-payoff
inequality bounds the negative term's magnitude by \(2/[3(K_-+1)]\).
Writing \(H_j=\sum_{k=1}^j1/k=\log j+\gamma+o(1)\), the finite part
of (4) is

\[
H_{2K_+}-\tfrac12H_{K_+}-\tfrac12H_{K_-}
=\ln2+\tfrac12\log(K_+/K_-)+o(1).
\]

By (3), the ratio tends to two. Thus

\[
v_P(n)\longrightarrow\frac32\ln2,
\qquad P\sim\frac32\ln2\succ\ln2.
\]

This disproves the recorded Pasadena evaluation in this model. The argument
uses convergent clipped expectations, not an ordinary expectation of Pasadena.

##### 4. Arroyo lies strictly above every sure outcome

For Arroyo \(A\), the positive branch indexed by \(k\) has payoff
\(2k\) and probability \(1/[(2k-1)2k]\). The negative branch has payoff
\(-(2k+1)\) and probability \(1/[2k(2k+1)]\).
The last unclipped indices are

\[
J_+=U_n/2,\qquad J_-=L_n/2-1.
\]

Its clipped expectation is exactly

\[
\sum_{k=1}^{J_+}\frac1{2k-1}
-\sum_{k=1}^{J_-}\frac1{2k}
+U_n\sum_{k>J_+}\frac1{(2k-1)2k}
-L_n\sum_{k>J_-}\frac1{2k(2k+1)}. \tag{5}
\]

Each probability-tail summand is asymptotic to \(1/(4k^2)\), and the
corresponding tail sum is asymptotic to \(1/(4J)\), by comparison with
the integral of \(k^{-2}\). Each of the last two magnitudes in (5)
therefore tends to \(1/2\), so their difference tends to zero. The harmonic
prefix has asymptotic value

\[
\ln2+\tfrac12\log(J_+/J_-)+o(1)
=\ln2+\tfrac12\log(U_n/L_n)+o(1)
=(n+1)\ln2+o(1).
\]

Consequently \(v_A(n)\to+\infty\). In (1), this yields
\(A\succ c\) for every real sure outcome \(c\), and in particular
\(A\not\sim\ln2\). Although Arroyo's folded expectation is \(\ln2\),
this model does not obey Folded Expectation.

##### 5. A symmetric-neutrality witness

Let \(C\) have the standard symmetric Cauchy law. Symmetry cancels its
clipped tails up to \(L_n\), leaving

\[
v_C(n)=\int_{L_n}^{U_n}\left(\frac12-\frac{\arctan t}{\pi}\right)dt
=\frac1\pi\log(U_n/L_n)+o(1)
=\frac{n\log4}{\pi}+o(1).
\]

The asymptotic follows from the integrand
\(1/(\pi t)+O(t^{-3})\); its integrated error tends to zero. Thus the
symmetric gamble \(C\) is strictly above every sure outcome, and Symmetric
Neutrality fails. This mechanism belongs to Goodsell's general asymmetric
construction; only these chosen cutoff rates and calculations are additions here.

##### Scope and diagnostics

The model satisfies DTU, Relative Expectation, L¹ Continuity, CDF-Area Extension,
and the shift properties, yet fails both named game evaluations. Its failure
of Negative Self-Similarity follows from the new Pasadena implication; further
exclusions are left to the map's inference engine rather than separately
asserted without evidence. No Scale Invariance or sum-invariance verdict is
claimed here.

`checks/calculation_factorizations.py` verifies the exact Pasadena clipping
formula against direct finite atom sums with bounded remainders, tests the
displayed cutoff asymptotic, and checks finite Arroyo sums. It also verifies
the exact coupling identities in the accompanying Pasadena proof. These are
diagnostics supporting quantified arguments, not simulations of a free
ultrafilter or proofs of all universal axioms.

### Clipped expectation: continuous ultrafilter dominance — `total-continuous-ultrafilter`

Model; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Expected Utility (`expected-utility`)
- Shift Invariance (`shift-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)

Violates:

- Scale Invariance (`scale-invariance`)
- Countable Sure-Thing (`countable-sure-thing`)
- Archimedean Gambles (`archimedean-gambles`)

Unknown in this model: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Folded Expectation (`folded-expectation`), Independent Sum Cancellation (`independent-sum-cancellation`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Relative Expectation (`relative-expectation`)

Construction.

Take all real-valued random variables and a cobounded ultrafilter U. Define X≽Y iff for every ε>0, {t:E[c_t(X)]≥E[c_t(Y)]−ε}∈U. This is the continuous-hyperreal quotient ordering in the proof of Theorem 3. Its EU, shift, reflection, and failed scale claims are given in Appendix B; see the accompanying write-up. Consequently Expected Utility does not imply Positive Affine Invariance, even with DTU.

Notes. No L¹ Continuity or Relative Expectation flag is inferred merely from the word continuous; these are distinct claims. Scale failure is source-attributed as above.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, Appendix B, Lemma 6 and proof of Theorem 3, p. 691; Theorems 7, 8 and 10, pp. 693–695

Record: `topics/unbounded-utility/models/total-continuous-ultrafilter.yaml`.

Write-up.

#### Clipped expectation: continuous ultrafilter dominance

Source: Goodsell, *Decision theory unbound*, Appendix B, Lemma 6 and proof
of Theorem 3 (p. 691), Theorems 7, 8, and 10 (pp. 693–695).
Human model: Zachary Goodsell. Recorded and translated by GPT-6 (Codex);
no transcription checker asserted.

With U and v_X as in the exact-ultrafilter model, define

$$X\succeq Y\quad\Longleftrightarrow\quad
\text{for every }\varepsilon>0,
\{t:v_X(t)\ge v_Y(t)-\varepsilon\}\in\mathcal U.$$

This quotients out infinitesimal errors in the ultrafilter comparison.
Reflexivity and transitivity follow using ε/2 in each premise and intersecting
sets. If X is not at least as good as Y, some positive ε gives a U-large
set where Y exceeds X by ε, which implies Y≻X. This proves Totality.
The affine mixture formula for v_X gives Independence after rescaling ε.
Equal laws give equality. Constants and simple variables stabilize, giving
Rich Outcomes and Simple EU. A strict stochastic dominance comparison gives
a fixed positive gap for all sufficiently large t, and so remains strict
after taking this quotient. Thus the model satisfies DTU.

For integrable X, v_X(t)→E[X] by dominated convergence. Hence two integrable
variables are compared exactly by their finite expectations, including
indifference when those expectations agree. This proves EU, the purpose of
the continuous quotient in the source's Theorem 3.

Reflection negates clipped expectation exactly. For any fixed b,

$$c_t(X+b)-c_t(X)\longrightarrow b,\qquad
|c_t(X+b)-c_t(X)|\le |b|.$$

Dominated convergence gives v_(X+b)(t)-v_X(t)→b, even for nonintegrable X.
Simultaneously shifting X and Y therefore changes their truncated comparison
by a function tending to zero, which the quotient ignores. This proves Shift
Invariance. Reflection and shift do **not** establish scale invariance.

The failed scale flag applies the source's Theorem 10 to this continuous
ultrafilter construction. Its witness and proof-audit limitation are described
in the exact-ultrafilter write-up and `extraction.md`. Thus this is a
source-attributed witness that DTU + EU + shift + reflection does not entail
positive affine invariance. The two St Petersburg arguments establish failure
of Countable Sure-Thing and Archimedean Gambles here as well.

No L¹ Continuity or Relative Expectation flag is inferred from the name
"continuous": the quotient construction and the topic's closure axiom are
different mathematical claims.

### Clipped expectation: exact ultrafilter dominance — `total-exact-ultrafilter`

Model; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)

Violates:

- Expected Utility (`expected-utility`)
- Scale Invariance (`scale-invariance`)
- Countable Sure-Thing (`countable-sure-thing`)
- Archimedean Gambles (`archimedean-gambles`)

Unknown in this model: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`)

Construction.

Take all real-valued random variables. Choose a cobounded ultrafilter U on positive truncation levels; define X≽Y iff {t:E[c_t(X)]≥E[c_t(Y)]}∈U. This is the exact hyperreal ordering of Theorem 1, not its continuous quotient. The accompanying write-up explains the satisfied axioms and EU counterexample; failure of Scale Invariance is the source’s Theorem 10.

Notes. The scale failure is recorded from the source theorem; its printed analytic witness has apparent typographical issues itemized in extraction.md. This record is a literature extraction, not a separately audited reconstruction of that witness.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, Appendix B, Theorem 1, pp. 690–691; Theorems 3 and 10, pp. 691, 693–695

Record: `topics/unbounded-utility/models/total-exact-ultrafilter.yaml`.

Write-up.

#### Clipped expectation: exact ultrafilter dominance

Source: Goodsell, *Decision theory unbound*, Appendix B, Theorems 1, 3,
and 10. Human model: Zachary Goodsell.
Recorded and translated by GPT-6 (Codex); no transcription checker asserted.

Take all real-valued random variables. Let U be an ultrafilter on positive
truncation levels containing every tail (s,∞). Define v_X(t)=E[c_t(X)]
as in the eventual-clipping write-up and set

$$X\succeq Y\quad\Longleftrightarrow\quad
\{t:v_X(t)\ge v_Y(t)\}\in\mathcal U.$$

Reflexivity holds because the entire domain is in U; finite intersections
prove transitivity; the ultrafilter dichotomy proves Totality. The ordering
extends eventual weak comparisons and eventual strictly positive gaps.
Thus its law invariance, Simple EU, richness, and stochastic dominance follow
from the calculations for clipped expectations. Common mixture components
cancel pointwise before taking the ultrafilter, giving Independence.
Reflection negates v_X exactly, giving reflection anti-invariance. These
properties give the DTU package in the topic's random-variable language.

The geometric N from the accompanying eventual model has expectation 2, but
v_N(t)<2 for every finite t>2. Therefore N is strictly worse than 2 on this
total ordering as well. This establishes failure of EU, exactly as the source's
Theorem 3 notes. The Countable Sure-Thing and Archimedean Gambles violations
follow from the recorded St Petersburg arguments.

**Scale failure is a source theorem application.** Goodsell's Theorem 10
(pp. 693–695) states that every total ordering constructed in this way fails
Scale Invariance. Its argument uses a pair of attainable clipped-expectation
curves whose difference oscillates in log scale, reverses sign on a doubling
of the truncation parameter, and cannot be neutralized simultaneously in both
phases by an ultrafilter. Apply that theorem to the U just chosen. This does
not assert that all total DTU models fail scale: the 2026 paper constructs
models that satisfy it.

The printed analytic witness has the notation/endpoint issues documented in
`extraction.md`. This model record accepts the published theorem for the scale
flag; it does not claim an independently checked correction of that entire
witness. The explicit EU counterexample and elementary satisfied-axiom
calculations above do not depend on those issues.

## 6. Derived state

Computed from the proved records only, by the closure rules in `README.md`. Conjectures take no part. A missing entry means *not recorded*, not *false*.

### 6.1 Interderivable principles

No two principles are currently interderivable.

### 6.2 Settled single-premise implications (50)

| From | To | Via |
| --- | --- | --- |
| Antitonic Sum Invariance | Shift Invariance | `antitonic-sum-implies-shift` |
| Archimedean Gambles | Archimedean Outcomes | `archimedean-gambles-restricts` |
| CDF-Area Extension | Archimedean Outcomes | `cdf-area-implies-eu`, `expected-utility-implies-simple`, `simple-eu-implies-archimedean-outcomes` |
| CDF-Area Extension | Expected Utility | `cdf-area-implies-eu` |
| CDF-Area Extension | Relative Expectation | `cdf-area-implies-relative` |
| CDF-Area Extension | Restricted Stochastic Equivalence | `cdf-area-implies-eu`, `expected-utility-implies-simple`, `simple-eu-implies-restricted-equivalence` |
| CDF-Area Extension | Restricted Totality | `cdf-area-implies-eu`, `expected-utility-implies-simple`, `simple-eu-implies-restricted-totality` |
| CDF-Area Extension | Transfer of a Shift Across a Mixture | `cdf-area-implies-relative`, `relative-implies-simple-relative`, `simple-relative-implies-shift-transfer` |
| CDF-Area Extension | Simple Expected Utility | `cdf-area-implies-eu`, `expected-utility-implies-simple` |
| CDF-Area Extension | Simple Relative Expectation | `cdf-area-implies-relative`, `relative-implies-simple-relative` |
| CDF-Area Extension | Statewise Dominance | `cdf-area-implies-eu`, `expected-utility-implies-simple`, `simple-eu-implies-archimedean-outcomes`, `cdf-area-implies-dominance`, `dominance-implies-statewise` |
| CDF-Area Extension | Stochastic Dominance | `cdf-area-implies-dominance` |
| CDF-Area Extension | Stochastic Equivalence | `cdf-area-implies-dominance`, `dominance-implies-equivalence` |
| Comonotonic Sum Invariance | Shift Invariance | `comonotonic-sum-implies-shift` |
| Existential Copula Sum Invariance | Shift Invariance | `existential-copula-implies-shift` |
| Expected Utility | Archimedean Outcomes | `expected-utility-implies-simple`, `simple-eu-implies-archimedean-outcomes` |
| Expected Utility | Restricted Stochastic Equivalence | `expected-utility-implies-simple`, `simple-eu-implies-restricted-equivalence` |
| Expected Utility | Restricted Totality | `expected-utility-implies-simple`, `simple-eu-implies-restricted-totality` |
| Expected Utility | Simple Expected Utility | `expected-utility-implies-simple` |
| Full Sum Invariance | Antitonic Sum Invariance | `full-sum-implies-antitonic` |
| Full Sum Invariance | Comonotonic Sum Invariance | `full-sum-implies-comonotonic` |
| Full Sum Invariance | Existential Copula Sum Invariance | `full-sum-implies-universal-copula`, `universal-copula-implies-existential` |
| Full Sum Invariance | Independent Sum Cancellation | `full-sum-implies-independent`, `independent-sum-implies-cancellation` |
| Full Sum Invariance | Independent Sum Invariance | `full-sum-implies-independent` |
| Full Sum Invariance | Independent Sum Preservation | `full-sum-implies-independent`, `independent-sum-implies-preservation` |
| Full Sum Invariance | Shift Invariance | `full-sum-implies-independent`, `independent-sum-implies-shift` |
| Full Sum Invariance | Universal Copula Sum Invariance | `full-sum-implies-universal-copula` |
| Independent Sum Invariance | Independent Sum Cancellation | `independent-sum-implies-cancellation` |
| Independent Sum Invariance | Independent Sum Preservation | `independent-sum-implies-preservation` |
| Independent Sum Invariance | Shift Invariance | `independent-sum-implies-shift` |
| Negative Affine Anti-Invariance | Reflection Anti-Invariance | `negative-affine-implies-reflection` |
| Positive Affine Invariance | Scale Invariance | `positive-affine-implies-scale` |
| Positive Affine Invariance | Shift Invariance | `positive-affine-implies-shift` |
| Relative Expectation | Transfer of a Shift Across a Mixture | `relative-implies-simple-relative`, `simple-relative-implies-shift-transfer` |
| Relative Expectation | Simple Relative Expectation | `relative-implies-simple-relative` |
| Simple Expected Utility | Archimedean Outcomes | `simple-eu-implies-archimedean-outcomes` |
| Simple Expected Utility | Restricted Stochastic Equivalence | `simple-eu-implies-restricted-equivalence` |
| Simple Expected Utility | Restricted Totality | `simple-eu-implies-restricted-totality` |
| Simple Relative Expectation | Transfer of a Shift Across a Mixture | `simple-relative-implies-shift-transfer` |
| Stochastic Dominance | Restricted Stochastic Equivalence | `dominance-implies-equivalence`, `stochastic-equivalence-restricts` |
| Stochastic Dominance | Stochastic Equivalence | `dominance-implies-equivalence` |
| Stochastic Equivalence | Restricted Stochastic Equivalence | `stochastic-equivalence-restricts` |
| Totality | Restricted Totality | `totality-restricts` |
| Universal Copula Sum Invariance | Antitonic Sum Invariance | `universal-copula-implies-antitonic` |
| Universal Copula Sum Invariance | Comonotonic Sum Invariance | `universal-copula-implies-comonotonic` |
| Universal Copula Sum Invariance | Existential Copula Sum Invariance | `universal-copula-implies-existential` |
| Universal Copula Sum Invariance | Independent Sum Cancellation | `universal-copula-implies-independent`, `independent-sum-implies-cancellation` |
| Universal Copula Sum Invariance | Independent Sum Invariance | `universal-copula-implies-independent` |
| Universal Copula Sum Invariance | Independent Sum Preservation | `universal-copula-implies-independent`, `independent-sum-implies-preservation` |
| Universal Copula Sum Invariance | Shift Invariance | `universal-copula-implies-antitonic`, `antitonic-sum-implies-shift` |

### 6.3 Refuted single-premise implications (592)

Read *A ⇏ B*: assuming A alone does not yield B, as the named model shows.

| From | To | Witness model |
| --- | --- | --- |
| Alternating St Petersburg = −1/2 | Antitonic Sum Invariance | `affine-symmetric-extension` |
| Alternating St Petersburg = −1/2 | Archimedean Gambles | `affine-symmetric-extension` |
| Alternating St Petersburg = −1/2 | Countable Sure-Thing | `affine-symmetric-extension` |
| Alternating St Petersburg = −1/2 | Full Sum Invariance | `affine-symmetric-extension` |
| Alternating St Petersburg = −1/2 | Independent Sum Cancellation | `affine-symmetric-extension` |
| Alternating St Petersburg = −1/2 | Independent Sum Invariance | `affine-symmetric-extension` |
| Alternating St Petersburg = −1/2 | Independent Sum Preservation | `affine-symmetric-extension` |
| Alternating St Petersburg = −1/2 | Universal Copula Sum Invariance | `affine-symmetric-extension` |
| Archimedean Outcomes | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Archimedean Outcomes | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Archimedean Outcomes | CDF-Area Extension | `eventual-clipped-expectation`, `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Expected Utility | `eventual-clipped-expectation`, `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-two-sample-minimum`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Mixture Independence | `finite-two-sample-minimum` |
| Archimedean Outcomes | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Archimedean Outcomes | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Archimedean Outcomes | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Archimedean Outcomes | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Archimedean Outcomes | Relative Expectation | `eventual-clipped-expectation`, `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Simple Expected Utility | `finite-two-sample-minimum` |
| Archimedean Outcomes | Statewise Dominance | `finite-two-sample-minimum` |
| Archimedean Outcomes | Stochastic Dominance | `finite-two-sample-minimum` |
| Archimedean Outcomes | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Archimedean Outcomes | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation` |
| Archimedean Outcomes | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Arroyo = ln 2 | Alternating St Petersburg = −1/2 | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Arroyo = ln 2 | Antitonic Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Arroyo = ln 2 | Archimedean Gambles | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Arroyo = ln 2 | Countable Sure-Thing | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Arroyo = ln 2 | Full Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Arroyo = ln 2 | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Arroyo = ln 2 | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Arroyo = ln 2 | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Arroyo = ln 2 | L¹ Continuity (random variables) | `lexicographic-folded-extension` |
| Arroyo = ln 2 | Negative Affine Anti-Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Arroyo = ln 2 | Uniqueness of Negative Self-Similarity | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Arroyo = ln 2 | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Arroyo = ln 2 | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Arroyo = ln 2 | Universal Copula Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| CDF-Area Extension | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| CDF-Area Extension | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| CDF-Area Extension | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| CDF-Area Extension | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| CDF-Area Extension | L¹ Continuity (random variables) | `lexicographic-folded-extension` |
| CDF-Area Extension | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| CDF-Area Extension | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| CDF-Area Extension | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| CDF-Area Extension | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| CDF-Area Extension | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Comonotonic Sum Invariance | Antitonic Sum Invariance | `cdf-area-preorder` |
| Comonotonic Sum Invariance | Archimedean Gambles | `cdf-area-preorder` |
| Comonotonic Sum Invariance | Countable Sure-Thing | `cdf-area-preorder` |
| Comonotonic Sum Invariance | Folded Expectation | `cdf-area-preorder` |
| Comonotonic Sum Invariance | Full Sum Invariance | `cdf-area-preorder` |
| Comonotonic Sum Invariance | Symmetric Gambles Are Neutral | `cdf-area-preorder` |
| Comonotonic Sum Invariance | Totality | `cdf-area-preorder` |
| Comonotonic Sum Invariance | Universal Copula Sum Invariance | `cdf-area-preorder` |
| Existential Copula Sum Invariance | Antitonic Sum Invariance | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Existential Copula Sum Invariance | Archimedean Gambles | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Existential Copula Sum Invariance | Countable Sure-Thing | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Existential Copula Sum Invariance | Folded Expectation | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Existential Copula Sum Invariance | Full Sum Invariance | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Existential Copula Sum Invariance | Negative Affine Anti-Invariance | `conjectured-total-independent-sum-extension` |
| Existential Copula Sum Invariance | Reflection Anti-Invariance | `conjectured-total-independent-sum-extension` |
| Existential Copula Sum Invariance | Symmetric Gambles Are Neutral | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Existential Copula Sum Invariance | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Existential Copula Sum Invariance | Universal Copula Sum Invariance | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Expected Utility | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Expected Utility | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Expected Utility | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Expected Utility | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Expected Utility | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Expected Utility | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Expected Utility | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Expected Utility | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Expected Utility | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Expected Utility | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Expected Utility | L¹ Continuity (random variables) | `lexicographic-folded-extension` |
| Expected Utility | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Expected Utility | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Expected Utility | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Expected Utility | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Expected Utility | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Expected Utility | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Expected Utility | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Expected Utility | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Expected Utility | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Folded Expectation | Alternating St Petersburg = −1/2 | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Antitonic Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Archimedean Gambles | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Countable Sure-Thing | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Full Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Folded Expectation | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | L¹ Continuity (random variables) | `lexicographic-folded-extension` |
| Folded Expectation | Negative Affine Anti-Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Uniqueness of Negative Self-Similarity | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Folded Expectation | Universal Copula Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Mixture Independence | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Mixture Independence | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Mixture Independence | CDF-Area Extension | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Mixture Independence | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Mixture Independence | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Mixture Independence | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Mixture Independence | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Mixture Independence | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Mixture Independence | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Mixture Independence | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Mixture Independence | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Mixture Independence | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation` |
| Mixture Independence | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Independent Sum Cancellation | Antitonic Sum Invariance | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Cancellation | Archimedean Gambles | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Cancellation | Countable Sure-Thing | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Cancellation | Folded Expectation | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Cancellation | Full Sum Invariance | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Cancellation | Negative Affine Anti-Invariance | `conjectured-total-independent-sum-extension` |
| Independent Sum Cancellation | Reflection Anti-Invariance | `conjectured-total-independent-sum-extension` |
| Independent Sum Cancellation | Symmetric Gambles Are Neutral | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Cancellation | Totality | `cdf-conclosure-preorder` |
| Independent Sum Cancellation | Universal Copula Sum Invariance | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Invariance | Antitonic Sum Invariance | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Invariance | Archimedean Gambles | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Invariance | Countable Sure-Thing | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Invariance | Folded Expectation | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Invariance | Full Sum Invariance | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Invariance | Negative Affine Anti-Invariance | `conjectured-total-independent-sum-extension` |
| Independent Sum Invariance | Reflection Anti-Invariance | `conjectured-total-independent-sum-extension` |
| Independent Sum Invariance | Symmetric Gambles Are Neutral | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Invariance | Totality | `cdf-conclosure-preorder` |
| Independent Sum Invariance | Universal Copula Sum Invariance | `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Preservation | Antitonic Sum Invariance | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Preservation | Archimedean Gambles | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Preservation | Countable Sure-Thing | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Preservation | Folded Expectation | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Preservation | Full Sum Invariance | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Preservation | Negative Affine Anti-Invariance | `conjectured-total-independent-sum-extension` |
| Independent Sum Preservation | Reflection Anti-Invariance | `conjectured-total-independent-sum-extension` |
| Independent Sum Preservation | Symmetric Gambles Are Neutral | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| Independent Sum Preservation | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Independent Sum Preservation | Universal Copula Sum Invariance | `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension` |
| L¹ Continuity (random variables) | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Folded Expectation | `asymmetric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Positive Affine Invariance | `geometric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Scale Invariance | `geometric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| L¹ Continuity (random variables) | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `polynomial-asymmetric-continuous-ultrafilter` |
| Negative Affine Anti-Invariance | Antitonic Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Negative Affine Anti-Invariance | Archimedean Gambles | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Negative Affine Anti-Invariance | Countable Sure-Thing | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Negative Affine Anti-Invariance | Folded Expectation | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Negative Affine Anti-Invariance | Full Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Negative Affine Anti-Invariance | Independent Sum Cancellation | `affine-symmetric-extension` |
| Negative Affine Anti-Invariance | Independent Sum Invariance | `affine-symmetric-extension` |
| Negative Affine Anti-Invariance | Independent Sum Preservation | `affine-symmetric-extension` |
| Negative Affine Anti-Invariance | Symmetric Gambles Are Neutral | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Negative Affine Anti-Invariance | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Negative Affine Anti-Invariance | Universal Copula Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Uniqueness of Negative Self-Similarity | Antitonic Sum Invariance | `affine-symmetric-extension` |
| Uniqueness of Negative Self-Similarity | Archimedean Gambles | `affine-symmetric-extension` |
| Uniqueness of Negative Self-Similarity | Countable Sure-Thing | `affine-symmetric-extension` |
| Uniqueness of Negative Self-Similarity | Full Sum Invariance | `affine-symmetric-extension` |
| Uniqueness of Negative Self-Similarity | Independent Sum Cancellation | `affine-symmetric-extension` |
| Uniqueness of Negative Self-Similarity | Independent Sum Invariance | `affine-symmetric-extension` |
| Uniqueness of Negative Self-Similarity | Independent Sum Preservation | `affine-symmetric-extension` |
| Uniqueness of Negative Self-Similarity | Universal Copula Sum Invariance | `affine-symmetric-extension` |
| Pasadena = ln 2 | Antitonic Sum Invariance | `affine-symmetric-extension` |
| Pasadena = ln 2 | Archimedean Gambles | `affine-symmetric-extension` |
| Pasadena = ln 2 | Countable Sure-Thing | `affine-symmetric-extension` |
| Pasadena = ln 2 | Full Sum Invariance | `affine-symmetric-extension` |
| Pasadena = ln 2 | Independent Sum Cancellation | `affine-symmetric-extension` |
| Pasadena = ln 2 | Independent Sum Invariance | `affine-symmetric-extension` |
| Pasadena = ln 2 | Independent Sum Preservation | `affine-symmetric-extension` |
| Pasadena = ln 2 | Universal Copula Sum Invariance | `affine-symmetric-extension` |
| Positive Affine Invariance | Antitonic Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Positive Affine Invariance | Archimedean Gambles | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Positive Affine Invariance | Countable Sure-Thing | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Positive Affine Invariance | Folded Expectation | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Positive Affine Invariance | Full Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Positive Affine Invariance | Independent Sum Cancellation | `affine-symmetric-extension` |
| Positive Affine Invariance | Independent Sum Invariance | `affine-symmetric-extension` |
| Positive Affine Invariance | Independent Sum Preservation | `affine-symmetric-extension` |
| Positive Affine Invariance | Symmetric Gambles Are Neutral | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Positive Affine Invariance | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Positive Affine Invariance | Universal Copula Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Reflection Anti-Invariance | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Reflection Anti-Invariance | Antitonic Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Archimedean Gambles | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | CDF-Area Extension | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Countable Sure-Thing | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Folded Expectation | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Full Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Reflection Anti-Invariance | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Negative Affine Anti-Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Uniqueness of Negative Self-Similarity | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Reflection Anti-Invariance | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Symmetric Gambles Are Neutral | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Reflection Anti-Invariance | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation` |
| Reflection Anti-Invariance | Universal Copula Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Relative Expectation | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Relative Expectation | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Relative Expectation | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Relative Expectation | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Relative Expectation | L¹ Continuity (random variables) | `lexicographic-folded-extension` |
| Relative Expectation | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Relative Expectation | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Relative Expectation | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Relative Expectation | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Relative Expectation | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Stochastic Equivalence | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Restricted Stochastic Equivalence | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Stochastic Equivalence | CDF-Area Extension | `eventual-clipped-expectation`, `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Expected Utility | `eventual-clipped-expectation`, `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-two-sample-minimum`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Mixture Independence | `finite-two-sample-minimum` |
| Restricted Stochastic Equivalence | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Restricted Stochastic Equivalence | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Stochastic Equivalence | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Stochastic Equivalence | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Stochastic Equivalence | Relative Expectation | `eventual-clipped-expectation`, `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Simple Expected Utility | `finite-two-sample-minimum` |
| Restricted Stochastic Equivalence | Statewise Dominance | `finite-two-sample-minimum` |
| Restricted Stochastic Equivalence | Stochastic Dominance | `finite-two-sample-minimum` |
| Restricted Stochastic Equivalence | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Stochastic Equivalence | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation` |
| Restricted Stochastic Equivalence | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Restricted Totality | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Totality | CDF-Area Extension | `eventual-clipped-expectation`, `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Restricted Totality | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Expected Utility | `eventual-clipped-expectation`, `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Restricted Totality | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-two-sample-minimum`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Mixture Independence | `finite-two-sample-minimum` |
| Restricted Totality | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Restricted Totality | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Restricted Totality | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Totality | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Totality | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Totality | Relative Expectation | `eventual-clipped-expectation`, `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Restricted Totality | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Simple Expected Utility | `finite-two-sample-minimum` |
| Restricted Totality | Statewise Dominance | `finite-two-sample-minimum` |
| Restricted Totality | Stochastic Dominance | `finite-two-sample-minimum` |
| Restricted Totality | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Restricted Totality | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation` |
| Restricted Totality | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Rich Outcomes | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Rich Outcomes | CDF-Area Extension | `eventual-clipped-expectation`, `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Rich Outcomes | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Expected Utility | `eventual-clipped-expectation`, `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Rich Outcomes | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-two-sample-minimum`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Mixture Independence | `finite-two-sample-minimum` |
| Rich Outcomes | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Rich Outcomes | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Rich Outcomes | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Rich Outcomes | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Rich Outcomes | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Rich Outcomes | Relative Expectation | `eventual-clipped-expectation`, `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Rich Outcomes | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Simple Expected Utility | `finite-two-sample-minimum` |
| Rich Outcomes | Statewise Dominance | `finite-two-sample-minimum` |
| Rich Outcomes | Stochastic Dominance | `finite-two-sample-minimum` |
| Rich Outcomes | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Rich Outcomes | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation` |
| Rich Outcomes | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Scale Invariance | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation` |
| Scale Invariance | Antitonic Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation` |
| Scale Invariance | Archimedean Gambles | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation` |
| Scale Invariance | CDF-Area Extension | `eventual-clipped-expectation` |
| Scale Invariance | Countable Sure-Thing | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation` |
| Scale Invariance | Expected Utility | `eventual-clipped-expectation` |
| Scale Invariance | Folded Expectation | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation` |
| Scale Invariance | Full Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation` |
| Scale Invariance | Independent Sum Cancellation | `affine-symmetric-extension` |
| Scale Invariance | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation` |
| Scale Invariance | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation` |
| Scale Invariance | L¹ Continuity (random variables) | `eventual-clipped-expectation` |
| Scale Invariance | Uniqueness of Negative Self-Similarity | `eventual-clipped-expectation` |
| Scale Invariance | Relative Expectation | `eventual-clipped-expectation` |
| Scale Invariance | Symmetric Gambles Are Neutral | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Scale Invariance | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation` |
| Scale Invariance | Universal Copula Sum Invariance | `affine-symmetric-extension`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation` |
| Shift Invariance | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Shift Invariance | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Shift Invariance | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Shift Invariance | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Shift Invariance | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Shift Invariance | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Shift Invariance | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Shift Invariance | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Shift Invariance | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Shift Invariance | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Shift Invariance | L¹ Continuity (random variables) | `lexicographic-folded-extension` |
| Shift Invariance | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Shift Invariance | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Shift Invariance | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Shift Invariance | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Shift Invariance | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Shift Invariance | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Shift Invariance | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Shift Invariance | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Shift Invariance | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Transfer of a Shift Across a Mixture | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | L¹ Continuity (random variables) | `lexicographic-folded-extension` |
| Transfer of a Shift Across a Mixture | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Transfer of a Shift Across a Mixture | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Simple Expected Utility | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Simple Expected Utility | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Expected Utility | CDF-Area Extension | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Simple Expected Utility | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Simple Expected Utility | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Simple Expected Utility | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Simple Expected Utility | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Expected Utility | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Expected Utility | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Expected Utility | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Simple Expected Utility | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Expected Utility | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation` |
| Simple Expected Utility | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Relative Expectation | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Simple Relative Expectation | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Relative Expectation | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Relative Expectation | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Simple Relative Expectation | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | L¹ Continuity (random variables) | `lexicographic-folded-extension` |
| Simple Relative Expectation | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Relative Expectation | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Relative Expectation | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Relative Expectation | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter` |
| Simple Relative Expectation | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Simple Relative Expectation | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder` |
| Simple Relative Expectation | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter` |
| Statewise Dominance | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Statewise Dominance | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Statewise Dominance | CDF-Area Extension | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Statewise Dominance | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Statewise Dominance | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Statewise Dominance | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Statewise Dominance | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Statewise Dominance | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Statewise Dominance | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Statewise Dominance | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Statewise Dominance | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Statewise Dominance | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation` |
| Statewise Dominance | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Stochastic Dominance | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Dominance | CDF-Area Extension | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Stochastic Dominance | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Stochastic Dominance | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Stochastic Dominance | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Stochastic Dominance | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Dominance | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Dominance | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Dominance | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Stochastic Dominance | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Dominance | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation` |
| Stochastic Dominance | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Stochastic Equivalence | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Equivalence | CDF-Area Extension | `eventual-clipped-expectation`, `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Expected Utility | `eventual-clipped-expectation`, `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `finite-two-sample-minimum`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Mixture Independence | `finite-two-sample-minimum` |
| Stochastic Equivalence | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Stochastic Equivalence | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Equivalence | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Equivalence | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Equivalence | Relative Expectation | `eventual-clipped-expectation`, `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Simple Expected Utility | `finite-two-sample-minimum` |
| Stochastic Equivalence | Statewise Dominance | `finite-two-sample-minimum` |
| Stochastic Equivalence | Stochastic Dominance | `finite-two-sample-minimum` |
| Stochastic Equivalence | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Stochastic Equivalence | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation` |
| Stochastic Equivalence | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Sure-Thing | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Sure-Thing | CDF-Area Extension | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Sure-Thing | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Sure-Thing | Folded Expectation | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Sure-Thing | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Sure-Thing | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Sure-Thing | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Sure-Thing | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Sure-Thing | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Sure-Thing | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Sure-Thing | Totality | `cdf-area-preorder`, `cdf-conclosure-preorder`, `eventual-clipped-expectation` |
| Sure-Thing | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `cdf-area-preorder`, `cdf-conclosure-preorder`, `conjectured-total-independent-sum-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Symmetric Gambles Are Neutral | Antitonic Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Archimedean Gambles | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | CDF-Area Extension | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Countable Sure-Thing | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Folded Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Full Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Symmetric Gambles Are Neutral | Independent Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Independent Sum Preservation | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Negative Affine Anti-Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Uniqueness of Negative Self-Similarity | `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Symmetric Gambles Are Neutral | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Totality | `eventual-clipped-expectation` |
| Symmetric Gambles Are Neutral | Universal Copula Sum Invariance | `affine-symmetric-extension`, `eventual-clipped-expectation`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Alternating St Petersburg = −1/2 | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension` |
| Totality | Antitonic Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Archimedean Gambles | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Arroyo = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Totality | CDF-Area Extension | `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Totality | Countable Sure-Thing | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Expected Utility | `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Totality | Folded Expectation | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `finite-two-sample-minimum`, `polynomial-asymmetric-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Full Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Mixture Independence | `finite-two-sample-minimum` |
| Totality | Independent Sum Cancellation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter` |
| Totality | Independent Sum Invariance | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Independent Sum Preservation | `affine-symmetric-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | L¹ Continuity (random variables) | `lexicographic-folded-extension`, `total-exact-ultrafilter` |
| Totality | Negative Affine Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Uniqueness of Negative Self-Similarity | `asymmetric-continuous-ultrafilter`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Totality | Pasadena = ln 2 | `polynomial-asymmetric-continuous-ultrafilter` |
| Totality | Positive Affine Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Reflection Anti-Invariance | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Totality | Relative Expectation | `finite-two-sample-minimum`, `total-exact-ultrafilter` |
| Totality | Scale Invariance | `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Simple Expected Utility | `finite-two-sample-minimum` |
| Totality | Statewise Dominance | `finite-two-sample-minimum` |
| Totality | Stochastic Dominance | `finite-two-sample-minimum` |
| Totality | Symmetric Gambles Are Neutral | `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `polynomial-asymmetric-continuous-ultrafilter` |
| Totality | Universal Copula Sum Invariance | `affine-symmetric-extension`, `asymmetric-continuous-ultrafilter`, `conjectured-total-independent-sum-extension`, `geometric-continuous-ultrafilter`, `lexicographic-folded-extension`, `polynomial-asymmetric-continuous-ultrafilter`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |

### 6.4 Open single-premise pairs (764)

Listed in `OPEN-QUESTIONS.md`.

### Negative implications (0)

Read A ⇒ ¬B: A and B cannot hold together. This does not by itself witness a model of A.

None.

### 6.5 What the recorded premise packages entail

Every multi-premise package used by a proved result, with its full consequence set.

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Symmetric Gambles Are Neutral + Independent Sum Invariance

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `symmetric-neutrality`, `independent-sum-consistency`.

**Inconsistent:** these premises imply False via independent-sum-implies-preservation, levy-refutes-neutral-independent-preservation. No consequences by explosion are listed.

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance + L¹ Continuity (random variables)

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`, `l1-continuity`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Refuted (a model satisfies the package and violates these): nothing
- Open: Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance + Relative Expectation

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`, `relative-expectation`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Refuted (a model satisfies the package and violates these): nothing
- Open: Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Archimedean Gambles

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `archimedean-gambles`.

**Inconsistent:** these premises imply False via dtu-refutes-archimedean-gambles. No consequences by explosion are listed.

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + L¹ Continuity (random variables)

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `l1-continuity`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Archimedean Outcomes (`archimedean-outcomes`), CDF-Area Extension (`cdf-area-extension`), Expected Utility (`expected-utility`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Folded Expectation (`folded-expectation`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Open: Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Refuted (a model satisfies the package and violates these): Independent Sum Cancellation (`independent-sum-cancellation`)
- Open: Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Pasadena = ln 2 (`pasadena-value`), Relative Expectation (`relative-expectation`)

#### Rich Outcomes + Expected Utility + Stochastic Equivalence + Mixture Independence + Stochastic Dominance + L¹ Continuity (random variables)

Assumes: `rich-outcomes`, `expected-utility`, `stochastic-equivalence`, `independence`, `stochastic-dominance`, `l1-continuity`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Archimedean Outcomes (`archimedean-outcomes`), CDF-Area Extension (`cdf-area-extension`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Folded Expectation (`folded-expectation`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Open: Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Totality (`totality`)

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Mixture Independence + Reflection Anti-Invariance

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `independence`, `reflection-anti-invariance`.

- Rules out (entails their negations): Countable Sure-Thing (`countable-sure-thing`)
- Entails: Archimedean Outcomes (`archimedean-outcomes`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), CDF-Area Extension (`cdf-area-extension`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Pasadena = ln 2 (`pasadena-value`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`)

#### Rich Outcomes + Stochastic Equivalence + Simple Expected Utility + Mixture Independence + Symmetric Gambles Are Neutral + Shift Invariance

Assumes: `rich-outcomes`, `stochastic-equivalence`, `simple-eu`, `independence`, `symmetric-neutrality`, `shift-invariance`.

- Rules out (entails their negations): Countable Sure-Thing (`countable-sure-thing`)
- Entails: Archimedean Outcomes (`archimedean-outcomes`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Positive Affine Invariance (`positive-affine-invariance`), Scale Invariance (`scale-invariance`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Pasadena = ln 2 (`pasadena-value`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Totality (`totality`)

#### Rich Outcomes + Archimedean Outcomes + Totality + Stochastic Dominance + Sure-Thing

Assumes: `rich-outcomes`, `archimedean-outcomes`, `totality`, `stochastic-dominance`, `sure-thing`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Mixture Independence (`independence`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`), Statewise Dominance (`statewise-dominance`), Stochastic Equivalence (`stochastic-equivalence`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Open: Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`)

#### Rich Outcomes + Stochastic Dominance + Mixture Independence + Symmetric Gambles Are Neutral + Independent Sum Preservation

Assumes: `rich-outcomes`, `stochastic-dominance`, `independence`, `symmetric-neutrality`, `independent-sum-preservation`.

**Inconsistent:** these premises imply False via levy-refutes-neutral-independent-preservation. No consequences by explosion are listed.

#### Rich Outcomes + Stochastic Equivalence + Mixture Independence + Relative Expectation + Uniqueness of Negative Self-Similarity

Assumes: `rich-outcomes`, `stochastic-equivalence`, `independence`, `relative-expectation`, `negative-self-similarity`.

- Rules out (entails their negations): nothing further
- Entails: Pasadena = ln 2 (`pasadena-value`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Totality (`restricted-totality`), Scale Invariance (`scale-invariance`), Simple Expected Utility (`simple-eu`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`)

#### Rich Outcomes + Stochastic Equivalence + Simple Expected Utility + Mixture Independence + Transfer of a Shift Across a Mixture

Assumes: `rich-outcomes`, `stochastic-equivalence`, `simple-eu`, `independence`, `shift-transfer`.

- Rules out (entails their negations): Countable Sure-Thing (`countable-sure-thing`)
- Entails: Archimedean Outcomes (`archimedean-outcomes`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`), Simple Relative Expectation (`simple-relative-expectation`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Relative Expectation (`relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`)

#### Rich Outcomes + Totality + Stochastic Equivalence + Mixture Independence + Symmetric Gambles Are Neutral

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `independence`, `symmetric-neutrality`.

- Rules out (entails their negations): nothing further
- Entails: Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), CDF-Area Extension (`cdf-area-extension`), Countable Sure-Thing (`countable-sure-thing`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Pasadena = ln 2 (`pasadena-value`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`)

#### Rich Outcomes + Totality + Stochastic Dominance + L¹ Continuity (random variables) + Independent Sum Cancellation

Assumes: `rich-outcomes`, `totality`, `stochastic-dominance`, `l1-continuity`, `independent-sum-cancellation`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Full Sum Invariance (`full-sum-consistency`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`), Stochastic Equivalence (`stochastic-equivalence`)
- Refuted (a model satisfies the package and violates these): nothing
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Gambles (`archimedean-gambles`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Mixture Independence (`independence`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)

#### Rich Outcomes + Stochastic Equivalence + Relative Expectation + Symmetric Gambles Are Neutral + Shift Invariance

Assumes: `rich-outcomes`, `stochastic-equivalence`, `relative-expectation`, `symmetric-neutrality`, `shift-invariance`.

- Rules out (entails their negations): nothing further
- Entails: Arroyo = ln 2 (`arroyo-value`), Folded Expectation (`folded-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Positive Affine Invariance (`positive-affine-invariance`), Scale Invariance (`scale-invariance`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Mixture Independence (`independence`), Pasadena = ln 2 (`pasadena-value`), Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Sure-Thing (`sure-thing`), Totality (`totality`)

#### Rich Outcomes + Simple Expected Utility + Stochastic Dominance + Archimedean Gambles

Assumes: `rich-outcomes`, `simple-eu`, `stochastic-dominance`, `archimedean-gambles`.

**Inconsistent:** these premises imply False via rich-simple-dominance-refutes-archimedean-gambles. No consequences by explosion are listed.

#### Rich Outcomes + Archimedean Outcomes + Stochastic Dominance + Mixture Independence

Assumes: `rich-outcomes`, `archimedean-outcomes`, `stochastic-dominance`, `independence`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`), Statewise Dominance (`statewise-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`)
- Open: Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`)

#### Rich Outcomes + Archimedean Outcomes + Stochastic Dominance + Relative Expectation

Assumes: `rich-outcomes`, `archimedean-outcomes`, `stochastic-dominance`, `relative-expectation`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Full Sum Invariance (`full-sum-consistency`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: CDF-Area Extension (`cdf-area-extension`), Expected Utility (`expected-utility`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Equivalence (`stochastic-equivalence`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`)
- Open: Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Mixture Independence (`independence`), Shift Invariance (`shift-invariance`), Sure-Thing (`sure-thing`)

#### Rich Outcomes + Archimedean Outcomes + Stochastic Equivalence + Statewise Dominance

Assumes: `rich-outcomes`, `archimedean-outcomes`, `stochastic-equivalence`, `statewise-dominance`.

- Rules out (entails their negations): Antitonic Sum Invariance (`antitonic-sum-consistency`), Full Sum Invariance (`full-sum-consistency`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Entails: Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Stochastic Dominance (`stochastic-dominance`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Countable Sure-Thing (`countable-sure-thing`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`)
- Open: Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Mixture Independence (`independence`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Sure-Thing (`sure-thing`)

#### Rich Outcomes + Simple Expected Utility + Sure-Thing + Countable Sure-Thing

Assumes: `rich-outcomes`, `simple-eu`, `sure-thing`, `countable-sure-thing`.

**Inconsistent:** these premises imply False via rich-simple-sure-thing-refutes-countable. No consequences by explosion are listed.

#### Rich Outcomes + Stochastic Equivalence + Simple Expected Utility + Uniqueness of Negative Self-Similarity

Assumes: `rich-outcomes`, `stochastic-equivalence`, `simple-eu`, `negative-self-similarity`.

- Rules out (entails their negations): nothing further
- Entails: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`)
- Refuted (a model satisfies the package and violates these): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Mixture Independence (`independence`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`)

#### Rich Outcomes + Stochastic Dominance + Antitonic Sum Invariance

Assumes: `rich-outcomes`, `stochastic-dominance`, `antitonic-sum-consistency`.

**Inconsistent:** these premises imply False via dominance-refutes-antitonic-sum. No consequences by explosion are listed.

#### Rich Outcomes + Mixture Independence + Folded Expectation

Assumes: `rich-outcomes`, `independence`, `folded-expectation`.

- Rules out (entails their negations): nothing further
- Entails: Arroyo = ln 2 (`arroyo-value`), Relative Expectation (`relative-expectation`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Positive Affine Invariance (`positive-affine-invariance`), Scale Invariance (`scale-invariance`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Pasadena = ln 2 (`pasadena-value`), Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`), Totality (`totality`)

#### Rich Outcomes + Stochastic Dominance + Full Sum Invariance

Assumes: `rich-outcomes`, `stochastic-dominance`, `full-sum-consistency`.

**Inconsistent:** these premises imply False via dominance-refutes-full-sum. No consequences by explosion are listed.

#### Totality + Mixture Independence + Negative Affine Anti-Invariance

Assumes: `totality`, `independence`, `negative-affine-anti-invariance`.

- Rules out (entails their negations): nothing further
- Entails: Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Totality (`restricted-totality`)
- Refuted (a model satisfies the package and violates these): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Rich Outcomes (`rich-outcomes`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)

#### Rich Outcomes + Simple Relative Expectation + L¹ Continuity (random variables)

Assumes: `rich-outcomes`, `simple-relative-expectation`, `l1-continuity`.

- Rules out (entails their negations): nothing further
- Entails: Relative Expectation (`relative-expectation`), Transfer of a Shift Across a Mixture (`shift-transfer`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Mixture Independence (`independence`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`), Simple Expected Utility (`simple-eu`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`), Totality (`totality`)

#### Rich Outcomes + Positive Affine Invariance + Reflection Anti-Invariance

Assumes: `rich-outcomes`, `positive-affine-invariance`, `reflection-anti-invariance`.

- Rules out (entails their negations): nothing further
- Entails: Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`)
- Refuted (a model satisfies the package and violates these): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Mixture Independence (`independence`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`)

#### Rich Outcomes + Shift Invariance + Scale Invariance

Assumes: `rich-outcomes`, `shift-invariance`, `scale-invariance`.

- Rules out (entails their negations): nothing further
- Entails: Positive Affine Invariance (`positive-affine-invariance`)
- Refuted (a model satisfies the package and violates these): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Mixture Independence (`independence`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`)

#### Antitonic Sum Invariance + Stochastic Equivalence

Assumes: `antitonic-sum-consistency`, `stochastic-equivalence`.

- Rules out (entails their negations): nothing further
- Entails: Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Shift Invariance (`shift-invariance`)
- Refuted (a model satisfies the package and violates these): nothing
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Gambles (`archimedean-gambles`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Countable Sure-Thing (`countable-sure-thing`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Mixture Independence (`independence`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Restricted Totality (`restricted-totality`), Rich Outcomes (`rich-outcomes`), Scale Invariance (`scale-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)

#### Archimedean Outcomes + Folded Expectation

Assumes: `archimedean-outcomes`, `folded-expectation`.

- Rules out (entails their negations): nothing further
- Entails: Expected Utility (`expected-utility`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Positive Affine Invariance (`positive-affine-invariance`), Scale Invariance (`scale-invariance`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Mixture Independence (`independence`), Pasadena = ln 2 (`pasadena-value`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Rich Outcomes (`rich-outcomes`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`)

#### Archimedean Outcomes + Relative Expectation

Assumes: `archimedean-outcomes`, `relative-expectation`.

- Rules out (entails their negations): nothing further
- Entails: Expected Utility (`expected-utility`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Mixture Independence (`independence`), Rich Outcomes (`rich-outcomes`), Shift Invariance (`shift-invariance`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`)

#### Archimedean Outcomes + Stochastic Dominance

Assumes: `archimedean-outcomes`, `stochastic-dominance`.

- Rules out (entails their negations): nothing further
- Entails: Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Statewise Dominance (`statewise-dominance`), Stochastic Equivalence (`stochastic-equivalence`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Countable Sure-Thing (`countable-sure-thing`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Mixture Independence (`independence`), Restricted Totality (`restricted-totality`), Rich Outcomes (`rich-outcomes`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Sure-Thing (`sure-thing`)

#### Comonotonic Sum Invariance + Stochastic Equivalence

Assumes: `comonotonic-sum-consistency`, `stochastic-equivalence`.

- Rules out (entails their negations): nothing further
- Entails: Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Shift Invariance (`shift-invariance`)
- Refuted (a model satisfies the package and violates these): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Expected Utility (`expected-utility`), Mixture Independence (`independence`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Restricted Totality (`restricted-totality`), Rich Outcomes (`rich-outcomes`), Scale Invariance (`scale-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Sure-Thing (`sure-thing`)

#### Rich Outcomes + Folded Expectation

Assumes: `rich-outcomes`, `folded-expectation`.

- Rules out (entails their negations): nothing further
- Entails: Arroyo = ln 2 (`arroyo-value`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Positive Affine Invariance (`positive-affine-invariance`), Scale Invariance (`scale-invariance`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Mixture Independence (`independence`), Pasadena = ln 2 (`pasadena-value`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`), Totality (`totality`)

#### Mixture Independence + Transfer of a Shift Across a Mixture

Assumes: `independence`, `shift-transfer`.

- Rules out (entails their negations): nothing further
- Entails: Shift Invariance (`shift-invariance`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Rich Outcomes (`rich-outcomes`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`)

#### Stochastic Equivalence + Mixture Independence

Assumes: `stochastic-equivalence`, `independence`.

- Rules out (entails their negations): nothing further
- Entails: Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Countable Sure-Thing (`countable-sure-thing`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Restricted Totality (`restricted-totality`), Rich Outcomes (`rich-outcomes`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`)

#### Independent Sum Preservation + Independent Sum Cancellation

Assumes: `independent-sum-preservation`, `independent-sum-cancellation`.

- Rules out (entails their negations): nothing further
- Entails: Independent Sum Invariance (`independent-sum-consistency`), Shift Invariance (`shift-invariance`)
- Refuted (a model satisfies the package and violates these): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Mixture Independence (`independence`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Rich Outcomes (`rich-outcomes`), Scale Invariance (`scale-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`)

#### Independent Sum Invariance + Stochastic Equivalence

Assumes: `independent-sum-consistency`, `stochastic-equivalence`.

- Rules out (entails their negations): nothing further
- Entails: Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Preservation (`independent-sum-preservation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Shift Invariance (`shift-invariance`)
- Refuted (a model satisfies the package and violates these): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Expected Utility (`expected-utility`), Mixture Independence (`independence`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Restricted Totality (`restricted-totality`), Rich Outcomes (`rich-outcomes`), Scale Invariance (`scale-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Sure-Thing (`sure-thing`)

#### Totality + Independent Sum Preservation

Assumes: `totality`, `independent-sum-preservation`.

- Rules out (entails their negations): nothing further
- Entails: Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`)
- Refuted (a model satisfies the package and violates these): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Mixture Independence (`independence`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Rich Outcomes (`rich-outcomes`), Scale Invariance (`scale-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`)

#### Rich Outcomes + Negative Affine Anti-Invariance

Assumes: `rich-outcomes`, `negative-affine-anti-invariance`.

- Rules out (entails their negations): nothing further
- Entails: Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`)
- Refuted (a model satisfies the package and violates these): Antitonic Sum Invariance (`antitonic-sum-consistency`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Folded Expectation (`folded-expectation`), Full Sum Invariance (`full-sum-consistency`), Independent Sum Cancellation (`independent-sum-cancellation`), Independent Sum Invariance (`independent-sum-consistency`), Independent Sum Preservation (`independent-sum-preservation`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`), Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), CDF-Area Extension (`cdf-area-extension`), Comonotonic Sum Invariance (`comonotonic-sum-consistency`), Existential Copula Sum Invariance (`existential-copula-sum-consistency`), Expected Utility (`expected-utility`), Mixture Independence (`independence`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`)

## 7. Additional write-ups

Hand-written notes not attached to a single record.

### `falsity-migration`

#### Falsity-constraint migration

Negative conclusions now use an additional premise and `conclusion: false`.
The following retired display nodes are preserved here for reference; their results retain their IDs, proofs and sources.

##### Failure of Full Sum Consistency (`failure-full-sum-consistency`)

Negation of `full-sum-consistency`. Full Sum Consistency does not hold: an admissible triple witnesses failure of its biconditional.

Sources:

- Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §6.1, p. 17

##### Failure of Antitonic Sum Consistency (`failure-antitonic-sum-consistency`)

Negation of `antitonic-sum-consistency`. Antitonic Sum Consistency does not hold: an admissible triple witnesses failure of its biconditional.

Sources:

- Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; Theorem 6, p. 19

##### Failure of Archimedean Gambles (`failure-archimedean-gambles`)

Negation of `archimedean-gambles`. There exist X ≻ Y ≻ Z such that no p ∈ (0,1) satisfies Y ~ M_p(X,Z).

Sources:

- Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 22

##### Failure of Countable Sure-Thing (`failure-countable-sure-thing`)

Negation of `countable-sure-thing`. Countable Sure-Thing is false: there are X,Y and a countable positive-probability partition satisfying its conditional premises but failing its corresponding weak or strict conclusion.

Sources:

- Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §§2.2–2.3, pp. 674–676

##### Failure of Independent Sum Consistency (`failure-independent-sum-consistency`)

Negation of `independent-sum-consistency`. Independent Sum Consistency does not hold: an admissible triple witnesses failure of its biconditional.

Sources:

- Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §4, especially the acknowledged error on p. 12

### `l1-translation`

#### Translating the source's L¹ metric to random variables

In *Symmetries of value*, p. 23, distance between two laws is the infimum of
E|A−B| over all couplings, with infinity allowed. Call this extended metric W.
The node in this topic instead uses E|X_n−X| for the actual variables.

Assume **Stochastic Equivalence**, the full random-variable domain, and the
real chart used in the source theorem packages. If W-continuity holds, then
actual-coupling L¹ convergence implies W-convergence, so the topic's closure
clause follows immediately.

Conversely, suppose laws μ_n converge to μ in W. Pick couplings (A_n,B_n) with
laws μ_n,μ and E|A_n−B_n|→0 (an approximate infimum within 1/n suffices).
On a standard Borel space, disintegrate these couplings over their common
second marginal and realize them with a single B of law μ and a sequence of
auxiliary uniform random variables. The resulting A'_n all share the same B
and satisfy E|A'_n−B|→0. All are realizable on the standing atomless space.
By Stochastic Equivalence, each comparison of μ_n with a fixed law ν holds
for these representatives as well. Apply the topic's continuity clause and
transfer the conclusion back by Stochastic Equivalence.

Without Stochastic Equivalence the transfer between representatives is
unavailable. This is why a metric on laws was not used in the node definition:
its zero-distance constant sequences would already force equal-law variables
to be indifferent by reflexivity and closure.

This verifies a **translation of the continuity assumption**. It does not
independently prove the paper's DTU ⇒ EU extension after adding continuity,
or the reverse direction of its Corollary 5. Those are cited source results.

## 8. Where this came from

Source documents are in `topics/unbounded-utility/sources/`. The extraction log, with transcription decisions and deliberately deferred items, is `topics/unbounded-utility/extraction.md`. Read it before trusting any single page reference.
