# Unbounded utility: random variables — complete map

Topic `unbounded-utility`. Generated 2026-09-08T15:53:45+00:00.

31 principles, 36 proved results, 2 recorded conjectures, 4 models.

This file is self-contained. Every principle statement, every proof, every model construction and every derived verdict in the database is reproduced below. `README.md` gives the semantics and the rules for adding to it; `OPEN-QUESTIONS.md` lists what is not settled.


First source-based extraction from Goodsell (2024, 2026). Preordering is standing; stochastic equivalence, outcome richness, and outcome Archimedeanness are explicit principles.

## 1. Framework


Gambles are measurable outcome-valued random variables on an atomless standard probability space. All such variables are available (Prospect Richness is standing). ≽ is reflexive and transitive, not assumed total or law-invariant. Outcomes are linearly ordered, with distinct reference outcomes 0 and 1, and sure-indifferent outcomes identified. A possibly partial real utility chart is defined by binary certainty comparisons; see background.md. Rich Outcomes supplies all real levels; Archimedean Outcomes rules out outcomes beyond the finite chart. M_p(X,Y) is randomized selection, never the pointwise sum pX+(1-p)Y.

**Notation.** X ≽ Y; X ≻ Y iff X ≽ Y and not Y ≽ X; X ~ Y iff both. L(X) is the law, X|E is X on E and sure 0 elsewhere. Numerical expressions use the normalized utility chart.

**Fixed background assumptions.** None. Every principle below is optional and must be assumed explicitly.

**Named package `du` (DU).** Rich Outcomes (`rich-outcomes`), Totality (`totality`), Stochastic Equivalence (`stochastic-equivalence`), Simple Expected Utility (`simple-eu`), Stochastic Dominance (`stochastic-dominance`), Mixture Independence (`independence`). Loaded by default in the viewer.

## 2. Background and standing conventions

*Reproduced from `topics/unbounded-utility/background.md`.*

This topic records a first reading of **Decision theory unbound** (Goodsell,
2024; published online in 2023) and **Symmetries of value** (Goodsell, 2026).
The source PDFs are in this topic's `sources/` directory:
[Decision theory unbound](topics/unbounded-utility/sources/Nous%20-%202023%20-%20Goodsell%20-%20Decision%20theory%20unbound%20%281%29.pdf)
and [Symmetries of value](topics/unbounded-utility/sources/Goodsell%20-%202026%20-%20Symmetries%20of%20value.pdf).
See `extraction.md` for the source inventory, limitations, and transcription notes.

### Objects and standing assumptions

A gamble is a measurable **outcome-valued random variable** X on a fixed
atomless standard probability space, which can be represented by [0,1] with
Lebesgue measure or by countably many independent fair coin tosses. All such
variables are available. Thus the first paper's **Prospect Richness** is a
domain convention here; it is different from the **Rich Outcomes** node.

The relation ≽ on gambles is reflexive and transitive. Write X ~ Y when both
comparisons hold, and X ≻ Y when X ≽ Y but not Y ≽ X. **Totality is optional.**
Outcomes themselves are linearly ordered by their sure comparisons; outcomes
indifferent for sure are identified. There are two distinct reference outcomes
called 0 and 1, with 1 ≻ 0. These are outcome and nondegeneracy conventions,
not an assumption that all gambles are comparable.

Equal random variables are the same object, but random variables with the same
law need not be indifferent. **Stochastic Equivalence is optional.** In
particular, do not replace a variable with an independent copy in a preference
comparison without an axiom that licenses the replacement. Almost-sure
indifference also follows from the dominance or equivalence axioms when used;
it is not an extra background preference axiom.

### Mixtures and restrictions

M_p(X,Y) means a p chance of X and a 1-p chance of Y. Fix the following lift on
[0,1], with an arbitrary fixed convention at endpoints:

- if 0 ≤ w < p, M_p(X,Y)(w) = X(w/p);
- otherwise, M_p(X,Y)(w) = Y((w-p)/(1-p)).

Its law is the mixture of the input laws. It is **not** the pointwise utility
average pX+(1-p)Y. Associativity and commutativity of probability mixtures are
identities of laws; their use as preference identities requires Stochastic
Equivalence. All theorem imports from the distribution formulation retain that
axiom explicitly or obtain it from Stochastic Dominance.

X|E equals X on E and the reference outcome 0 off E. Set X ≽_E Y iff
X|E ≽ Y|E. This is the first paper's definition, not conditional expectation
and not a fresh ranking conditional on a changed probability measure.

### Real utility levels and the two outcome principles

Do not make all outcomes real-valued utilities by definition: doing so would
hide the outcome assumption the user wants to inspect. Start with an ordered
standard Borel outcome space O. Its finite real utility chart u is calibrated by
binary comparisons relative to 0 and 1, as in Decision theory unbound, §2.1,
footnote 9:

- for 0 ≤ r ≤ 1, u(o)=r means o ~ M_r(1,0);
- for r > 1, u(o)=r means 1 ~ M_(1/r)(o,0);
- for r < 0, u(o)=r means 0 ~ M_(-r/(1-r))(1,o).

The better outcome is placed first in each binary mixture. In the negative
branch this exchanges the two branches of the source's notation, to align
the fixed random-variable lift with Archimedean Outcomes. Under the source's
Stochastic Equivalence the two conventions agree. No branch exchange is
silently used as an indifference when Stochastic Equivalence is absent.

The chart, wherever defined, is understood to be single-valued, measurable,
and compatible with the sure-outcome order; sure-indifferent outcomes have
already been identified. These are the source's utility-level conventions.
They are not a representation of preferences over all gambles. The remaining
axioms constrain how these binary comparisons extend to other random variables.

**Rich Outcomes:** every r ∈ ℝ occurs in this chart. This does not exclude
additional outcomes lacking a finite level. It is the first paper's axiom
called "Unbounded Utility", which is stronger than mere unboundedness.

**Archimedean Outcomes:** whenever sure a ≻ b ≻ c, there is p ∈ (0,1) such
that b ~ M_p(a,c). This supplies a finite chart coordinate for every outcome:
apply the condition to o and the reference pair 0,1 in their order. It does
not require that every real coordinate be realized. In particular it must not
be conflated with **Archimedean Gambles**, which quantifies over arbitrary
gambles in all three positions.

The **Simple Expected Utility** node asserts that this chart is total and
represents every finite-valued gamble by its expectation. Surjectivity is
deliberately omitted from that node and supplied by **Rich Outcomes**.
Consequently Simple EU implies Archimedean Outcomes, but no implication from
Rich Outcomes to Archimedean Outcomes is recorded.

Arithmetic notation such as X+b and −X abbreviates transforming the **utility
levels of the outcomes of X**, using u and its inverse on realized levels.
Numerical principles quantify over variables in the finite chart for which
the indicated transformed outcomes are available; they make no claim about
outcomes outside that chart. Full affine-group composition uses Rich Outcomes.
The source theorem packages include Rich Outcomes and Simple EU, so their
chart is all of ℝ and all the operations exist. Thus, throughout the numerical
proofs, X may simply be read as the real random variable u(X).

### Expectation and continuity

An ordinary expected utility in this dataset is **finite**: E|u(X)|<∞.
The sources treat St Petersburg as lacking an expected utility for their EU
principle. No rule comparing equal +∞ expectations is imported, and a
conditionally convergent series is not treated as a Lebesgue expectation.

Relative Expectation uses the expectation of the **pointwise difference**
u(X)-u(Y), which can be integrable when neither variable is. Mixtures remain
randomized selection, so these are different operations.

The L¹ node uses E|u(X_n)-u(X)|→0 for the variables' actual coupling, and the
upper-section closure clause printed in Symmetries, p. 23. This does not impose
Stochastic Equivalence by definition. With Stochastic Equivalence and the full
random-variable domain it is equivalent to the source's infimum-over-couplings
metric; the translation is explained in `writeups/l1-translation.md`.

Folded expectation requires absolute integrability of the *combined tail
difference*. It does not require each tail to be integrable and does not mean
merely taking a conditionally convergent improper integral.

### Source theorem packages

Preordering and availability of all random variables are standing throughout.
The 2026 paper's DTU is represented by:

**Rich Outcomes + Totality + Stochastic Equivalence + Simple EU + Stochastic
Dominance + Mixture Independence.**

The Stochastic Equivalence premise is redundant given this topic's weak-plus-
strict Dominance node, but is retained in imports to make the translation
visible. Archimedean Outcomes follows from Simple EU. **DTU + Sym** additionally
assumes Negative Affine Anti-Invariance, which supplies Positive Affine
Invariance as well as reflection. The elementary decomposition is recorded.

Full sufficient premise packages are preferred over unproved claims that a
paper's assumptions are minimal. There are no Lean files or Lean claims.

### Evidence and logical limitations

Provenance names the direct source: **Decision Theory Unbound**, **Symmetries
of Value**, or **Misc.** for original connecting proofs and one-off suggestions.
All records retain precise source references. The certificate names the mathematical author in
`produced_by` and credits AI transcription separately in `recorded_by`.
The checker list remains empty: human authorship of the source does not assert
human checking of its database transcription. A proved status here includes
**an application of a cited source theorem**; it does not mean that every
published proof has been independently audited. The record states when a
source supplies no expanded proof.

Countermodels witness non-implication. Source-based existence models are not
implemented comparison algorithms. The executable checks verify selected
concrete witness calculations, not arbitrary infinite or nonconstructive claims.

The two "Failure of ..." nodes express genuine negations, recorded with
explicit `negates` links. If the background implies both sides of either pair,
the graph displays a red inconsistency warning and hides all arrows. This
check uses proved results under the current source filters. The inference
engine still uses positive Horn rules; it does not infer arbitrary statements
from a contradiction. Missing arrows and missing model flags mean **not recorded**.

## 3. Principles

### Basic decision theory

#### Archimedean Gambles — `archimedean-gambles`


For any gambles X ≻ Y ≻ Z, there is p ∈ (0,1) with Y ~ M_p(X,Z). Unlike Archimedean Outcomes, X,Y,Z may themselves be unbounded gambles.

Tags: mixture, continuity.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 22, footnote 3

#### Archimedean Outcomes — `archimedean-outcomes`


For any three sure outcomes a ≻ b ≻ c, some nontrivial mixture of the outer two is equally good as the intermediate one: b ~ M_p(a,c) for some p ∈ (0,1). Only the three inputs are sure outcomes. This is the no-infinite-ratios condition, not continuity of preferences over arbitrary gambles.

Formal: `a ≻ b ≻ c ⇒ ∃p∈(0,1): b ~ M_p(a,c)`

Tags: outcomes.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 22, footnote 3
- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 678

#### Countable Sure-Thing — `countable-sure-thing`


For every countable measurable partition (E_n) into events of positive probability, if X|E_n ≽ Y|E_n for every n, then X ≽ Y. If one conditional comparison is strict, X ≻ Y.

Tags: conditioning, countable.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.2, p. 674

#### Failure of Archimedean Gambles — `failure-archimedean-gambles`


There exist X ≻ Y ≻ Z such that no p ∈ (0,1) satisfies Y ~ M_p(X,Z).

Explicit negation of Archimedean Gambles (`archimedean-gambles`).

Tags: incompatibility.

Notes. Logical negation of archimedean-gambles; the negates link enables inconsistency detection.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 22

#### Failure of Countable Sure-Thing — `failure-countable-sure-thing`


Countable Sure-Thing is false: there are X,Y and a countable positive-probability partition satisfying its conditional premises but failing its corresponding weak or strict conclusion.

Explicit negation of Countable Sure-Thing (`countable-sure-thing`).

Tags: incompatibility.

Notes. This node is the logical negation of countable-sure-thing. The negates link enables inconsistency detection; see extraction.md.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §§2.2–2.3, pp. 674–676

#### Mixture Independence — `independence`


For all X,Y,Z and 0<p<1, X ≽ Y iff M_p(X,Z) ≽ M_p(Y,Z), where M is the fixed randomized-selection construction described in the background.

Formal: `X ≽ Y ⇔ M_p(X,Z) ≽ M_p(Y,Z)`

Tags: mixture.

Notes. Mixture identities are identities in law; without Stochastic Equivalence they cannot be substituted as preference identities. Bridges to Sure-Thing explicitly retain Stochastic Equivalence.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 679
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 23

#### Restricted Stochastic Equivalence — `restricted-stochastic-equivalence`


If simple gambles X,Y have the same law, then X ~ Y.

Tags: distribution, finite.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.3, p. 675

#### Restricted Totality — `restricted-totality`


Every two simple (finite-valued) gambles are comparable. Outcome comparability is already standing in this topic.

Tags: ordering, finite.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.3, p. 675

#### Rich Outcomes — `rich-outcomes`


Every real number r occurs as a utility level of a sure outcome: for each r ∈ ℝ there is an outcome o_r with u(o_r)=r, with u defined by the normalized binary-mixture comparisons in the background. This does not assert that every outcome has a finite real level.

Formal: `∀r∈ℝ ∃o∈O_fin: u(o)=r`

Tags: outcomes.

Notes. Stronger than merely having no upper bound. Kept separate from Archimedean Outcomes at the user’s request. No Rich Outcomes ⇒ Archimedean Outcomes edge is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.2, p. 673 (called Unbounded Utility)
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, pp. 22–23

#### Simple Expected Utility — `simple-eu`


The normalized real utility chart u is defined on every outcome, is measurable, and ranks every pair of simple random variables exactly by finite expected utility: X ≽ Y iff E[u(X)] ≥ E[u(Y)]. Surjectivity of u is not included here.

Formal: `X,Y simple ⇒ (X ≽ Y ⇔ E[u(X)] ≥ E[u(Y)])`

Tags: expectation, finite.

Notes. The papers sometimes bundle a bijective representation with Simple EUT. Here its surjectivity is split out as Rich Outcomes. This principle does entail Archimedean Outcomes.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 680
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 23

#### Statewise Dominance — `statewise-dominance`


If X ≥ Y almost surely in the sure-outcome order, then X ≽ Y; if also P(X>Y)>0, then X ≻ Y.

Tags: dominance.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, pp. 678–679

#### Stochastic Dominance — `stochastic-dominance`


If P(X>o) ≥ P(Y>o) for every outcome threshold o, then X ≽ Y; if one threshold inequality is strict, X ≻ Y. Thresholds use the sure-outcome order.

Tags: dominance, distribution.

Notes. Includes the weak clause, as in the random-variable statement of the 2024 paper. The 2026 distribution formulation writes only the strict clause because equality of laws has already been identified there.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 678

#### Stochastic Equivalence — `stochastic-equivalence`


If X and Y have the same probability law over outcomes, then X ~ Y. The variables remain distinct objects; indifference is an additional axiom.

Formal: `L(X)=L(Y) ⇒ X ~ Y`

Tags: distribution.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.2, p. 674

#### Sure-Thing — `sure-thing`


For an event E with 0<P(E)<1, if X|E ~ Y|E, then X ≽ Y iff X|Eᶜ ≽ Y|Eᶜ. Here X|E equals X on E and sure 0 elsewhere; it is not a conditional expectation.

Tags: conditioning.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.2, p. 673

#### Totality — `totality`


For all gambles X,Y, either X ≽ Y or Y ≽ X.

Tags: ordering.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.2, p. 673

### Invariance principles

#### Negative Affine Anti-Invariance — `negative-affine-anti-invariance`


For all real a>0 and b, X ≽ Y iff −aY+b ≽ −aX+b.

Tags: symmetry.

Notes. Arithmetic uses the utility chart, on finite-level variables with the required transformed outcomes available. The source’s full ℝ setting is supplied by Rich Outcomes and Simple EU in theorem packages.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.2, pp. 686–688
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

#### Uniqueness of Negative Self-Similarity — `negative-self-similarity`


Fix 0<p<1, a>0, b∈ℝ and Z. If X ~ M_p(−aX+b,Z) and Y ~ M_p(−aY+b,Z), then X ~ Y. This records the uniqueness-in-value content of Theorem 10.

Tags: mixture, symmetry.

Notes. The paper also supplies a geometric-mixture solution. Its expanded formula has an apparent sign/power typo; the extraction records the unambiguous uniqueness statement.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 10, pp. 30–31

#### Positive Affine Invariance — `positive-affine-invariance`


For all real a>0 and b, X ≽ Y iff aX+b ≽ aY+b.

Tags: symmetry.

Notes. Arithmetic uses the utility chart, on finite-level variables with the required transformed outcomes available. The source’s full ℝ setting is supplied by Rich Outcomes and Simple EU in theorem packages.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.2, pp. 686–688
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

#### Reflection Anti-Invariance — `reflection-anti-invariance`


X ≽ Y iff −Y ≽ −X, using the one fixed normalized origin 0.

Tags: symmetry.

Notes. Arithmetic changes outcomes via their utility levels; it is not a relabeling of the utility function. Applies to finite-level variables when the indicated outcome transformation is available. Full-group implications explicitly assume Rich Outcomes. Reflection reverses the comparison; the displayed same-direction sign on p. 24 of Symmetries is a source typo, as its other definitions and proofs confirm.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.2, pp. 686–688
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

#### Scale Invariance — `scale-invariance`


For every real a>0, X ≽ Y iff aX ≽ aY.

Tags: symmetry.

Notes. Arithmetic uses the utility chart, on finite-level variables with the required transformed outcomes available. The source’s full ℝ setting is supplied by Rich Outcomes and Simple EU in theorem packages.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.2, pp. 686–688
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

#### Shift Invariance — `shift-invariance`


For every real b, X ≽ Y iff X+b ≽ Y+b.

Tags: symmetry.

Notes. Arithmetic uses the utility chart, on finite-level variables with the required transformed outcomes available. The source’s full ℝ setting is supplied by Rich Outcomes and Simple EU in theorem packages.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.2, pp. 686–688
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

#### Transfer of a Shift Across a Mixture — `shift-transfer`


For all real b and 0<p<1, M_p(X+b/p,Y) ~ M_p(X,Y+b/(1−p)). Variables and transformed outcomes are in the real utility chart.

Tags: mixture, symmetry.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 3, pp. 25–26

### Extensions of EUT

#### Expected Utility — `expected-utility`


The normalized chart u is defined on all outcomes and is measurable. Whenever u(X),u(Y) are integrable, X ≽ Y iff E[u(X)] ≥ E[u(Y)]. Expectations here are finite Lebesgue expectations; this says nothing about two +∞ expectations or conditionally convergent sums.

Tags: expectation.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.1, p. 685
- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 23

#### Folded Expectation — `folded-expectation`


Put h_X(t)=P(u(X)>t)−P(u(X)<−t) for t≥0. If ∫₀∞|h_X(t)|dt and ∫₀∞|h_Y(t)|dt are finite, compare X,Y exactly by F(X)=∫₀∞h_X(t)dt and F(Y). Boundary atoms do not change these integrals.

Tags: expectation.

Notes. Absolute Lebesgue integrability of the combined tail difference is essential. Mere convergence of an improper integral is a different proposal. Symmetric laws have F=0, however heavy their tails.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, pp. 27–29

#### L¹ Continuity (random variables) — `l1-continuity`


On variables with real utility levels, if E|u(X_n)−u(X)| → 0 and X_n ≽ Y for every n, then X ≽ Y. Only the upper-section clause is imposed, matching the paper. Distance can be infinite between other pairs.

Formal: `E|u(X_n)−u(X)|→0 and ∀n X_n ≽ Y ⇒ X ≽ Y`

Tags: continuity.

Notes. Uses the actual coupling of random variables, so does not build in law invariance. With Stochastic Equivalence and the standing availability of all variables this is equivalent to the paper’s extended Wasserstein-1 (infimum-over-couplings) formulation; see writeups/l1-translation.md.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 23

#### Relative Expectation — `relative-expectation`


For real-utility variables X,Y on the same probability space, if E|u(X)−u(Y)|<∞, then X ≽ Y iff E[u(X)−u(Y)] ≥ 0. Their individual expectations may both be undefined.

Tags: expectation, relative.

Notes. This is a same-space random-variable principle. Stochastic Equivalence is retained separately when importing the paper’s arbitrary-coupling formulation about laws.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, p. 26

#### Simple Relative Expectation — `simple-relative-expectation`


For real-utility variables X,Y on the same probability space, if u(X)−u(Y) takes finitely many values, X ≽ Y iff E[u(X)−u(Y)] ≥ 0. X and Y themselves need not be simple or integrable.

Tags: expectation, relative, finite.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, p. 26

### Prospect evaluations

#### Alternating St Petersburg = −1/2 — `alternating-st-petersburg-value`


Every X with P(u(X)=(−2)^n)=2^(−n), n≥1, is indifferent to sure utility −1/2.

Tags: evaluation.

Notes. A comparison with a sure outcome, not an assertion that the ordinary expected utility exists.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 9, p. 30

#### Arroyo = ln 2 — `arroyo-value`


Every X with P(u(X)=(−1)^(n+1)(n+1))=1/[n(n+1)], n≥1, is indifferent to sure utility ln 2.

Tags: evaluation.

Notes. A comparison with a sure outcome, not an assertion that the ordinary expected utility exists.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 8, pp. 29–30

#### Pasadena = ln 2 — `pasadena-value`


Every X with P(u(X)=−(−2)^n/n)=2^(−n), n≥1, is indifferent to sure utility ln 2.

Tags: evaluation.

Notes. A comparison with a sure outcome, not an assertion that the ordinary expected utility exists.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 11, pp. 32–33

#### Symmetric Gambles Are Neutral — `symmetric-neutrality`


If u(X) and −u(X) have the same law, then X ~ 0.

Tags: evaluation, symmetry.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, p. 27

## 4. Results

Each result is a Horn clause: the conjunction of its premises entails its conclusion, relative to the framework above. Premises are sufficient; minimality is not claimed.

### 4.1 Proved

#### Archimedean Gambles ⇒ Archimedean Outcomes — `archimedean-gambles-restricts`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Archimedean Gambles (`archimedean-gambles`)

Conclusion: Archimedean Outcomes (`archimedean-outcomes`)

Proof.

Sure outcomes are particular gambles. Restrict the triple of quantified gambles to constants.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, p. 22, footnote 3
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/archimedean-gambles-restricts.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/archimedean-gambles-restricts.yaml`.

#### Stochastic Dominance ⇒ Stochastic Equivalence — `dominance-implies-equivalence`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Stochastic Dominance (`stochastic-dominance`)

Conclusion: Stochastic Equivalence (`stochastic-equivalence`)

Proof.

Equal laws give equal upper-tail probabilities at every outcome threshold. Apply the weak dominance clause in both directions.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 678

Record: `topics/unbounded-utility/results/dominance-implies-equivalence.yaml`.

#### Archimedean Outcomes ∧ Stochastic Dominance ⇒ Statewise Dominance — `dominance-implies-statewise`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Archimedean Outcomes (`archimedean-outcomes`)
- Stochastic Dominance (`stochastic-dominance`)

Conclusion: Statewise Dominance (`statewise-dominance`)

Proof.

Use the real outcome chart supplied by Archimedean Outcomes. If X≥Y almost surely, {Y>t}⊆{X>t} modulo null events. If P(X>Y)>0, the countable family of rational cuts contains a cut with P(Y≤t<X)>0; approximate by a realized outcome threshold if necessary. The strict tail inequality then gives strict preference.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, pp. 678–679 and footnote 19

Record: `topics/unbounded-utility/results/dominance-implies-statewise.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ L¹ Continuity (random variables) ⇒ Expected Utility — `dtu-l1-implies-eu`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Expected Utility (`expected-utility`)

Proof.

Source-stated implication, §3, p. 23: adding L¹ Continuity to DTU yields Expected Utility. Stochastic Equivalence makes the quotient ordering on laws well-defined; the remaining premises give exactly the source’s DTU, with the surjectivity part of its Simple EU supplied separately by Rich Outcomes. The L¹ translation write-up establishes that the random-variable continuity axiom implies the source’s metric continuity. Apply the stated theorem and pull its expected-utility comparison back to X,Y. The source does not supply an expanded proof of the underlying implication; this is a theorem application and translation, not a new proof of that theorem.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 23

Record: `topics/unbounded-utility/results/dtu-l1-implies-eu.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ⇒ Failure of Archimedean Gambles — `dtu-refutes-archimedean-gambles`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)

Conclusion: Failure of Archimedean Gambles (`failure-archimedean-gambles`)

Proof.

Let S have P(u(S)=2^n)=2^(−n). For any real c choose N with N>c. The simple truncation min(S,2^N) has expectation N+1 and is stochastically dominated by S. Thus S≻c. In particular S≻1≻0. Every M_p(S,0), p>0, is also better than every sure outcome: its simple truncations have arbitrarily large finite expectations. Hence none is indifferent to 1. This violates Archimedean Gambles while preserving Archimedean Outcomes.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 22

Record: `topics/unbounded-utility/results/dtu-refutes-archimedean-gambles.yaml`.

#### Rich Outcomes ∧ Archimedean Outcomes ∧ Stochastic Equivalence ∧ Statewise Dominance ⇒ Stochastic Dominance — `equivalence-and-statewise-imply-dominance`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Statewise Dominance (`statewise-dominance`)

Conclusion: Stochastic Dominance (`stochastic-dominance`)

Proof.

On the full real chart, first-order dominance permits quantile realizations X′,Y′ using the same uniform random variable with X′≥Y′ almost surely. Distinct laws give P(X′>Y′)>0. Statewise Dominance compares these realizations, and Stochastic Equivalence plus transitivity transfers that comparison to X,Y. All realizations exist by standing Prospect Richness.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, footnote 19 (RV/quantile translation)

Record: `topics/unbounded-utility/results/equivalence-and-statewise-imply-dominance.yaml`.

#### Expected Utility ⇒ Simple Expected Utility — `expected-utility-implies-simple`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Expected Utility (`expected-utility`)

Conclusion: Simple Expected Utility (`simple-eu`)

Proof.

All simple variables have finite real expected utility. Restrict Expected Utility to them.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §4.1, p. 685
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/expected-utility-implies-simple.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/expected-utility-implies-simple.yaml`.

#### Archimedean Outcomes ∧ Folded Expectation ⇒ Expected Utility — `folded-implies-eu`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Archimedean Outcomes (`archimedean-outcomes`)
- Folded Expectation (`folded-expectation`)

Conclusion: Expected Utility (`expected-utility`)

Proof.

For an integrable real utility variable, the integral of the absolute folded tail difference is bounded by E|u(X)|, and the tail-integral formula gives F(X)=E[u(X)]. Archimedean Outcomes makes the chart total. Restrict the Folded Expectation comparison to integrable X,Y.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, p. 27
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/folded-implies-eu.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/folded-implies-eu.yaml`.

#### Rich Outcomes ∧ Folded Expectation ⇒ Symmetric Gambles Are Neutral — `folded-implies-symmetric-neutrality`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Folded Expectation (`folded-expectation`)

Conclusion: Symmetric Gambles Are Neutral (`symmetric-neutrality`)

Proof.

For a symmetric real law, h_X(t)=0 almost everywhere, so F(X)=0. The zero constant also has folded value zero; apply Folded Expectation.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, pp. 27–28

Record: `topics/unbounded-utility/results/folded-implies-symmetric-neutrality.yaml`.

#### Stochastic Equivalence ∧ Mixture Independence ⇒ Sure-Thing — `independence-to-sure-thing`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Stochastic Equivalence (`stochastic-equivalence`)
- Mixture Independence (`independence`)

Conclusion: Sure-Thing (`sure-thing`)

Proof.

Let p=P(E). Realize the conditional laws on E and Eᶜ as A,B for X and C,D for Y. Law invariance gives X~M_p(A,B), Y~M_p(C,D), X|E~M_p(A,0), Y|E~M_p(C,0). Independence cancels 0 to yield A~C from the hypothesis. Replace indifferent mixture components and cancel the common E component: X≽Y iff B≽D. The latter is equivalent to X|Eᶜ≽Y|Eᶜ by independence and law invariance.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 679 and p. 682, footnote 28

Record: `topics/unbounded-utility/results/independence-to-sure-thing.yaml`.

#### Rich Outcomes ∧ Negative Affine Anti-Invariance ⇒ Positive Affine Invariance — `negative-affine-implies-positive-affine`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Positive Affine Invariance (`positive-affine-invariance`)

Proof.

Compose x↦−x with x↦−ax+b. Both reverse the ordering, so their composition x↦ax+b preserves it. Rich Outcomes supplies all intermediate outcome levels.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

Record: `topics/unbounded-utility/results/negative-affine-implies-positive-affine.yaml`.

#### Negative Affine Anti-Invariance ⇒ Reflection Anti-Invariance — `negative-affine-implies-reflection`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Reflection Anti-Invariance (`reflection-anti-invariance`)

Proof.

Set a=1,b=0. The order is reversed.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24 (corrected sign)

Record: `topics/unbounded-utility/results/negative-affine-implies-reflection.yaml`.

#### Rich Outcomes ∧ Archimedean Outcomes ∧ Totality ∧ Stochastic Dominance ∧ Sure-Thing ⇒ Simple Expected Utility — `original-dtu-implies-simple-eu`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Totality (`totality`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)

Conclusion: Simple Expected Utility (`simple-eu`)

Proof.

Goodsell §3.2 gives the finite-lottery representation consequence of the original DTU axioms. Stochastic Dominance includes law invariance; Sure-Thing becomes Independence on laws. Restrict to finite gambles and use the outcome mixture calibrations to obtain the normalized vNM utility representation. Prospect Richness, Preordering and comparable outcomes are standing here.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, pp. 679–681 (representation result)

Record: `topics/unbounded-utility/results/original-dtu-implies-simple-eu.yaml`.

#### Positive Affine Invariance ⇒ Scale Invariance — `positive-affine-implies-scale`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Positive Affine Invariance (`positive-affine-invariance`)

Conclusion: Scale Invariance (`scale-invariance`)

Proof.

Set b=0.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/positive-affine-implies-scale.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/positive-affine-implies-scale.yaml`.

#### Positive Affine Invariance ⇒ Shift Invariance — `positive-affine-implies-shift`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Positive Affine Invariance (`positive-affine-invariance`)

Conclusion: Shift Invariance (`shift-invariance`)

Proof.

Set a=1.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/positive-affine-implies-shift.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/positive-affine-implies-shift.yaml`.

#### Rich Outcomes ∧ Positive Affine Invariance ∧ Reflection Anti-Invariance ⇒ Negative Affine Anti-Invariance — `positive-reflection-imply-negative`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)

Conclusion: Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Proof.

Apply reflection to reverse the comparison, then the positive transformation x↦ax+b to preserve that reversed comparison.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, p. 24

Record: `topics/unbounded-utility/results/positive-reflection-imply-negative.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Mixture Independence ∧ Reflection Anti-Invariance ⇒ Symmetric Gambles Are Neutral — `reflection-implies-symmetric-neutrality`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Mixture Independence (`independence`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)

Conclusion: Symmetric Gambles Are Neutral (`symmetric-neutrality`)

Proof.

Let H=M_1/2(X,−X). Its reflected law equals its own law, so H~−H. If H≻0, reflection gives −H≺0, contradiction; likewise if H≺0. Totality gives H~0. If X itself has symmetric law, Stochastic Equivalence gives −X~X and H~X, since the mixture then has X’s law. Thus X~0.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, pp. 25, 27

Record: `topics/unbounded-utility/results/reflection-implies-symmetric-neutrality.yaml`.

#### Archimedean Outcomes ∧ Relative Expectation ⇒ Expected Utility — `relative-implies-eu`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Archimedean Outcomes (`archimedean-outcomes`)
- Relative Expectation (`relative-expectation`)

Conclusion: Expected Utility (`expected-utility`)

Proof.

Archimedean Outcomes makes the real chart total. If u(X),u(Y) are integrable, so is their difference, and E[u(X)−u(Y)]=E[u(X)]−E[u(Y)]. Apply Relative Expectation.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, pp. 26–27
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/relative-implies-eu.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/relative-implies-eu.yaml`.

#### Relative Expectation ⇒ Simple Relative Expectation — `relative-implies-simple-relative`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Relative Expectation (`relative-expectation`)

Conclusion: Simple Relative Expectation (`simple-relative-expectation`)

Proof.

A finite-valued difference is integrable. Restrict Relative Expectation to such pairs.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §4, p. 26
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/relative-implies-simple-relative.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/relative-implies-simple-relative.yaml`.

#### Rich Outcomes ∧ Simple Expected Utility ∧ Sure-Thing ⇒ Failure of Countable Sure-Thing — `rich-simple-sure-thing-refutes-countable`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Simple Expected Utility (`simple-eu`)
- Sure-Thing (`sure-thing`)

Conclusion: Failure of Countable Sure-Thing (`failure-countable-sure-thing`)

Proof.

Use the strengthened St Petersburg contradiction from §2.3. Simple EU supplies Restricted Totality, Restricted Stochastic Equivalence and finite conditional EU calculations. With independent sequences of fair tosses let A be first-toss St Petersburg, B the same starting at toss 2, and C an independent St Petersburg variable. Conditional on B=2^n, A is a fair mixture of 2 and 2^(n+1), so its conditional expected value exceeds B by 1; Countable Sure-Thing would give A≻B. Partition the A,C space by the maximum of their finite stopping times. On each cell they are simple and their restricted laws coincide, so Countable Sure-Thing would give A~C. Repeat for B,C to get B~C, contradicting Preordering. Null sets can be assigned a finite outcome without changing the simple-law comparisons.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.3, pp. 675–676

Record: `topics/unbounded-utility/results/rich-simple-sure-thing-refutes-countable.yaml`.

#### Rich Outcomes ∧ Shift Invariance ∧ Scale Invariance ⇒ Positive Affine Invariance — `shift-scale-imply-positive-affine`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Shift Invariance (`shift-invariance`)
- Scale Invariance (`scale-invariance`)

Conclusion: Positive Affine Invariance (`positive-affine-invariance`)

Proof.

Apply Scale Invariance and then Shift Invariance. Rich Outcomes supplies all intermediate outcome levels.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §§3, 5, pp. 24, 34
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/shift-scale-imply-positive-affine.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/shift-scale-imply-positive-affine.yaml`.

#### Simple Expected Utility ⇒ Archimedean Outcomes — `simple-eu-implies-archimedean-outcomes`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Simple Expected Utility (`simple-eu`)

Conclusion: Archimedean Outcomes (`archimedean-outcomes`)

Proof.

For a≻b≻c put p=(u(b)−u(c))/(u(a)−u(c)). Then 0<p<1 and the simple variable M_p(a,c) has expectation u(b), so is indifferent to b.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, p. 22, footnote 3

Record: `topics/unbounded-utility/results/simple-eu-implies-archimedean-outcomes.yaml`.

#### Simple Expected Utility ⇒ Restricted Stochastic Equivalence — `simple-eu-implies-restricted-equivalence`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Simple Expected Utility (`simple-eu`)

Conclusion: Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)

Proof.

Equal laws of simple variables give equal finite expectations. Simple EU therefore gives both preference directions.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §§2.3, 3.2

Record: `topics/unbounded-utility/results/simple-eu-implies-restricted-equivalence.yaml`.

#### Simple Expected Utility ⇒ Restricted Totality — `simple-eu-implies-restricted-totality`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Simple Expected Utility (`simple-eu`)

Conclusion: Restricted Totality (`restricted-totality`)

Proof.

Finite real expectations are comparable, and Simple EU represents the preference in both directions.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, §3, pp. 22–23

Record: `topics/unbounded-utility/results/simple-eu-implies-restricted-totality.yaml`.

#### Stochastic Equivalence ⇒ Restricted Stochastic Equivalence — `stochastic-equivalence-restricts`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Stochastic Equivalence (`stochastic-equivalence`)

Conclusion: Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)

Proof.

Restrict the quantifiers to simple random variables.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.3, p. 675
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/stochastic-equivalence-restricts.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/stochastic-equivalence-restricts.yaml`.

#### Rich Outcomes ∧ Archimedean Outcomes ∧ Totality ∧ Stochastic Dominance ∧ Sure-Thing ⇒ Mixture Independence — `sure-thing-to-independence`

Proved result; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Totality (`totality`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)

Conclusion: Mixture Independence (`independence`)

Proof.

Source reduction, §3.2: in the original DTU framework, Stochastic Dominance yields Stochastic Equivalence. Preferences therefore descend to laws. Every law and its conditional realizations are available by Prospect Richness, and the paper identifies Sure-Thing in this quotient with von Neumann–Morgenstern Independence. Pull this implication back along X↦L(X). The full original DTU assumptions are retained; a weaker converse for arbitrary incomplete orders has not been extracted.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §3.2, p. 679

Record: `topics/unbounded-utility/results/sure-thing-to-independence.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ⇒ Alternating St Petersburg = −1/2 — `symmetry-evaluates-alternating`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)

Proof.

The law identity A =d M_1/2(−2,−2A) gives indifference by Stochastic Equivalence. If A≻−1/2 then −2A≺1, so Independence and Simple EU imply A~M_1/2(−2,−2A)≺M_1/2(−2,1)~−1/2, contradiction. The opposite strict case is analogous. Totality gives A~−1/2.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 9, p. 30

Record: `topics/unbounded-utility/results/symmetry-evaluates-alternating.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ⇒ Uniqueness of Negative Self-Similarity — `symmetry-implies-negative-self-similarity`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Uniqueness of Negative Self-Similarity (`negative-self-similarity`)

Proof.

If X≻Y, negative affine anti-invariance makes −aX+b≺−aY+b. Independence with the common Z then reverses the strict comparison between their mixtures. The assumed fixed-point indifferences imply X≺Y, contradiction. Interchange X,Y for the other strict case and use Totality.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 10, pp. 30–31

Record: `topics/unbounded-utility/results/symmetry-implies-negative-self-similarity.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ⇒ Transfer of a Shift Across a Mixture — `symmetry-implies-shift-transfer`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Transfer of a Shift Across a Mixture (`shift-transfer`)

Proof.

This is Theorem 3 transported from laws to random variables using Stochastic Equivalence. Reflection, Totality and Independence first make a half-mixture of V and −V indifferent to 0. Shift invariance then gives M_1/2(V+c,−V)~c/2. Pair the terms on the two sides of the proposed transfer with their negatives; both reduce to the same simple constant mixture. Independence cancels the common terms.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 3, pp. 25–26

Record: `topics/unbounded-utility/results/symmetry-implies-shift-transfer.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ⇒ Simple Relative Expectation — `symmetry-implies-simple-relative`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)

Conclusion: Simple Relative Expectation (`simple-relative-expectation`)

Proof.

Theorem 4. If D=u(X)−u(Y) has finite range, work with the diluted variables M_1/2(X,0), M_1/2(Y,0). Partition into the finitely many values of D. Transfer each constant difference to the zero branch by Theorem 3. Finite mixture substitution leaves M_1/2(Y,D) in place of M_1/2(X,0). Independence and Simple EU reduce the comparison to E[D]≥0. Law invariance permits each rearrangement of branches.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 4, pp. 26–27

Record: `topics/unbounded-utility/results/symmetry-implies-simple-relative.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ∧ L¹ Continuity (random variables) ⇒ Arroyo = ln 2 — `symmetry-l1-evaluates-arroyo`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Arroyo = ln 2 (`arroyo-value`)

Proof.

Theorem 8 evaluates the folded tail difference of A+1/2. Pair its positive and negative tails: the residual weights are 1/[2n(2n−1)]−1/[2n(2n+1)] at heights 2n+1/2, a positive integrable tail whose expectation is 1/2+ln 2. Folded Expectation gives A+1/2~1/2+ln 2. Shift Invariance gives A~ln 2.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 8, pp. 29–30

Record: `topics/unbounded-utility/results/symmetry-l1-evaluates-arroyo.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ∧ L¹ Continuity (random variables) ⇒ Pasadena = ln 2 — `symmetry-l1-evaluates-pasadena`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Pasadena = ln 2 (`pasadena-value`)

Proof.

Theorem 11. Couple Pasadena P with Highland Park H, retaining each outcome probability and replacing each negative denominator 2n by 2n−1. Then E[H−P]=−ln 2 with integrable difference. The paper writes H as M_2/3(Q,−2Q). It proves by Relative Expectation that Q~M_1/4(4Q,0), then Totality and affine invariance give Q~M_1/2(2Q,0). Reflection and Independence yield H~0; Relative Expectation together with shift transfer then gives P~ln 2. These are preference equalities, not ordinary expectations of P or H.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 11, pp. 32–33

Record: `topics/unbounded-utility/results/symmetry-l1-evaluates-pasadena.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ∧ L¹ Continuity (random variables) ⇒ Folded Expectation — `symmetry-l1-implies-folded`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Folded Expectation (`folded-expectation`)

Proof.

Theorem 6 couples the positive and negative utility tails in opposing order. Absolute integrability of the folded tail difference yields an integrable difference of these tail variables, with expectation F(X). Relative Expectation (Corollary 5) and reflection identify X with sure F(X). Apply the same construction to Y and compare the constants. Law invariance transfers the chosen couplings to the original variables.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 6, p. 27 and Figure 7, p. 29

Record: `topics/unbounded-utility/results/symmetry-l1-implies-folded.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ∧ L¹ Continuity (random variables) ⇒ Relative Expectation — `symmetry-l1-implies-relative`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- L¹ Continuity (random variables) (`l1-continuity`)

Conclusion: Relative Expectation (`relative-expectation`)

Proof.

Corollary 5. Approximate an integrable difference u(X)−u(Y) in L¹ by simple differences, apply Theorem 4, and use L¹ continuity to pass to the limit. This is recorded with the full source context DTU+Sym; the equivalence between its law metric and this topic’s random-variable continuity requires Stochastic Equivalence.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Corollary 5, p. 27

Record: `topics/unbounded-utility/results/symmetry-l1-implies-relative.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Negative Affine Anti-Invariance ∧ Relative Expectation ⇒ L¹ Continuity (random variables) — `symmetry-relative-implies-l1`

Proved result; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Premises:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Relative Expectation (`relative-expectation`)

Conclusion: L¹ Continuity (random variables) (`l1-continuity`)

Proof.

This is the reverse direction of Corollary 5 in its full DTU+Sym context. Pull preferences down to probability laws using Stochastic Equivalence and apply the source equivalence between Relative Expectation Theory and the extended L¹ metric continuity. Actual-coupling convergence implies convergence in that infimum metric, giving the random-variable clause. The source states this as a corollary without an expanded reverse-direction proof; no claim of an independent proof audit is made.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Corollary 5, p. 27

Record: `topics/unbounded-utility/results/symmetry-relative-implies-l1.yaml`.

#### Totality ⇒ Restricted Totality — `totality-restricts`

Proved result; source **Misc.**; produced by GPT-6 (Codex), 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; Lean stated; 2026-09-08.

Premises:

- Totality (`totality`)

Conclusion: Restricted Totality (`restricted-totality`)

Proof.

Restrict the quantifiers to simple random variables.

Notes. Source-based result or immediate restriction/composition. Premises are sufficient; minimality is not claimed. The direct source is recorded separately from the transcription; no translation checker is asserted.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, §2.3, p. 675
- **GPT-6 generated 8 Sep** — GPT-6 (Codex), 2026-09-08: elementary connecting proof in topics/unbounded-utility/results/totality-restricts.yaml (proof field), using the cited paper’s definitions; not a separately stated paper theorem.

Record: `topics/unbounded-utility/results/totality-restricts.yaml`.

### 4.2 Recorded conjectures

These are displayed but never used as evidence in any derivation below.

#### Countable Sure-Thing ∧ Archimedean Outcomes ⇒ Archimedean Gambles — `countable-sure-thing-outcomes-to-gambles`

Conjecture; source **Misc.**; produced by User suggestion, 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; checked by nobody; 2026-09-08.

Premises:

- Countable Sure-Thing (`countable-sure-thing`)
- Archimedean Outcomes (`archimedean-outcomes`)

Conclusion: Archimedean Gambles (`archimedean-gambles`)

No proof is recorded. This is a conjecture only.

Notes. Record the user's two-premise proposal as stated, relative to this topic's standing framework. The related Russell–Isaacs theorem uses Countable Independence, complete preferences, and countably supported lotteries; its passage from acts to lotteries assumes law invariance. A proof in the present random-variable framework, or identification of any additional necessary premises, is still required. Neither Totality nor Stochastic Equivalence should silently be treated as background. Excluded from proved deductions until verified.

Sources:

- **User suggestion 8 Sep** — User suggestion in this project's conversation, 2026-09-08; proposed implication, not a completed proof.
- **Infinite Prospects (candidate source)** — Possible related reference, not verified as establishing this exact arrow: Jeffrey Sanford Russell and Yoaav Isaacs, Infinite Prospects, Philosophy and Phenomenological Research 103 (2021), 178–198, DOI 10.1111/phpr.12704. Author-hosted manuscript, §§4–5 and Appendix A, especially pp. 15, 22, 25: https://www.yoaavisaacs.com/uploads/6/9/2/0/69204575/infinite-prospects-final.pdf

Record: `topics/unbounded-utility/results/countable-sure-thing-outcomes-to-gambles.yaml`.

#### Countable Sure-Thing ∧ Simple Expected Utility ⇒ Expected Utility — `countable-sure-thing-simple-to-full-eu`

Conjecture; source **Misc.**; produced by User suggestion, 2026-09-08; recorded by GPT-6 (Codex), 2026-09-08; checked by nobody; 2026-09-08.

Premises:

- Countable Sure-Thing (`countable-sure-thing`)
- Simple Expected Utility (`simple-eu`)

Conclusion: Expected Utility (`expected-utility`)

No proof is recorded. This is a conjecture only.

Notes. Candidate extension from finite-valued gambles to all integrable utility random variables. Verification must cover the full measurable domain, including variables with non-atomic distributions, and both directions of the expected-utility comparison. Do not silently add Rich Outcomes, Totality, Stochastic Equivalence, or Sure-Thing as premises. Rich Outcomes is optional here; the existing unbounded-utility inconsistency argument is not by itself a proof of this two-premise implication. Excluded from proved deductions until verified.

Sources:

- **User suggestion 8 Sep** — User suggestion in this project's conversation, 2026-09-08; proposed implication, not a completed proof.
- **Decision Theory Unbound** — Related motivation rather than a verified theorem with these exact premises: Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695, DOI 10.1111/nous.12473, §4.1, pp. 685–686.

Record: `topics/unbounded-utility/results/countable-sure-thing-simple-to-full-eu.yaml`.

## 5. Models

A model witnesses consistency, and so refutes every implication from what it satisfies to what it violates. Independence is never recorded directly; the model is the record.

### Total affine-symmetric extension (source existence construction) — `affine-symmetric-extension`

Model; source **Symmetries of Value**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- L¹ Continuity (random variables) (`l1-continuity`)

Violates:

- Countable Sure-Thing (`countable-sure-thing`)
- Archimedean Gambles (`archimedean-gambles`)

Unknown in this model: nothing; every principle is settled.

Construction.

Goodsell (2026), Theorem 2 constructs a total preference satisfying DTU, both affine symmetry principles, and L¹ Continuity. Start with the cone of Theorem 12, use Theorem 13 to extend any nontotal cone while preserving convexity, scale and reflection, and apply Zorn’s lemma. Fixed required comparisons preserve finite EU, dominance and prospect shifts; the end of §5 asserts preservation of L¹ Continuity. Pull the resulting ordering back from laws to all real-valued random variables. The two violations follow from the explicit St Petersburg witnesses in this topic. See the write-up for the scope of this source-based existence certificate.

Notes. This is a nonconstructive existence model, not an implemented comparator. Its existence and L¹ clause are source-attributed. No numerical test is claimed to verify Zorn’s lemma or the source proof.

Sources:

- **Symmetries of Value** — Goodsell, Symmetries of value, Noûs 60 (2026), 16–37; DOI 10.1111/nous.12549, Theorem 2, p. 24; Theorems 12–13 and end of §5, pp. 35–36

Record: `topics/unbounded-utility/models/affine-symmetric-extension.yaml`.

Write-up.

#### Affine-symmetric total extension: source existence model

Source: Goodsell, *Symmetries of value*, Theorem 2 (p. 24), with the
construction in Theorems 12–13 and the end of §5 (pp. 35–36).
Human model: Zachary Goodsell. Recorded and translated by GPT-6 (Codex);
no transcription checker asserted.

Theorem 2 asserts the consistency of DTU + Sym + L¹ Continuity. The source
constructs the ordering on probability laws via cones in the real vector
space of finite signed measures, then extends a partial ordering to a total
one. Signed measures are auxiliary proof objects, not this topic's gambles.

More specifically, Theorem 12 supplies a cone C that has the required finite
EU, dominance, scale, reflection, and prospect-shift properties, without
Totality. Theorem 13 says that a nontotal convex cone satisfying scale and
reflection has a proper extension preserving those properties and all its
existing weak and strict comparisons. Unions of chains preserve these
properties, so Zorn's lemma supplies a maximal extension. If it were nontotal,
Theorem 13 would extend it again, contradiction. Fixed required comparisons
for finite EU, dominance, and prospect shifts survive extensions. The end of
§5 asserts that the constructed model also has L¹ Continuity.

Pull the source's resulting preorder on probability laws back along X↦L(X)
on the domain of all real-valued random variables. Reflexivity, transitivity,
and Totality pull back immediately, and Stochastic Equivalence holds by
construction. The source's bijective utility representation supplies both
Rich Outcomes and this topic's Simple EU. Randomized-selection laws give
Mixture Independence, and utility transformations give the stated affine
symmetries. The L¹ translation write-up transfers source continuity to the
random-variable clause. This verifies that the cited existence theorem
applies to precisely the package listed in the model record.

The recorded St Petersburg implications then show that Countable Sure-Thing
and Archimedean Gambles fail in this model, while Archimedean Outcomes holds.
It also witnesses that adding the symmetries and L¹ is compatible with all the
evaluations extracted from §4.

This certificate is a **source theorem application and domain translation**.
It is not an implementation of the nonconstructive ordering or an independent
audit of the source's cone-extension theorem and continuity argument. No
numerical check can establish those existence claims.

### Eventual ordering of clipped expectations — `eventual-clipped-expectation`

Model; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Sure-Thing (`sure-thing`)
- Scale Invariance (`scale-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Failure of Archimedean Gambles (`failure-archimedean-gambles`)

Violates:

- Totality (`totality`)
- Expected Utility (`expected-utility`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Countable Sure-Thing (`countable-sure-thing`)
- Archimedean Gambles (`archimedean-gambles`)
- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)

Unknown in this model: Arroyo = ln 2 (`arroyo-value`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`)

Construction.

Take all real-valued random variables and let c_t(x)=max(−t,min(x,t)). Define X≽Y iff ∃s∀t>s E[c_t(X)]≥E[c_t(Y)]. The full construction, verification, and explicit witnesses are in the accompanying write-up. This is the incomplete model from Decision theory unbound, Theorem 2. It witnesses consistency of the unbounded framework and failure of full EU despite finite EU.

Executable checks: `topics/unbounded-utility/checks/countermodels.py`.

Notes. Clipping sends tails to ±t; it is not deletion of tail mass. No Shift Invariance claim is needed for this model.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, Theorem 2, pp. 683–685; Theorems 7 and 9, p. 693

Record: `topics/unbounded-utility/models/eventual-clipped-expectation.yaml`.

Write-up.

#### Eventual ordering of clipped expectations

Source: Goodsell, *Decision theory unbound*, Theorem 2, pp. 683–685;
Theorems 7 and 9, p. 693. Human model: Zachary Goodsell.
Recorded and translated by GPT-6 (Codex); no transcription checker asserted.

Take O=ℝ, all measurable random variables, and

$$c_t(x)=\max(-t,\min(x,t)),\qquad v_X(t)=\mathbb E[c_t(X)].$$

Define X≽Y iff there is s such that v_X(t)≥v_Y(t) for every t>s.

Reflexivity is immediate; transitivity follows by taking the larger of the
two thresholds. Equal-law variables have identical v-functions. Constants
have v_x(t)=x for all sufficiently large t. Hence Rich Outcomes holds,
and finite mixtures of constants have their usual expected utilities.
In particular Simple EU and Archimedean Outcomes hold.

For a randomized mixture, v_M(t)=p v_X(t)+(1-p)v_Z(t). Since p>0, comparison
with a common Z cancels, proving Independence. The recorded implication using
Stochastic Equivalence gives Sure-Thing.

For first-order dominance, use the tail-integral identity for clipped
expectations. The difference v_X(t)-v_Y(t) is the integral of the difference
of the upper-tail functions on [-t,t]. It is nonnegative. If one tail
inequality is strict, right continuity supplies an interval with positive
integral; all sufficiently large truncations therefore have a positive gap.
The preference is strictly better. This proves the weak and strict dominance
clauses, and the topic's Statewise Dominance consequence follows.

Reflection gives v_(-X)(t)=-v_X(t). Positive rescaling gives
v_(aX)(t)=a v_X(t/a); eventual comparisons are unchanged by this
reparametrization. Thus reflection and scale invariance hold. No Shift
Invariance flag is needed or claimed here.

If X has symmetric law, every clipped expectation is zero by the oddness of
c_t. Thus X~0 in this model, verifying Symmetric Gambles Are Neutral even
though Totality fails.

##### Failure of Totality

Let A take (-2)^n with probability 2^(-n), n≥1. At t=2^k,

$$v_A(2^k)=\sum_{n=1}^k(-1)^n+
              2^k\sum_{n>k}(-1)^n2^{-n}
          =\begin{cases}-2/3&k\text{ odd},\\-1/3&k\text{ even}.\end{cases}$$

Consequently neither A≽-1/2 nor -1/2≽A holds: each comparison fails at
arbitrarily large truncation levels. This is an explicit incomparability,
not a conclusion drawn from failing to find a comparison.
It also directly violates the node Alternating St Petersburg = −1/2.

##### Failure of Expected Utility and L¹ Continuity

Let N take n with probability 2^(-n), n≥1. Then E[N]=2 but, for integer k≥1,

$$v_N(k)=\mathbb E[\min(N,k)]=2-2^{1-k}<2.$$

The same strict bound holds at every finite truncation level above 2.
Thus 2≻N and EU is false. For the continuity witness, put

$$N_k=\min(N,k)+2^{1-k}.$$

Each N_k is simple and has expectation 2, so N_k~2. Yet
E|N_k-N|≤2·2^(1-k)→0 and N is not at least as good as 2. This violates
exactly the recorded upper-section L¹ Continuity clause.

##### Failure of the two gamble-level principles

The recorded Countable Sure-Thing counterargument uses only Rich Outcomes,
Simple EU, and Sure-Thing, all verified above. It therefore applies to this
model. For Archimedean Gambles, S with P(S=2^n)=2^(-n) is better than every
constant: its truncations at 2^k have expectation k+1. For p>0,
M_p(S,0) likewise has unbounded truncated expectations. Hence S≻1≻0
but no such mixture is indifferent to 1.

`checks/countermodels.py` verifies representative exact witness calculations.
The universal statements above are analytic proofs, not conclusions from
finite sampling.

### Continuous ultrafilter model: EU without full affine symmetry — `total-continuous-ultrafilter`

Model; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Expected Utility (`expected-utility`)
- Shift Invariance (`shift-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)

Violates:

- Scale Invariance (`scale-invariance`)
- Countable Sure-Thing (`countable-sure-thing`)
- Archimedean Gambles (`archimedean-gambles`)

Unknown in this model: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Relative Expectation (`relative-expectation`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`)

Construction.

Take all real-valued random variables and a cobounded ultrafilter U. Define X≽Y iff for every ε>0, {t:E[c_t(X)]≥E[c_t(Y)]−ε}∈U. This is the continuous-hyperreal quotient ordering in the proof of Theorem 3. Its EU, shift, reflection, and failed scale claims are given in Appendix B; see the accompanying write-up. Consequently Expected Utility does not imply Positive Affine Invariance, even with DTU.

Notes. No L¹ Continuity or Relative Expectation flag is inferred merely from the word continuous; these are distinct claims. Scale failure is source-attributed as above.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, Appendix B, Lemma 6 and proof of Theorem 3, p. 691; Theorems 7, 8 and 10, pp. 693–695

Record: `topics/unbounded-utility/models/total-continuous-ultrafilter.yaml`.

Write-up.

#### Continuous ultrafilter model

Source: Goodsell, *Decision theory unbound*, Appendix B, Lemma 6 and proof
of Theorem 3 (p. 691), Theorems 7, 8, and 10 (pp. 693–695).
Human model: Zachary Goodsell. Recorded and translated by GPT-6 (Codex);
no transcription checker asserted.

With U and v_X as in the exact-ultrafilter model, define

$$X\succeq Y\quad\Longleftrightarrow\quad
\text{for every }\varepsilon>0,
\{t:v_X(t)\ge v_Y(t)-\varepsilon\}\in\mathcal U.$$

This quotients out infinitesimal errors in the ultrafilter comparison.
Reflexivity and transitivity follow using ε/2 in each premise and intersecting
sets. If X is not at least as good as Y, some positive ε gives a U-large
set where Y exceeds X by ε, which implies Y≻X. This proves Totality.
The affine mixture formula for v_X gives Independence after rescaling ε.
Equal laws give equality. Constants and simple variables stabilize, giving
Rich Outcomes and Simple EU. A strict stochastic dominance comparison gives
a fixed positive gap for all sufficiently large t, and so remains strict
after taking this quotient. Thus the model satisfies DTU.

For integrable X, v_X(t)→E[X] by dominated convergence. Hence two integrable
variables are compared exactly by their finite expectations, including
indifference when those expectations agree. This proves EU, the purpose of
the continuous quotient in the source's Theorem 3.

Reflection negates clipped expectation exactly. For any fixed b,

$$c_t(X+b)-c_t(X)\longrightarrow b,\qquad
|c_t(X+b)-c_t(X)|\le |b|.$$

Dominated convergence gives v_(X+b)(t)-v_X(t)→b, even for nonintegrable X.
Simultaneously shifting X and Y therefore changes their truncated comparison
by a function tending to zero, which the quotient ignores. This proves Shift
Invariance. Reflection and shift do **not** establish scale invariance.

The failed scale flag applies the source's Theorem 10 to this continuous
ultrafilter construction. Its witness and proof-audit limitation are described
in the exact-ultrafilter write-up and `extraction.md`. Thus this is a
source-attributed witness that DTU + EU + shift + reflection does not entail
positive affine invariance. The two St Petersburg arguments establish failure
of Countable Sure-Thing and Archimedean Gambles here as well.

No L¹ Continuity or Relative Expectation flag is inferred from the name
"continuous": the quotient construction and the topic's closure axiom are
different mathematical claims.

### Total ordering by an ultrafilter of clipped expectations — `total-exact-ultrafilter`

Model; source **Decision Theory Unbound**; produced by Zachary Goodsell (cited paper); recorded by GPT-6 (Codex), 2026-09-08; transcription and random-variable formulation; checked by nobody; 2026-09-08.

Satisfies:

- Rich Outcomes (`rich-outcomes`)
- Totality (`totality`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Simple Expected Utility (`simple-eu`)
- Stochastic Dominance (`stochastic-dominance`)
- Mixture Independence (`independence`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)

Violates:

- Expected Utility (`expected-utility`)
- Scale Invariance (`scale-invariance`)
- Countable Sure-Thing (`countable-sure-thing`)
- Archimedean Gambles (`archimedean-gambles`)

Unknown in this model: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`)

Construction.

Take all real-valued random variables. Choose a cobounded ultrafilter U on positive truncation levels; define X≽Y iff {t:E[c_t(X)]≥E[c_t(Y)]}∈U. This is the exact hyperreal ordering of Theorem 1, not its continuous quotient. The accompanying write-up explains the satisfied axioms and EU counterexample; failure of Scale Invariance is the source’s Theorem 10.

Notes. The scale failure is recorded from the source theorem; its printed analytic witness has apparent typographical issues itemized in extraction.md. This record is a literature extraction, not a separately audited reconstruction of that witness.

Sources:

- **Decision Theory Unbound** — Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695; online 2023; DOI 10.1111/nous.12473, Appendix B, Theorem 1, pp. 690–691; Theorems 3 and 10, pp. 691, 693–695

Record: `topics/unbounded-utility/models/total-exact-ultrafilter.yaml`.

Write-up.

#### Total ordering by an ultrafilter of clipped expectations

Source: Goodsell, *Decision theory unbound*, Appendix B, Theorems 1, 3,
and 10. Human model: Zachary Goodsell.
Recorded and translated by GPT-6 (Codex); no transcription checker asserted.

Take all real-valued random variables. Let U be an ultrafilter on positive
truncation levels containing every tail (s,∞). Define v_X(t)=E[c_t(X)]
as in the eventual-clipping write-up and set

$$X\succeq Y\quad\Longleftrightarrow\quad
\{t:v_X(t)\ge v_Y(t)\}\in\mathcal U.$$

Reflexivity holds because the entire domain is in U; finite intersections
prove transitivity; the ultrafilter dichotomy proves Totality. The ordering
extends eventual weak comparisons and eventual strictly positive gaps.
Thus its law invariance, Simple EU, richness, and stochastic dominance follow
from the calculations for clipped expectations. Common mixture components
cancel pointwise before taking the ultrafilter, giving Independence.
Reflection negates v_X exactly, giving reflection anti-invariance. These
properties give the DTU package in the topic's random-variable language.

The geometric N from the accompanying eventual model has expectation 2, but
v_N(t)<2 for every finite t>2. Therefore N is strictly worse than 2 on this
total ordering as well. This establishes failure of EU, exactly as the source's
Theorem 3 notes. The Countable Sure-Thing and Archimedean Gambles violations
follow from the recorded St Petersburg arguments.

**Scale failure is a source theorem application.** Goodsell's Theorem 10
(pp. 693–695) states that every total ordering constructed in this way fails
Scale Invariance. Its argument uses a pair of attainable clipped-expectation
curves whose difference oscillates in log scale, reverses sign on a doubling
of the truncation parameter, and cannot be neutralized simultaneously in both
phases by an ultrafilter. Apply that theorem to the U just chosen. This does
not assert that all total DTU models fail scale: the 2026 paper constructs
models that satisfy it.

The printed analytic witness has the notation/endpoint issues documented in
`extraction.md`. This model record accepts the published theorem for the scale
flag; it does not claim an independently checked correction of that entire
witness. The explicit EU counterexample and elementary satisfied-axiom
calculations above do not depend on those issues.

## 6. Derived state

Computed from the proved records only, by the closure rules in `README.md`. Conjectures take no part. A missing entry means *not recorded*, not *false*.

### 6.1 Interderivable principles

No two principles are currently interderivable.

### 6.2 Settled single-premise implications (16)

| From | To | Via |
| --- | --- | --- |
| Archimedean Gambles | Archimedean Outcomes | `archimedean-gambles-restricts` |
| Expected Utility | Archimedean Outcomes | `expected-utility-implies-simple`, `simple-eu-implies-archimedean-outcomes` |
| Expected Utility | Restricted Stochastic Equivalence | `expected-utility-implies-simple`, `simple-eu-implies-restricted-equivalence` |
| Expected Utility | Restricted Totality | `expected-utility-implies-simple`, `simple-eu-implies-restricted-totality` |
| Expected Utility | Simple Expected Utility | `expected-utility-implies-simple` |
| Negative Affine Anti-Invariance | Reflection Anti-Invariance | `negative-affine-implies-reflection` |
| Positive Affine Invariance | Scale Invariance | `positive-affine-implies-scale` |
| Positive Affine Invariance | Shift Invariance | `positive-affine-implies-shift` |
| Relative Expectation | Simple Relative Expectation | `relative-implies-simple-relative` |
| Simple Expected Utility | Archimedean Outcomes | `simple-eu-implies-archimedean-outcomes` |
| Simple Expected Utility | Restricted Stochastic Equivalence | `simple-eu-implies-restricted-equivalence` |
| Simple Expected Utility | Restricted Totality | `simple-eu-implies-restricted-totality` |
| Stochastic Dominance | Restricted Stochastic Equivalence | `dominance-implies-equivalence`, `stochastic-equivalence-restricts` |
| Stochastic Dominance | Stochastic Equivalence | `dominance-implies-equivalence` |
| Stochastic Equivalence | Restricted Stochastic Equivalence | `stochastic-equivalence-restricts` |
| Totality | Restricted Totality | `totality-restricts` |

### 6.3 Refuted single-premise implications (203)

Read *A ⇏ B*: assuming A alone does not yield B, as the named model shows.

| From | To | Witness model |
| --- | --- | --- |
| Alternating St Petersburg = −1/2 | Archimedean Gambles | `affine-symmetric-extension` |
| Alternating St Petersburg = −1/2 | Countable Sure-Thing | `affine-symmetric-extension` |
| Archimedean Outcomes | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation` |
| Archimedean Outcomes | Archimedean Gambles | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Countable Sure-Thing | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Folded Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Archimedean Outcomes | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Negative Affine Anti-Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Positive Affine Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Scale Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Archimedean Outcomes | Totality | `eventual-clipped-expectation` |
| Arroyo = ln 2 | Archimedean Gambles | `affine-symmetric-extension` |
| Arroyo = ln 2 | Countable Sure-Thing | `affine-symmetric-extension` |
| Expected Utility | Archimedean Gambles | `affine-symmetric-extension`, `total-continuous-ultrafilter` |
| Expected Utility | Countable Sure-Thing | `affine-symmetric-extension`, `total-continuous-ultrafilter` |
| Expected Utility | Negative Affine Anti-Invariance | `total-continuous-ultrafilter` |
| Expected Utility | Positive Affine Invariance | `total-continuous-ultrafilter` |
| Expected Utility | Scale Invariance | `total-continuous-ultrafilter` |
| Failure of Archimedean Gambles | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation` |
| Failure of Archimedean Gambles | Archimedean Gambles | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Failure of Archimedean Gambles | Countable Sure-Thing | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Failure of Archimedean Gambles | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Failure of Archimedean Gambles | Folded Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Failure of Archimedean Gambles | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Failure of Archimedean Gambles | Negative Affine Anti-Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Failure of Archimedean Gambles | Positive Affine Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Failure of Archimedean Gambles | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Failure of Archimedean Gambles | Scale Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Failure of Archimedean Gambles | Totality | `eventual-clipped-expectation` |
| Failure of Countable Sure-Thing | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation` |
| Failure of Countable Sure-Thing | Archimedean Gambles | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Failure of Countable Sure-Thing | Countable Sure-Thing | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Failure of Countable Sure-Thing | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Failure of Countable Sure-Thing | Folded Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Failure of Countable Sure-Thing | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Failure of Countable Sure-Thing | Negative Affine Anti-Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Failure of Countable Sure-Thing | Positive Affine Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Failure of Countable Sure-Thing | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Failure of Countable Sure-Thing | Scale Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Failure of Countable Sure-Thing | Totality | `eventual-clipped-expectation` |
| Folded Expectation | Archimedean Gambles | `affine-symmetric-extension` |
| Folded Expectation | Countable Sure-Thing | `affine-symmetric-extension` |
| Mixture Independence | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation` |
| Mixture Independence | Archimedean Gambles | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Countable Sure-Thing | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Mixture Independence | Folded Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Mixture Independence | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Mixture Independence | Negative Affine Anti-Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Positive Affine Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Mixture Independence | Scale Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Mixture Independence | Totality | `eventual-clipped-expectation` |
| L¹ Continuity (random variables) | Archimedean Gambles | `affine-symmetric-extension` |
| L¹ Continuity (random variables) | Countable Sure-Thing | `affine-symmetric-extension` |
| Negative Affine Anti-Invariance | Archimedean Gambles | `affine-symmetric-extension` |
| Negative Affine Anti-Invariance | Countable Sure-Thing | `affine-symmetric-extension` |
| Uniqueness of Negative Self-Similarity | Archimedean Gambles | `affine-symmetric-extension` |
| Uniqueness of Negative Self-Similarity | Countable Sure-Thing | `affine-symmetric-extension` |
| Pasadena = ln 2 | Archimedean Gambles | `affine-symmetric-extension` |
| Pasadena = ln 2 | Countable Sure-Thing | `affine-symmetric-extension` |
| Positive Affine Invariance | Archimedean Gambles | `affine-symmetric-extension` |
| Positive Affine Invariance | Countable Sure-Thing | `affine-symmetric-extension` |
| Reflection Anti-Invariance | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation` |
| Reflection Anti-Invariance | Archimedean Gambles | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Countable Sure-Thing | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Folded Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Negative Affine Anti-Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Positive Affine Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Scale Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Reflection Anti-Invariance | Totality | `eventual-clipped-expectation` |
| Relative Expectation | Archimedean Gambles | `affine-symmetric-extension` |
| Relative Expectation | Countable Sure-Thing | `affine-symmetric-extension` |
| Restricted Stochastic Equivalence | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation` |
| Restricted Stochastic Equivalence | Archimedean Gambles | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Countable Sure-Thing | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Folded Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Negative Affine Anti-Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Positive Affine Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Scale Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Stochastic Equivalence | Totality | `eventual-clipped-expectation` |
| Restricted Totality | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation` |
| Restricted Totality | Archimedean Gambles | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Countable Sure-Thing | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Restricted Totality | Folded Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Restricted Totality | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Restricted Totality | Negative Affine Anti-Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Positive Affine Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Restricted Totality | Scale Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Restricted Totality | Totality | `eventual-clipped-expectation` |
| Rich Outcomes | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation` |
| Rich Outcomes | Archimedean Gambles | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Countable Sure-Thing | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Rich Outcomes | Folded Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Rich Outcomes | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Rich Outcomes | Negative Affine Anti-Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Positive Affine Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Rich Outcomes | Scale Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Rich Outcomes | Totality | `eventual-clipped-expectation` |
| Scale Invariance | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation` |
| Scale Invariance | Archimedean Gambles | `affine-symmetric-extension`, `eventual-clipped-expectation` |
| Scale Invariance | Countable Sure-Thing | `affine-symmetric-extension`, `eventual-clipped-expectation` |
| Scale Invariance | Expected Utility | `eventual-clipped-expectation` |
| Scale Invariance | Folded Expectation | `eventual-clipped-expectation` |
| Scale Invariance | L¹ Continuity (random variables) | `eventual-clipped-expectation` |
| Scale Invariance | Relative Expectation | `eventual-clipped-expectation` |
| Scale Invariance | Totality | `eventual-clipped-expectation` |
| Shift Invariance | Archimedean Gambles | `affine-symmetric-extension`, `total-continuous-ultrafilter` |
| Shift Invariance | Countable Sure-Thing | `affine-symmetric-extension`, `total-continuous-ultrafilter` |
| Shift Invariance | Negative Affine Anti-Invariance | `total-continuous-ultrafilter` |
| Shift Invariance | Positive Affine Invariance | `total-continuous-ultrafilter` |
| Shift Invariance | Scale Invariance | `total-continuous-ultrafilter` |
| Transfer of a Shift Across a Mixture | Archimedean Gambles | `affine-symmetric-extension` |
| Transfer of a Shift Across a Mixture | Countable Sure-Thing | `affine-symmetric-extension` |
| Simple Expected Utility | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation` |
| Simple Expected Utility | Archimedean Gambles | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Countable Sure-Thing | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Simple Expected Utility | Folded Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Simple Expected Utility | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Simple Expected Utility | Negative Affine Anti-Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Positive Affine Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Simple Expected Utility | Scale Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Simple Expected Utility | Totality | `eventual-clipped-expectation` |
| Simple Relative Expectation | Archimedean Gambles | `affine-symmetric-extension` |
| Simple Relative Expectation | Countable Sure-Thing | `affine-symmetric-extension` |
| Statewise Dominance | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation` |
| Statewise Dominance | Archimedean Gambles | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Countable Sure-Thing | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Statewise Dominance | Folded Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Statewise Dominance | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Statewise Dominance | Negative Affine Anti-Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Positive Affine Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Statewise Dominance | Scale Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Statewise Dominance | Totality | `eventual-clipped-expectation` |
| Stochastic Dominance | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation` |
| Stochastic Dominance | Archimedean Gambles | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Countable Sure-Thing | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Stochastic Dominance | Folded Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Stochastic Dominance | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Stochastic Dominance | Negative Affine Anti-Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Positive Affine Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Stochastic Dominance | Scale Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Dominance | Totality | `eventual-clipped-expectation` |
| Stochastic Equivalence | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation` |
| Stochastic Equivalence | Archimedean Gambles | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Countable Sure-Thing | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Folded Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Stochastic Equivalence | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Negative Affine Anti-Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Positive Affine Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Scale Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Stochastic Equivalence | Totality | `eventual-clipped-expectation` |
| Sure-Thing | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation` |
| Sure-Thing | Archimedean Gambles | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Countable Sure-Thing | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Sure-Thing | Folded Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Sure-Thing | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Sure-Thing | Negative Affine Anti-Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Positive Affine Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Sure-Thing | Scale Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Sure-Thing | Totality | `eventual-clipped-expectation` |
| Symmetric Gambles Are Neutral | Alternating St Petersburg = −1/2 | `eventual-clipped-expectation` |
| Symmetric Gambles Are Neutral | Archimedean Gambles | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Countable Sure-Thing | `affine-symmetric-extension`, `eventual-clipped-expectation`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Expected Utility | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Folded Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | L¹ Continuity (random variables) | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Negative Affine Anti-Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Positive Affine Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Relative Expectation | `eventual-clipped-expectation`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Scale Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Symmetric Gambles Are Neutral | Totality | `eventual-clipped-expectation` |
| Totality | Archimedean Gambles | `affine-symmetric-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Countable Sure-Thing | `affine-symmetric-extension`, `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Expected Utility | `total-exact-ultrafilter` |
| Totality | Folded Expectation | `total-exact-ultrafilter` |
| Totality | L¹ Continuity (random variables) | `total-exact-ultrafilter` |
| Totality | Negative Affine Anti-Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Positive Affine Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |
| Totality | Relative Expectation | `total-exact-ultrafilter` |
| Totality | Scale Invariance | `total-continuous-ultrafilter`, `total-exact-ultrafilter` |

### 6.4 Open single-premise pairs (711)

Listed in `OPEN-QUESTIONS.md`.

### 6.5 What the recorded premise packages entail

Every multi-premise package used by a proved result, with its full consequence set.

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance + L¹ Continuity (random variables)

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`, `l1-continuity`.

- Entails: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), Expected Utility (`expected-utility`), Failure of Archimedean Gambles (`failure-archimedean-gambles`), Failure of Countable Sure-Thing (`failure-countable-sure-thing`), Folded Expectation (`folded-expectation`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Refuted (a model satisfies the package and violates these): Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`)
- Open: nothing

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance + Relative Expectation

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`, `relative-expectation`.

- Entails: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), Expected Utility (`expected-utility`), Failure of Archimedean Gambles (`failure-archimedean-gambles`), Failure of Countable Sure-Thing (`failure-countable-sure-thing`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Refuted (a model satisfies the package and violates these): Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`)
- Open: nothing

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + L¹ Continuity (random variables)

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `l1-continuity`.

- Entails: Archimedean Outcomes (`archimedean-outcomes`), Expected Utility (`expected-utility`), Failure of Archimedean Gambles (`failure-archimedean-gambles`), Failure of Countable Sure-Thing (`failure-countable-sure-thing`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Folded Expectation (`folded-expectation`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`.

- Entails: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Failure of Archimedean Gambles (`failure-archimedean-gambles`), Failure of Countable Sure-Thing (`failure-countable-sure-thing`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Refuted (a model satisfies the package and violates these): Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`)
- Open: Arroyo = ln 2 (`arroyo-value`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Pasadena = ln 2 (`pasadena-value`), Relative Expectation (`relative-expectation`)

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Mixture Independence + Reflection Anti-Invariance

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `independence`, `reflection-anti-invariance`.

- Entails: Archimedean Outcomes (`archimedean-outcomes`), Failure of Countable Sure-Thing (`failure-countable-sure-thing`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Refuted (a model satisfies the package and violates these): Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Failure of Archimedean Gambles (`failure-archimedean-gambles`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`)

#### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence

Assumes: `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`.

- Entails: Archimedean Outcomes (`archimedean-outcomes`), Failure of Archimedean Gambles (`failure-archimedean-gambles`), Failure of Countable Sure-Thing (`failure-countable-sure-thing`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Statewise Dominance (`statewise-dominance`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Reflection Anti-Invariance (`reflection-anti-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)

#### Rich Outcomes + Archimedean Outcomes + Totality + Stochastic Dominance + Sure-Thing

Assumes: `rich-outcomes`, `archimedean-outcomes`, `totality`, `stochastic-dominance`, `sure-thing`.

- Entails: Failure of Archimedean Gambles (`failure-archimedean-gambles`), Failure of Countable Sure-Thing (`failure-countable-sure-thing`), Mixture Independence (`independence`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`), Statewise Dominance (`statewise-dominance`), Stochastic Equivalence (`stochastic-equivalence`)
- Refuted (a model satisfies the package and violates these): Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Reflection Anti-Invariance (`reflection-anti-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)

#### Rich Outcomes + Archimedean Outcomes + Stochastic Equivalence + Statewise Dominance

Assumes: `rich-outcomes`, `archimedean-outcomes`, `stochastic-equivalence`, `statewise-dominance`.

- Entails: Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Stochastic Dominance (`stochastic-dominance`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Totality (`totality`)
- Open: Arroyo = ln 2 (`arroyo-value`), Failure of Archimedean Gambles (`failure-archimedean-gambles`), Failure of Countable Sure-Thing (`failure-countable-sure-thing`), Mixture Independence (`independence`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Totality (`restricted-totality`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)

#### Rich Outcomes + Positive Affine Invariance + Reflection Anti-Invariance

Assumes: `rich-outcomes`, `positive-affine-invariance`, `reflection-anti-invariance`.

- Entails: Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`)
- Refuted (a model satisfies the package and violates these): Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), Expected Utility (`expected-utility`), Failure of Archimedean Gambles (`failure-archimedean-gambles`), Failure of Countable Sure-Thing (`failure-countable-sure-thing`), Folded Expectation (`folded-expectation`), Mixture Independence (`independence`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`)

#### Rich Outcomes + Shift Invariance + Scale Invariance

Assumes: `rich-outcomes`, `shift-invariance`, `scale-invariance`.

- Entails: Positive Affine Invariance (`positive-affine-invariance`)
- Refuted (a model satisfies the package and violates these): Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), Expected Utility (`expected-utility`), Failure of Archimedean Gambles (`failure-archimedean-gambles`), Failure of Countable Sure-Thing (`failure-countable-sure-thing`), Folded Expectation (`folded-expectation`), Mixture Independence (`independence`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`)

#### Rich Outcomes + Simple Expected Utility + Sure-Thing

Assumes: `rich-outcomes`, `simple-eu`, `sure-thing`.

- Entails: Archimedean Outcomes (`archimedean-outcomes`), Failure of Countable Sure-Thing (`failure-countable-sure-thing`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Totality (`totality`)
- Open: Arroyo = ln 2 (`arroyo-value`), Failure of Archimedean Gambles (`failure-archimedean-gambles`), Mixture Independence (`independence`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Reflection Anti-Invariance (`reflection-anti-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)

#### Archimedean Outcomes + Folded Expectation

Assumes: `archimedean-outcomes`, `folded-expectation`.

- Entails: Expected Utility (`expected-utility`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`)
- Refuted (a model satisfies the package and violates these): Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Failure of Archimedean Gambles (`failure-archimedean-gambles`), Failure of Countable Sure-Thing (`failure-countable-sure-thing`), Mixture Independence (`independence`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Rich Outcomes (`rich-outcomes`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`)

#### Archimedean Outcomes + Relative Expectation

Assumes: `archimedean-outcomes`, `relative-expectation`.

- Entails: Expected Utility (`expected-utility`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`)
- Refuted (a model satisfies the package and violates these): Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Arroyo = ln 2 (`arroyo-value`), Failure of Archimedean Gambles (`failure-archimedean-gambles`), Failure of Countable Sure-Thing (`failure-countable-sure-thing`), Folded Expectation (`folded-expectation`), Mixture Independence (`independence`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Rich Outcomes (`rich-outcomes`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`)

#### Archimedean Outcomes + Stochastic Dominance

Assumes: `archimedean-outcomes`, `stochastic-dominance`.

- Entails: Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Statewise Dominance (`statewise-dominance`), Stochastic Equivalence (`stochastic-equivalence`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Totality (`totality`)
- Open: Arroyo = ln 2 (`arroyo-value`), Failure of Archimedean Gambles (`failure-archimedean-gambles`), Failure of Countable Sure-Thing (`failure-countable-sure-thing`), Mixture Independence (`independence`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Totality (`restricted-totality`), Rich Outcomes (`rich-outcomes`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)

#### Rich Outcomes + Folded Expectation

Assumes: `rich-outcomes`, `folded-expectation`.

- Entails: Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Refuted (a model satisfies the package and violates these): Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), Expected Utility (`expected-utility`), Failure of Archimedean Gambles (`failure-archimedean-gambles`), Failure of Countable Sure-Thing (`failure-countable-sure-thing`), Mixture Independence (`independence`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`), Totality (`totality`)

#### Stochastic Equivalence + Mixture Independence

Assumes: `stochastic-equivalence`, `independence`.

- Entails: Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Sure-Thing (`sure-thing`)
- Refuted (a model satisfies the package and violates these): Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`), Expected Utility (`expected-utility`), Folded Expectation (`folded-expectation`), L¹ Continuity (random variables) (`l1-continuity`), Negative Affine Anti-Invariance (`negative-affine-anti-invariance`), Positive Affine Invariance (`positive-affine-invariance`), Relative Expectation (`relative-expectation`), Scale Invariance (`scale-invariance`), Totality (`totality`)
- Open: Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), Failure of Archimedean Gambles (`failure-archimedean-gambles`), Failure of Countable Sure-Thing (`failure-countable-sure-thing`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Reflection Anti-Invariance (`reflection-anti-invariance`), Restricted Totality (`restricted-totality`), Rich Outcomes (`rich-outcomes`), Shift Invariance (`shift-invariance`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Symmetric Gambles Are Neutral (`symmetric-neutrality`)

#### Rich Outcomes + Negative Affine Anti-Invariance

Assumes: `rich-outcomes`, `negative-affine-anti-invariance`.

- Entails: Positive Affine Invariance (`positive-affine-invariance`), Reflection Anti-Invariance (`reflection-anti-invariance`), Scale Invariance (`scale-invariance`), Shift Invariance (`shift-invariance`)
- Refuted (a model satisfies the package and violates these): Archimedean Gambles (`archimedean-gambles`), Countable Sure-Thing (`countable-sure-thing`)
- Open: Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`), Archimedean Outcomes (`archimedean-outcomes`), Arroyo = ln 2 (`arroyo-value`), Expected Utility (`expected-utility`), Failure of Archimedean Gambles (`failure-archimedean-gambles`), Failure of Countable Sure-Thing (`failure-countable-sure-thing`), Folded Expectation (`folded-expectation`), Mixture Independence (`independence`), L¹ Continuity (random variables) (`l1-continuity`), Uniqueness of Negative Self-Similarity (`negative-self-similarity`), Pasadena = ln 2 (`pasadena-value`), Relative Expectation (`relative-expectation`), Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`), Restricted Totality (`restricted-totality`), Transfer of a Shift Across a Mixture (`shift-transfer`), Simple Expected Utility (`simple-eu`), Simple Relative Expectation (`simple-relative-expectation`), Statewise Dominance (`statewise-dominance`), Stochastic Dominance (`stochastic-dominance`), Stochastic Equivalence (`stochastic-equivalence`), Sure-Thing (`sure-thing`), Symmetric Gambles Are Neutral (`symmetric-neutrality`), Totality (`totality`)

## 7. Additional write-ups

Hand-written notes not attached to a single record.

### `l1-translation`

#### Translating the source's L¹ metric to random variables

In *Symmetries of value*, p. 23, distance between two laws is the infimum of
E|A−B| over all couplings, with infinity allowed. Call this extended metric W.
The node in this topic instead uses E|X_n−X| for the actual variables.

Assume **Stochastic Equivalence**, the full random-variable domain, and the
real chart used in the source theorem packages. If W-continuity holds, then
actual-coupling L¹ convergence implies W-convergence, so the topic's closure
clause follows immediately.

Conversely, suppose laws μ_n converge to μ in W. Pick couplings (A_n,B_n) with
laws μ_n,μ and E|A_n−B_n|→0 (an approximate infimum within 1/n suffices).
On a standard Borel space, disintegrate these couplings over their common
second marginal and realize them with a single B of law μ and a sequence of
auxiliary uniform random variables. The resulting A'_n all share the same B
and satisfy E|A'_n−B|→0. All are realizable on the standing atomless space.
By Stochastic Equivalence, each comparison of μ_n with a fixed law ν holds
for these representatives as well. Apply the topic's continuity clause and
transfer the conclusion back by Stochastic Equivalence.

Without Stochastic Equivalence the transfer between representatives is
unavailable. This is why a metric on laws was not used in the node definition:
its zero-distance constant sequences would already force equal-law variables
to be indifferent by reflexivity and closure.

This verifies a **translation of the continuity assumption**. It does not
independently prove the paper's DTU ⇒ EU extension after adding continuity,
or the reverse direction of its Corollary 5. Those are cited source results.

## 8. Where this came from

Source documents are in `topics/unbounded-utility/sources/`. The extraction log, with transcription decisions and deliberately deferred items, is `topics/unbounded-utility/extraction.md`. Read it before trusting any single page reference.
