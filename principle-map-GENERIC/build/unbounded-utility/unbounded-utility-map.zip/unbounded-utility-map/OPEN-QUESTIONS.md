# Open questions — Unbounded utility: random variables

Everything the database does not currently settle. Each item is a place where a new result or a new model would be a real contribution.

**"Open" means not settled by the records in this bundle.** It does not mean unsolved in the literature, and it does not mean hard. Many entries below are routine and simply have not been added yet. Check the sources before assuming a question is new.

## 1. Recorded conjectures

Stated but unproved. They take no part in any derivation.

### Countable Sure-Thing ∧ Archimedean Outcomes ⇒ Archimedean Gambles — `countable-sure-thing-outcomes-to-gambles`

Record the user's two-premise proposal as stated, relative to this topic's standing framework. The related Russell–Isaacs theorem uses Countable Independence, complete preferences, and countably supported lotteries; its passage from acts to lotteries assumes law invariance. A proof in the present random-variable framework, or identification of any additional necessary premises, is still required. Neither Totality nor Stochastic Equivalence should silently be treated as background. Excluded from proved deductions until verified.

- **User suggestion 8 Sep** — User suggestion in this project's conversation, 2026-09-08; proposed implication, not a completed proof.
- **Infinite Prospects (candidate source)** — Possible related reference, not verified as establishing this exact arrow: Jeffrey Sanford Russell and Yoaav Isaacs, Infinite Prospects, Philosophy and Phenomenological Research 103 (2021), 178–198, DOI 10.1111/phpr.12704. Author-hosted manuscript, §§4–5 and Appendix A, especially pp. 15, 22, 25: https://www.yoaavisaacs.com/uploads/6/9/2/0/69204575/infinite-prospects-final.pdf

Record: `topics/unbounded-utility/results/countable-sure-thing-outcomes-to-gambles.yaml`.

### Countable Sure-Thing ∧ Simple Expected Utility ⇒ Expected Utility — `countable-sure-thing-simple-to-full-eu`

Candidate extension from finite-valued gambles to all integrable utility random variables. Verification must cover the full measurable domain, including variables with non-atomic distributions, and both directions of the expected-utility comparison. Do not silently add Rich Outcomes, Totality, Stochastic Equivalence, or Sure-Thing as premises. Rich Outcomes is optional here; the existing unbounded-utility inconsistency argument is not by itself a proof of this two-premise implication. Excluded from proved deductions until verified.

- **User suggestion 8 Sep** — User suggestion in this project's conversation, 2026-09-08; proposed implication, not a completed proof.
- **Decision Theory Unbound** — Related motivation rather than a verified theorem with these exact premises: Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695, DOI 10.1111/nous.12473, §4.1, pp. 685–686.

Record: `topics/unbounded-utility/results/countable-sure-thing-simple-to-full-eu.yaml`.

## 2. Open questions under each recorded package

The most useful place to work: these are open *given* assumptions the sources already make.

### DU

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + L¹ Continuity (random variables)

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `l1-continuity`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Folded Expectation (`folded-expectation`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Scale Invariance (`scale-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Pasadena = ln 2 (`pasadena-value`)
- Relative Expectation (`relative-expectation`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Mixture Independence + Reflection Anti-Invariance

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `independence`, `reflection-anti-invariance`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Failure of Archimedean Gambles (`failure-archimedean-gambles`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)

### Rich Outcomes + Archimedean Outcomes + Totality + Stochastic Dominance + Sure-Thing

Assuming `rich-outcomes`, `archimedean-outcomes`, `totality`, `stochastic-dominance`, `sure-thing`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)

### Rich Outcomes + Archimedean Outcomes + Stochastic Equivalence + Statewise Dominance

Assuming `rich-outcomes`, `archimedean-outcomes`, `stochastic-equivalence`, `statewise-dominance`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- Failure of Archimedean Gambles (`failure-archimedean-gambles`)
- Failure of Countable Sure-Thing (`failure-countable-sure-thing`)
- Mixture Independence (`independence`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Restricted Totality (`restricted-totality`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)

### Rich Outcomes + Positive Affine Invariance + Reflection Anti-Invariance

Assuming `rich-outcomes`, `positive-affine-invariance`, `reflection-anti-invariance`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- Expected Utility (`expected-utility`)
- Failure of Archimedean Gambles (`failure-archimedean-gambles`)
- Failure of Countable Sure-Thing (`failure-countable-sure-thing`)
- Folded Expectation (`folded-expectation`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)

### Rich Outcomes + Shift Invariance + Scale Invariance

Assuming `rich-outcomes`, `shift-invariance`, `scale-invariance`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- Expected Utility (`expected-utility`)
- Failure of Archimedean Gambles (`failure-archimedean-gambles`)
- Failure of Countable Sure-Thing (`failure-countable-sure-thing`)
- Folded Expectation (`folded-expectation`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)

### Rich Outcomes + Simple Expected Utility + Sure-Thing

Assuming `rich-outcomes`, `simple-eu`, `sure-thing`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- Failure of Archimedean Gambles (`failure-archimedean-gambles`)
- Mixture Independence (`independence`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)

### Archimedean Outcomes + Folded Expectation

Assuming `archimedean-outcomes`, `folded-expectation`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Failure of Archimedean Gambles (`failure-archimedean-gambles`)
- Failure of Countable Sure-Thing (`failure-countable-sure-thing`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)

### Archimedean Outcomes + Relative Expectation

Assuming `archimedean-outcomes`, `relative-expectation`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Failure of Archimedean Gambles (`failure-archimedean-gambles`)
- Failure of Countable Sure-Thing (`failure-countable-sure-thing`)
- Folded Expectation (`folded-expectation`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)

### Archimedean Outcomes + Stochastic Dominance

Assuming `archimedean-outcomes`, `stochastic-dominance`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- Failure of Archimedean Gambles (`failure-archimedean-gambles`)
- Failure of Countable Sure-Thing (`failure-countable-sure-thing`)
- Mixture Independence (`independence`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Restricted Totality (`restricted-totality`)
- Rich Outcomes (`rich-outcomes`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)

### Rich Outcomes + Folded Expectation

Assuming `rich-outcomes`, `folded-expectation`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- Expected Utility (`expected-utility`)
- Failure of Archimedean Gambles (`failure-archimedean-gambles`)
- Failure of Countable Sure-Thing (`failure-countable-sure-thing`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Scale Invariance (`scale-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Totality (`totality`)

### Stochastic Equivalence + Mixture Independence

Assuming `stochastic-equivalence`, `independence`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- Failure of Archimedean Gambles (`failure-archimedean-gambles`)
- Failure of Countable Sure-Thing (`failure-countable-sure-thing`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Restricted Totality (`restricted-totality`)
- Rich Outcomes (`rich-outcomes`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)

### Rich Outcomes + Negative Affine Anti-Invariance

Assuming `rich-outcomes`, `negative-affine-anti-invariance`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- Expected Utility (`expected-utility`)
- Failure of Archimedean Gambles (`failure-archimedean-gambles`)
- Failure of Countable Sure-Thing (`failure-countable-sure-thing`)
- Folded Expectation (`folded-expectation`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)

## 3. Unknown verdicts inside each model

For these principles the model has not been checked either way. Deciding one is a self-contained calculation in a construction that is already written down.

### Total affine-symmetric extension (source existence construction) — `affine-symmetric-extension`

Fully determined; nothing unknown.

### Eventual ordering of clipped expectations — `eventual-clipped-expectation`

- Arroyo = ln 2 (`arroyo-value`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)

### Continuous ultrafilter model: EU without full affine symmetry — `total-continuous-ultrafilter`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Folded Expectation (`folded-expectation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Relative Expectation (`relative-expectation`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)

### Total ordering by an ultrafilter of clipped expectations — `total-exact-ultrafilter`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)

## 4. Open single-premise pairs (711)

*A ⇒ B ?* means no recorded chain of results proves it and no recorded model refutes it. Grouped by antecedent. Most are open only because the obvious model has not been added.

- **Alternating St Petersburg = −1/2** (`alternating-st-petersburg-value`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Expected Utility, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Folded Expectation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Archimedean Gambles** (`archimedean-gambles`) ⇒ Alternating St Petersburg = −1/2, Arroyo = ln 2, Countable Sure-Thing, Expected Utility, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Folded Expectation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Archimedean Outcomes** (`archimedean-outcomes`) ⇒ Arroyo = ln 2, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Arroyo = ln 2** (`arroyo-value`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Expected Utility, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Folded Expectation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Countable Sure-Thing** (`countable-sure-thing`) ⇒ Alternating St Petersburg = −1/2, Archimedean Gambles, Archimedean Outcomes, Arroyo = ln 2, Expected Utility, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Folded Expectation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Expected Utility** (`expected-utility`) ⇒ Alternating St Petersburg = −1/2, Arroyo = ln 2, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Folded Expectation, L¹ Continuity (random variables), Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Relative Expectation, Rich Outcomes, Shift Invariance, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Failure of Archimedean Gambles** (`failure-archimedean-gambles`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Failure of Countable Sure-Thing, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Failure of Countable Sure-Thing** (`failure-countable-sure-thing`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Failure of Archimedean Gambles, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Folded Expectation** (`folded-expectation`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, Expected Utility, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **L¹ Continuity (random variables)** (`l1-continuity`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, Expected Utility, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Folded Expectation, Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Mixture Independence** (`independence`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Pasadena = ln 2, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Negative Affine Anti-Invariance** (`negative-affine-anti-invariance`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, Expected Utility, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Folded Expectation, L¹ Continuity (random variables), Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Pasadena = ln 2** (`pasadena-value`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, Expected Utility, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Folded Expectation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Positive Affine Invariance** (`positive-affine-invariance`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, Expected Utility, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Folded Expectation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Reflection Anti-Invariance** (`reflection-anti-invariance`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Mixture Independence, Pasadena = ln 2, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Relative Expectation** (`relative-expectation`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, Expected Utility, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Folded Expectation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Restricted Stochastic Equivalence** (`restricted-stochastic-equivalence`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Restricted Totality** (`restricted-totality`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Rich Outcomes** (`rich-outcomes`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Scale Invariance** (`scale-invariance`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Shift Invariance** (`shift-invariance`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, Expected Utility, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Folded Expectation, L¹ Continuity (random variables), Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Simple Expected Utility** (`simple-eu`) ⇒ Arroyo = ln 2, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Rich Outcomes, Shift Invariance, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Simple Relative Expectation** (`simple-relative-expectation`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, Expected Utility, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Folded Expectation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Statewise Dominance** (`statewise-dominance`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Stochastic Dominance** (`stochastic-dominance`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Sure-Thing, Symmetric Gambles Are Neutral, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Stochastic Equivalence** (`stochastic-equivalence`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Sure-Thing, Symmetric Gambles Are Neutral, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Sure-Thing** (`sure-thing`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Symmetric Gambles Are Neutral, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Symmetric Gambles Are Neutral** (`symmetric-neutrality`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Totality** (`totality`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Transfer of a Shift Across a Mixture** (`shift-transfer`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, Expected Utility, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Folded Expectation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Uniqueness of Negative Self-Similarity
- **Uniqueness of Negative Self-Similarity** (`negative-self-similarity`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, Expected Utility, Failure of Archimedean Gambles, Failure of Countable Sure-Thing, Folded Expectation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture

## 5. Deliberately deferred

`topics/unbounded-utility/extraction.md` has a section listing claims that were **not** recorded because they need a further reading of the sources. Those are marked deferred rather than open: the answer is likely in the literature and needs transcribing, not discovering. Read that section before starting work.

## 6. How to record an answer

- Proved an implication? Add `topics/unbounded-utility/results/<id>.yaml` with the full premise list and the proof.
- Refuted one? Add `topics/unbounded-utility/models/<id>.yaml` listing what you verified in `satisfies` and `violates`.
- Not sure? Add it with `status: conjectured`, an empty proof, and say in `notes` what would settle it.
- Then run `python3 scripts/pmap.py validate` and `status`. Never hand-edit the derived counts.

`README.md` has the exact record shapes and the sourcing rules. Follow them; an unsourced or misattributed record is worse than an absent one.
