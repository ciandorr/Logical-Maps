# Open questions — Unbounded Utility

Everything the database does not currently settle. Each item is a place where a new result or a new model would be a real contribution.

**"Open" means not settled by the records in this bundle.** It does not mean unsolved in the literature, and it does not mean hard. Many entries below are routine and simply have not been added yet. Check the sources before assuming a question is new.

## 1. Recorded conjectures

Stated but unproved. They take no part in any derivation.

### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Independent Sum Cancellation ⇒ Independent Sum Preservation — `conjectured-dtu-cancellation-implies-preservation`

Original work: conjecture formulation and partial analysis, not a proof or consistency witness. Totality plus cancellation already preserves strict comparisons. The unsettled issue is whether DTU forces common independent noise to preserve indifference as well. The new proved result continuous-total-cancellation-implies-preservation settles this after adding L1 Continuity: shift the upper variable by 1/n and pass to the limit. Without continuity that limiting step is unavailable. A proof must close the indifference gap without assuming continuity; a countermodel must satisfy all six DTU axioms plus cancellation and exhibit a tied pair that independent noise separates. Such a model would necessarily violate L1 Continuity. The existing total independent-sum extension satisfies both directions and does not separate them. This is an open entry in this map, not a claim about whether the question has been settled in the literature.

- **GPT-6 conjecture 9 Sep** — GPT-6 (Codex), 9 September 2026, follow-up question and partial analysis in writeups/conjectured-dtu-cancellation-implies-preservation.md.
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, unpublished manuscript, 5 June 2026, Lemma 1, pp. 7–8: source for the separated sum principles, not this conjecture.

Record: `topics/unbounded-utility/results/conjectured-dtu-cancellation-implies-preservation.yaml`.

### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Shift Invariance ⇒ Transfer of a Shift Across a Mixture — `conjectured-dtu-shift-implies-transfer`

Original work: conjecture formulation and partial analysis, not a proof or consistency witness. The candidate asks whether DTU plus Shift Invariance alone implies Shift Transfer, equivalently under DTU Simple Relative Expectation. The recorded neutrality-shift-imply-shift-transfer proof settles the question after adding Symmetric Neutrality. The DTU+L1-to-EU and eu-independence-l1-imply-relative proofs settle it after adding L1 Continuity, through Relative Expectation. Consequently a separating model would have to fail both neutrality and L1 Continuity. The continuous clipping models already satisfy Relative Expectation; the new lexicographic folded-tail model fails continuity but still satisfies Relative Expectation and neutrality. Neither family supplies the required separation. A proof must derive transfer without either supplementary premise, or a countermodel must exhibit an actual failed transfer instance while verifying DTU and every common constant shift. Conjectured here labels an unresolved question in this map; it expresses neither confidence that the implication is true nor a literature-wide claim that the question is open.

- **GPT-6 question 9 Sep** — GPT-6 (Codex), 9 September 2026, follow-up DU investigation; precise unresolved implication and partial analysis in writeups/conjectured-dtu-shift-implies-transfer.md.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37, DOI 10.1111/nous.12549, Theorems 3–4, pp. 25–27: source for Shift Transfer and its derivation with full affine symmetry, not this conjecture.

Record: `topics/unbounded-utility/results/conjectured-dtu-shift-implies-transfer.yaml`.

### Countable Sure-Thing ∧ Archimedean Outcomes ⇒ Archimedean Gambles — `countable-sure-thing-outcomes-to-gambles`

Record the user's two-premise proposal as stated, relative to this topic's standing framework. The related Russell–Isaacs theorem uses Countable Independence, complete preferences, and countably supported lotteries; its passage from acts to lotteries assumes law invariance. A proof in the present random-variable framework, or identification of any additional necessary premises, is still required. Neither Totality nor Stochastic Equivalence should silently be treated as background. Excluded from proved deductions until verified.

- **User suggestion 8 Sep** — User suggestion in this project's conversation, 2026-09-08; proposed implication, not a completed proof.
- **Infinite Prospects (candidate source)** — Possible related reference, not verified as establishing this exact arrow: Jeffrey Sanford Russell and Yoaav Isaacs, Infinite Prospects, Philosophy and Phenomenological Research 103 (2021), 178–198, DOI 10.1111/phpr.12704. Author-hosted manuscript, §§4–5 and Appendix A, especially pp. 15, 22, 25: https://www.yoaavisaacs.com/uploads/6/9/2/0/69204575/infinite-prospects-final.pdf

Record: `topics/unbounded-utility/results/countable-sure-thing-outcomes-to-gambles.yaml`.

### Countable Sure-Thing ∧ Simple Expected Utility ⇒ Expected Utility — `countable-sure-thing-simple-to-full-eu`

Candidate extension from finite-valued gambles to all integrable utility random variables. Verification must cover the full measurable domain, including variables with non-atomic distributions, and both directions of the expected-utility comparison. Do not silently add Rich Outcomes, Totality, Stochastic Equivalence, or Sure-Thing as premises. Rich Outcomes is optional here; the existing unbounded-utility inconsistency argument is not by itself a proof of this two-premise implication. Excluded from proved deductions until verified.

- **User suggestion 8 Sep** — User suggestion in this project's conversation, 2026-09-08; proposed implication, not a completed proof.
- **Decision Theory Unbound** — Related motivation rather than a verified theorem with these exact premises: Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695, DOI 10.1111/nous.12473, §4.1, pp. 685–686.

Record: `topics/unbounded-utility/results/countable-sure-thing-simple-to-full-eu.yaml`.

### CDF-area: total comonotonic extension — `conjectured-total-comonotonic-area-extension`

Original work: precise candidate formulation and comparison of two extension problems. The base area construction, its comonotonic property, and the broader unresolved consistency question are credited to Goodsell. The manuscript's Theorem 7 supplies only the incomplete area model, not this proposed total CDF-area extension. No new completed model is claimed. To settle positively, give a total extension and verify that adjoining comparisons preserves every old strict area comparison, full Mixture Independence, and comonotonic preservation and cancellation. To settle negatively, derive an incompatibility from the displayed package. A generic order extension is insufficient, and the total convolution model is not evidence that comonotonic invariance survives. No claim is made that the question is open in the literature.

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, unpublished manuscript, 5 June 2026, §3, pp. 7–8, and discussion before Theorem 7 and Theorem 7, pp. 19–20: CDF-area construction, its comonotonic invariance, and the broader unresolved consistency question.
- **GPT-6 conjecture 9 Sep** — GPT-6 (Codex), 9 September 2026, proposed total-extension package and obstacle analysis in writeups/conjectured-total-comonotonic-area-extension.md.

Record: `topics/unbounded-utility/models/conjectured-total-comonotonic-area-extension.yaml`.

## 2. Open questions under each recorded package

The most useful place to work: these are open *given* assumptions the sources already make.

### DU

Assuming `rich-outcomes`, `archimedean-outcomes`, `stochastic-equivalence`, `stochastic-dominance`, `independence`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)

### DTU

Assuming `rich-outcomes`, `archimedean-outcomes`, `totality`, `stochastic-equivalence`, `stochastic-dominance`, `independence`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance + L¹ Continuity (random variables)

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`, `l1-continuity`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance + Relative Expectation

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`, `relative-expectation`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + L¹ Continuity (random variables)

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `l1-continuity`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Pasadena = ln 2 (`pasadena-value`)
- Relative Expectation (`relative-expectation`)

### Rich Outcomes + Expected Utility + Stochastic Equivalence + Mixture Independence + Stochastic Dominance + L¹ Continuity (random variables)

Assuming `rich-outcomes`, `expected-utility`, `stochastic-equivalence`, `independence`, `stochastic-dominance`, `l1-continuity`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Totality (`totality`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Mixture Independence + Reflection Anti-Invariance

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `independence`, `reflection-anti-invariance`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Pasadena = ln 2 (`pasadena-value`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)

### Rich Outcomes + Stochastic Equivalence + Simple Expected Utility + Mixture Independence + Symmetric Gambles Are Neutral + Shift Invariance

Assuming `rich-outcomes`, `stochastic-equivalence`, `simple-eu`, `independence`, `symmetric-neutrality`, `shift-invariance`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Totality (`totality`)

### Rich Outcomes + Archimedean Outcomes + Totality + Stochastic Dominance + Sure-Thing

Assuming `rich-outcomes`, `archimedean-outcomes`, `totality`, `stochastic-dominance`, `sure-thing`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)

### Rich Outcomes + Stochastic Equivalence + Mixture Independence + Relative Expectation + Uniqueness of Negative Self-Similarity

Assuming `rich-outcomes`, `stochastic-equivalence`, `independence`, `relative-expectation`, `negative-self-similarity`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Restricted Totality (`restricted-totality`)
- Scale Invariance (`scale-invariance`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)

### Rich Outcomes + Stochastic Equivalence + Simple Expected Utility + Mixture Independence + Transfer of a Shift Across a Mixture

Assuming `rich-outcomes`, `stochastic-equivalence`, `simple-eu`, `independence`, `shift-transfer`, these remain open:

- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Relative Expectation (`relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)

### Rich Outcomes + Totality + Stochastic Equivalence + Mixture Independence + Symmetric Gambles Are Neutral

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `independence`, `symmetric-neutrality`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Pasadena = ln 2 (`pasadena-value`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)

### Rich Outcomes + Totality + Stochastic Dominance + L¹ Continuity (random variables) + Independent Sum Cancellation

Assuming `rich-outcomes`, `totality`, `stochastic-dominance`, `l1-continuity`, `independent-sum-cancellation`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Gambles (`archimedean-gambles`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Countable Sure-Thing (`countable-sure-thing`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)

### Rich Outcomes + Stochastic Equivalence + Relative Expectation + Symmetric Gambles Are Neutral + Shift Invariance

Assuming `rich-outcomes`, `stochastic-equivalence`, `relative-expectation`, `symmetric-neutrality`, `shift-invariance`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)
- Totality (`totality`)

### Rich Outcomes + Archimedean Outcomes + Stochastic Dominance + Mixture Independence

Assuming `rich-outcomes`, `archimedean-outcomes`, `stochastic-dominance`, `independence`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)

### Rich Outcomes + Archimedean Outcomes + Stochastic Dominance + Relative Expectation

Assuming `rich-outcomes`, `archimedean-outcomes`, `stochastic-dominance`, `relative-expectation`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Mixture Independence (`independence`)
- Shift Invariance (`shift-invariance`)
- Sure-Thing (`sure-thing`)

### Rich Outcomes + Archimedean Outcomes + Stochastic Equivalence + Statewise Dominance

Assuming `rich-outcomes`, `archimedean-outcomes`, `stochastic-equivalence`, `statewise-dominance`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Mixture Independence (`independence`)
- Restricted Totality (`restricted-totality`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Sure-Thing (`sure-thing`)

### Rich Outcomes + Stochastic Equivalence + Simple Expected Utility + Uniqueness of Negative Self-Similarity

Assuming `rich-outcomes`, `stochastic-equivalence`, `simple-eu`, `negative-self-similarity`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Scale Invariance (`scale-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)

### Rich Outcomes + Mixture Independence + Folded Expectation

Assuming `rich-outcomes`, `independence`, `folded-expectation`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Totality (`totality`)

### Totality + Mixture Independence + Negative Affine Anti-Invariance

Assuming `totality`, `independence`, `negative-affine-anti-invariance`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)

### Rich Outcomes + Simple Relative Expectation + L¹ Continuity (random variables)

Assuming `rich-outcomes`, `simple-relative-expectation`, `l1-continuity`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Shift Invariance (`shift-invariance`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Totality (`totality`)

### Rich Outcomes + Positive Affine Invariance + Reflection Anti-Invariance

Assuming `rich-outcomes`, `positive-affine-invariance`, `reflection-anti-invariance`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

### Rich Outcomes + Shift Invariance + Scale Invariance

Assuming `rich-outcomes`, `shift-invariance`, `scale-invariance`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

### Antitonic Sum Invariance + Stochastic Equivalence

Assuming `antitonic-sum-consistency`, `stochastic-equivalence`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Gambles (`archimedean-gambles`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Countable Sure-Thing (`countable-sure-thing`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- Full Sum Invariance (`full-sum-consistency`)
- Mixture Independence (`independence`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Totality (`restricted-totality`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)
- Universal Copula Sum Invariance (`universal-copula-sum-consistency`)

### Archimedean Outcomes + Folded Expectation

Assuming `archimedean-outcomes`, `folded-expectation`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Mixture Independence (`independence`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Rich Outcomes (`rich-outcomes`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)

### Archimedean Outcomes + Relative Expectation

Assuming `archimedean-outcomes`, `relative-expectation`, these remain open:

- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Mixture Independence (`independence`)
- Rich Outcomes (`rich-outcomes`)
- Shift Invariance (`shift-invariance`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

### Archimedean Outcomes + Stochastic Dominance

Assuming `archimedean-outcomes`, `stochastic-dominance`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Mixture Independence (`independence`)
- Restricted Totality (`restricted-totality`)
- Rich Outcomes (`rich-outcomes`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Sure-Thing (`sure-thing`)

### Comonotonic Sum Invariance + Stochastic Equivalence

Assuming `comonotonic-sum-consistency`, `stochastic-equivalence`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Totality (`restricted-totality`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)

### Rich Outcomes + Folded Expectation

Assuming `rich-outcomes`, `folded-expectation`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Totality (`totality`)

### Mixture Independence + Transfer of a Shift Across a Mixture

Assuming `independence`, `shift-transfer`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Rich Outcomes (`rich-outcomes`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

### Stochastic Equivalence + Mixture Independence

Assuming `stochastic-equivalence`, `independence`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Restricted Totality (`restricted-totality`)
- Rich Outcomes (`rich-outcomes`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)

### Independent Sum Preservation + Independent Sum Cancellation

Assuming `independent-sum-preservation`, `independent-sum-cancellation`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

### Independent Sum Invariance + Stochastic Equivalence

Assuming `independent-sum-consistency`, `stochastic-equivalence`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Totality (`restricted-totality`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)

### Totality + Independent Sum Preservation

Assuming `totality`, `independent-sum-preservation`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

### Rich Outcomes + Negative Affine Anti-Invariance

Assuming `rich-outcomes`, `negative-affine-anti-invariance`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

## 3. Unknown verdicts inside each model

For these principles the model has not been checked either way. Deciding one is a self-contained calculation in a construction that is already written down.

### Signed-measure cone: affine-symmetric extension — `affine-symmetric-extension`

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

### Clipped expectation: continuous ultrafilter dominance [−t, 2t] — `asymmetric-continuous-ultrafilter`

- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Scale Invariance (`scale-invariance`)

### CDF-area dominance — `cdf-area-preorder`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)

### CDF-area conclosure — `cdf-conclosure-preorder`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)

### CDF-area: total comonotonic extension — `conjectured-total-comonotonic-area-extension`

Fully determined; nothing unknown.

### CDF-area conclosure: total extension — `conjectured-total-independent-sum-extension`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Scale Invariance (`scale-invariance`)

### Clipped expectation: eventual dominance — `eventual-clipped-expectation`

- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)

### Two-sample minimum: zero extension — `finite-two-sample-minimum`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Antitonic Sum Invariance (`antitonic-sum-consistency`)
- Archimedean Gambles (`archimedean-gambles`)
- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Countable Sure-Thing (`countable-sure-thing`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Full Sum Invariance (`full-sum-consistency`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Scale Invariance (`scale-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Universal Copula Sum Invariance (`universal-copula-sum-consistency`)

### Clipped expectation: continuous ultrafilter dominance [−4ⁿ, 4ⁿ] — `geometric-continuous-ultrafilter`

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Pasadena = ln 2 (`pasadena-value`)

### Folded-tail cone: lexicographic extension — `lexicographic-folded-extension`

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Pasadena = ln 2 (`pasadena-value`)

### Clipped expectation: continuous ultrafilter dominance [−4ⁿ, 4²ⁿ] — `polynomial-asymmetric-continuous-ultrafilter`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Scale Invariance (`scale-invariance`)

### Clipped expectation: continuous ultrafilter dominance — `total-continuous-ultrafilter`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Folded Expectation (`folded-expectation`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Relative Expectation (`relative-expectation`)

### Clipped expectation: exact ultrafilter dominance — `total-exact-ultrafilter`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)

## 4. Open single-premise pairs (764)

*A ⇒ B ?* means neither implication nor incompatibility nor a countermodel is currently recorded. Grouped by antecedent. Most are open only because the obvious model has not been added.

- **Alternating St Petersburg = −1/2** (`alternating-st-petersburg-value`) ⇒ Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, Folded Expectation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Antitonic Sum Invariance** (`antitonic-sum-consistency`) ⇒ Alternating St Petersburg = −1/2, Archimedean Gambles, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Countable Sure-Thing, Existential Copula Sum Invariance, Expected Utility, Folded Expectation, Full Sum Invariance, Independent Sum Cancellation, Independent Sum Invariance, Independent Sum Preservation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity, Universal Copula Sum Invariance
- **Archimedean Gambles** (`archimedean-gambles`) ⇒ Alternating St Petersburg = −1/2, Antitonic Sum Invariance, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Countable Sure-Thing, Existential Copula Sum Invariance, Expected Utility, Folded Expectation, Full Sum Invariance, Independent Sum Cancellation, Independent Sum Invariance, Independent Sum Preservation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity, Universal Copula Sum Invariance
- **Archimedean Outcomes** (`archimedean-outcomes`) ⇒ Comonotonic Sum Invariance, Existential Copula Sum Invariance, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Relative Expectation, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Arroyo = ln 2** (`arroyo-value`) ⇒ Archimedean Outcomes, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, Folded Expectation, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture
- **CDF-Area Extension** (`cdf-area-extension`) ⇒ Comonotonic Sum Invariance, Existential Copula Sum Invariance, Mixture Independence, Rich Outcomes, Shift Invariance, Sure-Thing
- **Comonotonic Sum Invariance** (`comonotonic-sum-consistency`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Existential Copula Sum Invariance, Expected Utility, Independent Sum Cancellation, Independent Sum Invariance, Independent Sum Preservation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Countable Sure-Thing** (`countable-sure-thing`) ⇒ Alternating St Petersburg = −1/2, Antitonic Sum Invariance, Archimedean Gambles, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, Folded Expectation, Full Sum Invariance, Independent Sum Cancellation, Independent Sum Invariance, Independent Sum Preservation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity, Universal Copula Sum Invariance
- **Existential Copula Sum Invariance** (`existential-copula-sum-consistency`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Expected Utility, Independent Sum Cancellation, Independent Sum Invariance, Independent Sum Preservation, L¹ Continuity (random variables), Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Expected Utility** (`expected-utility`) ⇒ CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Mixture Independence, Relative Expectation, Rich Outcomes, Shift Invariance, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Folded Expectation** (`folded-expectation`) ⇒ Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture
- **Full Sum Invariance** (`full-sum-consistency`) ⇒ Alternating St Petersburg = −1/2, Archimedean Gambles, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Countable Sure-Thing, Expected Utility, Folded Expectation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Independent Sum Cancellation** (`independent-sum-cancellation`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, Independent Sum Invariance, Independent Sum Preservation, L¹ Continuity (random variables), Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Independent Sum Invariance** (`independent-sum-consistency`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, L¹ Continuity (random variables), Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Independent Sum Preservation** (`independent-sum-preservation`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, Independent Sum Cancellation, Independent Sum Invariance, L¹ Continuity (random variables), Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **L¹ Continuity (random variables)** (`l1-continuity`) ⇒ Archimedean Outcomes, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, Mixture Independence, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Totality, Transfer of a Shift Across a Mixture
- **Mixture Independence** (`independence`) ⇒ Archimedean Outcomes, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Negative Affine Anti-Invariance** (`negative-affine-anti-invariance`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, L¹ Continuity (random variables), Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Pasadena = ln 2** (`pasadena-value`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, Folded Expectation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Positive Affine Invariance** (`positive-affine-invariance`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Reflection Anti-Invariance** (`reflection-anti-invariance`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Mixture Independence, Pasadena = ln 2, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Relative Expectation** (`relative-expectation`) ⇒ Archimedean Outcomes, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, Mixture Independence, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Restricted Stochastic Equivalence** (`restricted-stochastic-equivalence`) ⇒ Archimedean Outcomes, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Relative Expectation, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Restricted Totality** (`restricted-totality`) ⇒ Archimedean Outcomes, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Restricted Stochastic Equivalence, Rich Outcomes, Shift Invariance, Simple Relative Expectation, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Rich Outcomes** (`rich-outcomes`) ⇒ Archimedean Outcomes, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Restricted Stochastic Equivalence, Restricted Totality, Shift Invariance, Simple Relative Expectation, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Scale Invariance** (`scale-invariance`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Shift Invariance** (`shift-invariance`) ⇒ Archimedean Outcomes, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, Mixture Independence, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Simple Expected Utility** (`simple-eu`) ⇒ Comonotonic Sum Invariance, Existential Copula Sum Invariance, Mixture Independence, Rich Outcomes, Shift Invariance, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Simple Relative Expectation** (`simple-relative-expectation`) ⇒ Archimedean Outcomes, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, Mixture Independence, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Statewise Dominance** (`statewise-dominance`) ⇒ Archimedean Outcomes, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Mixture Independence, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Stochastic Dominance** (`stochastic-dominance`) ⇒ Archimedean Outcomes, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Mixture Independence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Sure-Thing, Transfer of a Shift Across a Mixture
- **Stochastic Equivalence** (`stochastic-equivalence`) ⇒ Archimedean Outcomes, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Relative Expectation, Sure-Thing, Transfer of a Shift Across a Mixture
- **Sure-Thing** (`sure-thing`) ⇒ Archimedean Outcomes, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Mixture Independence, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Transfer of a Shift Across a Mixture
- **Symmetric Gambles Are Neutral** (`symmetric-neutrality`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Totality** (`totality`) ⇒ Archimedean Outcomes, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Restricted Stochastic Equivalence, Rich Outcomes, Shift Invariance, Simple Relative Expectation, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Transfer of a Shift Across a Mixture** (`shift-transfer`) ⇒ Archimedean Outcomes, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, Mixture Independence, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Uniqueness of Negative Self-Similarity** (`negative-self-similarity`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Existential Copula Sum Invariance, Expected Utility, Folded Expectation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture
- **Universal Copula Sum Invariance** (`universal-copula-sum-consistency`) ⇒ Alternating St Petersburg = −1/2, Archimedean Gambles, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Countable Sure-Thing, Expected Utility, Folded Expectation, Full Sum Invariance, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity

## 5. Deliberately deferred

`topics/unbounded-utility/extraction.md` has a section listing claims that were **not** recorded because they need a further reading of the sources. Those are marked deferred rather than open: the answer is likely in the literature and needs transcribing, not discovering. Read that section before starting work.

## 6. How to record an answer

- Proved an implication? Add `topics/unbounded-utility/results/<id>.yaml` with the full premise list and the proof.
- Refuted one? Add `topics/unbounded-utility/models/<id>.yaml` listing what you verified in `satisfies` and `violates`.
- Not sure? Add it with `status: conjectured`, an empty proof, and say in `notes` what would settle it.
- Then run `python3 scripts/pmap.py validate` and `status`. Never hand-edit the derived counts.

`README.md` has the exact record shapes and the sourcing rules. Follow them; an unsourced or misattributed record is worse than an absent one.
